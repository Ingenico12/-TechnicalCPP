/* ---------------------------------------------------------------------------------------------- *
*                            PROGRAM HISTORY                                                     *
* ---------------------------------------------------------------------------------------------- *
* Ver.  Author(s)     Date         Description                                                   *
* ---   ---------     ----         -----------                                                   *
* V01   RS Software   07/01/2018   Need to customize EMV Parameters as per business need         *
* ---------------------------------------------------------------------------------------------- */
#ifndef CRYPTODATA_H_INCLUDED
#define CRYPTODATA_H_INCLUDED

// TODO Temp
static const unsigned char DES3_keys[24] =
{
    0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
    0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
    0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01
};


// DES context structure
typedef struct {
    unsigned long esk[32];     /*!< DES encryption subkeys */
    unsigned long dsk[32];     /*!< DES decryption subkeys */
} des_context;
// Triple-DES context structure
typedef struct {
    unsigned long esk[96];     /*!< Triple-DES encryption subkeys */
    unsigned long dsk[96];     /*!< Triple-DES decryption subkeys */
} des3_context;

extern void des_set_key( des_context *ctx, unsigned char key[8] );
extern void des_encrypt (des_context *ctx, unsigned char input[8], unsigned char output[8] );
extern void des_decrypt (des_context *ctx, unsigned char input[8], unsigned char output[8] );
extern void des_cbc_encrypt (des_context *ctx, unsigned char iv[8], unsigned char *input, unsigned char *output, int len);
extern void des_cbc_decrypt (des_context *ctx, unsigned char iv[8], unsigned char *input, unsigned char *output, int len);
extern void des3_set_2keys (des3_context *ctx, unsigned char key[16]);
extern void des3_set_3keys (des3_context *ctx, unsigned char key[24]);
extern void des3_encrypt (des3_context *ctx, unsigned char input[8], unsigned char output[8]);
extern void des3_decrypt (des3_context *ctx, unsigned char input[8], unsigned char output[8]);
extern void des3_cbc_encrypt (des3_context *ctx, unsigned char iv[8], unsigned char *input, unsigned char *output, int len);
extern void des3_cbc_decrypt (des3_context *ctx, unsigned char iv[8], unsigned char *input, unsigned char *output, int len);

#endif
