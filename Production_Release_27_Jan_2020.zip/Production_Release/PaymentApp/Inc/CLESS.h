/**
 * \file
 * \brief Main header file for the Easy Path to Contactless Sample application.
 *
 * \author  Ingenico
 *
 * \author  Ingenico has intellectual property rights relating to the technology embodied \n
 *       in this software. In particular, and without limitation, these intellectual property rights may\n
 *       include one or more patents.\n
 *       This software is distributed under licenses restricting its use, copying, distribution, and\n
 *       and decompilation. No part of this software may be reproduced in any form by any means\n
 *       without prior written authorization of Ingenico.
 */

/**
 * \mainpage Overview
 * The Easy Path to Contact'less Sample application is not a full payment application but it demonstrates
 * how to use or call the Easy Path Contact'less kernels. This version of the sample complies with Telium+.
 *
 * The main characteristics of this sample are:
 *   - Two kernels are supported:
 *      - MasterCard PayPass 3:
 *         - With mobile authentication (double tap).
 *         - With Torn recovery.
 *         - With card balance.
 *         - Without Data Exchange & Data storage.
 *      - Visa payWave 2.1.1:
 *         - With Issuer Script processing.
 *         - With mobile authentication (double tap).
 *         - Without DRL.
 *   - Application selection:
 *      - Implicit.
 *      - Explicit.
 *   - Only debit transactions are supported (no refund or credit).
 *   - Simple user interface (the UI only manages the case of an iCT250 with internal contact'less reader).
 *   - Communication with Host not implemented (no authorization, no parameters downloading, no batch processing...).
 *   - No ticket.
 *   - No PIN online.
 *   - No black list.
 *   - No language management.
 *
 * To use this sample:
 *   - In implicit mode, just enter the amount and validate.
 *   - In explicit mode, select the CLess application in F menu, then 'Explicit Trn' item.
 *   - To activate/deactivate the kernel debug traces, in the CLess application menu select the corresponding 'Debug Trace' On or Off item.
 *
 */


#ifndef CLESS_H_INCLUDED
#define CLESS_H_INCLUDED

#include "GL_GraphicLib.h"

// Generic Tool Library includes
#include "GTL_SharedExchange.h"
#include "GTL_Convert.h"
#include "GTL_Assert.h"
#include "GTL_BerTlv.h"
#include "GTL_BerTlvDecode.h"
#include "GTL_TagsInfo.h"
#include "GTL_StdTimer.h"

#include "TlvTree.h"

// Cless includes
#include "oem_cless.h"
#include "TPass.h"

// EMV Lib includes
#include "EmvLib_Tags.h"

// Entry Point includes
#include "EntryPoint_Tags.h"

// Common cless kernel includes
#include "Common_Kernels_Tags.h"
#include "Common_Kernels_API.h"
// PayPass kernel includes
#include "PayPass_Tags.h"
#include "PayPass3_API.h"
// payWave kernel includes
#include "payWave_API.h"
#include "payWave_Tags.h"
//EXPRESS kernel
#include "ExpressPay3_API.h"
#include "ExpressPay_Tags.h"
#include "_emvdctag_.h"
#include "MSGlib.h"
#include "TlvTree.h"
#include "loaderapi_def.h"
#include "GTL_Traces.h"
#include "EmvLib_Tags.h"
#include "GTL_TagsInfo.h"
#include "Discover_Tags.h"
#include "oem_public_def.h"
//DiscoverDPAS component
#include "DiscoverDPAS_Tags.h"
#include "DiscoverDPAS_API_Common.h"
#include "DiscoverDPAS_API.h"
#include "Discover_API.h"

// JCB kernel includes
#include "JCB_Tags.h"
#include "JCB_API.h"

#define NUMBER_OF_ITEMS(Array)			  (sizeof(Array)/sizeof((Array)[0]))

#define SERVICE_CUSTOM_KERNEL             0x0999   ///< Service number that payment kernels have to used to call the customization functions
#define SERVICE_DE_KERNEL                 0x0998   ///< Service number that payPass kernel use to call Data Exchange functions.

#define APCLESS_AID_PAYPASS_IDENTIFIER       0
#define APCLESS_AID_PAYWAVE_IDENTIFIER       1
#define APCLESS_AID_DISCOVER_IDENTIFIER      5
#define APCLESS_AID_DISCOVERDPAS_IDENTIFIER  4
#define APCLESS_AID_EXPRESSPAY_IDENTIFIER	 7
#define APCLESS_AID_JCB_IDENTIFIER	 		 6

#define TAG_SAMPLE_ENCIPHERED_PIN_CODE		0x9F918800		/*!< Sample parameters : Enciphered pin code for on-line verification. */
#define TAG_SAMPLE_PARAMETERS_LABEL			0x9F918801		/*!< Sample parameters : Indicates the parameter label. */
#define TAG_SAMPLE_GENERIC_MONEY_EXTENDED	0x9F918802		/*!< Sample parameters : Defines a money. nom:3car, code:3car, decimal pos:1car, centseparator:1car, thousandseparator:1car, currencyposition:0after1before. - Format : t - Length : 10 bytes - Source : Terminal. */
#define TAG_SAMPLE_DOUBLE_DIP_TIMEOUT		0x9F918803		/*!< Sample parameters : Indicates how soon the reader can accept the same card to perform the next transaction having the same amount. Time in milliseconds. (VisaWave requirement)*/
#define TAG_SAMPLE_NO_CARD_TIMEOUT			0x9F918804		/*!< Sample parameters : Timout value for card detection process. Time in milliseconds. (VisaWave and Interac requirement)*/
#define TAG_SAMPLE_ZERO_CHECK_DEACTIVATED	0x9F918805		/*!< Sample parameters : Set to true, payWave kernel doesn't realize the zero check with the Online cryptogram */
#define TAG_SAMPLE_TRANSACTION_CASHBACK		0x9F918806		/*!< Internal transaction cashback : kernel subset. */
#define TAG_SAMPLE_INTERAC_MODE				0x9F918807		/*!< Sample parameters : Specific Interac Mode to perform Interac GUI operations. (Interac requirement)*/
// Constructed tags
#define TAG_SAMPLE_AID_PARAMETERS			0xBF918800		/*!< Sample parameters : AID subset. */
#define TAG_SAMPLE_CAKEYS_PARAMETERS		0xBF918801		/*!< Sample parameters : CAKEYS subset. */
#define TAG_SAMPLE_CAREVOK_PARAMETERS		0xBF918802		/*!< Sample parameters : CAREVOK subset. */
#define TAG_SAMPLE_ICS_PARAMETERS		    0xBF918803		/*!< Sample parameters : global parameters (ICS) subset. */
#define TAG_SAMPLE_SPECIFIC_PARAMETERS		0xBF918804		/*!< Sample parameters : kernel subset. */

#define CLESS_SAMPLE_TERM_TYPE_FINANCIAL_ATT_ONLINE_ONLY		0x11	/*!< Terminal Type - Financial, Attended, Online only. */
#define CLESS_SAMPLE_TERM_TYPE_FINANCIAL_UNATT_ONLINE_ONLY		0x14	/*!< Terminal Type - Financial, Unattended, Online only. */
#define CLESS_SAMPLE_TERM_TYPE_MERCHANT_ATT_ONLINE_ONLY			0x21	/*!< Terminal Type - Merchant, Attended, Online only. */
#define CLESS_SAMPLE_TERM_TYPE_MERCHANT_UNATT_ONLINE_ONLY		0x24	/*!< Terminal Type - Merchant, Unattended, Online only. */
#define CLESS_SAMPLE_TERM_TYPE_CARDHOLDER_UNATT_ONLINE_ONLY		0x34	/*!< Terminal Type - Cardholder, Unattended, Online only. */
#define TAG_SAMPLE_EXPRESSPAY_DOUBLE_TAP_TIME	0x9F918809		/*!< Sample parameters (Specific Expresspay): To configure the period of time the contactless reader field is deactivated between the two taps of the Mobile CVM. Time in milliseconds. Range: one to three seconds (default 1.5 seconds). (Expresspay requirement). */

#define E_USER_EVENT							30								//!< User event offset.
#define USER_EVENT								1 << E_USER_EVENT				//!< User event.

// Screen definitions
//#define APCLESS_SCREEN_IDLE                              (1)         ///<
//#define APCLESS_SCREEN_PRESENT_CARD                      (2)         ///<
#define APCLESS_SCREEN_RETRY                             (3)         ///<
#define APCLESS_SCREEN_USE_CONTACT                       (4)         ///<
#define APCLESS_SCREEN_REMOVE_CARD                       (5)         ///<
#define APCLESS_SCREEN_WAIT_CARD_REMOVAL                 (6)         ///<
#define APCLESS_SCREEN_TIMEOUT_ELAPSED                   (7)         ///<
#define APCLESS_SCREEN_CANCELLED                         (8)         ///<
#define APCLESS_SCREEN_PROCESSING                        (9)         ///<
#define APCLESS_SCREEN_COLLISION                         (10)        ///<
#define APCLESS_SCREEN_ONLINE_APPROVED                   (11)        ///<
#define APCLESS_SCREEN_ONLINE_PIN_REQUIRED               (12)        ///<
#define APCLESS_SCREEN_SIGNATURE_REQUIRED                (13)        ///<
#define APCLESS_SCREEN_ERROR                             (14)        ///<
#define APCLESS_SCREEN_CARD_BLOCKED                      (15)        ///<
#define APCLESS_SCREEN_APPLICATION_BLOCKED               (16)        ///<
#define APCLESS_SCREEN_OFFLINE_APPROVED                  (17)        ///<
#define APCLESS_SCREEN_OFFLINE_DECLINED                  (18)        ///<
#define APCLESS_SCREEN_ONLINE_PROCESSING                 (19)        ///<
#define APCLESS_SCREEN_ONLINE_DECLINED                   (20)        ///<
#define APCLESS_SCREEN_PIN_CANCEL                        (21)        ///<
#define APCLESS_SCREEN_PIN_ERROR                         (22)        ///<
//#define APCLESS_SCREEN_ERASE_CUSTOMER                    (23)        ///<
//#define APCLESS_SCREEN_USER                              (24)        ///<
//#define APCLESS_SCREEN_KEYBOARD                          (25)        ///<
#define APCLESS_SCREEN_ERROR_STATUS                      (26)        ///<
//#define APCLESS_SCREEN_BATCH_ERROR                       (27)        ///<
#define APCLESS_SCREEN_REPRESENT_CARD                    (28)        ///<
#define APCLESS_SCREEN_ONLINE_UNABLE                     (29)        ///<
#define APCLESS_SCREEN_TRY_ANOTHER_CARD                  (31)        ///<
#define APCLESS_SCREEN_PHONE_INSTRUCTIONS                (32)        ///<
#define APCLESS_SCREEN_PHONE_INSTRUCTIONS_RETRY          (33)        ///<
#define CLESS_SAMPLE_JCB_SCREEN_CARD_READ_OK             (104)           /*!<  */
#define APCLESS_PAYPASS_SCREEN_SIGNATURE_REQUIRED         (63)        ///<
#define APCLESS_PAYPASS_SCREEN_OFFLINE_APPROVED_REFUND    (66)        ///<
#define APCLESS_PAYPASS_SCREEN_ERROR_REFUND               (67)        ///<
#define APCLESS_PAYPASS_SCREEN_APPROVED                   (68)        ///<
#define APCLESS_PAYPASS_SCREEN_SIGNATURE_OK               (69)        ///<
#define APCLESS_PAYPASS_SCREEN_SIGNATURE_KO               (70)        ///<
#define APCLESS_PAYPASS_SCREEN_AUTHORISING                (71)        ///<
#define APCLESS_PAYPASS_SCREEN_DECLINED                   (72)        ///<
#define APCLESS_PAYPASS_SCREEN_PHONE_INSTRUCTIONS         (73)        ///<
#define APCLESS_PAYPASS_SCREEN_WAIT_CARD_REMOVAL          (75)        ///<

#define APCLESS_SCREEN_CARD_NOT_SUPPORTED                 (131)       ///<
#define APCLESS_SCREEN_EMPTY                              (133)       ///<
#define APCLESS_SCREEN_WAIT_END_DISPLAY                   (134)       ///<  Wait the end of the display hold time (only useful for the last display before returning to the manager)
//CLESS Param
#define C_SHARED_KERNEL_BUFFER_SIZE          16384    ///< Maximum size of the shared buffer exchanged between this application and the kernels.
#define APCLESS_SCHEME_UNKNOWN         0x00     ///< Indicates current transaction is unknown.
#define APCLESS_SCHEME_PAYPASS         0x01     ///< Indicates current transaction is a PayPass transaction.
#define APCLESS_SCHEME_PAYWAVE         0x02     ///< Indicates current transaction is a payWave transaction.
#define APCLESS_SCHEME_VISAWAVE        0x03     ///< Indicates current transaction is a VisaWave transaction.
#define APCLESS_SCHEME_EXPRESSPAY      0x04     ///< Indicates current transaction is a ExpressPay transaction.
#define APCLESS_SCHEME_DISCOVER        0x05     ///< Indicates current transaction is a Discover transaction.
#define APCLESS_SCHEME_JCB         	   0x06     ///< Indicates current transaction is a JCB transaction.
#define APCLESS_SCHEME_INTERAC         0x07     ///< Indicates current transaction is a Interac transaction.
#define APCLESS_SCHEME_DISCOVER_DPAS           0x08
// Transaction type
#define APCLESS_TRANSACTION_TYPE_DEBIT       0x00     ///< Definition of debit transaction type.
#define APCLESS_TRANSACTION_TYPE_CASH        0x01     ///< Definition of cash transaction type.
#define APCLESS_TRANSACTION_TYPE_REFUND      0x20     ///< Definition of refund transaction type.
//Paypass
#define APCLESS_PAYPASS_MAX_NUMBER_OF_TORN_TXN_LOG_RECORDS            3       ///< Max number of Torn Transaction Log Records.
//PinManagement
#define  ERROR_INPUT								70		//<! Pin code input error.

//CLESS Selection method
#define APCLESS_SELECTION_UNKNOWN     0              ///< Application selection method is not defined.
#define APCLESS_SELECTION_IMPLICIT    1              ///< Application has been selected with the implicit selection method
#define APCLESS_SELECTION_EXPLICIT    2              ///< Application has been selected with the explicit selection method

//sound
#define __BEEP_VOLUME          (255)     ///< Default beep volume
#define __BEEP_OK_FREQUENCY    (1500)    ///< Beep frequency for a success tone
#define __BEEP_ERROR_FREQUENCY (750)     ///< Beep frequency for an alert tone
#define __BEEP_OK_DELAY        (50)      ///< Success tone duration
#define __BEEP_ERROR_DELAY     (20)      ///< Alert tone duration


#define WITHBEEP                    TRUE
#define WITHOUTBEEP                 FALSE


//// Types //////////////////////////////////////////////////////
//PinManagement
typedef struct {
	byte nombre; /*!< data length.*/
	byte donnees[50]; /*!< data of the buffer.*/
} BUFFER_SIZE;
// The common boolean type
typedef enum
{
	B_FALSE = FALSE,
	B_TRUE  = TRUE,
	B_NON_INIT  = 0xFF
} T_Bool;


typedef enum
{
    ZERO = T_NUM0,
    ONE = T_NUM1,
    TWO = T_NUM2,
    THREE = T_NUM3,
    FOUR = T_NUM4,
    FIVE = T_NUM5,
    SIX = T_NUM6,
    SEVEN = T_NUM7,
    EIGHT = T_NUM8,
    NINE = T_NUM9,
    T_F1 = T_SK1,
    T_F2 = T_SK2,
    T_F3 = T_SK3,
    T_F4 = T_SK4,
    CU_T_POINT = T_POINT,
    T_STAR = 0x07,
    CU_VALID = T_VAL,
	CORRECT = T_CORR,
	CANCEL = T_ANN
} T_CUTERMkey;

// Exchange with Input Pin Scheme via IAPP
typedef enum
   {
   K_VALID =   0x01,
   K_CORRECT = 0x02,
   K_CANCEL =  0x03,
   K_TIMEOUT = 0x04,
   K_HID_NUM = '*'
   } T_KSUkey;

typedef struct {
	int iCiphMode;		/*!< CLEAR_DATA_MODE, DES_CIPHERED_MODE or TDES_CIPHERED_MODE */
	int iSecretId; // Secret Area Id of the ciphering Key
	int iIdKey;    // Id of the ciphering Key
} T_CIPHERTLV;

typedef struct
{
	unsigned int uiMessageLength;
	unsigned char ucMessage[32]; // Message can be truncated depending on the device
} PIN_MESSAGE;


typedef struct
{
	unsigned long ulTimeoutBefore;
	unsigned long ulTimeoutInter;
} PIN_TXT_STRUCT;

//// Global variables ///////////////////////////////////////////
extern int APCLESS_DebugTrace;          //< Global boolean variable to activate or not the kernel traces
TLV_TREE_NODE pTreeCurrentParam; 		//Express

//// Functions //////////////////////////////////////////////////
int  					CLESS_Explicit_GetParam 			(void);
void 					CLESS_Explicit_DoTransaction 		(void);

// CLESSKernel.h
int 					CLESS_AddTransactionGenericData		(T_SHARED_DATA_STRUCT* kernelSharedData);
int 					CLESS_AddAIDRelatedData				(T_SHARED_DATA_STRUCT* selectionSharedData, T_SHARED_DATA_STRUCT* kernelSharedData, int* kernelToUse);

// CLESSParamTrn.h
void 					APCLESS_ParamTrn_Clear(void);
void 					CLESS_Txn_SetTransactionType		(unsigned char type);
unsigned char 			CLESS_Txn_GetTransactionType 		(void);
void 					CLESS_Txn_SetAmountBcd 				(unsigned char* amountBcd);
const unsigned char* CLESS_Txn_GetAmountBcd(void);
const unsigned char* CLESS_Txn_GetAmountBin(void);
void CLESS_Txn_SetCurrencyCode(unsigned char* currencyCode);
const unsigned char* CLESS_Txn_GetCurrencyCode(void);
void CLESS_Txn_SetCurrencyExponent(unsigned char currencyExponent);
const unsigned char* CLESS_Txn_GetCurrencyExponent(void);
void CLESS_Txn_SetDateTime(void);
const unsigned char* CLESS_Txn_GetDate(void);
const unsigned char* CLESS_Txn_GetTime(void);
void CLESS_Txn_SetDoubleTapInProgress(int doubleTapInProgress);
int CLESS_Txn_GetDoubleTapInProgress(void);
void CLESS_Txn_SetCurrentPaymentScheme(int scheme);
int CLESS_Txn_GetCurrentPaymentScheme(void);
void CLESS_Txn_IncrementTsc(void);
int CLESS_Txn_AddTscToSharedBuffer(T_SHARED_DATA_STRUCT* dataBuffer);
void CLESS_Txn_SetDebugTrace(int trace);
int CLESS_Txn_GetDebugTrace(void);

// CLESSSelection.h
void CLESS_Selection_SetMethod(int mode);
int CLESS_Selection_GetMethod(void);
int CLESS_Selection_GiveInfo(TLV_TREE_NODE * tlvTree, const int explicitSelection);
int CLESS_Selection_GuiCustomisation(T_SHARED_DATA_STRUCT* dataStruct);

// CLESSServicesKernel.h
int CLESS_ServicesKernel_Custom(unsigned int size, void* data);

// CLESSServicesImplicit.h
int CLESS_Implicit_ClessGiveInfo (NO_SEGMENT appliId, S_TRANSIN* paramIn, S_CLESS_GIVEINFO* paramOut);
int CLESS_Implicit_ClessDebitAid (NO_SEGMENT appliId, unsigned int size, void* data);
int CLESS_Implicit_ClessEnd (NO_SEGMENT appliId);
int CLESS_Implicit_CustomSelectionGui(unsigned int size, void* data);

// CLESSGui.h
void CLESS_GUI_Init(void);
T_GL_HGRAPHIC_LIB  CLESS_GUI_GoalHandle(void);
int CLESS_GUI_TransactionBegin(void);
void CLESS_GUI_TransactionEnd(int previous);
int CLESS_GUI_Menu( const char *title, int defaultItem, const char* Items[]);
void CLESS_GUI_Display_Error_No_TPass(void);
void CLESS_GUI_PresentCard(const char* currencyLabel, unsigned int currencyExp, const unsigned char* amountBcd, unsigned int amountLength);
void CLESS_GUI_IndicatorIdle(void);
void CLESS_GUI_IndicatorWait(void);
void CLESS_GUI_IndicatorAlert(void);
void CLESS_GUI_IndicatorNotReady(void);
void CLESS_GUI_DisplayScreen(unsigned long screenIdentifier);
void CLESS_GUI_DisplayScreenWithBalance(unsigned long screenId, const char* currencyLabel, unsigned int currencyExp, const unsigned char* amountBcd, unsigned int amountLength);

//customization
void HelperErrorSequence(int nWithBeep);

// MasterCard ==> PayPass.h
int CLESS_PayPass_PerformTransaction(T_SHARED_DATA_STRUCT* dataStruct);
int CLESS_PayPass_KernelCustomiseStep(T_SHARED_DATA_STRUCT* sharedData, const unsigned char ucCustomisationStep);


#ifdef PAYPASS_TORN
   unsigned int CLESS_PayPassTorn_GetNumberOfTornTxnLogRecords(void);
   void CLESS_PayPassTorn_CleanLog(void);
   int CLESS_PayPassTorn_IsTornTxn(T_SHARED_DATA_STRUCT* sharedDataStruct);
   int CLESS_PayPassTorn_AddRecord(T_SHARED_DATA_STRUCT* sharedDataStruct);
   int CLESS_PayPassTorn_RemoveRecord(void);
#endif

// VISA ==> PayWave.h
int CLESS_PayWave_PerformTransaction(T_SHARED_DATA_STRUCT* dataStruct);
int CLESS_PayWave_KernelCustomiseStep(T_SHARED_DATA_STRUCT* sharedData, const unsigned char ucCustomisationStep);

//JCB ==>
int ClessSample_JCB_PerformTransaction (T_SHARED_DATA_STRUCT * pKernelDataStruct);
int Cless_JCB_CustomizeStep(T_SHARED_DATA_STRUCT * pSharedData, const unsigned char ucCustomizationStep);
// American Express (AMEX) ==> ExpressPay
int CLESS_ExpressPay_PerformTransaction (T_SHARED_DATA_STRUCT* dataStruct);
void ClessSample_ExpressPay_UnsetMobileCVM (void);
void ClessSample_ExpressPay_DebugActivation (int bActivate);

// Discover ZIP
int  CLESS_Discover_PerformTransaction (T_SHARED_DATA_STRUCT * pDataStruct);
int  CLESS_Discover_CustomiseStep (T_SHARED_DATA_STRUCT * pSharedData, const unsigned char usCustomisationStep);

// Discover DPAS
int  CLESS_DiscoverDPAS_PerformTransaction (T_SHARED_DATA_STRUCT * pDataStruct);
void CLESS_DiscoverDPAS_DebugActivation (int bActivate);
int  CLESS_DiscoverDPAS_CustomiseStep (T_SHARED_DATA_STRUCT * pSharedData, const unsigned char usCustomisationStep);

#endif  //CLESS_H_INCLUDED

