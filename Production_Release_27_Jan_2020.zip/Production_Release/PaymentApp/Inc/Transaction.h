/* --------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                  *
 * --------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                *
 * ---   ---------     ----         -----------                                *
 * V01   RS Software   12/31/2017   Initial Creation                           *
 * --------------------------------------------------------------------------- */
#ifndef TRANSACTION_H
#define TRANSACTION_H

#include "LinkLayer.h"
#include <stdlib.h>
#include <string.h>
#include <GL_Types.h>

#define MAX_FEE_COUNT 3

#define MAX_RESPONSE_LENGTH 1024
#define RESPONSE_TIMEOUT 30*1000

#define CUSTOMER_COPY 0
#define MERCHANT_COPY 1
#define DUPLICATE_COPY 2

/* ---------------------------------------------------------------------------------------------- *
 * DATA STRUCTURES                                                                                *
 * ---------------------------------------------------------------------------------------------- */
typedef struct {
	unsigned char tagName [2];
	int tagNameLen;
} TAGNAME;
#define EMVTAGTBL  \
		{{"\x8A\x00", 1}, {"\x91\x00", 1}, {"\x86\x00", 1}, {"\x71\x00", 1}, \
		 {"\x72\x00", 1}, {"\x57\x00", 1}, {"\x82\x00", 1}, {"\x84\x00", 1}, \
		 {"\x95\x00", 1}, {"\x9A\x00", 1}, {"\x9C\x00", 1}, {"\x4F\x00", 1}, \
		 {"\x9B\x00", 1}, {"\x5A\x00", 1}, {"\x5F\x2A", 2}, {"\x5F\x20", 2}, \
		 {"\x9F\x02", 2}, {"\x9F\x03", 2}, {"\x9F\x09", 2}, {"\x9F\x10", 2}, \
		 {"\x9F\x1A", 2}, {"\x9F\x1E", 2}, {"\x9F\x26", 2}, {"\x9F\x27", 2}, \
		 {"\x9F\x33", 2}, {"\x9F\x34", 2}, {"\x9F\x35", 2}, {"\x9F\x36", 2}, \
		 {"\x9F\x37", 2}, {"\x9F\x41", 2}, {"\x9F\x53", 2}, {"\x9F\x6E", 2}, \
		 {"\x9F\x7C", 2}, {"\x9F\x39", 2}, {"\x9F\x40", 2}, {"\x9F\x06", 2}, \
		 {"\x9F\x21", 2}, {"\x5F\x34", 2}, {"\x5F\x36", 2}, {"\x5F\x24", 2}, \
		 {"\x5F\x30", 2}, {"\x9F\x24", 2}, {"\x9F\x4C", 2}, {"\x9F\x6B", 2}}

typedef struct sFeesApplied {
	char feeAmount 			[13];
	char feeMID 			[20];
	char feeType 			[7];
	char feeCharges			[13];
};

//Batch details

typedef struct mBatch{
	char mGrandTotal[50 +1];
	char mTotalcount [10 +1];
	char mRefundTotal[40 +1];
	//char mSalesTotal[20 +1];

}mBatch;
typedef struct mSubBatch{
	    char mMerchantName[50];
	    int mClerkid;
		char mNetAmt[20];
		char mrefundNetAmt[20];
	    char mType[20 +1];
		char mAmount[20 +1];
		char mRefundAmount[20 +1];
		char mTransactionId[20 +1];
		char subTotalCount[10 +1];
 }mSubBatch;
//Refund Transaction List Buffer
	#define	MAXIMIUM_TXN_IN_A_LIST		15


typedef struct refundTxnListBuffer {
	char txnDate 			[19+1];
	char txnAmount 			[12+1];
	char txn_ReferenceNo 	[21+1];
	char txn_CardHolderName	[30+1];
};
/* ---------------------------------------------------------------------------------------------- *
 * User Data are compromised with                                                                 *
 * 	1.	Transaction Data.                                                                         *
 * 	2. 	Card Data.                                                                                *
 * 	3.  Card holder Data.                                                                         *
 * 	4.  Terminal Data                                                                             *
 * ---------------------------------------------------------------------------------------------- */
typedef struct sFeePinPad{
	char mFeeType[5];
	char mFeeMid[12];
	char mAmount[12];
};
typedef struct sPinPadData{
	int feeCount;
	struct sFeePinPad feeData[3];
	char mTranType[10];
};
typedef struct sUserData {
	// General Data
	char mUserText 			[40];
	char errorCode			[10];
	// Transaction Data
	char mTransactionType 	[18];
		#define PURCHASE   				"PURCHASE"
		#define PREAUTH					"PREAUTH"
		#define COMPLETION				"COMPLETION"
		#define FORCESALE				"FORCESALE"
		#define BALANCE_INQUIRY			"BALANCEINQUIRY"
		#define CASH_ADVANCE			"CASH_ADVANCE"
		#define	PAYMENT					"PAYMENT"
		#define REFUND					"REFUND"
		#define PARTIAL_REVERSAL		"PARTIALREVERSAL"
		#define FULL_REVERSAL			"FULLREVERSAL"
		#define	AUTO_REVERSAL			"AUTOREVERSAL"
		#define	BATCH_SETTLE			"BATCH_SETTLE"
		#define TRAN_SUM                "TRAN_SUM"
		#define DUPLICATE_RECEIPT		"DUPLICATERECEIPT"
	char mInputAmount 		    [12];
	char mTxnReferenceID		[22];
	char mLastFourDigitCardNo   [4+1];
	char mResponseTxnType		[18];
	//  MSP Proprietary
	char feeResult			[2];
	char feeResponsecode	[10];
	char feeResponseMsg		[20];
	int  mFeeCount;
	struct sFeesApplied feeList	[3];

	int  mTransactionCount;
	struct refundTxnListBuffer txnList[15];

	//  MSP Proprietary
	//char mDepartmentName[DEPARTMENT_COUNT][DEPARTMENT_NAME_LEN];//  MSP Proprietary
	//char mClerkID[6];
	// Card Data
	char mCardType;
		#define CREDIT  				'C'
        #define DEBIT   				'D'
		#define EBT						'E'
	char mCardInputMode		[15];
		#define SWIPE       			"SWIPE"
		#define MANUALENTRY     		"MANUALENTRY"
		#define EMV			    		"EMV"
		#define EMVCONTACTLESS  		"EMVCONTACTLESS"
		#define MSRCONTACTLESS  		"MSRCONTACTLESS"
		#define FALLBACK  				"FALLBACK"
	int  mCardNumberLength;
	char mCardNumber 		[19];
	char mCardExpiryDate 	[4];
	char mSVC 				[3];
	int  mTrack1Length;
	char mTrack1			[79];
	int  mTrack2Length;
	char mTrack2 			[40];
	char mCVVByPassReason;
	char mCVV 				[6];
	int  mEMVRequestDataLength;
	unsigned char emvData	[512];
    char mEMVApp 			[16];
    char mEMVAID 			[32];
    char mEMVTVR			[10];
    char mEMVTSI 			[4];
    char mEMVARC			[2];
	char mCLESSStandard 	[10];
		#define PAYWAVE					"PayWave"
		#define PAYPASS					"PayPass"
		#define EXPRESSPAY				"ExpressPay"
		#define DPAS					"D-Pass"
	int fallBackCount;
	// Card holder data
	char mCardHolderName 	[30];
	char mCardHolderAdd		[25];
	char mCardHolderCity	[25];
	char mCardHolderState	[25];
	char mCardHolderZip		[9 +1];
	int mCHVerificationMethod;
		#define NO_AUTHENTICATION		0
		#define PAPER_SIGNATURE			1
		#define ONLINE_PIN      		2
		#define SIGN_OFF_CLR_PIN		3
		#define OFF_ENCIPHER_PIN		4
		#define SIGN_OFF_ENC_PIN		5
		#define	OFF_CLEARTEXT_PIN		6
	char mDUKPTPINBlock	[16];
	char mDUKPTKSN [20];
	// Terminal Data
	char mCardInputHighestCap;
		#define UNKNOWN					'0'		// Not Specific
		#define NO_TERMINAL				'1'		// Manual; no terminal; Voice auth/ARU only
		#define MSR_ONLY				'2'		// Magnetic stripe reader capability only
		#define BAR_CODE				'3'		// Bar code/ Payment code
		#define OCR						'4'		// Optical character reader (OCR) capability [MC, AX]
		#define ICC						'5'		// Integrated circuit card (ICC) capability
		#define KEYED_ONLY				'6'		// Key entry only capability
		#define CLESS_MSR				'A'		// PAN auto-entry via contactless magnetic stripe
		#define MSR_KEYED				'B'		// Magnetic stripe reader and key entry capability
		#define MSR_KEYED_ICC			'C'		// Magnetic stripe reader, ICC, and key entry capability
		#define MSR_ICC					'D'		// Magnetic stripe reader and ICC capability
		#define ICC_KEYED				'E'		// ICC and key entry capability
		#define MSR_KEYED_ICC_CLESS		'H'		// ICC Reader and Contactless Capability; Magnetic stripe & manual entry implied
		#define CLESS_EMV				'M'		// PAN auto-entry via Contactless chip
	char mCHAuthenticationHighestCap;
		#define NO_AUTHENTICATIN		'0'		// No electronic authentication capability (Paper Signature, No CVM)
		#define PIN_ENTRY				'1'		// PIN entry capability
		#define E_SIGNATURE				'2'		// Electronic signature analysis capability
	char mCardCaptureCap;
		#define NO_CAPTURE				'0'		// No capture capability
		#define CARD_CAPTURE			'1'		// Card capture capability
	char mOperatingEnvironment;
		#define VIRTUAL_TERMINAL		'0'		// No terminal used; Voice auth/ARU only
		#define ATTENDED_TERMINAL		'1'		// On card acceptor premises; attended terminal
		#define UNATTENDED_TERMINAL		'2'		// On card acceptor premises; unattended terminal
	char mCardholderPresenceIndicator;
		#define HOLDER_PRESENT			'0'		// Cardholder present
		#define HOLDER_NOT_PRESENT		'1'		// Cardholder not present; unspecified reason
		#define MAIL_ORDER				'2'		// Cardholder not present; mail transaction
		#define PHONE_ORDER				'3'		// Cardholder not present; phone transaction
	char mCardPresenceIndicator;
		#define CARD_NOT_PRESENT		'0'		// Card not present
		#define CARD_PRESENT			'1'		// Card present
	char mCardDataOutputCap;
		#define NONE					'0'
	char mTerminalDataOutputCap;
		#define NO_PRINT_DISPLAY		'1'		// None
		#define PRINT_ONLY				'2'		// Printing capability only
		#define DISPLAY_ONLY			'3'		// Display capability only
		#define BOTH_PRINT_DISPLAY		'4'		// Printing and display capability
	char mPINCaptureCap;						// 0 - 12
	char mTerminalID[13];
	char mMerchantID[13];
	char mGatewayAPIKey[50];
	char mSequenceNo[5];
	char mClerkID   [6];
	char mReferenceNo[20 +1];
	char mDepartmentName [24+1];
	char mMerchantAddres [24+1];
	char mMerchantCity [24 +1];
	char mMerchantState [24+1];
	char mMerchantZip  [10 +1];
	char mMerchantPhone [20 +1];
	char mDeptMID[20+1];
	char mDeptAPIKey[48+1];
	char mTxnCurrencyCode[4];
	int  mReceiptEnable;
	char mCashBackAmount 	[12];
	char mSettledAmount 	[12];
	char mTotalAmount 		[12];
	char mAuthCode			[6+1];
	char mMessageReasonCode [4];
	char mAVS				[20];
// Transaction Level 2 Data
   int  mLevel2Data;
   char mOptAmtId[2];
   char mOptAmt[12];
   char mPONumber [17];                     // MasterCard and VISA Only
   char mPurchaseIDFormat;                         // MasterCard and VISA Only
		  #define NOT_USED                  'Z'
		  #define RESERVED                  '0'
		  #define DIRECT_MARKETING   		'1'
		  #define RFU                       '2'
		  #define AUTO_RENTAL         		'3'
		  #define HOTEL               		'4'
   char mPurchaseID [24];                          // MasterCard and VISA Only
   char mLocalTaxInclFlag;                         // MasterCard and VISA Only
		  #define 		TAX_NOT_PROVIDED   			'0'
		  #define       TAX_AMOUNT                 '1'
		  #define       TAX_EXEMPT                 '2'
   char mLocalTax       [12];                      // MasterCard and VISA Only
   char mNatTaxInclFlag;                           // MasterCard and VISA Only
		  #define TAX_NOT_INCLUDED   '0'
		  #define       TAX_INCLUDED         '1'
   char mNatTax [12];                              // MasterCard and VISA Only
   char mMVATRegNum [20];                          // VISA Only
   char mCVATRegNum [13];                          // VISA Only
   char mSumCommodityCd [4];                // VISA Only
   char mDiscAmt [12];                             // VISA Only
   char mFreightAmt [12];                          // MasterCard and VISA Only
   char mDutyAmt [12];                             // MasterCard and VISA Only
   char mDestZip [10];                             // MasterCard and VISA Only
   char mShippingZip [10];                         // MasterCard and VISA Only
   char mDestCountryCode [3];               // MasterCard and VISA Only
   int  mLineItemCount[2];
   char mVATInvcRefNum [12];                // VISA Only
   char mOrderDate [6];                            // YYMMDD  .. VISA Only
   char mVATTaxAmt [12];                           // VISA Only
   char mVATTaxRate [4];                           // VISA Only  0.00
   char mAltTaxAmtID[2];
   char mAltTaxAmt[12];

   char mCostPerUnit[2];
   char mLineItemTotCnt[6];
   char mAltTaxID[2];
   char mTaxTypeApplied[2];
   char mDiscInd[2];
   char mNetGrossInd[2];
   char mExtItemAmt[12+1];
   char mDrCrInd[2];
   char mItemDiscRate[2];
   char mItemQtyExpInd[2];
   char mItemDisExpInd[2];

   // Level 2 AMEX Only
   char mSupplierRefNum [9];
   char mCHRefNum [17];
   char mShipToZip [9];
   char mSalesTaxAmt [6];
   char mchargeDesc1 [24];
   char mRequesterName[24];
   char mTotalTaxAmt[12];
   char mTaxTypeCode[3];

   // Transaction Level 3 Data
   int  mLevel3Data;
   char mProductCd [12];
   char mProductCommodityCd [12];
   char mProductDesc [13];
   char mProductQuantity [12];
   char mProductMeasurementUnit [12];       // Meter
   char mDiscountAmt [12];

   //fallback related data
   int chipErrorFlag;
   int emptyCandidateListFlag;
   //Flag for pin entry cancelled by card holder
   int pinEntryCancel;
   	   #define PIN_ENTRY_CANCELLED_BY_CARDHOLDER TRUE
};
/* ---------------------------------------------------------------------------------------------- *
 * Host Data                                                                                      *
 * ---------------------------------------------------------------------------------------------- */
typedef struct responseFeeDetails{
	char txnAmount [12+1];
	char txnAuthCode [10+1];
	char txnMid [19+1];
	char txnCardInputType[20];
	char txnResponseMsg[50];
	char txnResponseCode[10];
	char txnType [10];
};
typedef struct sHostData {
	char mResponseResult	[10];
	char mResponseText 		[64];
	char mResponseDef 		[72];
	char mResponseCode		[6+1];
	int  mResponseType;
		#define	DENIAL					0
		#define	APPROVAL				1
	char mResponseMID		[20];
	char mResponseTermID    [20];
	char mTxnType 			[18];
	char mCardNumber		[20];
	char mCardExpDate		[5];
	char mCardBrand			[10];
	char mTokenID			[22];
	char mTxnSequenceNo		[22];
	char mRRN				[12];
	char mAuthCode			[6];
	char mTxnAmount			[12];
	char mTxnCurrency		[3];
	char mSettlementAmount	[12];
	char mSettlementCurrency[3];
	char mConvenienceFee	[12];
	char mServiceFee		[12];
	char mStateFee			[12];
	struct responseFeeDetails feeDetail[MAX_FEE_COUNT]; //  MSP Proprietary
	char mTxnDateTime		[12]; 		// YYMMDDHHMMSS
	int  mEMVRespDataLength;
	unsigned char emvData	[256];
	//SETTLEMENT DATA
	char batchNetDeposit	[24];
	char batchNumber		[12];
	char batchRecordCount	[12];
	char batchCoreResponseCode  [3];
	char batchCoreResponseText	[25];
	char batchConvResponseCode  [3];
	char batchConvResponseText	[25];
};

/* ---------------------------------------------------------------------------------------------- *
 * DECLARATIONS OF FUNCTIONS                                                                      *
 * ---------------------------------------------------------------------------------------------- */
// User Data
extern char * getUserText 			();
extern void   setUserText 			(char * userText);
extern char * getTransactionType 	();
extern void   setTransactionType 	(char * transactionType);
extern void   setResponseTxnType 	(char * txnType);
extern char * getResponseTxnType 	();
extern char * getInputAmount 		();
extern void   setDepartmentName     (char *deptName);
extern int    getDepartmentName		(char *depname);
extern char * getDeptMID 			();
extern void   setDeptMID    		(char *deptMID);
extern void   setReferenceNo        (char *refid);
extern void   setClerkID            (char *clerkID);
extern void   setInputAmount 		(char * inputAmount);
extern char * getCashBackAmount		();
extern void   setCashBackAmount		(char * cashBackAmount);
extern char * getSettledAmount		();
extern void   setSettledAmount		(char * settledAmount);
extern char * getTotalAmount		();
extern void   setTotalAmount		(char * totalAmount);
extern char * getAuthCode			();
extern void   setAuthCode			(char * authCode);
extern char * getMessageReasonCode	();
extern void   setMessageReasonCode	(char * messageReasonCode);
extern char * getTransReferenceNo	();
extern char * getLastFourDigitCardNo();
extern void   setTransReferenceNo	(char * txnSequenceNo);
extern void   setLastFourDigitCardNo(char * lastFourDigitOfCardNo);
extern char   getCardType			();
extern void   setCardType			(char cardType);
extern char * getCardInputMode		();
extern void	  setCardInputMode		(char * cardInputMode);
extern int 	  getCardNumber			(char * cardNum, int * cardNumLength);
extern void   setCardNumber			(char * cardNum, int cardNumLength);
extern char * getCardExpiryDate		();
extern void   setCardExpiryDate		(char * expiryDate);
extern char * getSVC				();
extern void   setSVC				(char * svc);
extern int    getTrack2Data			(char * track2Data, int * track2DataLength);
extern void   setTrack2Data			(char * track2Data, int track2DataLength);
extern int    getTrack1Data			(char * track1Data, int * track1DataLength);
extern void   setTrack1Data			(char * track1Data, int track1DataLength);
extern char * getCVV				();
extern void   setCVV				(char * cvv);
extern void   setCVVByPassReason	(char reason);
extern char   getCVVByPassReason	();
extern char * getAVS				();
extern void   setAVS				(char * avs);
extern int    getRequestEMVData     (unsigned char * emvData, int * length);
extern void   setRequestEMVData     (unsigned char * emvData, int length);
extern char * getEMVApplicationLabel ();
extern void   setEMVApplicationLabel (char * emvApp);
extern char * getEMVApplicationIdentifier ();
extern void   setEMVApplicationIdentifier (char * emvAID);
extern char * getEMVTerminalVerificationResult ();
extern void   setEMVTerminalVerificationResult (char * emvTVR);
extern char * getEMVTransactionStatusInformation ();
extern void   setEMVTransactionStatusInformation (char * emvTSI);
extern char * getEMVAuthorizationResponseCode ();
extern void   setEMVAuthorizationResponseCode (char * emvARC);
extern char * getCLESSStandard		();
extern void   setCLESSStandard		(char * clessStd);
extern int    getFallBackCount      ();
extern void   setFallBackCount      (int count);
extern char * getCardHolderName		();
extern void   setCardHolderName	(char * cardHolderName, int cardHolderNameLength);
extern int    getCHVerificationMethod();
extern void   setCHVerificationMethod(int cvm);
extern char * getPINData			();
extern void   setPINData			(char * pinData);
extern char	  getCardInputHighestCap();
extern void	  setCardInputHighestCap(char cardInputHighestCap);
extern char	  getCHAuthenticationHighestCap();
extern void	  setCHAuthenticationHighestCap(char chAuthenticationHighestCap);
extern char	  getCardCaptureCap		();
extern void	  setCardCaptureCap		(char cardCaptureCap);
extern char	  getOperatingEnvironment();
extern void	  setOperatingEnvironment(char operatingEnvironment);
extern char	  getCardholderPresenceIndicator();
extern void	  setCardholderPresenceIndicator(char cardholderPresenceIndicator);
extern char	  getCardPresenceIndicator();
extern void	  setCardPresenceIndicator(char cardPresenceIndicator);
extern char	  getCardDataOutputCap	();
extern void	  setCardDataOutputCap	(char cardDataOutputCap);
extern char	  getTerminalDataOutputCap ();
extern void	  setTerminalDataOutputCap (char terminalDataOutputCap);
extern char	  getPINCaptureCap		();
extern void	  setPINCaptureCap		(char pinCaptureCap);
extern char*  getUserTerminalID		();
extern void	  setUserTerminalID		(char *terminalID);
extern char*  getUserMerchantID		();
extern void	  setUserMerchantID		(char *merchantID);
extern char*  getUserAPIKey			();
extern void	  setUserAPIKey			(char *apiKey);
extern char*  getUserTxnSequnceNo	();
extern void	  setUserTxnSequnceNo	(char *txnSequenceNo);
extern char*  getUserCurrencyCode	();
extern void   setUserCurrencyCode   (char *txnCurrencyCode);
extern void   setUserReceiptFlag    (int receiptMode);
extern int    getUserReceiptFlag    ();

//Level 2 fields
extern void   setLevel2Flg(int flag);
extern int    getLevel2Flg();
extern void   setPurchaseIDFormat(char format);
extern char   getPurchaseIDFormat();
extern void   setPurchaseID(char *purchaseID);
extern char * getPurchaseID();
extern void   setLocalTaxInclFlag(char flag);
extern char   getLocalTaxInclFlag();
extern void   setNatTax(char *amt);
extern char * getNatTax();
extern void   setPONumber(char *number);
extern char * getPONumber();
extern void   setMVATRegNum(char *number);
extern char * getMVATRegNum();
extern void   setCVATRegNum(char *number);
extern char * getCVATRegNum();
extern void   setSumCommodityCd(char *number);
extern char * getSumCommodityCd();
extern void   setDiscAmt(char *amt);
extern char * getDiscAmt();
extern void   setFreightAmt(char *amt);
extern char * getFreightAmt();
extern void   setDutyAmt(char *amt);
extern char * getDutyAmt();
extern void   setDestZip(char *zip);
extern char * getDestZip();
extern void   setShippingZip(char *zip);
extern char * getShippingZip();
extern void   setDestCountryCode(char *code);
extern char * getDestCountryCode();
extern void   setVATInvcRefNum(char *num);
extern char * getVATInvcRefNum();
extern void   setOrderDate(char *num);
extern char * getOrderDate();
extern void   setVATTaxAmt(char *amt);
extern char * getVATTaxAmt();
extern void   setVATTaxRate(char *amt);
extern char * getVATTaxRate();

extern void   setSupplierRefNum(char *refNumber);
extern char * getSupplierRefNum();
extern void   setCHRefNum(char *refNumber);
extern char * getCHRefNum();
extern void   setShipToZip(char *shipZip);
extern char * getShipToZip();
extern void   setSalesTaxAmt(char *amt);
extern char * getSalesTaxAmt();
extern void   setChargeDesc1(char *desc);
extern char * getChargeDesc1();

//Level 3 fields
extern void   setProductCd(char *code);
extern char * getProductCd();
extern void   setProductCommodityCd(char *code);
extern char * getProductCommodityCd();
extern void   setProductDesc(char *desc);
extern char * getProductDesc();
extern void   setProductQuantity(char *quantity);
extern char * getProductQuantity();
extern void   setProductMeasurementUnit(char *unit);
extern char * getProductMeasurementUnit();
extern void   setDiscountAmt(char *amt);
extern char * getDiscountAmt();



extern char * getErrorCode			();
extern void	  setErrorCode			(char * errorCode);
// TODO: Would be changes as per host
extern int    getProprietaryData 	(struct sFeesApplied * feelist,int *feeCount);
extern void   setProprietaryData 	(struct sFeesApplied * feelist,int feeCount);
extern void   setTxnListForRefund 	(struct refundTxnListBuffer * txnlist,int txnCount);
extern int    getTxnListForRefund 	(struct refundTxnListBuffer * txnlist,int *txnCount);

extern char * getFeeResult			();
extern char * getFeeRespMsg			();
extern char * getFeeResponseCode	();
extern void   setFeeResult 			(char *feeResult);
extern void   setFeeResponseCode 	(char *respCode);
extern void   setFeeRespMsg 		(char *rspMsg);
extern void   updateFeeDetailsWithResponse (struct responseFeeDetails *approvedFeeDetails);

// Payment_Card.c
void keyedCardEntryUI (NO_SEGMENT appliId);
void readCardData (NO_SEGMENT appliId, char * returnMessage);

//HOST DATA
extern void  setResponseResult(char *responseResult);
extern char* getResponseResult();
extern void  setResponseText(char *responseResult);
extern char* getResponseText();
extern void  setResponseDefination(char *responseDef);
extern char* getResponseDefination();
extern void  setResponseCode(char *responseCode);
extern char* getResponseCode();
extern void  setResponseType(int responseType);
extern int   getResponseType();
extern void  setResponseMID(char *respMID);
extern char* getResponseMID();
extern void  setResponseTermID(char *respTermID);
extern char* getResponseTermID();
extern void  setTxnType(char *txnType);
extern char* getTxnType();
extern void  setRespCardNumber(char *cardNumber);
extern char* getRespCardNumber();
extern void  setCardBrand(char *cardBrand);
extern char* getCardBrand();
extern void  setRespCardExpDate(char *expDate);
extern char* getRespCardExpDate();
extern void  setRespTokenID(char *txnTokenID);
extern char* getRespTokenID();
extern void  setRespTxnSequenceNo(char *txnSequenceNo);
extern char* getRespTxnSequenceNo();
extern void  setRRN(char *txnRRN);
extern char* getRRN();
extern void  setRespAuthCode(char *authCode);
extern char* getRespAuthCode();
extern void  setTxnAmount(char *txnAmount);
extern char* getTxnAmount();
extern void  setTxnCurrency(char *txnCurrency);
extern char* getTxnCurrency();
extern void  setSettlementAmount(char *settlementAmount);
extern char* getSettlementAmount();
extern void  setSettlementCurrency(char *settlementCurrency);
extern char* getSettlementCurrency();
extern void  setConvenienceFee(char *convenienceFee);
extern char* getConvenienceFee();
extern void  setServiceFee(char *serviceFee);
extern char* getServiceFee();
extern void  setStateFee(char *stateFee);
extern char* getStateFee();
extern void  setTxnDateTime(char *txnDateTime);
extern char* getTxnDateTime();
extern void  setEMVRespDataLength(int emvRespDataLength);
extern int   getEMVRespDataLength();
extern void  setEMVData(unsigned char *emvData);
extern unsigned char* getEMVData();
extern void  setChipErrorFlag(int flag);
extern int   getChipErrorFlag();
extern void  setEmptyCandidateListFlag(int flag);
extern int   getEmptyCandidateListFlag();
extern void  setPINEntryCancelbyCardholder(int flag);
extern int   getPINEntryCancelbyCardholder();
extern int houseKeeping();
extern int processOnlineTransaction ();
extern void printBatchReceipt(int batchflag);
extern void printTranSummaryReceipt(int batchflag);
#endif
