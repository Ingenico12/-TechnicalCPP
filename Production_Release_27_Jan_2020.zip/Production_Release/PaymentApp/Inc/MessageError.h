#ifndef MESSAGEERROR_H_INCLUDED
#define MESSAGEERROR_H_INCLUDED

typedef struct {
   char errorCode[10];
   char errorMsg[40];
}ERRORTABLE;

extern void displayError (char * errorCode);

#endif
