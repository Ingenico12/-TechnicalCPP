/**
* \file
* \brief This module implements main the EMV Engine services.
*
* \author Ingenico
* \author Copyright (c) 2012 Ingenico, 28-32, boulevard de Grenelle,\n
* 75015 Paris, France, All Rights Reserved.
*
* \author Ingenico has intellectual property rights relating to the technology embodied\n
* in this software. In particular, and without limitation, these intellectual property rights may\n
* include one or more patents.\n
* This software is distributed under licenses restricting its use, copying, distribution, and\n
* and decompilation. No part of this software may be reproduced in any form by any means\n
* without prior written authorisation of Ingenico.
**/

#ifndef EMV_H_INCLUDED
#define EMV_H_INCLUDED

#include "GL_GraphicLib.h"
#include "TlvTree.h"
#include "GTL_Assert.h"
#include "SEC_interface.h"
#include "GTL_Convert.h"

#include "_emvdctag_.h"
#include "def_tag.h"
#include "EmvEngineInterface.h"
#include "EngineInterface.h"
#include "EngineInterfaceLib.h"

#include "EPSTOOL_TlvTree.h"
#include "EPSTOOL_PinEntry.h"
#include "EPSTOOL_Unicode.h"

/////////////////////////////////////////////////////////////////
//// Macros & preprocessor definitions //////////////////////////
//// Types //////////////////////////////////////////////////////
//! \brief Status of the transaction.
typedef enum
{
	APEMV_TR_STATUS_UNKNOWN,				//!< Unknown status.

	APEMV_TR_STATUS_APPROVED,				//!< The transaction is approved.
	APEMV_TR_STATUS_DECLINED,				//!< The transaction is declined.

	APEMV_TR_STATUS_SERVICE_NOT_ALLOWED,	//!< The service is not allowed.
	APEMV_TR_STATUS_CANCELLED,				//!< The transaction is cancelled.

	APEMV_TR_STATUS_CARD_BLOCKED,			//!< The card is blocked.
	APEMV_TR_STATUS_CARD_REMOVED,			//!< The transaction is removed.

	APEMV_TR_STATUS_TERMINAL_ERROR,			//!< There is an error that comes from the terminal.
	APEMV_TR_STATUS_CARD_ERROR,				//!< There is an error that comes from the card.
	APEMV_TR_STATUS_CARD_NOT_SUPPORTED_EMV,	//!< There is an error that card not supported EMV.

	APEMV_TR_STATUS_END
} APEMV_ServicesEmv_TransactionStatus_e;

//! brief Structure that contains all necessary information of an AID. Used to display a menu to select an AID.
typedef struct
{
	int aidLength;							//!< The length of the AID.
	unsigned char aid[16];					//!< The AID.
	char applicationLabel[16 + 1];			//!< The Application Label.
	unsigned char issuerCodeTableIndex;		//!< The Issuer Code Table Index.
	char preferredName[16 + 1];				//!< The Application Preferred Name.
} APEMV_UI_SelectAidItem_t;

//// Static function definitions ////////////////////////////////

//// Global variables ///////////////////////////////////////////
extern T_GL_HGRAPHIC_LIB idleGraphicInstance;

//// Functions //////////////////////////////////////////////////

int emvDoTransaction		(NO_SEGMENT appliId, int doEmvAppliSelection, TLV_TREE_NODE inputTlvTree);
int emvGetTransactionData	(TLV_TREE_NODE outputTlvTree);

int emvAmountIsSet			(void);
int emvAmountSet			(unsigned long long amount, TLV_TREE_NODE outputTlvTree);

APEMV_ServicesEmv_TransactionStatus_e emvTransacStatusGet	(void);
void emvTransacStatusChange	(APEMV_ServicesEmv_TransactionStatus_e status);
void emvTransacStatusSet	(unsigned short statusCode);

void emvGetGlobalParam		(TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);

//ServiceEMV_0_AppSel.h
extern void emvGetAidList			(TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvMenuSelect			(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);

//ServiceEMV_1_FinalSelect.h
void emvStepStart			(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvDisplayMessage		(TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvGetAidData			(TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvGetAidParam			(TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvGetAidIcs			(TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvStepFinalSelection	(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvMenuChooseLanguage	(TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvStepApplicationSelection (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvMenuAccountType		(TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);

//ServiceEMV_2_Init.h
void emvStepInitiateApplicationProcessing	(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvStepReadApplicationData				(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvStepOfflineDataAuthentication		(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvStepProcessingRestrictions			(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);

//ServiceEMV_3_CVM.h
void emvStepCardholderVerificationFirst		(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvStepCardholderVerificationOther		(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);

//ServiceEMV_4_ActionAnalysis.h
void emvGetLastTransaction					(TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvStepTerminalRiskManagement			(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvStepTerminalActionAnalysis			(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvStepCardActionAnalysis				(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);

//ServiceEMV_5_OnlineProcessing.h
void emvAuthorisation						(TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvVoiceReferral						(TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvStepOnLineProcessing				(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvStepIssuerToCardScriptProcessing1	(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvStepCompletion						(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);
void emvStepIssuerToCardScriptProcessing2	(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);

//ServiceEMV_6_Stop.h
void emvStepStop							(unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);

//ServiceManager.h
int ServicesManager_IsName(NO_SEGMENT appliId, S_ETATOUT *paramOut);
int ServicesManager_GiveYourDomain(NO_SEGMENT appliId, S_INITPARAMOUT *paramOut);
int ServicesManager_GiveYourSpecificContext(NO_SEGMENT appliId, S_SPECIFIC_CONTEXT *paramOut);
int ServicesManager_GiveMoneyExtended(NO_SEGMENT appliId, S_MONEYOUT_EXTENDED *paramOut);

int ServicesManager_IsState(NO_SEGMENT appliId, S_ETATOUT *paramOut);
int ServiceManager_IsDelete(NO_SEGMENT appliId, S_DELETE *paramOut);

int APEMV_ServicesManager_GiveAid(NO_SEGMENT appliId, const S_TRANSIN *paramIn, _DEL_ *paramOut);
int APEMV_ServicesManager_IsCardEmvForYou(NO_SEGMENT appliId, const S_AID *paramIn, S_CARDOUT *paramOut);
int APEMV_ServicesManager_DebitEmv(NO_SEGMENT appliId, const S_TRANSIN *paramIn, S_TRANSOUT *paramOut);

int APEMV_ServicesManager_MoreFunction(NO_SEGMENT appliId);

//EMV_UserInterface.h
T_GL_HGRAPHIC_LIB APEMV_UI_GoalHandle(void);
void APEMV_UI_GoalDestroy(void);

void APEMV_UI_GoalOpen(void);
void APEMV_UI_GoalClose(void);

//EMV_UserInterfaceDisplay.h
int APEMV_UI_TransactionBegin(void);
void APEMV_UI_TransactionEnd(int previous);

void APEMV_UI_MessageInsertCard(void);
void APEMV_UI_MessageRemoveCard(void);
void APEMV_UI_MessagePleaseWait(void);
void APEMV_UI_MessageNoRemainingPin(void);
void APEMV_UI_MessageWrongPin(void);
void APEMV_UI_MessageCorrectPin(void);
void APEMV_UI_MessageApproved(void);
void APEMV_UI_MessageDeclined(void);
void APEMV_UI_MessageServiceNotAllowed(void);
void APEMV_UI_MessageTransactionCancelled(void);
void APEMV_UI_PINEntryCancelledbyCardholder(void);
void APEMV_UI_MessageCardBlocked(void);
void APEMV_UI_MessageCardRemoved(void);
void APEMV_UI_MessageCardError(void);
void APEMV_UI_MessageCardNotSupportedEMV(void);
void APEMV_UI_MessageTransactionError(void);

int APEMV_UI_MessageAuthorisation(void);
void APEMV_UI_RequestSignature(void);

int APEMV_UI_MenuSelectAid(int numOfAids, const APEMV_UI_SelectAidItem_t *aids);
void APEMV_UI_MenuSelectLanguage(char language[2]);
int APEMV_UI_MenuSelectAccountType(unsigned char *accountType);
int APEMV_UI_MenuForceAcceptance(void);
int APEMV_UI_AmountEntry(unsigned long *amount);

EPSTOOL_PinEntry_Status_e APEMV_UI_PinEntry(int pinType, int pinTryCounter, int *pinLength);




#endif // EMV_H_INCLUDED
