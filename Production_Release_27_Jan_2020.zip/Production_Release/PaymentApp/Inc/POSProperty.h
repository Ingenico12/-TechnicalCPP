/* --------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                  *
 * --------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                *
 * ---   ---------     ----         -----------                                *
 * V01   RS Software   12/31/2017   Initial Creation                           *
 * --------------------------------------------------------------------------- */
#ifndef __POSProperty_H

#define PINPAD_INTERNAL				true
#define PINPAD_EXTERNAL				false
#define PRINT_RECEIPT				true

#define CARD_KEYED					true
#define CARD_SWIPE					true
#define CARD_INSERT					true
#define CARD_TAP					true

#define MSR_TRACK1					false
#define MSR_TRACK2					true
#define EMV_STANDARDCHIP			false
#define EMV_QUICKCHIP				true
#define CLESS_MSR_MODE				true
#define CLESS_PAYPASS_ENABLED		true
#define CLESS_PAYWAVE_ENABLED		true
#define CLESS_EXPRESSPAY_ENABLED	true
#define CLESS_DPASS_ENABLED			true

#define CREDIT_CARD_SUPPORTED		true
#define DEBIT_CARD_SUPPORTED		true

#if (PINPAD_EXTERNAL == false)
#endif

#endif
#define __POSProperty_H
