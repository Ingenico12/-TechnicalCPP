/* --------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                  *
 * --------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                *
 * ---   ---------     ----         -----------                                *
 * V01   RS Software   12/31/2017   Initial Creation                           *
 * --------------------------------------------------------------------------- */
#ifndef UTILS_H
#define UTILS_H


#include "CLESS.h"
/* --------------------------------------------------------------------------- *
 * DATA STRUCTURES                                                             *
 * --------------------------------------------------------------------------- */
#define TMR_NBR 4
#define EPSTOOL_Convert_ULongToEmvBin			EPSTOOL_Convert_ULongToBigEndian		//!< Convert an unsigned long number into an EMV binary number.
#define EPSTOOL_Convert_UShortToEmvBin			EPSTOOL_Convert_UShortToBigEndian		//!< Convert an unsigned short number into an EMV binary number.
#define EPSTOOL_Convert_EmvBinToULong			EPSTOOL_Convert_BigEndianToULong		//!< Convert an EMV binary number into an unsigned long number.
#define EPSTOOL_Convert_EmvBinToUShort			EPSTOOL_Convert_BigEndianToUShort		//!< Convert an EMV binary number into an unsigned short number.

/* --------------------------------------------------------------------------- *
 * DECLARATIONS OF FUNCTIONS                                                             *
 * --------------------------------------------------------------------------- */
extern int  bitTest (int bit, unsigned char *bitmap);
extern int  bitOff (int bit, unsigned char *bitmap);
extern int  bitOn (int bit, unsigned char *bitmap);
extern int  hexadecimalToDecimal (char hexValString[]);
extern int  unsignedCharToInteger (unsigned char * pFieldData, int len);
extern char * unsignedCharToASCII (unsigned char * pFieldData, int len);
extern char *ulltostr(unsigned long long value, char *ptr, int base);
extern void callTerminalDisplay (char * displayText);

extern int  luhnCheck (char *cardNumber);
extern void UintToIp (doubleword uiVal,char*tcIp);
extern int  TimerStop(byte ucTimerNbr);
extern long TimerGet(byte ucTimerNbr);
extern long TimerStart(byte ucTimerNbr, long lDelay);
extern void make_date(int *d, int *m, int *y, int days);
extern void encryption(char *E_buf, int len);
extern void decryption(char *D_buf, int len);
extern doubleword IpToUint(const char *pcStr);
extern const char *parseStr(char ucToken, char *pcDst, const char *pcSrc, int iDim);

extern void EPSTOOL_Convert_ULongToBigEndian(unsigned long number, unsigned char *bigEndian);
extern void EPSTOOL_Convert_ULongToLittleEndian(unsigned long number, unsigned char *littleEndian);
extern void EPSTOOL_Convert_UShortToBigEndian(unsigned short number, unsigned char *bigEndian);
extern void EPSTOOL_Convert_UShortToLittleEndian(unsigned short number, unsigned char *littleEndian);

extern unsigned long int EPSTOOL_Convert_BigEndianToULong(const unsigned char *bigEndian);
extern unsigned long int EPSTOOL_Convert_LittleEndianToULong(const unsigned char *littleEndian);
extern unsigned short int EPSTOOL_Convert_BigEndianToUShort(const unsigned char *bigEndian);
extern unsigned short int EPSTOOL_Convert_LittleEndianToUShort(const unsigned char *littleEndian);

extern int EPSTOOL_Convert_AsciiToUl(const char* asciiString, int length, unsigned long* number);

extern void EPSTOOL_Convert_UllToDcbNumber(unsigned long long value, void *dcb, int dcbLength);

extern void APCLESS_Tools_ConvertAsciiToBcd(char* ascii, int asciiLen, unsigned char* pBcd, int iShift);
extern int APCLESS_Tools_SharedBufferRetrieveInfo (T_SHARED_DATA_STRUCT* sharedData, unsigned long tag, unsigned char ** info);
extern int APCLESS_Tools_NumberOfDaysBetweenTwoDates (Telium_Date_t *date1, Telium_Date_t *date2);

extern void acknowledgePINPad();

#endif
