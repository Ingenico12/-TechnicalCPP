/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   06/30/2018   This module implements the EMV Engine services related to the *
 * 									Final Selection.                                              *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "SEC_interface.h"
#include "GL_GraphicLib.h"
#include "TlvTree.h"
#include "GTL_Assert.h"
#include "_emvdctag_.h"
#include "def_tag.h"
#include "EngineInterface.h"
#include "EngineInterfaceLib.h"
#include "servcomm.h"

#include "EPSTOOL_TlvTree.h"
#include "EPSTOOL_PinEntry.h"
#include "EMV.h"

#include "transaction.h"
#include "emvparameter.h"
#include "MerchantData.h"
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: This function call twice                                                              *
 * 			1. just before application selection (if performed).                                  *
 * 			2. just before final selection.                                                       *
 *				Service: 	I_EMVCUST_Process_Step_TlvTree.                                       *
 *				Function: 	EMVDC_START                                                           *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree. Usually empty.                                            *
 * [out]:   outputTlvTree Output TlvTree. Usually contains the transaction data.                  *
 * ---------------------------------------------------------------------------------------------- */
void emvStepStart (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	if (*statusCode == TAG_CUST_PROCESS_COMPLETED) {
		// Get transaction data
		if (!emvGetTransactionData (outputTlvTree)) {
			*statusCode = TAG_CUST_PROCESSING_ERROR;
		}
	}
	emvTransacStatusSet (*statusCode);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called when a message must be displayed on Terminal Screen                            *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree TlvTree that contains the message to display.              *
 * [out]:   outputTlvTree Output TlvTree. Usually empty.                                          *
 * ---------------------------------------------------------------------------------------------- */
void emvDisplayMessage (TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	EPSTOOL_Data_t dataMsgId;

	(void)outputTlvTree;

	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	// Retrieve the message to display
	if (EPSTOOL_TlvTree_FindFirstData(inputTlvTree, TAG_EG_MESSAGE_CODE_NUM, &dataMsgId) != NULL) {
		if (dataMsgId.length == 1) {
			switch(dataMsgId.value[0]) {
				case 0x0b:	// MESS_INSERT_CARD
					APEMV_UI_MessageInsertCard();
					break;
				case 0x10:	// MESS_REMOVE_CARD
					APEMV_UI_MessageRemoveCard();
					break;
				case 0x0e:	// MESS_PLEASE_WAIT
					APEMV_UI_MessagePleaseWait();
					break;

				default:
					// Unknown message!
					// Does not display anything
					break;
			}
		}
	}
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Retrieves the data (terminal configuration) linked with the selected AID.             *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree that contains the selected AID.                            *
 * [out]:   outputTlvTree Output TlvTree  that must be filled with the AID Specific Data          *
 * ---------------------------------------------------------------------------------------------- */
void emvGetAidData (TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	EPSTOOL_Data_t dataAid;
	static const unsigned char treshValueForBiasedRandSel[4] = { 0x00, 0x00, 0x00, 0x00 };		// 00.00
	static const unsigned char targPercForBiasedRandSel[1] = { 20 };							// 20%
	static const unsigned char maxTargPercForBiasedRandSel[1] = { 80 };							// 80%

	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	// Get the AID
	if (EPSTOOL_TlvTree_FindFirstData(inputTlvTree, TAG_AID_PROPRIETARY, &dataAid) != NULL) {
		if ((dataAid.length >= 5) && (dataAid.length <= 16) && (dataAid.value != NULL)) {      		// Is the AID valid ?
			struct AIDdata aidData = {0};
			if (getAIDSpecificParameters (dataAid.value, &aidData)) {
				VERIFY(TlvTree_AddChild(outputTlvTree, TAG_TRESH_VALUE_FOR_BIASED_RAND_SEL, treshValueForBiasedRandSel, sizeof(treshValueForBiasedRandSel)) != NULL);
				VERIFY(TlvTree_AddChild(outputTlvTree, TAG_TARG_PERC_FOR_BIASED_RAND_SEL, targPercForBiasedRandSel, sizeof(targPercForBiasedRandSel)) != NULL);
				VERIFY(TlvTree_AddChild(outputTlvTree, TAG_MAX_TARG_PERC_FOR_BIASED_RAND_SEL, maxTargPercForBiasedRandSel, sizeof(maxTargPercForBiasedRandSel)) != NULL);

				char temp[512] = {0};
				memcpy (temp, aidData.denialTAC, sizeof(aidData.denialTAC));
				unsigned char denialTAC[5] = {0};
				asciiToHEX(temp, denialTAC);
				VERIFY(TlvTree_AddChild(outputTlvTree, TAG_TERMINAL_ACTION_CODE_DENIAL, denialTAC, sizeof(denialTAC)) != NULL);

				memset (temp, 0, sizeof(temp));
				memcpy (temp, aidData.onlineTAC, sizeof(aidData.onlineTAC));
				unsigned char onlineTAC[5] = {0};
				asciiToHEX(temp, onlineTAC);
				VERIFY(TlvTree_AddChild(outputTlvTree, TAG_TERMINAL_ACTION_CODE_ONLINE, onlineTAC, sizeof(onlineTAC)) != NULL);

				memset (temp, 0, sizeof(temp));
				memcpy (temp, aidData.defaultTAC, sizeof(aidData.defaultTAC));
				unsigned char defaultTAC[5] = {0};
				asciiToHEX(temp, defaultTAC);
				VERIFY(TlvTree_AddChild(outputTlvTree, TAG_TERMINAL_ACTION_CODE_DEFAULT, defaultTAC, sizeof(defaultTAC)) != NULL);

				memset (temp, 0, sizeof(temp));
				memcpy (temp, aidData.defaultDDOL, aidData.lengthDDOL*2);
				unsigned char defaultDDOL[252] = {0};
				asciiToHEX(temp, defaultDDOL);
				VERIFY(TlvTree_AddChild(outputTlvTree, TAG_DEFAULT_DDOL, defaultDDOL, aidData.lengthDDOL) != NULL);

				memset (temp, 0, sizeof(temp));
				memcpy (temp, aidData.defaultTDOL, aidData.lengthTDOL*2);
				unsigned char defaultTDOL[252] = {0};
				asciiToHEX(temp, defaultTDOL);
				VERIFY(TlvTree_AddChild(outputTlvTree, TAG_DEFAULT_TDOL, defaultTDOL, aidData.lengthTDOL) != NULL);

				memset (temp, 0, sizeof(temp));
				memcpy (temp, aidData.appVersion, sizeof(aidData.appVersion));
				unsigned char version[2] = {0};
				asciiToHEX(temp, version);
				VERIFY(TlvTree_AddChild(outputTlvTree, TAG_VERSION_NUMBER_TERMINAL, version, sizeof(version)) != NULL);
			}
		}
	}
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Retrieves the parameters linked with the selected AID.                              NU*
 * [Note] : It is no more used as it can be done in emvGetAidData ().                             *
 *          the functionalities as required.                                                      *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree.                                                           *
 * [out]:   outputTlvTree Output TlvTree. (that must be filled with the AID parameters.)          *
 * ---------------------------------------------------------------------------------------------- */
void emvGetAidParam (TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	// Nothing to do!
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Retrieves a specific ICS for the selected AID.                                      NU*
 * [Note] : It is no more used as it can be done in emvGetAidData ().                             *
 *          the functionalities as required.                                                      *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree.                                                           *
 * [out]:   outputTlvTree Output TlvTree. (that must be filled with ICS data)                     *
 * ---------------------------------------------------------------------------------------------- */
void emvGetAidIcs (TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	// Nothing to do!
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called just after the final select command.                                           *
 * [Note] : No additional processing. Will update the functionalities as required.                *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree.                                                           *
 * [out]:   outputTlvTree Output TlvTree.                                                         *
 * ---------------------------------------------------------------------------------------------- */
void emvStepFinalSelection (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	emvTransacStatusSet (*statusCode);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called when the cardholder must select the language to use.                         NU*
 * [Note] : No in scope. Multi-language not supported by customized application                   *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree.                                                           *
 * [out]:   outputTlvTree Output TlvTree. selected language in TAG_EG_CARDHOLDER_LANGUAGE.        *
 * ---------------------------------------------------------------------------------------------- */
void emvMenuChooseLanguage (TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	char language[2];

	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	// Select the language to use
	APEMV_UI_MenuSelectLanguage(language);
	VERIFY(TlvTree_AddChild(outputTlvTree, TAG_EG_CARDHOLDER_LANGUAGE, language, sizeof(language)) != NULL);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called after the whole application select process.                                    *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree.                                                           *
 * [out]:   outputTlvTree Output TlvTree that will be filled with miscellaneous data for processng*
 * ---------------------------------------------------------------------------------------------- */
void emvStepApplicationSelection (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	unsigned long ulAmount = 0;
	char cAmount[12] = {0};
	unsigned char ucAmount[6] = {0};

	// Tag 9F02 Authorization Amount.
	TlvTree_AddChild(outputTlvTree, TAG_AMOUNT_AUTH_NUM, 0, 6);     // Default Value in Tag 9F02
	TlvTree_AddChild(outputTlvTree, TAG_AMOUNT_AUTH_BIN, 0, 4);		// Default Value in Tag 81

	struct sFeesApplied fees [MAX_FEE_COUNT];
	int feeCount;
	getProprietaryData (fees,&feeCount);
	int n;
	for (n = 0; n < 3; n++){
		if (!memcmp (fees[n].feeType, "CORE", sizeof("CORE"))){
			char temp[20] = {0};
			strcpy (temp, fees[n].feeAmount);
			float fAmount = atoff(temp);
			int iAmount = fAmount * 100;
			memset (temp, 0 , sizeof(temp));
			sprintf (temp, "%d", iAmount);
			memcpy (&cAmount[sizeof(cAmount) - strlen(temp)], temp, strlen(temp));
			memset (cAmount, '0', sizeof(cAmount) - strlen(temp));
			Aschex(ucAmount,cAmount,12);
			TlvTree_AddChild(outputTlvTree, TAG_AMOUNT_AUTH_NUM, &ucAmount, 6);		// Tag 9F02
			EPSTOOL_Convert_AsciiToUl(cAmount, -1 , &ulAmount);
			TlvTree_AddChild(outputTlvTree, TAG_AMOUNT_AUTH_BIN, &ulAmount, 4);     // Tag 81
		}
	}

	memset (cAmount, 0, sizeof(cAmount));
	memset (ucAmount, 0, sizeof(ucAmount));
	ulAmount = 0;
	// Tag 9F03 Cashback Amount.
	memcpy (cAmount, getCashBackAmount(), sizeof(cAmount));
	if (atoll(cAmount)){
		Aschex (ucAmount,cAmount,12);
		TlvTree_AddChild(outputTlvTree, TAG_AMOUNT_OTHER_NUM, &ucAmount, 6);	// Tag 9F03
		EPSTOOL_Convert_AsciiToUl(cAmount, -1 , &ulAmount);
		TlvTree_AddChild(outputTlvTree, TAG_AMOUNT_OTHER_BIN, &ulAmount, 4);    // Tag 9F04
	} else {
		TlvTree_AddChild(outputTlvTree, TAG_AMOUNT_OTHER_NUM, 0, 6);			// Default Value in Tag 9F03
		TlvTree_AddChild(outputTlvTree, TAG_AMOUNT_OTHER_BIN, 0, 4);			// Default Value in Tag 9F04
	}

	Telium_Date_t date;
	unsigned char heure_dcb [3];
	unsigned char date_dcb [3];
	Telium_Read_date(&date);

	Aschex(&date_dcb[0],date.year,2);
	Aschex(&date_dcb[1],date.month,2);
	Aschex(&date_dcb[2],date.day,2);
	Aschex(&heure_dcb[0],date.hour,2);
	Aschex(&heure_dcb[1],date.minute,2);
	Aschex(&heure_dcb[2],date.second,2);

	TlvTree_AddChild(outputTlvTree, TAG_TRANSACTION_DATE, (unsigned char *) date_dcb, 3);      // Tag 9A
	TlvTree_AddChild(outputTlvTree, TAG_TRANSACTION_TIME, (unsigned char *) heure_dcb, 3);     // Tag 9F21

	const unsigned long cst_tag_list[] = {
			TAG_TERMINAL_TYPE,
			TAG_TERMINAL_CAPABILITIES,
			TAG_TERMINAL_COUNTRY_CODE,
			TAG_TRANSACTION_CURRENCY_CODE,
			TAG_TRANSACTION_CURRENCY_EXP,
			TAG_ADD_TERMINAL_CAPABILITIES,
			TAG_TERMINAL_FLOOR_LIMIT,
			TAG_CUST_IS_FLOOR_LIMIT_CHECKING,
			TAG_CUST_IS_RANDOM_TRANSACTION_SELECT,
			TAG_CUST_IS_VELOCITY_CHECKING,
			TAG_CUST_SUPPORTED_LANGUAGE_LIST,
			TAG_USE_PSE,
			TAG_PSE_ALGO,
			TAG_CUST_IS_CARDHOLDER_CONFIRMATION,
			TAG_CUST_IS_REVOK_SUPPORTED,
			TAG_CUST_IS_ODA_PROCESSING

	};
	EMVDataElement termParam[] = {ContactEMVParameter};
	int emvTagCount =  sizeof (cst_tag_list) / sizeof(unsigned long);
	int emvParam = sizeof (termParam) / sizeof (EMVDataElement);
	int x, y;
	for (x = 0; x < emvTagCount; x++){
		for (y = 0; y < emvParam; y++){
			if (!memcmp(&cst_tag_list[x],&termParam[y].tag, sizeof(unsigned long))){
				VERIFY(TlvTree_AddChild(outputTlvTree, termParam[y].tag, termParam[y].ptValue, termParam[y].length) != NULL);
			}
		}
	}

	// Need to be add PINPAD status if any external PINPAD is available and functioning.
	  unsigned char pinpadok=0;
	  //if (IsIPP3XX())
		  pinpadok = 0x01;
	  //else
		  //pinpadok = 0x00;

	TlvTree_AddChild(outputTlvTree, TAG_PP_OK, (unsigned char *) &pinpadok, 1);	// Tag 9F813B (if Pinpad is functioning)

	// TODO: Terminals supporting Offline cryptography should support Certificate Revocation Lists (CRLs).
	// Offline cryptography has not implemented. TAG_CUST_IS_REVOK_SUPPORTED = FALSE
	// TlvTree_AddChild(outputTlvTree, TAG_CUST_CA_REVOK_1+i, CA_revok.revoked_CA[i], CA_revok.Taglength[i]);	 // Tag 9F8425 - 9F8429 (def_tag.h)

	// TODO: PIN is not in scope. Otherwise, this indication need to be considered.
	// TlvTree_AddChild(outputTlvTree, TAG_BYPASS_PIN, (unsigned char *) &BypassPIN, 1);

	emvTransacStatusSet (*statusCode);
}

/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called when the cardholder must select the account to use.                          NU*
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree. Usually empty.                                            *
 * [out]:   outputTlvTree Output TlvTree that must contain the selected account type in           *
 *          TAG_ACCOUNT_TYPE.                                                                     *
 * ---------------------------------------------------------------------------------------------- */
void emvMenuAccountType (TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	unsigned char accountType;

	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	// Select the account type
	if (APEMV_UI_MenuSelectAccountType(&accountType)) {
		// Set tag TAG_ACCOUNT_TYPE
		VERIFY(TlvTree_AddChild(outputTlvTree, TAG_ACCOUNT_TYPE, &accountType, sizeof(accountType)) != NULL);
	}
}
