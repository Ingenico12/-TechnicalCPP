/* --------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                  *
 * --------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                *
 * ---   ---------     ----         -----------                                *
 * V01   RS Software   12/31/2017   Initial Creation                           *
 * --------------------------------------------------------------------------- */
#include "sdk_tplus.h"
#include "emvparameter.h"

void asciiToHEX (char * hexString, unsigned char * output){
	char *p;
	int cnt = strlen(hexString) / 2;
	unsigned char *result = (unsigned char *)malloc(cnt), *r;
	unsigned int c;
	for (p = hexString, r = result; *p; p += 2) {
	    if (sscanf(p, "%02X", &c) != 1) {
	        break; // Didn't parse as expected
	    }
	    *r++ = c;
	}
	memcpy (output, result, cnt);
	free (result);
}
int getCertificationAuthorityPublicKey (unsigned char  *selectedAID,
		   	   	   	   	   	   	   	    unsigned char  index,
										unsigned char  *modulus,
										unsigned int   *modLength,
										unsigned char  *exponent,
										unsigned int   *expLength) {

	// RID
	char asciiAID [32] = {0};
	char asciiRID [10 + 1] = {0};
	int lengthAID = 0;
	memcpy (&lengthAID, selectedAID, 1);
	memcpy (asciiAID, hexToASCII (selectedAID+1, lengthAID), lengthAID*2);
	memcpy (asciiRID, asciiAID, 10);
	// Index
	char asciiIndex [2 + 1] = {0};
	memcpy (asciiIndex, hexToASCII (&index, 1), 2);

	CAPKelement capk[] = {CAPKTable};
	int capkCount = sizeof (capk) / sizeof (CAPKelement);
	int n;
	for (n = 0; n < capkCount; n++){
		if (!memcmp(capk[n].aid, asciiAID, 10) && !memcmp(capk[n].index, asciiIndex, 2)) {
			unsigned char keyElement[512] = {0};
			asciiToHEX(capk[n].exponent, keyElement);
			*expLength = strlen(capk[n].exponent) / 2;
			memcpy (exponent, keyElement, *expLength);

			memset (keyElement, 0, 512);
			asciiToHEX(capk[n].modulus, keyElement);
			*modLength = strlen(capk[n].modulus) / 2;
			memcpy (modulus, keyElement, *modLength);
			return TRUE;
		}
	}
	return FALSE;
}
int getTerminalSupportedAIDList (unsigned char * aidList, int * aidListLength, int * aidCount){
	struct AIDdata aid[] = {AIDTable};
	*aidCount = sizeof(aid) / sizeof(struct AIDdata);
	*aidListLength = 0;
	unsigned char temp [18] = {0};

	int n;
	for (n = 0; n < *aidCount; n++){
		memset (temp, 0, sizeof(temp));
		int aidLength = strlen(aid[n].aid) / 2;
		memcpy (temp, &aidLength, 1);
		asciiToHEX(aid[n].aid, temp+1);
		memcpy (&aidList[*aidListLength], temp, aidLength + 1);
		*aidListLength = *aidListLength + aidLength + 1;
	}
	if (*aidListLength > 0)
		return TRUE;
	return FALSE;
}
int getAIDSpecificParameters (unsigned char *appID, struct AIDdata *aidData) {
	struct AIDdata aid[] = {AIDTable};
	int aidCount = sizeof(aid) / sizeof(struct AIDdata);
	int n;

	// AID
	char aidASCII [24+1] = {0};
	unsigned char aidLength = 0;
	memcpy (&aidLength, appID, sizeof(aidLength));
	memcpy (aidASCII, unsignedCharToASCII(appID+1, (int)aidLength), (int)aidLength*2);
	for (n = 0; n < aidCount; n++){
		if (!strncmp (aidASCII, aid[n].aid, strlen(aid[n].aid))){
			memcpy (aidData->denialTAC, aid[n].denialTAC, sizeof(aidData->denialTAC));
			memcpy (aidData->onlineTAC, aid[n].onlineTAC, sizeof(aidData->onlineTAC));
			memcpy (aidData->defaultTAC, aid[n].defaultTAC, sizeof(aidData->defaultTAC));
			aidData->lengthDDOL = aid[n].lengthDDOL;
			memcpy (aidData->defaultDDOL, aid[n].defaultDDOL, aidData->lengthDDOL);
			aidData->lengthTDOL = aid[n].lengthTDOL;
			memcpy (aidData->defaultTDOL, aid[n].defaultTDOL, aidData->lengthTDOL);
			memcpy(aidData->appVersion, aid[n].appVersion,sizeof(aid[n].appVersion));
			return TRUE;
		}
	}
	return FALSE;
}
int getCLESSAIDSpecificData (unsigned char * requestAID, int length, struct sContactlessTable * clessTable){
	char asciiAID [32] = {0};
	memcpy (asciiAID, hexToASCII (requestAID, length), length*2);

	struct sContactlessTable cless[] = {ContactlessTable};
	int aidCount = sizeof(cless) / sizeof(struct sContactlessTable);
	int n;
	for (n = 0; n < aidCount; n++){
		if (!memcmp (asciiAID, cless[n].aid, length*2)){
			clessTable->aid = cless[n].aid;
			memcpy (clessTable->currencyCode, cless[n].currencyCode, sizeof(cless[n].currencyCode));
			memcpy (clessTable->floorLimit, cless[n].floorLimit, sizeof(cless[n].floorLimit));
			memcpy (clessTable->clessTxnLimit_NODCVM, cless[n].clessTxnLimit_NODCVM, sizeof(cless[n].clessTxnLimit_NODCVM));
			memcpy (clessTable->clessTxnLimit_DCVM, cless[n].clessTxnLimit_DCVM, sizeof(cless[n].clessTxnLimit_DCVM));
			memcpy (clessTable->clessCVMLimit, cless[n].clessCVMLimit, sizeof(cless[n].clessCVMLimit));
			memcpy (clessTable->txnType, cless[n].txnType, sizeof(cless[n].txnType));
			memcpy (clessTable->denialTAC, cless[n].denialTAC, sizeof(cless[n].denialTAC));
			memcpy (clessTable->onlineTAC, cless[n].onlineTAC, sizeof(cless[n].onlineTAC));
			memcpy (clessTable->defaultTAC, cless[n].defaultTAC, sizeof(cless[n].defaultTAC));
			return 1;
		}
	}
	return 0;
}
