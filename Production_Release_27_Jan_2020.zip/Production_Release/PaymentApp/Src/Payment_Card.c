#include <sdk_tplus.h>
#include <OSL_Logger.h>
#include <GL_GraphicLib.h>

#include "_emvdctag_.h"
#include "del_lib.h"
#include "def_tag.h"
#include "servcomm.h"
#include "LinkLayer.h"
#include "serveng.h"
#include "EngineInterfaceLib.h"
#include "EngineInterface.h"
#include "GL_GraphicLib.h"
#include "sec_interface.h"
#include "GTL_Assert.h"
#include "GTL_Convert.h"
#include "EPSTOOL_TlvTree.h"
#include "EPSTOOL_PinEntry.h"
#include "EPSTOOL_Unicode.h"
#include "transaction.h"
#include "GL_Types.h"
#include "Utils.h"
#include "EMV.h"
#include "CLESS.h"
#include "emvparameter.h"

void keyedCardEntryUI (NO_SEGMENT appliId){
	ulong choice=0, result=0;
	DATE date={0};
	char *cvvMenu[5]={"Not Provided","Not legible","Not Present",0};

	if (getCardType () == DEBIT) {
		setUserText ("DEBIT CANT BE KEYED");
		setErrorCode ("ERROR:031");
		goto lblEnd;
	}
	setCardInputMode (MANUALENTRY);
	setCHVerificationMethod (PAPER_SIGNATURE);            // CVM = NO CVM
	/* Screen - Enter Card Number */
	char cardNum[20] = {'\0'};
	result=GL_Dialog_Text (APEMV_UI_GoalHandle(), "MANUAL ENTRY", "Enter Card Number",
						"/d/d/d/d /d/d/d/d /d/d/d/d /d/d/d/d /d/d/d", cardNum, sizeof(cardNum), 3*GL_TIME_MINUTE);
	if(result == GL_KEY_VALID){
		if(luhnCheck(cardNum)){
			setCardNumber (cardNum, strlen(cardNum));

			/* Screen - Enter Expire Date */
			char expDate[5]={'\0'};
			result = GL_Dialog_Text (APEMV_UI_GoalHandle(), "MANUAL ENTRY", "Enter Expire Date MMYY",
								"/d/d///d/d", expDate, sizeof(expDate), 3*GL_TIME_MINUTE);
			if(result==GL_KEY_VALID){
				int expDat = atoi(expDate);
				if((expDat/100) > 1 && (expDat/100) <= 12 && (expDat%100) <= 99){
					Telium_Read_date(&date);
					char year[2+1]={0};
					char month[2+1]={0};
					memcpy(month,expDate,2);
					memcpy(year,&expDate[2],2);
					memset(expDate,0,sizeof(expDate));
					memcpy(expDate,year,2);
					memcpy(&expDate[2],month,2);
					setCardExpiryDate (expDate);
					char currentYear[2+1]={0};
					memcpy(currentYear,date.year,2);
					if(atoi(year)==atoi(currentYear)){  //year checking
						char currentMonth[2+1]={0};
						memcpy(currentMonth,date.month,2);
						if(atoi(month)<atoi(currentMonth))	//month checking
							setErrorCode("ERROR:002");
					}
					else if (atoi(year)<atoi(currentYear))
						setErrorCode("ERROR:002");
				}
				else{
					setErrorCode("ERROR:002");
					goto lblEnd;
				}
			}
			else{
				setErrorCode("ERROR:012");
				goto lblEnd;
			}

			char cvv[5]={'\0'};
			if(cardNum[0] != '4' ){ //CVV NOT REQUIRED FOR VISA KEYED
				GL_Dialog_Text (APEMV_UI_GoalHandle(), "Card Info", "Enter CVV2/CID2/CVC2", "/d/d/d/d", cvv, sizeof(cvv), 3*GL_TIME_MINUTE);
				if(((!memcmp (cardNum, "34", 2)) || (!memcmp (cardNum, "37", 2)))){
					if ((strlen(cvv) == 4)){
						setCVV(cvv);
						setCVVByPassReason('1');//CVV2 Present
					}
				}
				else if ((strlen(cvv) == 3)){
					setCVV(cvv);
					setCVVByPassReason('1');//CVV2 Present
				}
				else if ((strlen(cvv) <= 0)){
					choice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "CVV BY-PASS REASON",(const)cvvMenu , choice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
					if(choice==GL_KEY_CANCEL){
						setErrorCode("ERROR:012");
						goto lblEnd;
					}
					else{
						if(choice == 0)
							setCVVByPassReason('0');//Not Provided
						else if(choice == 1)
							setCVVByPassReason('2');//Not legible
						else if(choice == 2)
							setCVVByPassReason('9');//Not Present
					}
				}
				else{
					setErrorCode("ERROR:003");
					goto lblEnd;
				}
			}
		}
		else{
			setErrorCode("ERROR:001");
			goto lblEnd;
		}

		/* Screen - Enter Name */
		/*char chName[24+1]={'\0'};
		result = GL_Dialog_Text (APEMV_UI_GoalHandle(), "MANUAL ENTRY", "Enter Customer Name:",
							"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", chName, sizeof(chName), 3*GL_TIME_MINUTE);
		if(result == GL_KEY_VALID ){
			if(strlen(chName)>0)
				setCardHolderName(chName,strlen(chName));
			else {
				setErrorCode("ERROR:034");
				goto lblEnd;
			}
		}
		else{
			setErrorCode("ERROR:012");
			goto lblEnd;
		}*/
		/* Screen - Enter Address */
		/*char chAddress[24+1]={'\0'};
		result = GL_Dialog_Text (APEMV_UI_GoalHandle(), "MANUAL ENTRY", "Enter Customer Address:",
							"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", chAddress, sizeof(chAddress), 3*GL_TIME_MINUTE);
		if(result == GL_KEY_VALID ){
			if(strlen(chName)>0)
				setCardHolderAddress(chAddress,strlen(chAddress));
			else {
				setErrorCode("ERROR:036");
				goto lblEnd;
			}
		}
		else{
			setErrorCode("ERROR:012");
			goto lblEnd;
		}*/

		/* Screen - Enter City */
		/*char chCity[24+1]={'\0'};
		result = GL_Dialog_Text (APEMV_UI_GoalHandle(), "MANUAL ENTRY", "Enter Customer City:",
							"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", chCity, sizeof(chCity), 3*GL_TIME_MINUTE);
		if(result == GL_KEY_VALID ){
			if(strlen(chName)>0)
				setCardHolderCity(chCity,strlen(chCity));
		}
		else{
			setErrorCode("ERROR:012");
			goto lblEnd;
		}*/
		/* Screen - Enter State */
		/*char chState[24+1]={'\0'};
		result = GL_Dialog_Text (APEMV_UI_GoalHandle(), "MANUAL ENTRY", "Enter Customer State:",
							"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", chState, sizeof(chState), 3*GL_TIME_MINUTE);
		if(result == GL_KEY_VALID ){
			if(strlen(chState)>0)
				setCardHolderState(chState,strlen(chState));
		}
		else{
			setErrorCode("ERROR:012");
			goto lblEnd;
		}*/
		/* Screen - Enter Zip */
		/*char chZip[9+1]={'\0'};
		result = GL_Dialog_Text (APEMV_UI_GoalHandle(), "MANUAL ENTRY", "Enter Customer ZIP Code:",
							"/d/d/d/d/d/d/d/d/d", chZip, sizeof(chZip), 3*GL_TIME_MINUTE);
		if(result == GL_KEY_VALID ){
			if(strlen(chZip)>0)
				setCardHolderZip(chZip,strlen(chZip));
			else {
				setErrorCode("ERROR:037");
				goto lblEnd;
			}
		}
		else{
			setErrorCode("ERROR:012");
			goto lblEnd;
		}*/


	}
	else{
		setErrorCode("ERROR:012");
		goto lblEnd;
	}

lblEnd:
	return;
}
void IsoError(int iSta, char *pcTrk) {
	switch (iSta) {
		case DEF_SEP: strcpy(pcTrk, "ERROR:005"); break;
		case DEF_PAR: strcpy(pcTrk, "ERROR:006"); break;
		case DEF_LRC: strcpy(pcTrk, "ERROR:007"); break;
		case DEF_LUH: strcpy(pcTrk, "ERROR:008"); break;
		case DEF_NUM: strcpy(pcTrk, "ERROR:009"); break;
		case NO_DATA: strcpy(pcTrk, "ERROR:010"); break;
		default:      strcpy(pcTrk, "ERROR:011"); break;
	}
}
void readCardData (NO_SEGMENT appliId, char * rMsg){
	byte ucLen=0;
    char tcTmp[128] = {'\0'};
    char *pcSrc = NULL, *pcDst = NULL;
    char tcTrk1[60] = {'\0'};
    char tcTrk2[40] = {'\0'};
	int  iRet = 0, iKey=0, iTimeout=0;
	ulong choice = 0;

	Telium_File_t *sKeyboard=NULL;
	Telium_File_t *hMag31 = NULL;
	Telium_File_t *hMag2 = NULL;
	Telium_File_t *hCam0 = NULL;
	Telium_File_t *hcless = NULL;

	sKeyboard = Telium_Fopen("KEYBOARD", "r*");					// Open Keyboard peripheral




    if (!getFallBackCount()) {
    	if (IsCless() == 1)
    		GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Swipe, Insert or Tap\n\n[CANCEL]Manual Entry", GL_ICON_INFORMATION, GL_BUTTON_VALID, 10);
    	else
    		GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Swipe, Insert or Tap\n\n[CANCEL]Manual Entry", GL_ICON_INFORMATION, GL_BUTTON_VALID, 10);
    }
    else if (getFallBackCount() >= FALLBACK_COUNT_MAX){
    	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Please Swipe...", GL_ICON_INFORMATION, GL_BUTTON_VALID, 10);
    	setCardInputMode (FALLBACK);
    }
    else
    	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Please Insert Chip...", GL_ICON_INFORMATION, GL_BUTTON_VALID, 10);


    if (IsISO1() == 1) 	hMag31 = Telium_Fopen("SWIPE31", "r*");			// Open MSR TRACK 1 peripheral
    if (IsISO2() == 1)	hMag2 =  Telium_Fopen("SWIPE2", "r*");			// Open MSR TRACK 2 peripheral
    hCam0 = Telium_Fopen("CAM0", "rw*");								// Open Smart Card peripheral


    if (IsCless() == 1) {
    	CLESS_Explicit_GetParam ();
    	hcless = Telium_Fopen("CLESS","rw*");							// Open Contactless peripheral
    }

    Telium_Reset_buf(sKeyboard, _receive_id);
    TimerStart(0, 30*1000);

    int  iSta = 0;
    do {
    	if (IsCless() == 1){
    		if(strcmp(getCardInputMode(),FALLBACK))
    			iSta = Telium_Ttestall(SWIPE31 | SWIPE2 | CAM0 | CLESS, 100);
    		else
    			iSta = Telium_Ttestall(SWIPE31 | SWIPE2, 100);
    	}
    	else
    		iSta = Telium_Ttestall(SWIPE31 | SWIPE2 | CAM0, 100);

    	if (iSta != 0)  break;

    	Telium_Ttestall(KEYBOARD,100);
    	Telium_Fread(&iKey,1,1,sKeyboard);

    	if(iKey==T_ANN){
    		strcpy(rMsg,"MANUAL");
        	Telium_Reset_buf (sKeyboard, _receive_id);
        	keyedCardEntryUI (appliId);
        	goto lblEnd;
    	}
    	Telium_Reset_buf(sKeyboard, _receive_id);
    	iTimeout = TimerGet(0);
    	if(iTimeout<=0) {
    		strcpy(rMsg,"ERROR:013");
    		setErrorCode(rMsg);
    		Telium_Reset_buf(sKeyboard, _receive_id);
    		goto lblEnd;
    	}
    } while(1);

    if (IsCless() == 1) {
    	iSta |= Telium_Ttestall(iSta ^ (SWIPE31 | SWIPE2 | CAM0 | CLESS), 10);
    	iSta |= Telium_Ttestall(iSta ^ (SWIPE31 | SWIPE2 | CAM0 | CLESS), 10);
    }
    else {
    	iSta |= Telium_Ttestall(iSta ^ (SWIPE31 | SWIPE2 | CAM0), 10);
    	iSta |= Telium_Ttestall(iSta ^ (SWIPE31 | SWIPE2 | CAM0), 10);
    }

    // Swipe/Track 1 Detected
	if (iSta & SWIPE31) {
		memset(tcTmp, 0, sizeof(tcTmp));
	    memset(tcTrk1, 0, sizeof(tcTrk1));
		iRet = Telium_Is_iso1(hMag31, &ucLen, (byte*)tcTmp); // *** Read ISO1 to ascii format ***
		if (iRet != ISO_OK) {
			IsoError (iRet, tcTrk1);
		}
		else {
			pcSrc = tcTmp;
			pcDst = tcTrk1;
			while(*pcSrc) {                                  // Find start sentinel
				if(*pcSrc++ == '%')
					break;
			}
			while(*pcSrc) {                                  // Copy all data between start and end sentinels
				if(*pcSrc == '?')
					break;
				*pcDst++ = *pcSrc++;
			}
		}
		if (!strstr(tcTrk1, "ERROR")) {
			char custName[24 +1] = {0};
			setTrack1Data (tcTrk1, strlen(tcTrk1));
			if (strtok(tcTrk1,"^")) {
				char *token = strtok(NULL,"/^");
				if(strlen(token)){
					strcpy(custName, token);
					token = strtok(NULL,"/^");{
						if(strlen(token)){
							strcat(custName, " ");
							strcat(custName, token);
						}
					}
				}
				setCardHolderName (custName, strlen(custName));
			}
		}
	}
	// Swipe/Track 2 Detected
	if(iSta & SWIPE2) {
		memset(tcTmp, 0, sizeof(tcTmp));
	    memset(tcTrk2, 0, sizeof(tcTrk2));
		iRet = Telium_Is_iso2(hMag2, &ucLen, (byte*)tcTmp);  // *** Read ISO2 to ASCII format ***
		if (iRet != ISO_OK) {
			IsoError (iRet, tcTrk2);
		    strcpy (rMsg, tcTrk2);
		    setErrorCode(rMsg);
		}
		else {
			pcSrc = tcTmp;
			pcDst = tcTrk2;
			while(*pcSrc) {                                  // Find start sentinel
				if(*pcSrc++ == 'B'){
					*pcDst++ = ';';
					break;
				}
			}
			while(*pcSrc) {                                  // Copy all data between start and end sentinels
				if(*pcSrc == 'F'){
					*pcDst = '?';
					break;
				}
				if(*pcSrc == 'D')
					*pcSrc = '=';
				*pcDst++ = *pcSrc++;
			}
		}
		setTrack2Data (tcTrk2, strlen(tcTrk2));

        char * token = strtok(&tcTrk2[1],"=");
        setCardNumber (token, strlen(token));

        token = strtok(NULL,"'\0'");
        char cardExpiryDate [4] = {0};
        memcpy (cardExpiryDate, token, sizeof(cardExpiryDate));
        setCardExpiryDate (cardExpiryDate);

        char svc [3] = {0};
        memcpy (svc, token + sizeof (cardExpiryDate), sizeof (svc));
        setSVC (svc);
        if (svc[0] == '2' || svc[0] == '6') {
        	int fallBackCount = getFallBackCount();
        	if (fallBackCount < FALLBACK_COUNT_MAX) {
        		setFallBackCount(fallBackCount + 1);
        	    if(hMag2)  Telium_Fclose(hMag2);
        		if(hMag31) Telium_Fclose(hMag31);
    			if(sKeyboard) Telium_Fclose(sKeyboard);
    			sKeyboard = NULL;
        		readCardData (appliId, rMsg);
        		return;
        	}
        	else {
        		setCHVerificationMethod (getCardType() == CREDIT	? PAPER_SIGNATURE 	:
        								(getCardType() == DEBIT  	? ONLINE_PIN 		:
        										 	 	 	 	 	  NO_AUTHENTICATION));
        	}
        }
        else {
    		setCardInputMode (SWIPE);
    		setCHVerificationMethod (getCardType() == CREDIT	? PAPER_SIGNATURE 	:
    								(getCardType() == DEBIT  	? ONLINE_PIN 		:
    										 	 	 	 	 	  NO_AUTHENTICATION));
        }
	}
	// Card Insert detected
	if(iSta & CAM0) {
		if (hCam0 != NULL) {
			Telium_Fclose(hCam0);
			hCam0 = NULL;
		}
		int doTransaction = TRUE;
		TLV_TREE_NODE inputTlvTree = TlvTree_New(0);
		if (inputTlvTree != NULL) {
			// By default, a standard transaction
			unsigned char buffer[4] = {0};
			buffer[0] = TYPE_GOODS_SERVICES;
			if (TlvTree_AddChild (inputTlvTree, TAG_INT_TRANSACTION_TYPE, buffer, 1) == NULL) {
				doTransaction = FALSE;
			}

			// Debit
			if (strcmp(getTransactionType(), REFUND)){
				buffer[0] = 0x00;
				if (TlvTree_AddChild (inputTlvTree, TAG_TRANSACTION_TYPE, buffer, 1) == NULL) {
					doTransaction = FALSE;
				}
			}
			// Credit
			else {
				buffer[0] = 0x20;
				if (TlvTree_AddChild (inputTlvTree, TAG_TRANSACTION_TYPE, buffer, 1) == NULL) {
					doTransaction = FALSE;
				}
			}
			if (doTransaction) {
				setCardInputMode (EMV);
				int previousUiState = APEMV_UI_TransactionBegin();
				emvDoTransaction (appliId, TRUE, inputTlvTree);
				APEMV_UI_TransactionEnd(previousUiState);
			}
		}
		EPSTOOL_TlvTree_Release(&inputTlvTree);
		// If Fallback
		if (getFallBackCount() == FALLBACK_COUNT_MAX){
		    if (hMag2 != NULL)  Telium_Fclose(hMag2);
			if (hMag31 != NULL)	Telium_Fclose(hMag31);
			if (hCam0 != NULL)	Telium_Fclose(hCam0);
			if(sKeyboard) Telium_Fclose(sKeyboard);
			sKeyboard = NULL;
			readCardData (appliId, rMsg);
    		return;
		}
	}
	// Card Tap detected
	if(iSta & CLESS) {
		if(hcless != NULL) {
			Telium_Fclose(hcless);
			hcless=NULL;
		}
		CLESS_Explicit_DoTransaction ();
	}
	// PIN Entry
	int pinLength;
	if (getCHVerificationMethod() == ONLINE_PIN ){
		if((!strcmp(getCardInputMode(),SWIPE))||
			(!strcmp(getCardInputMode(),FALLBACK))){
			switch (APEMV_UI_PinEntry (INPUT_PIN_ON, 3, &pinLength)) {
			case EPSTOOL_PINENTRY_SUCCESS:
				if (encryptPIN() == FALSE)
					setErrorCode("ERROR:033");
				break;
			case EPSTOOL_PINENTRY_TIMEOUT:
				setErrorCode("ERROR:013");
				break;
			case EPSTOOL_PINENTRY_ERROR:
			case EPSTOOL_PINENTRY_CANCEL:
				setErrorCode("ERROR:044");
				break;
			case EPSTOOL_PINENTRY_EVENT:
			case EPSTOOL_PINENTRY_BYPASS:
			default:
				break;
			}
		}
	}

lblEnd:
	TimerStop(0);
    if(hMag2 	!= NULL)  	Telium_Fclose(hMag2);
	if(hMag31 	!= NULL)	Telium_Fclose(hMag31);
	if(hCam0 	!= NULL)	Telium_Fclose(hCam0);
    if(hcless 	!= NULL)	Telium_Fclose(hcless);
    if(sKeyboard!= NULL)	Telium_Fclose(sKeyboard);
	return;
}
