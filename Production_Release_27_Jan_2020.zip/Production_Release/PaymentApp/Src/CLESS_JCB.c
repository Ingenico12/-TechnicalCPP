/**
* \author ------------------------------------------------------------------------------\n
* \author INGENICO Technical Software Department\n
* \author ------------------------------------------------------------------------------\n
* \author Copyright (c) 2014 INGENICO.\n
* \author 28-32 boulevard de Grenelle 75015 Paris, France.\n
* \author All rights reserved.\n
* \author This source program is the property of the INGENICO Company mentioned above\n
* \author and may not be copied in any form or by any means, whether in part or in whole,\n
* \author except under license expressly granted by such INGENICO company.\n
* \author All copies of this source program, whether in part or in whole, and\n
* \author whether modified or not, must display this and all other\n
* \author embedded copyright and ownership notices in full.\n
**/


/////////////////////////////////////////////////////////////////
//// Includes ///////////////////////////////////////////////////

#include "sdk.h"
#include "CLESS.h"
#include "sec_interface.h"
#include "EPSTOOL_PinEntry.h"
#include "transaction.h"

#define CLESS_JCB_END_APPLI                          1
#define CLESS_JCB_END_APPLI_RESTART_COMM_ERROR       2
#define CLESS_JCB_END_APPLI_RESTART_ON_DEVICE_CVM    3

#define WITHBEEP                    TRUE
#define WITHOUTBEEP                 FALSE

#define C_TIME_1S                   100

#define C_CLESS_VOID_PAN_SEQ_NUMBER     0xff

static unsigned long gs_ulAllLedsOnRemoveCardTime;
t_topstack * g_tsRemoveCard_task_handle;                        // Handle of the Remove Card task.
static int g_RemoveCardTaskRunning = FALSE;                     // Indicates if the Remove Card task is still running or if it is waiting to be killed.

static int  gs_bManageUirdStatus = FALSE;
int removecard=0;

/*---------- Static functions definition -----------*/
static T_Bool Cless_JCB_OnlinePinManagement (T_SHARED_DATA_STRUCT * pStructureForOnlineData, int nCardHolderLang);
static int  CLESS_JCB_AddJCBSpecificData(T_SHARED_DATA_STRUCT* dataStruct);
static int  Cless_JCB_RetrieveTransactionOutcome(T_SHARED_DATA_STRUCT * pResultDataStruct, int * pTransactionOutcome);
static int  Cless_JCB_RetrieveFieldOffValue(T_SHARED_DATA_STRUCT * pResultDataStruct, unsigned char * pFieldOff);
static int  Cless_JCB_RetrieveStart(T_SHARED_DATA_STRUCT * pResultDataStruct, int * pStart);
static int  Cless_JCB_RetrieveUirdMessageOnOutcome(T_SHARED_DATA_STRUCT * pResultDataStruct, int * pUirdMessage, int * pUirdStatus);
static int  Cless_JCB_RetrieveUirdMessageOnRestart (T_SHARED_DATA_STRUCT * pResultDataStruct, int * pUirdMessage, int * pUirdStatus);
static int  Cless_JCB_RetrieveCardType (T_SHARED_DATA_STRUCT * pResultDataStruct, unsigned short * pCardType);
static int  Cless_JCB_RetrieveCvmToApply (T_SHARED_DATA_STRUCT * pResultDataStruct, unsigned char * pCvm);

static void Cless_JCB_DisplayUirdMsg(T_SHARED_DATA_STRUCT * pDataStruct, const int bPhoneMessage, bool bOnOutcomeMessage, bool bSuppressBeep);
static void Cless_JCB_HandleBeepAndLeds(T_SHARED_DATA_STRUCT * pDataStruct, bool bOnOutcomeMessage);
static void Cless_JCB_AddRecordToBatch(T_SHARED_DATA_STRUCT * pSharedData, unsigned short usCardType);

int Cless_JCB_EndTransaction(T_SHARED_DATA_STRUCT * pKernelDataStruct);
int Cless_JCB_ManageDeclined(T_SHARED_DATA_STRUCT * pKernelDataStruct);
int Cless_JCB_ManageSelectNext(T_SHARED_DATA_STRUCT * pKernelDataStruct);
int Cless_JCB_ManageEndApplication(T_SHARED_DATA_STRUCT * pKernelDataStruct);
int Cless_JCB_ManageApprovedOutcome(T_SHARED_DATA_STRUCT * pKernelDataStruct);
int Cless_JCB_ManageTryAnotherInterface(T_SHARED_DATA_STRUCT * pKernelDataStruct);
int Cless_JCB_ManageUnknownOutcome(T_SHARED_DATA_STRUCT * pKernelDataStruct, int nTransactionOutcome);
int Cless_JCB_IsUirdStatusManaged (void);

int JCB_OnlineRequestData(T_SHARED_DATA_STRUCT* dataStruct, unsigned short cardType);
int Cless_JCB_CustomizeStep(T_SHARED_DATA_STRUCT * pSharedData, const unsigned char ucCustomisationStep);
//! \brief Launch the scanning task.
//! \return
//! - \a TRUE if task correctly launch
//! - \a FALSE else.
int  ClessSample_Scan_LaunchScanningTask(void);
static word __ClessSample_Scan_StartScanningTask (void);
static void __ClessSample_Scan_InitScanningVariables (void);

/**
 * function:    __ClessSample_Scan_InitScanningVariables
 * @brief: Initialise scanning global variables
 * @param   void
 * @return  void
 */
/*static void __ClessSample_Scan_InitScanningVariables (void)
{
    g_wCurrentTask = 0xFF; // Init the custom application task number
    g_ScanningTask = 0xFF; // Init the scanning task number
    g_tsScanning_task_handle = NULL; // init the scanning task handle
    g_bScanning_task_to_be_killed = FALSE; // Task has not to be killed
    g_ScanningTaskRunning = FALSE; //Task is not running
}*/

//int ClessSample_Scan_LaunchScanningTask (void){
//	// Init global variables
//	__ClessSample_Scan_InitScanningVariables();
//
//	// Get the main task id
//	g_wCurrentTask = Telium_CurrentTask();
//	// Launch the scanning task
//	g_tsScanning_task_handle = Telium_Fork (&__ClessSample_Scan_StartScanningTask, NULL, -1);
//}

//! \brief Wait the end of the Remove Card task.
void UIH_RemoveCardTask_WaitEnd (void)
{
    if (g_tsRemoveCard_task_handle != NULL) // If the task is launched
    {
        while (g_RemoveCardTaskRunning) // While the task has not terminated processing
        {
            // Waits a little
            Telium_Ttestall (0, 1);
        }
        g_tsRemoveCard_task_handle = NULL;
    }
}

//! \brief Wait allowing user to see srceen message.
//! \return nothing.
void Helper_WaitUserDisplay(void)
{
    // To see message before the iddle message
    Telium_Ttestall(0, 2* C_TIME_1S);
}
//! \brief Tell if the UIRD transaction status must be managed or not.
//! \return
//!     - TRUE if transaction status is managed
//!     - FALSE else.
int Cless_JCB_IsUirdStatusManaged (void)
{
    return (gs_bManageUirdStatus);
}

//! \brief Handle the beep and LEDs
//! \param[in] pDataStruct Shared buffer containing the UIRD, containing itself the message to be displayed.
//! \param[in] bOnOutcomeMessage \a TRUE if this is a message to display on outcome, \a FALSE if this is a message to display on restart.
static void Cless_JCB_HandleBeepAndLeds(T_SHARED_DATA_STRUCT * pDataStruct, bool bOnOutcomeMessage){

    int             nUirdMessage, nUirdStatus;
    unsigned long   ulBeforeDeselectDisplayTime = 0;
    int             nTimeout;

    // Get the UIRD message to be displayed
    if (bOnOutcomeMessage)
        Cless_JCB_RetrieveUirdMessageOnOutcome(pDataStruct, &nUirdMessage, &nUirdStatus);
    else
        Cless_JCB_RetrieveUirdMessageOnRestart(pDataStruct, &nUirdMessage, &nUirdStatus);

    if (Cless_JCB_IsUirdStatusManaged())
    {
        switch (nUirdStatus)
        {
            case JCB_UIRD_STATUS_NOT_READY:
                // switch off LEDs
                // Audio Indication: None
                TPass_LedsOff(TPASS_LED_1 | TPASS_LED_2 | TPASS_LED_3 | TPASS_LED_4);
                break;
            case JCB_UIRD_STATUS_IDLE:
                // LED 1 is blinking
                // Audio Indication: None
                // Make the first Led blinking 200ms every 5 seconds
                TPass_LedsBlink(TPASS_LED_1, 10, 240);
                break;
            case JCB_UIRD_STATUS_READY_TO_READ:
                // switch on LED 1,
                // Audio Indication: None
                TPass_LedsOn(TPASS_LED_1);
                break;
            case JCB_UIRD_STATUS_PROCESSING:
                // Not applicable for this option
                break;
            case JCB_UIRD_STATUS_CARD_READ_SUCCESSFULLY:
                // the first LED is already on.
                // the following sequence has been optimized in order to satisfy performance requirements
                // Audio Indication: Success Tone
                // T0: start buzzer, LED 2 on
                ulBeforeDeselectDisplayTime = GTL_StdTimer_GetCurrent();
                TPass_Buzzer(__BEEP_OK_FREQUENCY, (unsigned char)__BEEP_VOLUME);
                TPass_LedsOn(TPASS_LED_1 | TPASS_LED_2);
                // Wait before turning on third LED
                nTimeout = GTL_StdTimer_GetRemaining(ulBeforeDeselectDisplayTime, 13);
                if (nTimeout > 0)
                    Telium_Ttestall(0, nTimeout);
                // T0 + 125 ms: LED 3 on
                TPass_LedsOn (TPASS_LED_1 | TPASS_LED_2 | TPASS_LED_3);
                // Wait before turning on fourth LED
                nTimeout = GTL_StdTimer_GetRemaining(ulBeforeDeselectDisplayTime, 25);
                if (nTimeout > 0)
                    Telium_Ttestall(0, nTimeout);
                // T0 + 250 ms: LED 4 on
                TPass_LedsOn (TPASS_LED_1 | TPASS_LED_2 | TPASS_LED_3 | TPASS_LED_4);
                // Wait before stopping the buzzer
                nTimeout = GTL_StdTimer_GetRemaining(ulBeforeDeselectDisplayTime, __BEEP_OK_DELAY);
                if (nTimeout > 0)
                {
                    Telium_Ttestall(0, nTimeout);
                    nTimeout = 0;
                }
                // T0 + 500 ms: stop buzzer
                TPass_Buzzer (0, 0);
                // Wait before switching off all the LEDs
                nTimeout = GTL_StdTimer_GetRemaining(ulBeforeDeselectDisplayTime, 100);
                if (nTimeout > 0)
                {
                    Telium_Ttestall(0, nTimeout);
                    nTimeout = 0;
                }
                // T0 + 1000 ms: all LEDs off
                TPass_LedsOff(TPASS_LED_1 | TPASS_LED_2 | TPASS_LED_3 | TPASS_LED_4);
                break;
            case JCB_UIRD_STATUS_PROCESSING_ERROR:
                // switch off all LEDs
                // Audio Indication: Optional Alert Tone
                TPass_LedsOff(TPASS_LED_1 | TPASS_LED_2 | TPASS_LED_3 | TPASS_LED_4);
                TPass_BuzzerBeep(__BEEP_ERROR_FREQUENCY, (unsigned char)__BEEP_VOLUME, __BEEP_ERROR_DELAY);
                Telium_Ttestall (0, __BEEP_ERROR_DELAY);
                TPass_BuzzerBeep(__BEEP_ERROR_FREQUENCY, (unsigned char)__BEEP_VOLUME, __BEEP_ERROR_DELAY);
                break;
            case JCB_UIRD_STATUS_NA:
            default:
                break;
        }
    }

}

//! \brief Display a specific message according to the UIRD.
//! \param[in] pDataStruct Shared buffer containing the UIRD, containing itself the message to be displayed.
//! \param[in] bPhoneMessage \a TRUE if function called when displaying phone message, \a FALSE else.
//! \param[in] bOnOutcomeMessage \a TRUE if this is a message to display on outcome, \a FALSE if this is a message to display on restart.
//! \param[in] bSuppressBeep \a TRUE to suppress Beep and LEDS, \a FALSE Sound beep and update LEDs.
static void Cless_JCB_DisplayUirdMsg(T_SHARED_DATA_STRUCT * pDataStruct, const int bPhoneMessage, bool bOnOutcomeMessage, bool bSuppressBeep){
	int             nUirdMessage, nUirdStatus;

	if (bPhoneMessage)
	{
		UIH_RemoveCardTask_WaitEnd();
		HelperErrorSequence(WITHBEEP);
	}

	// Sound beep and display LEDs
	if (!bSuppressBeep)
		Cless_JCB_HandleBeepAndLeds(pDataStruct, bOnOutcomeMessage);

	// Get the UIRD message to be displayed
	if (bOnOutcomeMessage)
		Cless_JCB_RetrieveUirdMessageOnOutcome (pDataStruct, &nUirdMessage, &nUirdStatus);
	else
		Cless_JCB_RetrieveUirdMessageOnRestart(pDataStruct, &nUirdMessage, &nUirdStatus);

	switch (nUirdMessage)
	{
			case JCB_UIRD_MESSAGE_ID_PROCESSING:
				CLESS_GUI_DisplayScreen(APCLESS_SCREEN_PROCESSING);
				CLESS_GUI_DisplayScreen(APCLESS_PAYPASS_SCREEN_WAIT_CARD_REMOVAL);
				break;
			case JCB_UIRD_MESSAGE_ID_CARD_READ_OK:
				CLESS_GUI_DisplayScreen (CLESS_SAMPLE_JCB_SCREEN_CARD_READ_OK);
				break;
			case JCB_UIRD_MESSAGE_ID_TRY_AGAIN:
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_REPRESENT_CARD);
				break;
			case JCB_UIRD_MESSAGE_ID_APPROVED:
				CLESS_GUI_DisplayScreen (APCLESS_PAYPASS_SCREEN_APPROVED);
				break;
			case JCB_UIRD_MESSAGE_ID_APPROVED_SIGN:
				CLESS_GUI_DisplayScreen (APCLESS_PAYPASS_SCREEN_SIGNATURE_OK);
				break;
			case JCB_UIRD_MESSAGE_ID_DECLINED:
				CLESS_GUI_DisplayScreen (APCLESS_PAYPASS_SCREEN_DECLINED);
				break;
			case JCB_UIRD_MESSAGE_ID_ERROR_OTHER_CARD:
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ERROR);
				break;
			case JCB_UIRD_MESSAGE_ID_SEE_PHONE:
				// Request cardholder to follow his phone for instructions
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_PHONE_INSTRUCTIONS);
				if (bPhoneMessage)
				{
					// Indicate double tap is in progress
					 CLESS_Txn_SetDoubleTapInProgress(TRUE);
				}
				break;
			case JCB_UIRD_MESSAGE_ID_AUTHORIZING_PLEASE_WAIT:
				CLESS_GUI_DisplayScreen (APCLESS_PAYPASS_SCREEN_AUTHORISING);
				break;
			case JCB_UIRD_MESSAGE_ID_INSERT_CARD:
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_USE_CONTACT);
				break;
			case JCB_UIRD_MESSAGE_ID_CLEAR_DISPLAY:
				 CLESS_GUI_DisplayScreen(APCLESS_SCREEN_EMPTY);
				break;
			default:
				break;
	}

	 Telium_Ttestall(0,15);
}

//! \brief Perform the Online PIN input and encipher PIN.
//! \param[out] pStructureForOnlineData Data returned by the kernel in which the enciphered online PIN would be added.
//! \return
//!     - \ref TRUE if correctly performed.
//!     - \ref FALSE if an error occurred.
static T_Bool Cless_JCB_OnlinePinManagement (T_SHARED_DATA_STRUCT * pStructureForOnlineData, int nCardHolderLang)
{
    char*                   pcFuncName = "Cless_JCB_OnlinePinManagement";
    int                     nPosition, cr;
    const unsigned char *   pPan;
    const unsigned char *   pValueAmountNum;
    unsigned long           ulPanLength;
    const unsigned char *   pTrack2Data;
    unsigned long           ulTrack2DataLength;
    char                    aucDymmyMsg[] = " ";
    BUFFER_SIZE             buffer_saisie;
    MSGinfos                tMsg;
    unsigned long           ulReadDataRecordLength, ulAmountNumLength;
    unsigned char *         pReadDataRecordValue;
    T_SHARED_DATA_STRUCT    tDataRecord;
    unsigned long           ulAmount;


    // Get the DATA RECORD and copy all the data in the structure to be sent to the HOST
    nPosition = SHARED_EXCHANGE_POSITION_NULL;
    cr = GTL_SharedExchange_FindNext (pStructureForOnlineData, &nPosition, TAG_JCB_DATA_RECORD, &ulReadDataRecordLength, (const unsigned char **)&pReadDataRecordValue);
    if (cr == STATUS_SHARED_EXCHANGE_OK)
    {
        if (GTL_SharedExchange_InitEx (&tDataRecord, ulReadDataRecordLength, ulReadDataRecordLength, pReadDataRecordValue) != STATUS_SHARED_EXCHANGE_OK)
        {
            GTL_Traces_TraceDebug ("%s : Unable to initialize the DATA RECORD structure", pcFuncName);
            return (B_FALSE);
        }
    }

    // Tags have been got (if present), get the PAN
    nPosition = SHARED_EXCHANGE_POSITION_NULL;
    if (GTL_SharedExchange_FindNext (&tDataRecord, &nPosition, TAG_EMV_APPLI_PAN, &ulPanLength, &pPan) != STATUS_SHARED_EXCHANGE_OK)
    {
        // Maybe it is a MStripe card, so try to extract PAN from Track2 Data
        nPosition = SHARED_EXCHANGE_POSITION_NULL;

        if (GTL_SharedExchange_FindNext (&tDataRecord, &nPosition, TAG_EMV_TRACK_2_EQU_DATA, &ulTrack2DataLength, &pTrack2Data) != STATUS_SHARED_EXCHANGE_OK)
        {
            GTL_Traces_TraceDebug ("%s : Missing PAN for Online PIN", pcFuncName);
            return (B_FALSE);
        }
        // Continue with the PAN extracted from the track2 data
        pPan = pTrack2Data;
    }

    // get the amount authorized
    ulAmount = 5432;
    nPosition = SHARED_EXCHANGE_POSITION_NULL;
    if (GTL_SharedExchange_FindNext (&tDataRecord, &nPosition, TAG_EMV_AMOUNT_AUTH_NUM, &ulAmountNumLength, &pValueAmountNum) == STATUS_SHARED_EXCHANGE_OK)
    {
        GTL_Convert_DcbNumberToUl(pValueAmountNum, &ulAmount, 6);
    }

    // Warning, erase display must be made only if Pin input will be made on customer screen
   /* if (ClessSample_IsPinpadPresent())
    {
        // Display dummy message to erase display
        tMsg.message = aucDymmyMsg;
        tMsg.coding = _ISO8859_;
        tMsg.file = GetCurrentFont();
        Helper_DisplayTextCustomer(ERASE, HELPERS_CUSTOMER_LINE_1, &tMsg, CLESSSAMPLE_ALIGN_CENTER, LEDSOFF);
    }*/

    // Request online PIN entry
    //todo
    //cr = ClessSample_PinManagement_OnLinePinManagement ((unsigned char*)pPan, 1, ulAmount, 30000, 10000, nCardHolderLang, &buffer_saisie);
    cr = 0;
    if (cr == INPUT_PIN_ON)
    {
        cr = GTL_SharedExchange_AddTag(pStructureForOnlineData, TAG_SAMPLE_ENCIPHERED_PIN_CODE, buffer_saisie.nombre , (const unsigned char *)buffer_saisie.donnees);
        if (cr != STATUS_SHARED_EXCHANGE_OK)
        {
            GTL_Traces_TraceDebug ("%s : Unable to add TAG_SAMPLE_ENCIPHERED_PIN_CODE in the shared buffer (cr = 0x%02X)", pcFuncName, cr);
            return (B_FALSE);
        }
    }
    else if (cr == CANCEL_INPUT)
    {
        GTL_Traces_TraceDebug ("%s : input pin Cancelled", pcFuncName);
        return (B_NON_INIT);
    }

    return (B_TRUE);
}

//! \brief Fill buffer with specific JCB requirements for transaction.
//! \param[out] dataStruct Shared exchange structure filled with the specific JCB data.
//! \return
//!     - \ref TRUE if correctly performed.
//!     - \ref FALSE if an error occurred.
static int CLESS_JCB_AddJCBSpecificData (T_SHARED_DATA_STRUCT * pDataStruct){
	int nResult;
	object_info_t ObjectInfo;
	T_KERNEL_TRANSACTION_FLOW_CUSTOM sTransactionFlowCustom;
	unsigned char StepInterruption[KERNEL_PAYMENT_FLOW_STOP_LENGTH];// Bit field to stop payment flow,
																	// if all bit set to 0 => no stop during payment process
																	// if right bit set to 1 : stop after payment step number 1
	unsigned char StepCustom[KERNEL_PAYMENT_FLOW_CUSTOM_LENGTH]; 	// Bit field to custom payment flow,
																	// if all bit set to 0 => no stop during payment process
																	// if right bit set to 1 : stop after payment step number 1
	if (pDataStruct == NULL) {
		nResult = FALSE;
		goto End;
	}
	memset(StepInterruption, 0, sizeof(StepInterruption)); // Default Value : not stop on process
	memset(StepCustom, 0, sizeof(StepCustom)); // Default Value : not stop on process
	ObjectGetInfo(OBJECT_TYPE_APPLI, ApplicationGetCurrent(), &ObjectInfo);
	nResult = TRUE;

	// Add a tag for Do_Txn management
	if(GTL_SharedExchange_AddTag(pDataStruct, TAG_KERNEL_PAYMENT_FLOW_STOP, KERNEL_PAYMENT_FLOW_STOP_LENGTH, (const unsigned char *)StepInterruption) != STATUS_SHARED_EXCHANGE_OK) {
		nResult = FALSE;
		goto End;
	}
	ADD_STEP_CUSTOM(STEP_JCB_REMOVE_CARD,StepCustom);// To do GUI when MStripe card has been read
	ADD_STEP_CUSTOM(STEP_JCB_GET_CA_PUB_KEY, StepCustom);
	memcpy ((void*)&sTransactionFlowCustom, (void*)StepCustom, KERNEL_PAYMENT_FLOW_CUSTOM_LENGTH);
	sTransactionFlowCustom.usApplicationType = ObjectInfo.application_type; // Kernel will call this application for customisation
	sTransactionFlowCustom.usServiceId = SERVICE_CUSTOM_KERNEL; 			// Kernel will call SERVICE_CUSTOM_KERNEL service id for customisation
	if(GTL_SharedExchange_AddTag(pDataStruct, TAG_KERNEL_PAYMENT_FLOW_CUSTOM, sizeof(T_KERNEL_TRANSACTION_FLOW_CUSTOM), (const unsigned char *)&sTransactionFlowCustom) != STATUS_SHARED_EXCHANGE_OK) {
		nResult = FALSE;
		goto End;
	}
	End:
		return (nResult);
}

//! \brief Get the JCB transaction outcome from the Outcome Parameter Set.
//! \param[in] pResultDataStruct Structure containing the C5 kernel output.
//! \param[out] pTransactionOutcome Retrieved transaction outcome :
//!     - \a JCB_OPS_STATUS_APPROVED if transaction is approved.
//!     - \a JCB_OPS_STATUS_ONLINE_REQUEST if an online authorization is requested.
//!     - \a JCB_OPS_STATUS_DECLINED if the transaction is declined.
//!     - \a JCB_OPS_STATUS_TRY_ANOTHER_INTERFACE transaction should be retried on an other interface.
//!     - \a JCB_OPS_STATUS_END_APPLICATION if the transaction is terminated.
//!     - \a JCB_OPS_STATUS_SELECT_NEXT if next AID shall be selected.
//!     - \a JCB_OPS_STATUS_TRY_AGAIN transaction shall be restarted from the begining..
//! \return
//!     - \ref TRUE if correctly retrieved.
//!     - \ref FALSE if an error occurred.
static int  Cless_JCB_RetrieveTransactionOutcome (T_SHARED_DATA_STRUCT * pResultDataStruct, int * pTransactionOutcome)
{
    char* pcFuncName = "Cless_JCB_RetrieveTransactionOutcome";
    int nPosition, cr;
    unsigned long ulReadLength;
    const unsigned char * pReadValue;

    // Init position
    nPosition = SHARED_EXCHANGE_POSITION_NULL;

    // Init output data
    if (pTransactionOutcome != NULL)
        *pTransactionOutcome = JCB_OPS_STATUS_END_APPLICATION;

    // Get the Outcome Parameter Set
    cr = GTL_SharedExchange_FindNext(pResultDataStruct, &nPosition, TAG_JCB_OUTCOME_PARAMETER_SET, &ulReadLength, &pReadValue);

    if (cr != STATUS_SHARED_EXCHANGE_OK)
    {
        GTL_Traces_TraceDebug ("%s : Unable to get the outcome parameter set from the kernel response (cr = 0x%02X)", pcFuncName, cr);
        return (FALSE);
    }

    // Get the transaction outcome
    if (pTransactionOutcome != NULL)
        *pTransactionOutcome = pReadValue[JCB_OPS_STATUS_OFFSET];

    return (TRUE);
}

int Cless_JCB_EndTransaction(T_SHARED_DATA_STRUCT * pKernelDataStruct){

    // deselect the card and close the driver
    ClessEmv_DeselectCard(0, TRUE, FALSE);
    ClessEmv_CloseDriver();

	// Increment the transaction sequence counter
	//ClessSample_Batch_IncrementTransactionSeqCounter();

	// Transaction is completed, clear JCB kernel transaction data
	JCB_Clear ();
	removecard=0;
	// Return result
	return (CLESS_CR_MANAGER_END);
}

//! \brief Get the Field Off value (read from the Outcome Parameter Set).
//! \param[in] pResultDataStruct Structure containing the C5 kernel output.
//! \param[out] pFieldOff Retrieved field off value (in units of 100 ms).
//!     - \a JCB_OPS_FIELD_OFF_REQUEST_NA if Field Off is not applicable to the case.
//! \return
//!     - \ref TRUE if correctly retrieved.
//!     - \ref FALSE if an error occurred.
static int Cless_JCB_RetrieveFieldOffValue(T_SHARED_DATA_STRUCT * pResultDataStruct, unsigned char * pFieldOff){
	char*                   pcFuncName = "__ClessSample_JCB_RetrieveFieldOffValue";
	int                     nPosition, cr;
	unsigned long           ulReadLength;
	const unsigned char *   pReadValue;

	// Init output data
	*pFieldOff = JCB_OPS_FIELD_OFF_REQUEST_NA;

	// Get the Outcome Parameter Set
	nPosition = SHARED_EXCHANGE_POSITION_NULL;
	cr = GTL_SharedExchange_FindNext(pResultDataStruct, &nPosition, TAG_JCB_OUTCOME_PARAMETER_SET, &ulReadLength, &pReadValue);
	if (cr != STATUS_SHARED_EXCHANGE_OK)
	{
		GTL_Traces_TraceDebug ("%s : Unable to get the outcome parameter set from the kernel response (cr = 0x%02X)", pcFuncName, cr);
		return (FALSE);
	}

	// Get the Field Off value
	*pFieldOff = pReadValue[JCB_OPS_FIELD_OFF_REQUEST_OFFSET];

	return (TRUE);
}

//! \brief Get the start byte from the Outcome Parameter Set.
//! \param[in] pResultDataStruct Structure containing the C5 kernel output.
//! \param[out] pStart Retrieved start value :
//!     - \a JCB_OPS_START_A if transaction needs to start at A.
//!     - \a JCB_OPS_START_B if transaction needs to start at B.
//!     - \a JCB_OPS_START_C if transaction needs to start at C.
//!     - \a JCB_OPS_START_D if transaction needs to start at D.
//! \return
//!     - \ref TRUE if correctly retrieved.
//!     - \ref FALSE if an error occurred.
static int  Cless_JCB_RetrieveStart(T_SHARED_DATA_STRUCT * pResultDataStruct, int * pStart){
	char*                   pcFuncName = "Cless_JCB_RetrieveStart";
	int                     nPosition, cr;
	unsigned long           ulReadLength;
	const unsigned char *   pReadValue;

	// Init output data
	*pStart = JCB_OPS_START_NA;

	// Get the Outcome Parameter Set
	nPosition = SHARED_EXCHANGE_POSITION_NULL;
	cr = GTL_SharedExchange_FindNext(pResultDataStruct, &nPosition, TAG_JCB_OUTCOME_PARAMETER_SET, &ulReadLength, &pReadValue);
	if (cr != STATUS_SHARED_EXCHANGE_OK)
	{
		GTL_Traces_TraceDebug ("%s : Unable to get the outcome parameter set from the kernel response (cr = 0x%02X)", pcFuncName, cr);
		return (FALSE);
	}

	// Get the start value
	*pStart = pReadValue[JCB_OPS_START_OFFSET];

	return (TRUE);
}

//! \brief Get the JCB message to be displayed on outcome from the UIRD.
//! \param[in] pResultDataStruct Structure containing the C5 kernel output.
//! \param[out] pUirdMessage Retrieved from transaction outcome :
//!     - \a JCB_UIRD_MESSAGE_ID_ENTER_PIN                   - Indicates that the cardholder has to enter his PIN code.
//!     - \a JCB_UIRD_MESSAGE_ID_TRY_AGAIN                   - Indicates that the card has to be presented again.
//!     - \a JCB_UIRD_MESSAGE_ID_APPROVED                    - Indicates that the transaction is approved.
//!     - \a JCB_UIRD_MESSAGE_ID_APPROVED_SIGN               - Indicates that the transaction is approved but signature required.
//!     - \a JCB_UIRD_MESSAGE_ID_DECLINED                    - Indicates that the transaction is declined.
//!     - \a JCB_UIRD_MESSAGE_ID_SEE_PHONE                   - Indicates that the cardholder shall see his phone for instructions.
//!     - \a JCB_UIRD_MESSAGE_ID_AUTHORIZING_PLEASE_WAIT     - Indicates that the cardholder the transaction is sent online for authorization.
//!     - \a JCB_UIRD_MESSAGE_ID_INSERT_CARD                 - Indicates that the cardholder has to insert his card.
//!     - \a JCB_UIRD_MESSAGE_ID_NA Message                  - Indicates that the identifier is not applicable.
//! \param[out] pUirdStatus Retrieved from transaction outcome :
//!     - \a JCB_UIRD_STATUS_NOT_READY                       - Indicates that the reader is ready.
//!     - \a JCB_UIRD_STATUS_IDLE                            - Indicates that the reader is idle.
//!     - \a JCB_UIRD_STATUS_READY_TO_READ                   - Indicates that the reader is ready to read the card.
//!     - \a JCB_UIRD_STATUS_PROCESSING                      - Indicates that the transaction is in progress.
//!     - \a JCB_UIRD_STATUS_CARD_READ_SUCCESSFULLY          - Indicates that the card has been read successfully.
//!     - \a JCB_UIRD_STATUS_PROCESSING_ERROR                - Indicates that an error occured.
//!     - \a JCB_UIRD_STATUS_NA                              - Indicates that the Status for UIRD is not applicable.
//! \return
//!     - \ref TRUE if correctly retrieved.
//!     - \ref FALSE if an error occurred.
static int  Cless_JCB_RetrieveUirdMessageOnOutcome(T_SHARED_DATA_STRUCT * pResultDataStruct, int * pUirdMessage, int * pUirdStatus){
	char*                   pcFuncName = "__ClessSample_JCB_RetrieveUirdMessageOnOutcome";
	int                     nPosition, cr;
	unsigned long           ulReadLength;
	const unsigned char *   pReadValue;
	bool                    bUiRequestPresent;

	// Init output data
	*pUirdMessage = JCB_UIRD_MESSAGE_ID_NA;
	*pUirdStatus  = JCB_UIRD_STATUS_NA;

	// First case: the Outcome Parameter Set is present but the UI request is not present
	// Get the Outcome Parameter Set
	nPosition = SHARED_EXCHANGE_POSITION_NULL;
	cr = GTL_SharedExchange_FindNext(pResultDataStruct, &nPosition, TAG_JCB_OUTCOME_PARAMETER_SET, &ulReadLength, &pReadValue);
	if (cr == STATUS_SHARED_EXCHANGE_OK)
	{
		// Check if a UI request on outcome is present
		bUiRequestPresent = ((pReadValue[JCB_OPS_DATA_PRESENCE_OFFSET] & JCB_OPS_DATA_PRESENCE_MASK_UIR_ON_OUTCOME) == JCB_OPS_DATA_PRESENCE_MASK_UIR_ON_OUTCOME);
		if (!bUiRequestPresent)
			return (TRUE);
	}
	// Second case: the UI request should be present
	// Get the UI request on outcome
	nPosition = SHARED_EXCHANGE_POSITION_NULL;
	cr = GTL_SharedExchange_FindNext(pResultDataStruct, &nPosition, TAG_JCB_UIR_ON_OUTCOME_DATA, &ulReadLength, &pReadValue);
	if (cr != STATUS_SHARED_EXCHANGE_OK)
	{
		GTL_Traces_TraceDebug ("%s : Unable to get the UIR on outcome data from the kernel response (cr = 0x%02X)", pcFuncName, cr);
		return (FALSE);
	}
	// Get the UIRD message
	*pUirdMessage = pReadValue[JCB_UIRD_MESSAGE_ID_OFFSET];
	*pUirdStatus  = pReadValue[JCB_UIRD_STATUS_OFFSET];

	return (TRUE);
}

//! \brief Get the JCB message to be displayed on restart from the UIRD.
//! \param[in] pResultDataStruct Structure containing the C5 kernel output.
//! \param[out] pUirdMessage Retrieved transaction outcome :
//!     - \a JCB_UIRD_MESSAGE_ID_PROCESSING     - Indicates that a treatment is in progress.
//!     - \a JCB_UIRD_MESSAGE_ID_TRY_AGAIN      - Indicates that the card has to be presented again.
//! \param[out] pUirdStatus Retrieved from transaction outcome :
//!     - \a JCB_UIRD_STATUS_NOT_READY                       - Indicates that the reader is ready.
//!     - \a JCB_UIRD_STATUS_IDLE                            - Indicates that the reader is idle.
//!     - \a JCB_UIRD_STATUS_READY_TO_READ                   - Indicates that the reader is ready to read the card.
//!     - \a JCB_UIRD_STATUS_PROCESSING                      - Indicates that the transaction is in progress.
//!     - \a JCB_UIRD_STATUS_CARD_READ_SUCCESSFULLY          - Indicates that the card has been read successfully.
//!     - \a JCB_UIRD_STATUS_PROCESSING_ERROR                - Indicates that an error occured.
//!     - \a JCB_UIRD_STATUS_NA                              - Indicates that the Status for UIRD is not applicable.
//! \return
//!     - \ref TRUE if correctly retrieved.
//!     - \ref FALSE if an error occurred.
static int  Cless_JCB_RetrieveUirdMessageOnRestart(T_SHARED_DATA_STRUCT * pResultDataStruct, int * pUirdMessage, int * pUirdStatus){

    char*                   pcFuncName = "__ClessSample_JCB_RetrieveUirdMessageOnRestart";
    int                     nPosition, cr;
    unsigned long           ulReadLength;
    const unsigned char *   pReadValue;
    bool                    bUiRequestPresent;


    // Init output data
    *pUirdMessage = JCB_UIRD_MESSAGE_ID_NA;
    *pUirdStatus  = JCB_UIRD_STATUS_NA;

    // First case: the Outcome Parameter Set is present but the UI request is not present
    // Get the Restart Parameter Set
    nPosition = SHARED_EXCHANGE_POSITION_NULL;
    cr = GTL_SharedExchange_FindNext(pResultDataStruct, &nPosition, TAG_JCB_OUTCOME_PARAMETER_SET, &ulReadLength, &pReadValue);
    if (cr == STATUS_SHARED_EXCHANGE_OK)
    {
        // Check if a UI request on restart is present
        bUiRequestPresent = ((pReadValue[JCB_OPS_DATA_PRESENCE_OFFSET] & JCB_OPS_DATA_PRESENCE_MASK_UIR_ON_RESTART) == JCB_OPS_DATA_PRESENCE_MASK_UIR_ON_RESTART);
        if (!bUiRequestPresent)
            return (TRUE);
    }
    // Second case: the UI request should be present
    // Get the UI request on restart
    nPosition = SHARED_EXCHANGE_POSITION_NULL;
    cr = GTL_SharedExchange_FindNext(pResultDataStruct, &nPosition, TAG_JCB_UIR_ON_RESTART_DATA, &ulReadLength, &pReadValue);
    if (cr != STATUS_SHARED_EXCHANGE_OK)
    {
        GTL_Traces_TraceDebug ("%s : Unable to get the UIR on restart data from the kernel response (cr = 0x%02X)", pcFuncName, cr);
        return (FALSE);
    }
    // Get the UIRD message
    *pUirdMessage = pReadValue[JCB_UIRD_MESSAGE_ID_OFFSET];
    *pUirdStatus  = pReadValue[JCB_UIRD_STATUS_OFFSET];

    return (TRUE);

}

//! \brief manage a 'declined' outcome.
//! \param[in] pDataStruct Data buffer to be filled and used for JCB transaction.
//! \return
//!     - JCB kernel result.
int Cless_JCB_ManageDeclined(T_SHARED_DATA_STRUCT * pKernelDataStruct){
	// Display the message on outcome located in the UIRD
	Cless_JCB_DisplayUirdMsg(pKernelDataStruct, FALSE, TRUE, FALSE);

	//todo
	/*if (!UIH_IsRemoveCardTaskRunning())
		HelperLedsOff();
	Helper_WaitUserDisplay();*/

	// Return result
	return (Cless_JCB_EndTransaction(pKernelDataStruct));
}

//! \brief manage a select next outcome.
//! \param[in] pDataStruct Data buffer to be filled and used for JCB transaction.
//! \return
//!     - JCB kernel result.
int Cless_JCB_ManageSelectNext(T_SHARED_DATA_STRUCT * pKernelDataStruct){
	// Transaction is completed, clear JCB kernel transaction data
	JCB_Clear ();
	// Return result
	return (CLESS_CR_MANAGER_REMOVE_AID);
}

//! \brief Get the card type.
//! \param[in] pResultDataStruct Structure containing the C5 kernel output.
//! \param[out] pCardType Retrieved card type
//!     - \a 0 If card type not found.
//!     - \a 0x8501 for MStripe card.
//!     - \a 0x8502 for MChip card.
//! \return
//!     - \ref TRUE if correctly retrieved.
//!     - \ref FALSE if an error occurred.
static int Cless_JCB_RetrieveCardType (T_SHARED_DATA_STRUCT * pResultDataStruct, unsigned short * pCardType){
	int nPosition, cr;
	unsigned long ulReadLength;
	const unsigned char * pReadValue;

	nPosition = SHARED_EXCHANGE_POSITION_NULL;

	if (pCardType != NULL)
		*pCardType = 0;// Default result

	cr = GTL_SharedExchange_FindNext(pResultDataStruct, &nPosition, TAG_KERNEL_CARD_TYPE, &ulReadLength, &pReadValue);
	if (cr != STATUS_SHARED_EXCHANGE_OK)
	{
		return (FALSE);
	}

	// Get the card type
	if (pCardType != NULL)
		*pCardType = (pReadValue[0] << 8) + pReadValue[1];

	return (TRUE);
}

//! \brief Get the CVM to apply (read from the Outcome Parameter Set).
//! \param[in] pResultDataStruct Structure containing the C5 kernel output.
//! \param[out] pCvm Retrieved transaction outcome :
//!     - \a JCB_OPS_CVM_NO_CVM No CVM to be performed.
//!     - \a JCB_OPS_CVM_SIGNATURE if signature shall be performed.
//!     - \a JCB_OPS_CVM_ONLINE_PIN if online PIN shall be performed.
//!     - \a JCB_OPS_CVM_CONFIRMATION_CODE_VERIFIED if confirmation code has been verified.
//!     - \a JCB_OPS_CVM_TO_BE_PERFORMED if confirmation code has to be performed by the reader.

//!     - \a JCB_OPS_CVM_NA if CVM is not applicable to the case.
//! \return
//!     - \ref TRUE if correctly retrieved.
//!     - \ref FALSE if an error occurred.
static int  Cless_JCB_RetrieveCvmToApply (T_SHARED_DATA_STRUCT * pResultDataStruct, unsigned char * pCvm){

	char*  pcFuncName = "Cless_JCB_RetrieveCvmToApply";
	int nPosition, cr;
	unsigned long ulReadLength;
	const unsigned char * pReadValue;

	// Init position
	nPosition = SHARED_EXCHANGE_POSITION_NULL;

	// Init output data
	if (pCvm != NULL)
		*pCvm = JCB_OPS_CVM_NA;

	// Get the Outcome Parameter Set
	cr = GTL_SharedExchange_FindNext(pResultDataStruct, &nPosition, TAG_JCB_OUTCOME_PARAMETER_SET, &ulReadLength, &pReadValue);
	if (cr != STATUS_SHARED_EXCHANGE_OK)
	{
		GTL_Traces_TraceDebug ("%s : Unable to get the outcome parameter set from the kernel response (cr = 0x%02X)", pcFuncName, cr);
		return (FALSE);
	}

	// Get the CVM to apply
	if (pCvm != NULL)
		*pCvm = pReadValue[JCB_OPS_CVM_OFFSET];

	return (TRUE);
}

//! \brief Add the transaction data record to the batch.
//! \param[in] pSharedData Shared buffer to be used to retrieve the data record.
//! \param[in] usCardType Card type.
static void Cless_JCB_AddRecordToBatch(T_SHARED_DATA_STRUCT * pSharedData, unsigned short usCardType)
{
    char*                   pcFuncName = "Cless_JCB_AddRecordToBatch";
    // Tags required for Offline and Online approved transactions
    T_TI_TAG                tRequestedTags[] = {TAG_JCB_DATA_RECORD, TAG_EMV_TRANSACTION_TYPE, TAG_EMV_TRANSACTION_DATE};
    unsigned int            nIndex;
    int                     nPosition;
    int                     nResult, bErrorDetected;
    int                     merchLang;
    T_SHARED_DATA_STRUCT *  pTransactionData;
    T_SHARED_DATA_STRUCT    tTempStruct;
    unsigned long           ulReadLength;
    unsigned char *         pReadValue;


    (void) usCardType;

    // Clear the shared exchange buffer
    GTL_SharedExchange_ClearEx (pSharedData, FALSE);
    nIndex = 0;
    bErrorDetected = FALSE;


    // Allocate the shared buffer containing the transaction data
    pTransactionData = GTL_SharedExchange_InitLocal (2048);
    if (pTransactionData == NULL)
    {
        // An error occurred when initialising the local data exchange
        GTL_Traces_TraceDebug ("%s : An error occurred when initializing the transaction data buffer", pcFuncName);
        bErrorDetected = TRUE;
        goto End;
    }

    // Build the list of tags  and ...
    while (nIndex < NUMBER_OF_ITEMS(tRequestedTags))
    {
        GTL_SharedExchange_AddTag (pSharedData, tRequestedTags[nIndex], 0, NULL);
        nIndex ++;
    }
    // ... get the values from the kernel
    nResult = JCB_GetData (pSharedData);
    if (nResult != KERNEL_STATUS_OK)
    {
        GTL_Traces_TraceDebug ("%s : Unable to get JCB data (nResult = 0x%02X)\n", pcFuncName, nResult);
        bErrorDetected = TRUE;
        goto End;
    }

    // Get the Data Record and ...
    nPosition = SHARED_EXCHANGE_POSITION_NULL;
    if (GTL_SharedExchange_FindNext (pSharedData, &nPosition, TAG_JCB_DATA_RECORD, &ulReadLength, (const unsigned char **)&pReadValue) != STATUS_SHARED_EXCHANGE_OK)
    {
        GTL_Traces_TraceDebug ("%s : Unable to retrieve the Data Record", pcFuncName);
        bErrorDetected = TRUE;
        goto End;
    }
    // ... copy it in the transaction data
    if (GTL_SharedExchange_InitEx (&tTempStruct, ulReadLength, ulReadLength, pReadValue) != STATUS_SHARED_EXCHANGE_OK)
    {
        GTL_Traces_TraceDebug ("%s : Unable to init the local structure with data record", pcFuncName);
        bErrorDetected = TRUE;
        goto End;
    }
    if (GTL_SharedExchange_AddSharedBufferContent (pTransactionData, &tTempStruct) != STATUS_SHARED_EXCHANGE_OK)
    {
        GTL_Traces_TraceDebug ("%s : Unable to copy the data record in the transaction data buffer", pcFuncName);
        bErrorDetected = TRUE;
        goto End;
    }

    // get the transaction type if present and ...
    nPosition = SHARED_EXCHANGE_POSITION_NULL;
    if (GTL_SharedExchange_FindNext (pSharedData, &nPosition, TAG_EMV_TRANSACTION_TYPE, &ulReadLength, (const unsigned char **)&pReadValue) == STATUS_SHARED_EXCHANGE_OK)
    {
        // ... copy it in the transaction data
        if (GTL_SharedExchange_AddTag (pTransactionData, TAG_EMV_TRANSACTION_TYPE, ulReadLength, pReadValue)!= STATUS_SHARED_EXCHANGE_OK)
        {
            GTL_Traces_TraceDebug ("%s : Unable to copy the transaction type in the transaction data buffer", pcFuncName);
            bErrorDetected = TRUE;
            goto End;
        }
    }

    // get the transaction date if present and ...
    nPosition = SHARED_EXCHANGE_POSITION_NULL;
    if (GTL_SharedExchange_FindNext (pSharedData, &nPosition, TAG_EMV_TRANSACTION_DATE, &ulReadLength, (const unsigned char **)&pReadValue) == STATUS_SHARED_EXCHANGE_OK)
    {
        // ... copy it in the transaction data
        if (GTL_SharedExchange_AddTag (pTransactionData, TAG_EMV_TRANSACTION_DATE, ulReadLength, pReadValue)!= STATUS_SHARED_EXCHANGE_OK)
        {
            GTL_Traces_TraceDebug ("%s : Unable to copy the transaction date in the transaction data buffer", pcFuncName);
            bErrorDetected = TRUE;
            goto End;
        }
    }

    // add the transaction record in the batch file
    //todo
   /* if (!ClessSample_Batch_AddTransactionToBatch (pTransactionData))
    {
        GTL_Traces_TraceDebug ("%s : Saving the transaction data in batch has failed", pcFuncName);
        bErrorDetected = TRUE;
        goto End;
    }*/

End:
    if (pTransactionData != NULL)
        // Destroy the transaction data buffer previously allocated
        GTL_SharedExchange_DestroyLocal (pTransactionData);
    if (bErrorDetected)
    {
    	//todo
        //merchLang = PSQ_Give_Language();
        //ClessSample_GuiState_DisplayScreen(CLESS_SAMPLE_SCREEN_BATCH_ERROR, merchLang, merchLang);
    }

}

//! \brief manage an approved outcome.
//! \param[in] pDataStruct Data buffer to be filled and used for JCB transaction.
//! \return
//!     - JCB kernel result.
int Cless_JCB_ManageApprovedOutcome(T_SHARED_DATA_STRUCT * pKernelDataStruct){
	char*                   pcFuncName = "Cless_JCB_ManageApprovedOutcome";
	unsigned char           ucCvm;
	unsigned short          usCardType;

	// Retrieve the card type
	if (!Cless_JCB_RetrieveCardType(pKernelDataStruct, &usCardType))
	{
		GTL_Traces_TraceDebug ("%s : retrieving the 'card type' has failed. Force 'type not found'.\n", pcFuncName);
		usCardType = 0;
	}

	// Get the CVM to perform
	if (!Cless_JCB_RetrieveCvmToApply(pKernelDataStruct, &ucCvm))
	{
		GTL_Traces_TraceDebug ("%s : retrieving the 'CVM to apply' has failed. Force 'CVM N/A'.\n", pcFuncName);
		ucCvm = JCB_OPS_CVM_NA;
	}

	 // Display the message on outcome located in the UIRD
	 Cless_JCB_DisplayUirdMsg(pKernelDataStruct, FALSE, TRUE, FALSE);

	 // print the receipt
	 //todo
	 //__ClessSample_JCB_PrintReceipt(pKernelDataStruct, ucCvm);

	 // user interface sequence according to the CVM
	 switch (ucCvm){
	 case JCB_OPS_CVM_SIGNATURE:
		 // display approved and request for signature
		 CLESS_GUI_DisplayScreen(APCLESS_PAYPASS_SCREEN_SIGNATURE_OK);
		 // the transaction is stored in the batch
		 Cless_JCB_AddRecordToBatch(pKernelDataStruct, usCardType);
		 break;

	 default:
		 // display approved
		 CLESS_GUI_DisplayScreen(APCLESS_SCREEN_ONLINE_PROCESSING );
		 // the transaction is stored in the batch
		 Cless_JCB_AddRecordToBatch(pKernelDataStruct, usCardType);
	 }
	 // end transaction
	 return (Cless_JCB_EndTransaction(pKernelDataStruct));

}

//! \brief manage a 'try another interface' outcome.
//! \param[in] pDataStruct Data buffer to be filled and used for JCB transaction.
//! \return
//!     - JCB kernel result.
int Cless_JCB_ManageTryAnotherInterface(T_SHARED_DATA_STRUCT * pKernelDataStruct)
{

    // Display the message on outcome located in the UIRD
    Cless_JCB_DisplayUirdMsg(pKernelDataStruct, FALSE, TRUE, FALSE);

    //todo
   /* if (!UIH_IsRemoveCardTaskRunning())
        HelperLedsOff();
    Helper_WaitUserDisplay();*/

    // Return result
    return (Cless_JCB_EndTransaction(pKernelDataStruct));
}

//! \brief manage an 'end application' outcome.
//! \param[in] pDataStruct Data buffer to be filled and used for JCB transaction.
//! \return
//!     - JCB kernel result.
int Cless_JCB_ManageEndApplication(T_SHARED_DATA_STRUCT * pKernelDataStruct){
	unsigned char           ucFieldOff;
	unsigned int            nEndApplicationType;
	int                     nResult;
	int                     nTransactionStart;
	int                     nUirdMessageOnOutcome, nUirdStatus;

	// get field off information
	Cless_JCB_RetrieveFieldOffValue(pKernelDataStruct, &ucFieldOff);

	// Retrieve the start value in the OPS
	Cless_JCB_RetrieveStart(pKernelDataStruct, &nTransactionStart);

	// Get the UIRD message on outcome to be displayed
	Cless_JCB_RetrieveUirdMessageOnOutcome(pKernelDataStruct, &nUirdMessageOnOutcome, &nUirdStatus);

	// identify the end application type
	if (nTransactionStart == JCB_OPS_START_NA)
		// end application without restart
		nEndApplicationType = CLESS_JCB_END_APPLI;
	else
	{
		// end application with restart. Get the reason of the restart.
		if(nUirdMessageOnOutcome == JCB_UIRD_MESSAGE_ID_TRY_AGAIN)
			// restart is due to  a communication error with the card
			nEndApplicationType = CLESS_JCB_END_APPLI_RESTART_COMM_ERROR;
		else
			// restart is due to an on-device CVM
			nEndApplicationType = CLESS_JCB_END_APPLI_RESTART_ON_DEVICE_CVM;
	}

	// manage  end application
	 switch (nEndApplicationType){
	 	 case CLESS_JCB_END_APPLI_RESTART_COMM_ERROR:
	 		// Display the outcome message
	 		Cless_JCB_DisplayUirdMsg(pKernelDataStruct, FALSE, TRUE, FALSE);
#ifndef __SIMU_ICC__
            ClessEmv_CloseDriver();
#endif
	 		 // Transaction shall be restarted from the beginning
	 		 nResult = CLESS_CR_MANAGER_RESTART;
	 		 break;
	 	case CLESS_JCB_END_APPLI_RESTART_ON_DEVICE_CVM:
	 		Cless_JCB_DisplayUirdMsg(pKernelDataStruct, FALSE, TRUE, FALSE);
	 		// Display the outcome message
#ifndef __SIMU_ICC__
            ClessEmv_CloseDriver();
#endif
            if(ucFieldOff != 0)
            	Telium_Ttestall(0, ucFieldOff * 10);
            // display the restart message
            Cless_JCB_DisplayUirdMsg(pKernelDataStruct, FALSE, FALSE, FALSE);
            //todo
            // Turn on the 1st LED only
           // HelperWaitLedsTime();
            //HelperCardWait();
            // Transaction shall be restarted
            nResult = CLESS_CR_MANAGER_RESTART_DOUBLE_TAP;
            break;
	 	 case CLESS_JCB_END_APPLI:
	 	 default:
	 	      	  return (Cless_JCB_EndTransaction(pKernelDataStruct));
	 }

	 // Transaction is completed, clear JCB kernel transaction data
	 JCB_Clear ();

	 // Return result
	 return (nResult);
}

//! \brief manage an 'unknown' outcome.
//! \param[in] pKernelDataStruct Data buffer to be filled and used for JCB transaction.
//! \param[in] nTransactionOutcome.
//! \return
//!     - JCB kernel result.
int Cless_JCB_ManageUnknownOutcome(T_SHARED_DATA_STRUCT * pKernelDataStruct, int nTransactionOutcome){

	char*                   pcFuncName = "__ClessSample_JCB_ManageUnknownOutcome";
	GTL_Traces_TraceDebug ("%s : OPS Status = %02X", pcFuncName, nTransactionOutcome);
	// Indicate an error occurred (transaction is terminated)
	CLESS_GUI_DisplayScreen(APCLESS_SCREEN_ERROR);
	//todo
	//UIH_RemoveCardTask_WaitEnd();
	HelperErrorSequence(WITHBEEP);
	//Helper_WaitUserDisplay();
	// Indicate double tap is not in progress
	CLESS_Txn_SetDoubleTapInProgress(FALSE);

	return (Cless_JCB_EndTransaction(pKernelDataStruct));
}

//! \brief Perform the C5 kernel customisation.
//! \param[in,out] pSharedData Shared buffer used for customisation.
//! \param[in] ucCustomisationStep Step to be customized.
//! \return
//!     - \a KERNEL_STATUS_CONTINUE always.
int Cless_JCB_CustomizeStep(T_SHARED_DATA_STRUCT * pSharedData, const unsigned char ucCustomizationStep)
{
	char*                   pcFuncName = "ClessSample_JCB_CustomizeStep";
	unsigned char ucCapkIndex;
	unsigned char ucRid[7];
	unsigned long ulReadLength;
	unsigned char Modulus [255] = {0};
    unsigned int ModulusLength = 0;
    unsigned char Exponent [3] = {0};
    unsigned int ExponentLength = 0;
    unsigned short found;
    int nResult = KERNEL_STATUS_CONTINUE;
    int                     nPosition;
    const unsigned char *   pReadValue;
    const unsigned char *   pPan;
    unsigned long           ulPanLength;
    const unsigned char *   pPanSeqNumber;
    unsigned char           ucVoidPanSeqNumber = C_CLESS_VOID_PAN_SEQ_NUMBER;// Unused value for PanSeqNumber
    unsigned long           ulPanSeqNbLength;
    unsigned char           bPanInExceptionFile = FALSE;
    int                     cr;


    switch (ucCustomizationStep) // Steps to customize
    {
      	case (STEP_JCB_REMOVE_CARD):
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_REMOVE_CARD);
				GTL_SharedExchange_ClearEx (pSharedData, FALSE);
				nResult = KERNEL_STATUS_CONTINUE;
				removecard=1;
            break;
        case (STEP_JCB_GET_CA_PUB_KEY):
            // Init RID value
            memset (ucRid, 0, sizeof(ucRid));

            // Get the CA public key index (card)
            nPosition = SHARED_EXCHANGE_POSITION_NULL;
            if (GTL_SharedExchange_FindNext (pSharedData, &nPosition, TAG_EMV_CA_PUBLIC_KEY_INDEX_CARD, &ulReadLength, (const unsigned char **)&pReadValue) == STATUS_SHARED_EXCHANGE_OK)
                ucCapkIndex = pReadValue[0];
            else
                ucCapkIndex = 0;

				// Get the DF Name returned by the card
				nPosition = SHARED_EXCHANGE_POSITION_NULL;
				if (GTL_SharedExchange_FindNext (pSharedData, &nPosition, TAG_EMV_DF_NAME, &ulReadLength, (const unsigned char **)&pReadValue) == STATUS_SHARED_EXCHANGE_OK)
					memcpy (ucRid+1, pReadValue, 5);
					memcpy (ucRid, "\x05", 1);
				//memcpy (ucRid, unsignedCharToASCII(pReadValue,ulReadLength), ulReadLength*2);

				// Clear the output structure
				GTL_SharedExchange_ClearEx (pSharedData, FALSE);
				   if (strlen(ucRid) && ucCapkIndex != 0) {
						 found = getCertificationAuthorityPublicKey (ucRid,
																	 ucCapkIndex,
																	Modulus,
																	&ModulusLength,
																	Exponent,
																	&ExponentLength);
						 if (found) {
							 if (GTL_SharedExchange_AddTag(pSharedData, TAG_EMV_INT_CAPK_MODULUS, ModulusLength, Modulus) != STATUS_SHARED_EXCHANGE_OK) {
								 GTL_SharedExchange_ClearEx(pSharedData, FALSE);
								 return FALSE;
							 }
							 if (GTL_SharedExchange_AddTag(pSharedData, TAG_EMV_INT_CAPK_EXPONENT, ExponentLength, Exponent) != STATUS_SHARED_EXCHANGE_OK) {
								 GTL_SharedExchange_ClearEx(pSharedData, FALSE);
								 return FALSE;
							 }
						 }
					 }
				// Get the CA public key data (Modulus, exponent, etc) in the parameters
				/*if (!ClessSample_Parameters_GetCaKeyData (pTreeCurrentParam, ucCapkIndex, ucRid, pSharedData))
				{
					// An error occurred when retreiving the CA Public Key data in the parameters
					GTL_Traces_TraceDebug ("ClessSample_DiscoverDPAS_CustomiseStep : ClessSample_Parameters_GetCaKeyData failed");
				}*/
				nResult = KERNEL_STATUS_CONTINUE;
				break;
        case (STEP_JCB_EXCEPTION_FILE_CHECK):
            // Get the PAN
            nPosition = SHARED_EXCHANGE_POSITION_NULL;
            if (GTL_SharedExchange_FindNext (pSharedData, &nPosition, TAG_EMV_APPLI_PAN, &ulPanLength, &pPan) != STATUS_SHARED_EXCHANGE_OK)
            {
                // Pan parameters is missing, we cannot check BlackList
                GTL_Traces_TraceDebug ("%s : PAN is missing for excpetion file checking", pcFuncName);
                break;
            }

            // Get the PAN Sequence Number
            nPosition = SHARED_EXCHANGE_POSITION_NULL;
            if (GTL_SharedExchange_FindNext (pSharedData, &nPosition, TAG_EMV_APPLI_PAN_SEQUENCE_NUMBER, &ulPanSeqNbLength, &pPanSeqNumber) != STATUS_SHARED_EXCHANGE_OK)
            {
                // Pan Sequence Number is missing, we will check BlackList without PanSeqNumber
                pPanSeqNumber = &ucVoidPanSeqNumber;
            }

            // Check if PAN is in the exception file
            //todo
           // bPanInExceptionFile = ClessSample_BlackListIsPan((int)ulPanLength, pPan, (int)(pPanSeqNumber[0]));

           /* GTL_SharedExchange_ClearEx (pSharedData, FALSE);

            if (bPanInExceptionFile)
            {
                // Add TAG_KERNEL_PAN_IN_BLACK_LIST tag in the exchange buffer to indicate to JCB kernel that the PAN is in the black list
                if (GTL_SharedExchange_AddTag (pSharedData, TAG_KERNEL_PAN_IN_BLACK_LIST, 1, &bPanInExceptionFile) != STATUS_SHARED_EXCHANGE_OK)
                {
                    GTL_SharedExchange_ClearEx (pSharedData, FALSE);
                    GTL_Traces_TraceDebug ("%s : Unable to add TAG_KERNEL_PAN_IN_BLACK_LIST in the shared buffer", pcFuncName);
                }
            }*/
            nResult = KERNEL_STATUS_CONTINUE;
            break;

        default:
            GTL_Traces_TraceDebug ("%s : The step to customize is unknown = 0x%02X\n", pcFuncName, ucCustomizationStep);
            break;
    }

    return nResult;
}

/* --------------------------------------------------------------------------------------------- *
* Purpose: Prepare EMV Data block. The following EMV tag may be sent in EMV request block.   	 *
* ---------------------------------------------------------------------------------------------- */
int JCB_OnlineRequestData(T_SHARED_DATA_STRUCT* dataStruct, unsigned short cardType) {
	int result = TRUE;
	unsigned long length;
	const unsigned char* ptValue;
	int position;

	typedef struct{
		unsigned long tagNum;
		unsigned char tagName[2];
		int tagNameLength;
		int tagDataMinLen;
		int mandatoryFlag;
	}EMVTags;

	EMVTags JCBRequestTags [] =
	   {{TAG_EMV_AIP,                        	"\x82",     1, 2, TRUE},
		{TAG_EMV_DF_NAME,                    	"\x84",     1, 5, TRUE},
		{TAG_EMV_TVR,                        	"\x95",     1, 5, TRUE},
		{TAG_EMV_TRANSACTION_DATE,           	"\x9A",     1, 3, TRUE},
		{TAG_EMV_TRANSACTION_TYPE,           	"\x9C",     1, 1, TRUE},
		{TAG_EMV_TRANSACTION_CURRENCY_CODE,  	"\x5F\x2A", 2, 2, TRUE},
		{TAG_EMV_AMOUNT_AUTH_NUM,            	"\x9F\x02", 2, 6, TRUE},
		{TAG_EMV_AMOUNT_OTHER_NUM,           	"\x9F\x03", 2, 6, TRUE},
		{TAG_EMV_ISSUER_APPLI_DATA,    			"\x9F\x10", 2, 0, TRUE},
		{TAG_EMV_TERMINAL_COUNTRY_CODE,      	"\x9F\x1A", 2, 2, TRUE},
		{TAG_EMV_APPLICATION_CRYPTOGRAM,      	"\x9F\x26", 2, 8, TRUE},
		{TAG_EMV_CRYPTOGRAM_INFO_DATA,			"\x9F\x27", 2, 1, TRUE},
		{TAG_EMV_ATC,                        	"\x9F\x36", 2, 2, TRUE},
		{TAG_EMV_UNPREDICTABLE_NUMBER,       	"\x9F\x37", 2, 4, TRUE},
		{TAG_EMV_POS_ENTRY_MODE, 		 		"\x9F\x39", 2, 1, TRUE},
		{TAG_EMV_TERMINAL_CAPABILITIES,      	"\x9F\x33", 2, 3, FALSE},
		{TAG_EMV_CVM_RESULTS,                 	"\x9F\x34", 2, 3, FALSE},
		{TAG_EMV_TERMINAL_TYPE,              	"\x9F\x35", 2, 1, FALSE},
		{TAG_EMV_ADD_TERMINAL_CAPABILITIES,  	"\x9F\x40", 2, 5, FALSE},
		{TAG_EMV_AID_CARD, 				 		"\x4F",     1,16, FALSE},
		{TAG_EMV_AID_TERMINAL, 		         	"\x9F\x06", 2,16, FALSE},
		{TAG_EMV_TSI, 						 	"\x9B",     1, 2, FALSE},
		{TAG_EMV_TRANSACTION_TIME, 		     	"\x9F\x21", 2, 3, FALSE},
		{TAG_EMV_APPLI_PAN_SEQUENCE_NUMBER,		"\x5F\x34", 2, 1, FALSE},
		{TAG_EMV_IFD_SERIAL_NUMBER,				"\x9F\x1E", 2, 8, FALSE},
		{TAG_EMV_TRANSACTION_CURRENCY_EXPONENT,	"\x5F\x36", 2, 1, FALSE},
		{TAG_EMV_APPLI_VERSION_NUMBER_TERM,		"\x9F\x09", 2, 2, FALSE},
		{TAG_EMV_APPLI_PAN,						"\x5A", 	1,10, FALSE},
		{TAG_EMV_TRANSACTION_SEQUENCE_COUNTER,	"\x9F\x41", 2, 4, FALSE},
		{TAG_EMV_APPLI_EXPIRATION_DATE,			"\x5F\x24", 2, 3, FALSE},
		{TAG_EMV_TRACK_2_EQU_DATA,				"\x57",     1,37, FALSE},
		{TAG_EMV_SERVICE_CODE,					"\x5F\x30", 2, 2, FALSE},
		{TAG_EMV_CARDHOLDER_NAME,				"\x5F\x20", 2,26, FALSE},
		{TAG_EMV_ICC_DYNAMIC_NUMBER,			"\x9F\x4C", 2, 0, FALSE}};

		setCardInputMode (MSRCONTACTLESS);
		if(!removecard)
			CLESS_GUI_DisplayScreen (APCLESS_SCREEN_REMOVE_CARD);
    	unsigned char dataEMV[256] = {0};
    	int i, j = 0;
    	int tagCount = sizeof(JCBRequestTags) / sizeof(JCBRequestTags[0]);
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		unsigned char poscode[1] = {0};
		char  posencode[2]="07";
		Aschex(poscode,posencode, sizeof(posencode));
		GTL_SharedExchange_AddTag(dataStruct, TAG_EMV_POS_ENTRY_MODE, sizeof(poscode), poscode);
    	for (i = 0; i < tagCount; i++){
    		length = 0;
    		position = SHARED_EXCHANGE_POSITION_NULL;
    		if (dataStruct->ulDataLength)
    			GTL_SharedExchange_FindNext(dataStruct, &position, JCBRequestTags[i].tagNum, &length, &ptValue);

    		if (length != 0){
    			memcpy (&dataEMV[j], JCBRequestTags[i].tagName, JCBRequestTags[i].tagNameLength);
    			memcpy (&dataEMV[j + JCBRequestTags[i].tagNameLength], &length, 1);
    			memcpy (&dataEMV[j + JCBRequestTags[i].tagNameLength + 1], ptValue, length);
    			j = j + JCBRequestTags[i].tagNameLength + 1 + length;
    		}
    		else {
    			if (JCBRequestTags[i].mandatoryFlag == TRUE) {
    				memcpy (&dataEMV[j], JCBRequestTags[i].tagName, JCBRequestTags[i].tagNameLength);
    				memcpy (&dataEMV[j + JCBRequestTags[i].tagNameLength], &JCBRequestTags[i].tagDataMinLen, 1);
    				memset (&dataEMV[j + JCBRequestTags[i].tagNameLength + 1], 0, JCBRequestTags[i].tagDataMinLen);
    				j = j + JCBRequestTags[i].tagNameLength + 1 + JCBRequestTags[i].tagDataMinLen;
    			}
    		}
    	}
    	setRequestEMVData(dataEMV, j);

    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_TRANSACTION_CURRENCY_CODE, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
		}
		// Set EMV Application Label
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_APPLICATION_LABEL, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char app[17] = {0};
			memcpy(app,ptValue,length);
			setEMVApplicationLabel(app);
		}
		// set EMV Application Identifier (AID)
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_DF_NAME, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char aid[33] = {0};
			memcpy (aid, hexToASCII(ptValue,length), length*2);
			setEMVApplicationIdentifier (aid);
		}
		// Set Transaction Status Information(TSI)
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_TSI, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char tsi[5] = {0};
			memcpy(tsi,ptValue,length);
			setEMVTransactionStatusInformation(tsi);
		}

    	// Get Card Number (Tag 5A)
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_APPLI_PAN, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char cardNo [20] = {0};
			Hexasc (cardNo, ptValue, length*2);
			int n;
			for (n = 0; n < length*2; n++) {
				if ((int)cardNo[n] < 48 || (int)cardNo[n] > 57)
					cardNo[n] = '\x00';
			}
			setCardNumber(cardNo, strlen(cardNo));
		}
		// Get Card Holder Name
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_CARDHOLDER_NAME, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			setCardHolderName (ptValue, length);
		}
		// Set Expiration Date.
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_APPLI_EXPIRATION_DATE, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char cardAppExp[5] = {0};
			Hexasc(cardAppExp, ptValue, 4);
			setCardExpiryDate(cardAppExp);
		}
		// Get Track Data (Tag 57)
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_TRACK_2_EQU_DATA, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char tag57 [40] = {0};
			memcpy (tag57, unsignedCharToASCII(ptValue,length), length*2);
			int trackLength = 0;
			if (tag57 [0] != 'B'){
				char temp [40] = {0};
				temp [0] = 'B';
				memcpy (temp+1, tag57, length*2);
				trackLength = length*2 + 1;
				memcpy (tag57, temp, trackLength);
				if (tag57 [strlen(tag57) - 1] != 'F'){
					tag57 [strlen(tag57)] = 'F';
					trackLength = trackLength + 1;
				}
			}
			else
				trackLength = length*2;

			char *pcSrc = NULL, *pcDst = NULL;
			char tcTrk2[40] = {'\0'};
			pcSrc = tag57;
			pcDst = tcTrk2;
			while(*pcSrc) {                                  // Find start sentinel
				if(*pcSrc++ == 'B'){
					*pcDst++ = ';';
					break;
				}
			}
			while(*pcSrc) {                                  // Copy all data between start and end sentinels
				if(*pcSrc == 'F'){
					*pcDst = '?';
					break;
				}
				if(*pcSrc == 'D')
					*pcSrc = '=';
				*pcDst++ = *pcSrc++;
			}
			setTrack2Data(tcTrk2, trackLength);
		}
	return result;
}

int ClessSample_JCB_PerformTransaction (T_SHARED_DATA_STRUCT * pKernelDataStruct){

	char*                   pcFuncName = "ClessSample_JCB_PerformTransaction";
	int                     result = CLESS_CR_MANAGER_END;
	int                     cr, nTransactionOutcome;
	unsigned char           ucCvm;
	int                     nCardHolderLang;
	bool                    bGoOnline;
	bool                    bTransactionStillInProgress;
	int                     nTransactionStart;
	char                    asciiTimeWithoutCr[100];
	unsigned short getCardType = 0;

	// reset restart flag
	//gs_bRestartFlag = FALSE;

	// Indicate JCB kernel is going to be used (for customization purposes)
	CLESS_Txn_SetCurrentPaymentScheme (APCLESS_SCHEME_JCB);

	// Get the JCB
	if (CLESS_JCB_AddJCBSpecificData(pKernelDataStruct))
	{
	 // Call the JCB kernel to perform the transaction
	 cr = JCB_DoTransaction(pKernelDataStruct);
	 if ((cr != KERNEL_STATUS_OK)&&
			 (cr != KERNEL_STATUS_CANCELLED)&&
			 (cr != (KERNEL_STATUS_CANCELLED|KERNEL_STATUS_STOPPED_BY_APPLICATION_MASK)))
	 {
		 // Indicate that an error occurred (transaction is terminated)
		 CLESS_GUI_DisplayScreen(APCLESS_SCREEN_ERROR);
		 result = Cless_JCB_EndTransaction(pKernelDataStruct);
		return result;
	 }
	 //get Card Type
	 if (!Cless_JCB_RetrieveCardType(pKernelDataStruct, &getCardType))
	 {
		 getCardType = 0;
	 }

	 // by default, transaction is no more in progress
	 bTransactionStillInProgress = FALSE;

	 // Get the transaction outcome
	 // - JCB_OPS_STATUS_APPROVED if transaction is approved.
	 // - JCB_OPS_STATUS_ONLINE_REQUEST if an online authorization is requested.
	 // - JCB_OPS_STATUS_DECLINED if the transaction is declined.
	 // - JCB_OPS_STATUS_TRY_ANOTHER_INTERFACE transaction should be retried on an other interface.
	 // - JCB_OPS_STATUS_END_APPLICATION if the transaction is terminated.
	 // - JCB_OPS_STATUS_SELECT_NEXT if next AID shall be selected.
	 if (!Cless_JCB_RetrieveTransactionOutcome(pKernelDataStruct, &nTransactionOutcome))
	 {
		 nTransactionOutcome = JCB_OPS_STATUS_END_APPLICATION;
	 }

	 switch (nTransactionOutcome){
	 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	 case JCB_OPS_STATUS_APPROVED:
		 // Get all the kernel data (used to print the receipt)
		 JCB_GetAllData(pKernelDataStruct);
		 // manage the approved outcome
		 result = Cless_JCB_ManageApprovedOutcome(pKernelDataStruct);
		 break;
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	 case JCB_OPS_STATUS_DECLINED:
		 result = Cless_JCB_ManageDeclined(pKernelDataStruct);
		 break;
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	 case JCB_OPS_STATUS_TRY_ANOTHER_INTERFACE:
		 result = Cless_JCB_ManageTryAnotherInterface(pKernelDataStruct);
		 break;
	 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	 case JCB_OPS_STATUS_SELECT_NEXT:
		 result = Cless_JCB_ManageSelectNext(pKernelDataStruct);
		 break;
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	 case JCB_OPS_STATUS_ONLINE_REQUEST:
		 // Get all the kernel data to manage the issuer update processing
		 JCB_GetAllData(pKernelDataStruct);
		 // Get the CVM to be performed
		 if (Cless_JCB_RetrieveCvmToApply(pKernelDataStruct, &ucCvm))
		 {
			 if(ucCvm == JCB_OPS_CVM_ONLINE_PIN)
				setCHVerificationMethod(ONLINE_PIN);
			else if(ucCvm == JCB_OPS_CVM_SIGNATURE)
				setCHVerificationMethod(PAPER_SIGNATURE);
			else
				setCHVerificationMethod(PAPER_SIGNATURE);
		 }
		result = JCB_OnlineRequestData(pKernelDataStruct, getCardType);
		//if PIN online is required and managed it.
		if (getCHVerificationMethod() == ONLINE_PIN ){
			int pinLength;
			switch (APEMV_UI_PinEntry (INPUT_PIN_ON, 3, &pinLength)) {
				case EPSTOOL_PINENTRY_SUCCESS:
					if (encryptPIN() == FALSE)
						setErrorCode("ERROR:033");
					break;
				case EPSTOOL_PINENTRY_TIMEOUT:
					setErrorCode("ERROR:013");
					break;
				case EPSTOOL_PINENTRY_ERROR:
				case EPSTOOL_PINENTRY_CANCEL:
					setErrorCode("ERROR:044");
					break;
				case EPSTOOL_PINENTRY_EVENT:
				case EPSTOOL_PINENTRY_BYPASS:
				default:
					break;
				}
			}
		CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ONLINE_PROCESSING);
		break;
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	 case JCB_OPS_STATUS_END_APPLICATION:
		 result = Cless_JCB_ManageEndApplication(pKernelDataStruct);
		 break;
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	 default:
		 result = Cless_JCB_ManageUnknownOutcome(pKernelDataStruct, nTransactionOutcome);
		break;
	 }

  }

	Cless_JCB_EndTransaction(pKernelDataStruct);
	// Return result
	return (result);

}
