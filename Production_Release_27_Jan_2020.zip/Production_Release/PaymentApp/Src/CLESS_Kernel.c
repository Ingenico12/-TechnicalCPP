/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   04/01/2018   This module This module is used to fill/initialise the kernel *
 *                                  data buffer.                                                  *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "CLESS.h"
#include "transaction.h"
#include "emvparameter.h"

static int __APCLESS_Kernel_CopyAIDParamToSharedBuffer(int aidIdentifier, T_SHARED_DATA_STRUCT* buffer, char* aidvalue);

/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Copy all the tags of an AID to a shared buffer.                                       *
 * 			                                                                                      *
 * [in]	:	aidIdentifier identifies the AID parameters set (correspond to                        *
 *          TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER)	                                              *
 * [out]:   buffer shared buffer where the parameters are copied to.                              *
 * ---------------------------------------------------------------------------------------------- */
static int __APCLESS_Kernel_CopyAIDParamToSharedBuffer(int aidIdentifier, T_SHARED_DATA_STRUCT* buffer, char* aidvalue) {
   int result = FALSE;

   if(aidIdentifier == APCLESS_AID_PAYPASS_IDENTIFIER) {
	   const unsigned long paypass_tag_list[] = {
		        TAG_PAYPASS_CARD_DATA_INPUT_CAPABILITY,
				TAG_PAYPASS_MCHIP_CVM_CAPABILITY_CVM_NOT_REQUIRED,
				TAG_PAYPASS_DEFAULT_UDOL,
				TAG_PAYPASS_INT_MCHIP_TERMINAL_AVN_LIST,
				TAG_PAYPASS_INT_MSTRIPE_TERMINAL_AVN_LIST,
				TAG_EMV_APPLI_VERSION_NUMBER_TERM,
				TAG_PAYPASS_MSTRIPE_INDICATOR,
				TAG_KERNEL_TERMINAL_SUPPORTED_LANGUAGES,
				TAG_PAYPASS_TRANSACTION_CATEGORY_CODE,
				TAG_PAYPASS_TERMINAL_CAPABILITIES_CVM_REQ,
				TAG_PAYPASS_TERMINAL_CAPABILITIES_NO_CVM_REQ,
				TAG_PAYPASS_MSTRIPE_APPLI_VERSION_NUMBER_TERM,
				TAG_PAYPASS_MSTRIPE_CVM_CAPABILITY_CVM_REQUIRED,
				TAG_PAYPASS_MSTRIPE_CVM_CAPABILITY_CVM_NOT_REQUIRED,
				TAG_GENERIC_DETECTION_TYPE,
				TAG_GENERIC_DETECTION_GLOBAL_TIMEOUT,
				TAG_GENERIC_DETECTION_NB_CARDS_TO_DETECT,
				TAG_SAMPLE_NO_CARD_TIMEOUT,
				TAG_EMV_ACQUIRER_IDENTIFIER,
				TAG_EMV_MERCHANT_CATEGORY_CODE,
				TAG_EMV_MERCHANT_IDENTIFIER,
				TAG_EMV_TERMINAL_IDENTIFICATION,
				TAG_GENERIC_DETECTION_NB_CARDS_TO_DETECT
	   };
	   EMVDataElement termParamPayPass[] = {CLESSPayPassParameter};
	   int emvTagCount =  sizeof (paypass_tag_list) / sizeof(unsigned long);
	   int emvParam = sizeof (termParamPayPass) / sizeof (EMVDataElement);
	   int x, y;
	   for (x = 0; x < emvTagCount; x++){
		  for (y = 0; y < emvParam; y++){
			  if (!memcmp(&paypass_tag_list[x],&termParamPayPass[y].tag, sizeof(unsigned long))){
				 if(GTL_SharedExchange_AddTag(buffer, paypass_tag_list[x], termParamPayPass[y].length, termParamPayPass[y].ptValue) != STATUS_SHARED_EXCHANGE_OK) goto End;
			  }
		  }
	   }
	   unsigned char aidPaypass[7] = {0};
	   asciiToHEX(aidvalue,aidPaypass);
	   struct sContactlessTable clessPayPass = {0};
	   if (getCLESSAIDSpecificData (aidPaypass, sizeof(aidPaypass), &clessPayPass)) {
		   unsigned char currCode[2] = {0};
		   unsigned char tac [5];
		   unsigned char amount [6];

           if(!strcmp(aidvalue,"A0000000041010")){
        	   unsigned char terminal_risk [8]={0x6C,0x7A,0x00,0x00,0x00,0x00,0x00,0x00};
        	   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_TERMINAL_RISK_MANAGEMENT_DATA, sizeof(terminal_risk), terminal_risk) != STATUS_SHARED_EXCHANGE_OK) goto End;
        	   unsigned char kernelvalue [1]={0x30};
			   if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_KERNEL_CONFIGURATION, sizeof(kernelvalue), kernelvalue ) != STATUS_SHARED_EXCHANGE_OK) goto End;
			   unsigned char securityvalue [1]={0x08};
			   if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_SECURITY_CAPABILITY, sizeof(securityvalue), securityvalue ) != STATUS_SHARED_EXCHANGE_OK) goto End;
			   unsigned char mchipcvmvalue [1]={0x60};
			   if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_MCHIP_CVM_CAPABILITY_CVM_REQUIRED, sizeof(mchipcvmvalue), mchipcvmvalue ) != STATUS_SHARED_EXCHANGE_OK) goto End;
			   if (!strcmp (getTransactionType(), "REFUND")){
				   unsigned char terminal_type [1]={0x23};
				   if(GTL_SharedExchange_AddTag(buffer, TAG_TERMINAL_TYPE, sizeof(terminal_type), terminal_type) != STATUS_SHARED_EXCHANGE_OK) goto End;
			   }
           }else if(!strcmp(aidvalue,"A0000000043060")){
        	   unsigned char terminal_risk [8]={0x4C,0x5A,0x80,0x00,0x00,0x00,0x00,0x00};
			   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_TERMINAL_RISK_MANAGEMENT_DATA, sizeof(terminal_risk), terminal_risk) != STATUS_SHARED_EXCHANGE_OK) goto End;
			   unsigned char kernelvalue [1]={0xB0};
			   if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_KERNEL_CONFIGURATION, sizeof(kernelvalue), kernelvalue ) != STATUS_SHARED_EXCHANGE_OK) goto End;
			   unsigned char securityvalue [1]={0xC8};
			   if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_SECURITY_CAPABILITY, sizeof(securityvalue), securityvalue ) != STATUS_SHARED_EXCHANGE_OK) goto End;
			   unsigned char mchipcvmvalue [1]={0x40};
			   if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_MCHIP_CVM_CAPABILITY_CVM_REQUIRED, sizeof(mchipcvmvalue), mchipcvmvalue ) != STATUS_SHARED_EXCHANGE_OK) goto End;

           }else if(!strcmp(aidvalue,"A0000000042203")){
        	   unsigned char terminal_risk [8]={0x48,0x48,0x80,0x00,0x00,0x00,0x00,0x00};
        	   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_TERMINAL_RISK_MANAGEMENT_DATA, sizeof(terminal_risk), terminal_risk) != STATUS_SHARED_EXCHANGE_OK) goto End;
        	   unsigned char kernelvalue [1]={0x90};
        	   if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_KERNEL_CONFIGURATION, sizeof(kernelvalue), kernelvalue ) != STATUS_SHARED_EXCHANGE_OK) goto End;
        	   unsigned char securityvalue [1]={0xC8};
        	   if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_SECURITY_CAPABILITY, sizeof(securityvalue), securityvalue ) != STATUS_SHARED_EXCHANGE_OK) goto End;
        	   unsigned char mchipcvmvalue [1]={0x40};
			   if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_MCHIP_CVM_CAPABILITY_CVM_REQUIRED, sizeof(mchipcvmvalue), mchipcvmvalue ) != STATUS_SHARED_EXCHANGE_OK) goto End;
           	   }
		   Aschex(currCode,clessPayPass.currencyCode, sizeof(clessPayPass.currencyCode));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_TRANSACTION_CURRENCY_CODE, sizeof(currCode), currCode) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount,clessPayPass.floorLimit,sizeof(clessPayPass.floorLimit));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_FLOOR_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   if(strcmp(aidvalue,"A0000000042203")){
		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessPayPass.clessTxnLimit_DCVM, sizeof(clessPayPass.clessTxnLimit_DCVM));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_CLESS_TRANSACTION_LIMIT_DCV, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;
		   }


		    memset (amount, 0, sizeof(amount));
		    Aschex (amount, clessPayPass.clessTxnLimit_NODCVM, sizeof(clessPayPass.clessTxnLimit_NODCVM));
		    if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_CLESS_TRANSACTION_LIMIT_NO_DCV, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessPayPass.clessCVMLimit, sizeof(clessPayPass.clessCVMLimit));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_CVM_REQUIRED_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   Aschex (tac, clessPayPass.denialTAC, sizeof(clessPayPass.denialTAC));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_DENIAL, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   char temp1 [11] = {0};
		   memcpy (temp1, clessPayPass.onlineTAC, sizeof (clessPayPass.onlineTAC));
		   asciiToHEX(temp1, tac);
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_ONLINE, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   memset (temp1, 0, sizeof(temp1));
		   memcpy (temp1, clessPayPass.defaultTAC, sizeof (clessPayPass.defaultTAC));
		   asciiToHEX(temp1, tac);
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_DEFAULT, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;
	   }
	   unsigned char aidPaypassCAPKIndexList[] = {0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x09,0x22,0x52,0xEF,0xF0,0xF1,0xF3,0xF5,0xF6,0xF7,0xF8,0xF9,0xFA,0xFB,0xFC,0xFD,0xFE,0xFF};
	   if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_INT_SUPPORTED_CAPK_INDEX_LIST, sizeof(aidPaypassCAPKIndexList), aidPaypassCAPKIndexList) != STATUS_SHARED_EXCHANGE_OK) goto End;
	   // Add following empty tags to activate the card balance
	   if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_BALANCE_READ_BEFORE_GENAC, 0, NULL) != STATUS_SHARED_EXCHANGE_OK) goto End;
	   if(GTL_SharedExchange_AddTag(buffer, TAG_PAYPASS_BALANCE_READ_AFTER_GENAC, 0, NULL) != STATUS_SHARED_EXCHANGE_OK) goto End;

	   result = TRUE;
   }
   else if (aidIdentifier == APCLESS_AID_PAYWAVE_IDENTIFIER) {
	  unsigned char aidpayWaveKernelToUse[] = {0x00, 0x03};             // Visa payWave kernel number = 1
	  unsigned char aidpayWaveOptions[] = {0x05, 0x01, 0x00, 0x00};     // Partial AID, PPSE method
	  if(GTL_SharedExchange_AddTag(buffer, TAG_EP_KERNEL_TO_USE, sizeof(aidpayWaveKernelToUse), aidpayWaveKernelToUse) != STATUS_SHARED_EXCHANGE_OK) goto End;
	  if(GTL_SharedExchange_AddTag(buffer, TAG_EP_AID_OPTIONS, sizeof(aidpayWaveOptions), aidpayWaveOptions) != STATUS_SHARED_EXCHANGE_OK) goto End;

	  const unsigned long paywave_tag_list[] = {
			   TAG_PAYWAVE_TERM_SUPPORTED_FDDA_VERSIONS,
			  // TAG_PAYWAVE_IS_TRANSACTION_LOG_SUPPORTED,
			  // TAG_PAYWAVE_ENABLE_INTERRUPT_ON_READ,
			  // TAG_PAYWAVE_QVSDC_NOT_ALLOWED,
			  // TAG_PAYWAVE_IS_SDA_SUPPORTED,
			   TAG_PAYWAVE_TERMINAL_TRANSACTION_QUALIFIERS,
			   TAG_GENERIC_DETECTION_TYPE,
			   TAG_GENERIC_DETECTION_GLOBAL_TIMEOUT,
			   TAG_GENERIC_DETECTION_NB_CARDS_TO_DETECT,
			   TAG_SAMPLE_NO_CARD_TIMEOUT,
			   TAG_EMV_ACQUIRER_IDENTIFIER,
			   TAG_EMV_MERCHANT_CATEGORY_CODE,
			   TAG_EMV_MERCHANT_IDENTIFIER,
			   TAG_EMV_TERMINAL_IDENTIFICATION,
			   TAG_EMV_TERMINAL_FLOOR_LIMIT
	  };
	  EMVDataElement termParamPayWave[] = {CLESSPayWaveParameter};
	  int emvTagCount =  sizeof (paywave_tag_list) / sizeof(unsigned long);
	  int emvParam = sizeof (termParamPayWave) / sizeof (EMVDataElement);
	  int x, y;
	  for (x = 0; x < emvTagCount; x++){
		  for (y = 0; y < emvParam; y++){
			  if (!memcmp(&paywave_tag_list[x],&termParamPayWave[y].tag, sizeof(unsigned long))){
				  if(GTL_SharedExchange_AddTag(buffer, paywave_tag_list[x], termParamPayWave[y].length, termParamPayWave[y].ptValue) != STATUS_SHARED_EXCHANGE_OK) goto End;
			  }
		  }
	  }
	  unsigned char aidpayWave[] ={0xA0, 0x00, 0x00, 0x00, 0x03, 0x10, 0x10};//{0xA0, 0x00, 0x00, 0x00, 0x03, 0x20, 0x10};//
	  struct sContactlessTable clessPayWave = {0};
	  if (getCLESSAIDSpecificData (aidpayWave, sizeof(aidpayWave), &clessPayWave)) {
		  unsigned char tac [5];
   	      unsigned char amount [6];

   	      memset (amount, 0, sizeof(amount));
   	      Aschex (amount,clessPayWave.floorLimit,sizeof(clessPayWave.floorLimit));
		  if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_FLOOR_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		  memset (amount, 0, sizeof(amount));
		  Aschex (amount, clessPayWave.clessTxnLimit_DCVM, sizeof(clessPayWave.clessTxnLimit_DCVM));
		  if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_TRANSACTION_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		  memset (amount, 0, sizeof(amount));
		  Aschex (amount, clessPayWave.clessCVMLimit, sizeof(clessPayWave.clessCVMLimit));
		  if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_CVM_REQUIRED_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;
		  if(GTL_SharedExchange_AddTag(buffer, TAG_PAYWAVE_CARD_CVM_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		  memset (tac, 0, sizeof(tac));
		  Aschex (tac, clessPayWave.denialTAC, sizeof(clessPayWave.denialTAC));
		  if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_DENIAL, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;

		  memset (tac, 0, sizeof(tac));
		  char temp1 [11] = {0};
		  memcpy (temp1, clessPayWave.onlineTAC, sizeof (clessPayWave.onlineTAC));
		  asciiToHEX(temp1, tac);
		  if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_ONLINE, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;

		  memset (tac, 0, sizeof(tac));
		  memset (temp1, 0, sizeof(temp1));
		  memcpy (temp1, clessPayWave.defaultTAC, sizeof (clessPayWave.defaultTAC));
		  asciiToHEX(temp1, tac);
		  if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_DEFAULT, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;
	  }
	  result = TRUE;
   }
   else if (aidIdentifier == APCLESS_AID_EXPRESSPAY_IDENTIFIER) {
	   const unsigned long expressPay_tag_list [] = {
			   TAG_EXPRESSPAY_UNPREDICTABLE_NUMBER_RANGE,
			   TAG_EXPRESSPAY_INT_TERMINAL_AVN_LIST,
			   TAG_EMV_TERMINAL_CAPABILITIES,
			   TAG_EXPRESSPAY_TERMINAL_CAPABILITIES,
			   TAG_EXPRESSPAY_TERMINAL_TRANSACTION_CAPABILITIES,
			   TAG_EXPRESSPAY_FULL_ONLINE_EMV_REMOVAL_TIMEOUT,
			   TAG_EP_KERNEL_TO_USE,
			   TAG_EP_AID_OPTIONS,
			   TAG_GENERIC_DETECTION_TYPE,
			   TAG_GENERIC_DETECTION_GLOBAL_TIMEOUT,
			   TAG_GENERIC_DETECTION_NB_CARDS_TO_DETECT,
			   TAG_SAMPLE_EXPRESSPAY_DOUBLE_TAP_TIME,
			   TAG_EMV_INT_DEFAULT_TDOL,
			   TAG_SAMPLE_NO_CARD_TIMEOUT,
			   TAG_EMV_TERMINAL_FLOOR_LIMIT
	   };
	   EMVDataElement termParamExpressPay[] = {CLESSExpressPayParameter};
	   int emvTagCount =  sizeof (expressPay_tag_list) / sizeof(unsigned long);
	   int emvParam = sizeof (termParamExpressPay) / sizeof (EMVDataElement);
	   int x, y;
	   for (x = 0; x < emvTagCount; x++){
		  for (y = 0; y < emvParam; y++){
			  if (!memcmp(&expressPay_tag_list[x],&termParamExpressPay[y].tag, sizeof(unsigned long))){
				 if(GTL_SharedExchange_AddTag(buffer, expressPay_tag_list[x], termParamExpressPay[y].length, termParamExpressPay[y].ptValue) != STATUS_SHARED_EXCHANGE_OK) goto End;
			  }
		  }
	   }
	   unsigned char aidExpressPay[] = {0xA0, 0x00, 0x00, 0x00, 0x25, 0x01};
	   struct sContactlessTable clessExpressPay = {0};
	   if (getCLESSAIDSpecificData (aidExpressPay, sizeof(aidExpressPay), &clessExpressPay)) {
		   unsigned char tac [5];
		   unsigned char amount [6];

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessExpressPay.floorLimit, sizeof(clessExpressPay.floorLimit));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_FLOOR_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessExpressPay.clessTxnLimit_DCVM, sizeof(clessExpressPay.clessTxnLimit_DCVM));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_TRANSACTION_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessExpressPay.clessCVMLimit, sizeof(clessExpressPay.clessCVMLimit));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_CVM_REQUIRED_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   Aschex (tac, clessExpressPay.denialTAC, sizeof(clessExpressPay.denialTAC));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_DENIAL, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   char temp1 [11] = {0};
		   memcpy (temp1, clessExpressPay.onlineTAC, sizeof (clessExpressPay.onlineTAC));
		   asciiToHEX(temp1, tac);
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_ONLINE, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   memset (temp1, 0, sizeof(temp1));
		   memcpy (temp1, clessExpressPay.defaultTAC, sizeof (clessExpressPay.defaultTAC));
		   asciiToHEX(temp1, tac);
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_DEFAULT, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;
	   }
	   unsigned char aidExpressPayCAPKIndexList[] = {0x01,0x02,0x03,0x04,0x10,0x52,0x60,0x62,0x64,0x65,0x66,0x67,0x68,0x96,0x97,0x98,0x99,0x0E,0x0F,0xA1,0xC1,0xC2,0xC3,0xC8,0xC9,0xCA};
	   if(GTL_SharedExchange_AddTag(buffer, TAG_EXPRESSPAY_INT_SUPPORTED_CAPK_INDEX_LIST, sizeof(aidExpressPayCAPKIndexList), aidExpressPayCAPKIndexList) != STATUS_SHARED_EXCHANGE_OK) goto End;
	   result = TRUE;
   }
   else if (aidIdentifier == APCLESS_AID_DISCOVERDPAS_IDENTIFIER) {
	   const unsigned long DiscoverDPAS_tag_list [] = {
			   TAG_EMV_APPLI_VERSION_NUMBER_TERM,
			   TAG_EMV_INT_DEFAULT_TDOL,
			   TAG_SAMPLE_NO_CARD_TIMEOUT,
			   TAG_DISCOVER_DPAS_TERMINAL_TRANSACTION_QUALIFIERS,
			   TAG_EMV_TERMINAL_FLOOR_LIMIT
	   };
	   EMVDataElement termParamDiscoverDPAS[] = {CLESSDiscoverDPASPayParameter};
	   int emvTagCount =  sizeof (DiscoverDPAS_tag_list) / sizeof(unsigned long);
	   int emvParam = sizeof (termParamDiscoverDPAS) / sizeof (EMVDataElement);
	   int x, y;
	   for (x = 0; x < emvTagCount; x++){
		   for (y = 0; y < emvParam; y++){
			   if (!memcmp(&DiscoverDPAS_tag_list[x],&termParamDiscoverDPAS[y].tag, sizeof(unsigned long))){
				 if(GTL_SharedExchange_AddTag(buffer, DiscoverDPAS_tag_list[x], termParamDiscoverDPAS[y].length, termParamDiscoverDPAS[y].ptValue) != STATUS_SHARED_EXCHANGE_OK) goto End;
			   }
		   }
	   }
	   unsigned char aidDiscoverDPAS[] = {0xA0, 0x00, 0x00, 0x01, 0x52, 0x30, 0x10};
	   struct sContactlessTable clessDiscoverDPAS = {0};
	   if (getCLESSAIDSpecificData (aidDiscoverDPAS, sizeof(aidDiscoverDPAS), &clessDiscoverDPAS)) {
		   unsigned char tac [5];
		   unsigned char amount [6];

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessDiscoverDPAS.floorLimit, sizeof(clessDiscoverDPAS.floorLimit));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_FLOOR_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessDiscoverDPAS.clessTxnLimit_DCVM, sizeof(clessDiscoverDPAS.clessTxnLimit_DCVM));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_TRANSACTION_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessDiscoverDPAS.clessCVMLimit, sizeof(clessDiscoverDPAS.clessCVMLimit));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_CVM_REQUIRED_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   Aschex (tac, clessDiscoverDPAS.denialTAC, sizeof(clessDiscoverDPAS.denialTAC));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_DENIAL, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   char temp1 [11] = {0};
		   memcpy (temp1, clessDiscoverDPAS.onlineTAC, sizeof (clessDiscoverDPAS.onlineTAC));
		   asciiToHEX(temp1, tac);
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_ONLINE, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   memset (temp1, 0, sizeof(temp1));
		   memcpy (temp1, clessDiscoverDPAS.defaultTAC, sizeof (clessDiscoverDPAS.defaultTAC));
		   asciiToHEX(temp1, tac);
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_DEFAULT, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;
	   }
	   unsigned char aidDiscoverDPASCAPKIndexList[] = {0x52,0x5A,0x5B,0x5C,0x04,0x05};
	   if(GTL_SharedExchange_AddTag(buffer, TAG_DISCOVER_DPAS_INT_SUPPORTED_CAPK_INDEX_LIST, sizeof(aidDiscoverDPASCAPKIndexList), aidDiscoverDPASCAPKIndexList) != STATUS_SHARED_EXCHANGE_OK) goto End;
	   result = TRUE;
   }
   else if (aidIdentifier == APCLESS_AID_DISCOVER_IDENTIFIER) {
	   const unsigned long discoverZIP_tag_list [] = {
			   TAG_EMV_INT_DEFAULT_TDOL,
			   TAG_SAMPLE_NO_CARD_TIMEOUT,
			   TAG_DISCOVER_DPAS_TERMINAL_TRANSACTION_QUALIFIERS,
			   TAG_EMV_TERMINAL_FLOOR_LIMIT
	   };
	   EMVDataElement termParamDiscoverZIP[] = {CLESSDiscoverPayParameter};
	   int emvTagCount =  sizeof (discoverZIP_tag_list) / sizeof(unsigned long);
	   int emvParam = sizeof (termParamDiscoverZIP) / sizeof (EMVDataElement);
	   int x, y;
	   for (x = 0; x < emvTagCount; x++){
		   for (y = 0; y < emvParam; y++){
			   if (!memcmp(&discoverZIP_tag_list[x],&termParamDiscoverZIP[y].tag, sizeof(unsigned long))){
				   if(GTL_SharedExchange_AddTag(buffer, discoverZIP_tag_list[x], termParamDiscoverZIP[y].length, termParamDiscoverZIP[y].ptValue) != STATUS_SHARED_EXCHANGE_OK) goto End;
			   }
		   }
	   }
	   unsigned char aidDiscover[] = {0xA0, 0x00, 0x00, 0x03, 0x24, 0x10, 0x10};
	   struct sContactlessTable clessDiscover = {0};
	   if (getCLESSAIDSpecificData (aidDiscover, sizeof(aidDiscover), &clessDiscover)) {
		   unsigned char tac [5];
		   unsigned char amount [6];

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessDiscover.floorLimit, sizeof(clessDiscover.floorLimit));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_FLOOR_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessDiscover.clessTxnLimit_DCVM, sizeof(clessDiscover.clessTxnLimit_DCVM));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_TRANSACTION_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessDiscover.clessCVMLimit, sizeof(clessDiscover.clessCVMLimit));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_CVM_REQUIRED_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   Aschex (tac, clessDiscover.denialTAC, sizeof(clessDiscover.denialTAC));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_DENIAL, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   char temp1 [11] = {0};
		   memcpy (temp1, clessDiscover.onlineTAC, sizeof (clessDiscover.onlineTAC));
		   asciiToHEX(temp1, tac);
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_ONLINE, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   memset (temp1, 0, sizeof(temp1));
		   memcpy (temp1, clessDiscover.defaultTAC, sizeof (clessDiscover.defaultTAC));
		   asciiToHEX(temp1, tac);
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_DEFAULT, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;
	   }
	   result = TRUE;
   }
   else if (aidIdentifier == APCLESS_AID_JCB_IDENTIFIER) {

	   unsigned char aidJCB[]  			 =	{0xA0, 0x00, 0x00, 0x00, 0x65, 0x10, 0x10};
	   unsigned char aidJCBKernelToUse[] = 	{0x00, 0x05};					// JCB  kernel number = 5
	   unsigned char aidJCBOptions[]	 =	{0x05, 0x01, 0x00, 0x00};     	// Partial AID, PPSE method; 	05 01 00 00

	   struct sContactlessTable clessJCB = {0};
	   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_KERNEL_TO_USE, sizeof(aidJCBKernelToUse), aidJCBKernelToUse) != STATUS_SHARED_EXCHANGE_OK) goto End;
	   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_AID_OPTIONS, sizeof(aidJCBOptions), aidJCBOptions) != STATUS_SHARED_EXCHANGE_OK) goto End;

	   const unsigned long JCB_tag_list [] = {
			   TAG_JCB_COMBINAISON_OPTIONS,
			   TAG_JCB_IMPLEMENTATION_OPTIONS,
			   TAG_JCB_TERMINAL_INTERCHANGE_PROFILE_S,
			   TAG_JCB_THRESHOLD_VALUE_BIASED_RAND_SEL,
			   TAG_EMV_INT_TARGET_PERC_RAND_SEL,
			   TAG_EMV_INT_MAX_TARGET_PERC_BIASED_RAND_SEL,
			   TAG_EP_ASSOCIATED_KERNEL_ID,
			   TAG_GENERIC_DETECTION_TYPE,
			   TAG_GENERIC_DETECTION_GLOBAL_TIMEOUT,
			   TAG_GENERIC_DETECTION_NB_CARDS_TO_DETECT,
			   TAG_SAMPLE_NO_CARD_TIMEOUT,
			   TAG_EMV_ACQUIRER_IDENTIFIER,
			   TAG_EMV_MERCHANT_CATEGORY_CODE,
			   TAG_EMV_MERCHANT_IDENTIFIER,
			   TAG_EMV_TERMINAL_IDENTIFICATION,
			   TAG_KERNEL_REVOKED_CERTIFICATE_LIST,
			   TAG_EMV_TERMINAL_FLOOR_LIMIT
	   };
	   EMVDataElement termParamJCB[] = {CLESSJCBParameter};
	   int emvTagCount =  sizeof (JCB_tag_list) / sizeof(unsigned long);
	   int emvParam = sizeof (termParamJCB) / sizeof (EMVDataElement);
	   int x, y;
	   for (x = 0; x < emvTagCount; x++){
		   for (y = 0; y < emvParam; y++){
			   if (!memcmp(&JCB_tag_list[x],&termParamJCB[y].tag, sizeof(unsigned long))){
				   if(GTL_SharedExchange_AddTag(buffer, JCB_tag_list[x], termParamJCB[y].length, termParamJCB[y].ptValue) != STATUS_SHARED_EXCHANGE_OK) goto End;
			   }
		   }
	   }
	   if (getCLESSAIDSpecificData(aidJCB, sizeof(aidJCB), &clessJCB)) {
		   unsigned char amount [6];
		   unsigned char tac [5];

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessJCB.floorLimit, sizeof(clessJCB.floorLimit));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_FLOOR_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessJCB.clessTxnLimit_DCVM, sizeof(clessJCB.clessTxnLimit_DCVM));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_TRANSACTION_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (amount, 0, sizeof(amount));
		   Aschex (amount, clessJCB.clessCVMLimit, sizeof(clessJCB.clessCVMLimit));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EP_CLESS_CVM_REQUIRED_LIMIT, sizeof(amount), amount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   Aschex (tac, clessJCB.denialTAC, sizeof(clessJCB.denialTAC));
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_DENIAL, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   char temp1 [11] = {0};
		   memcpy (temp1, clessJCB.onlineTAC, sizeof (clessJCB.onlineTAC));
		   asciiToHEX(temp1, tac);
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_ONLINE, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;

		   memset (tac, 0, sizeof(tac));
		   memset (temp1, 0, sizeof(temp1));
		   memcpy (temp1, clessJCB.defaultTAC, sizeof (clessJCB.defaultTAC));
		   asciiToHEX(temp1, tac);
		   if(GTL_SharedExchange_AddTag(buffer, TAG_EMV_INT_TAC_DEFAULT, sizeof(tac), tac) != STATUS_SHARED_EXCHANGE_OK) goto End;
		   unsigned char aidDiscoverJCBCAPKIndexList[] = {0x0F,0x11,0x13,0x50,0x51,0x53};
		  if(GTL_SharedExchange_AddTag(buffer, TAG_JCB_INT_SUPPORTED_CAPK_INDEX_LIST, sizeof(aidDiscoverJCBCAPKIndexList), aidDiscoverJCBCAPKIndexList) != STATUS_SHARED_EXCHANGE_OK) goto End;
	   }
	   result = TRUE;
   }
End:
   return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Add the generic transaction data in the kernel shared buffer (date, time, amount, etc)*
 * 			                                                                                      *
 * [out]:   kernelSharedData Shared exchange structure filled with the generic transaction data.  *
 * ---------------------------------------------------------------------------------------------- */
int CLESS_AddTransactionGenericData (T_SHARED_DATA_STRUCT* kernelSharedData) {
	int result;
	NO_SERIE serial={0};

	result = FALSE;

	if(kernelSharedData == NULL) {
		goto End;
	}

	if (GTL_SharedExchange_AddTag(kernelSharedData, TAG_EMV_TRANSACTION_DATE, 3, CLESS_Txn_GetDate()) != STATUS_SHARED_EXCHANGE_OK) goto End;
	if (GTL_SharedExchange_AddTag(kernelSharedData, TAG_EMV_TRANSACTION_TIME, 3, CLESS_Txn_GetTime()) != STATUS_SHARED_EXCHANGE_OK) goto End;
	if(CLESS_Txn_GetAmountBcd() != NULL) {
		if (GTL_SharedExchange_AddTag(kernelSharedData, TAG_EMV_AMOUNT_AUTH_NUM, 6, CLESS_Txn_GetAmountBcd()) != STATUS_SHARED_EXCHANGE_OK) goto End;
		if (GTL_SharedExchange_AddTag(kernelSharedData, TAG_EMV_AMOUNT_AUTH_BIN, 4, CLESS_Txn_GetAmountBin()) != STATUS_SHARED_EXCHANGE_OK) goto End;

		unsigned char otherAmount [6] = {0};
		if (GTL_SharedExchange_AddTag(kernelSharedData, TAG_EMV_AMOUNT_OTHER_NUM, 6, otherAmount) != STATUS_SHARED_EXCHANGE_OK) goto End;
		if (GTL_SharedExchange_AddTag(kernelSharedData, TAG_EMV_AMOUNT_OTHER_BIN, 4, otherAmount) != STATUS_SHARED_EXCHANGE_OK) goto End;

		const unsigned long cless_tag_list[] = {
			TAG_EMV_TERMINAL_TYPE,
			TAG_EMV_TERMINAL_CAPABILITIES,
			TAG_ADD_TERMINAL_CAPABILITIES,
			TAG_KERNEL_TERMINAL_SUPPORTED_LANGUAGES,
			TAG_EMV_TRANSACTION_CURRENCY_CODE,
			TAG_EMV_TRANSACTION_CURRENCY_EXPONENT,
			TAG_EMV_TERMINAL_COUNTRY_CODE
        };
        EMVDataElement termParam[] = {CLESSParameter};
        int emvTagCount =  sizeof (cless_tag_list) / sizeof(unsigned long);
        int emvParam = sizeof (termParam) / sizeof (EMVDataElement);
        int x, y;
        for (x = 0; x < emvTagCount; x++){
        	for (y = 0; y < emvParam; y++){
        		if (!memcmp(&cless_tag_list[x],&termParam[y].tag, sizeof(unsigned long))){
        			if (GTL_SharedExchange_AddTag(kernelSharedData, cless_tag_list[x], termParam[y].length, termParam[y].ptValue) != STATUS_SHARED_EXCHANGE_OK) goto End;
        		}
        	}
        }
	}
	unsigned char buffer[4] = {0};
	// Debit
	if (strcmp(getTransactionType(), REFUND)) {
		buffer[0] = APCLESS_TRANSACTION_TYPE_DEBIT;
		if (GTL_SharedExchange_AddTag(kernelSharedData, TAG_EMV_INT_TRANSACTION_TYPE, 1, buffer) != STATUS_SHARED_EXCHANGE_OK) goto End;
		if (GTL_SharedExchange_AddTag(kernelSharedData, TAG_EMV_TRANSACTION_TYPE, 1, buffer) != STATUS_SHARED_EXCHANGE_OK) goto End;
	}
	// Credit
	else {
		buffer[0] = APCLESS_TRANSACTION_TYPE_REFUND;
		if (GTL_SharedExchange_AddTag(kernelSharedData, TAG_EMV_INT_TRANSACTION_TYPE, 1, buffer) != STATUS_SHARED_EXCHANGE_OK) goto End;
		if (GTL_SharedExchange_AddTag(kernelSharedData, TAG_EMV_TRANSACTION_TYPE, 1, buffer) != STATUS_SHARED_EXCHANGE_OK) goto End;
	}
	// Extract Serial Number and add it to the data
	PSQ_Give_Serial_Number(serial);
	if (GTL_SharedExchange_AddTag(kernelSharedData, TAG_EMV_IFD_SERIAL_NUMBER, 8, (unsigned char *)serial) != STATUS_SHARED_EXCHANGE_OK) goto End;
	// Add the transaction sequence counter
	if (CLESS_Txn_AddTscToSharedBuffer(kernelSharedData) == FALSE)  goto End;
	result = TRUE;
End:
	return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Find the correct AID parameters (to perform the transaction) according to the         *
 *          application selection result and add the parameters to the kernel shared buffer.      *
 * 			                                                                                      *
 * [in] :   selectionSharedData Shared buffer containing the application selection results.       *
 * [out]:   kernelSharedData Shared buffer to be filled with the correct AID parameters           *
 *          (depending on the Application Selection results).                                     *
 * [out]:   kernelToUse Indicates the kernel to be used for the transaction.                      *
 * ---------------------------------------------------------------------------------------------- */
int CLESS_AddAIDRelatedData (T_SHARED_DATA_STRUCT* selectionSharedData, T_SHARED_DATA_STRUCT* kernelSharedData, int* kernelToUse) {
   int result = FALSE;
   int cr, cr2;
   int position;
   char aid[33] = {0};
   int aidIndex = 0xff;
   unsigned long readTag;
   unsigned long readLength;
   const unsigned char* readValue;
   T_SHARED_DATA_STRUCT candidateElementTags;
   //unsigned char* cardAid;
   //unsigned int  cardAidLength;

   if (kernelToUse != NULL)
	  *kernelToUse = DEFAULT_EP_KERNEL_UNKNOWN;

   if ((selectionSharedData == NULL) || (kernelSharedData == NULL))  goto End;

   // TODO: Find the good Candidate Element in the Candidate List sent by EntryPoint
   // (it is possible to have several candidate element at the same time)
   // For this sample, we just use the first candidate element (no further check).
   position = SHARED_EXCHANGE_POSITION_NULL;
   if (GTL_SharedExchange_FindNext(selectionSharedData, &position, TAG_EP_CANDIDATE_LIST_ELEMENT, &readLength, &readValue)!= STATUS_SHARED_EXCHANGE_OK) goto End;

   // init the candidateElementTags shared buffer with TAG_EP_CANDIDATE_LIST_ELEMENT found
   if (GTL_SharedExchange_InitEx(&candidateElementTags, readLength, readLength, (unsigned char *)readValue) != STATUS_SHARED_EXCHANGE_OK)  goto End;

   // Get the Kernel to Use
   position = SHARED_EXCHANGE_POSITION_NULL;
   if(GTL_SharedExchange_FindNext (&candidateElementTags, &position, TAG_EP_KERNEL_TO_USE, &readLength, &readValue)!= STATUS_SHARED_EXCHANGE_OK) goto End;

   if (kernelToUse != NULL)
	   *kernelToUse = readValue[1] + (readValue[0] << 8);

   // Get the AID proprietary identifier
   position = SHARED_EXCHANGE_POSITION_NULL;
   if(GTL_SharedExchange_FindNext (&candidateElementTags, &position, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, &readLength, &readValue)!= STATUS_SHARED_EXCHANGE_OK)  goto End;

   aidIndex = readValue[3] + (readValue[2] << 8) + (readValue[1] << 16) + (readValue[0] << 24);
   // TODO: Reactivate the code below to get the AID or DF NAME
#if 0
   // Get the AID from TAG_EMV_AID_CARD or from TAG_EMV_DF_NAME
   position = SHARED_EXCHANGE_POSITION_NULL;
   if(GTL_SharedExchange_FindNext (&candidateElementTags, &position, TAG_EMV_AID_CARD, &readLength, &readValue)!= STATUS_SHARED_EXCHANGE_OK)
   {
	  position = SHARED_EXCHANGE_POSITION_NULL;
	  if(GTL_SharedExchange_FindNext (&candidateElementTags, &position, TAG_EMV_DF_NAME, &readLength, &readValue)!= STATUS_SHARED_EXCHANGE_OK)
	  {
		 goto End;
	  }
   }
   cardAid = (unsigned char*)readValue;
   cardAidLength = readLength;
#endif

   // Add the AID's parameters to the kernel shared buffer
   	readLength = 0;
	position = SHARED_EXCHANGE_POSITION_NULL;
	if (GTL_SharedExchange_FindNext(&candidateElementTags, &position, TAG_EMV_AID_TERMINAL, &readLength, &readValue) == STATUS_SHARED_EXCHANGE_OK) {
		if(readLength>7)
		 readLength=7;
		memcpy (aid, hexToASCII(readValue,readLength), readLength*2);
	}
   if(__APCLESS_Kernel_CopyAIDParamToSharedBuffer(aidIndex, kernelSharedData,aid) == FALSE)  goto End;

   // Add some of the candidate element tags to the kernel shared buffer
   position = SHARED_EXCHANGE_POSITION_NULL;
   cr2 = STATUS_SHARED_EXCHANGE_OK;
   while (cr2 == STATUS_SHARED_EXCHANGE_OK) {
	  cr2 = GTL_SharedExchange_GetNext(&candidateElementTags, &position, &readTag, &readLength, &readValue);

	  if (cr2 == STATUS_SHARED_EXCHANGE_OK) {
		 switch (readTag) {
			case TAG_EP_AID_ADDITIONAL_RESULTS:
			case TAG_EMV_AID_TERMINAL:
			case TAG_EP_CLESS_APPLI_CAPABILITY_TYPE:
			case TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER:
			   cr2 = GTL_SharedExchange_AddTag(kernelSharedData, readTag, readLength, readValue);
			   if (cr2 != STATUS_SHARED_EXCHANGE_OK)  goto End;
			   break;

			default:
			   break;
		 }
	  }
   }

   // Add Final Select SW
   position = SHARED_EXCHANGE_POSITION_NULL;
   cr = GTL_SharedExchange_FindNext (selectionSharedData, &position, TAG_EP_FINAL_SELECT_STATUS_WORD, &readLength, &readValue);
   if (cr == STATUS_SHARED_EXCHANGE_OK)  {   // If tag with AID informations found
	  cr2 = GTL_SharedExchange_AddTag (kernelSharedData, TAG_EP_FINAL_SELECT_STATUS_WORD, readLength, readValue);
	  if (cr2 != STATUS_SHARED_EXCHANGE_OK) goto End;
   }
   else {
	  goto End;
   }

   // Add Final Select Response
   position = SHARED_EXCHANGE_POSITION_NULL;
   cr = GTL_SharedExchange_FindNext (selectionSharedData, &position, TAG_EP_FINAL_SELECT_RESPONSE, &readLength, &readValue);
   if (cr == STATUS_SHARED_EXCHANGE_OK)  // If tag with AID informations found
   {
	  cr2 = GTL_SharedExchange_AddTag (kernelSharedData, TAG_EP_FINAL_SELECT_RESPONSE, readLength, readValue);
	  if (cr2 != STATUS_SHARED_EXCHANGE_OK)
	  {
		 goto End;
	  }
   }
   else
   {
	  // No error management, as a card could answer only a SW without data (in case of processing error)
   }

   // Add Final Select Command
   position = SHARED_EXCHANGE_POSITION_NULL;
   cr = GTL_SharedExchange_FindNext (selectionSharedData, &position, TAG_EP_FINAL_SELECT_COMMAND_SENT, &readLength, &readValue);
   if (cr == STATUS_SHARED_EXCHANGE_OK)  // If tag with AID informations found
   {
	  cr2 = GTL_SharedExchange_AddTag (kernelSharedData, TAG_EP_FINAL_SELECT_COMMAND_SENT, readLength, readValue);
	  if (cr2 != STATUS_SHARED_EXCHANGE_OK)
	  {
		 goto End;
	  }

	  result = TRUE;
   }

End:

   if(result == FALSE)  //case an error occurs
   {
	  GTL_SharedExchange_ClearEx (kernelSharedData, FALSE);
   }

   return result;
}
static T_SERVICE_CALL_SHARED_EXCHANGE_STRUCT* __GetSharedStructFromServiceCall(void *pData) {
   return (T_SERVICE_CALL_SHARED_EXCHANGE_STRUCT *)pData;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: This service is called by the contactless kernels for customisation processing.       *
 *  		This is the application that provide kernel the service and the application type to   *
 *  		call for customisation.                                                               *
 *                                                                                                *
 * [in] :   size Size of data (not used as data is a shared service call struct). 		          *
 * [in,out]: data Data buffer to be used to get and provide data to the kernel.                   *
 * ---------------------------------------------------------------------------------------------- */
int APCLESS_ServicesKernel_Custom(unsigned int size, void* data) {
   int cr;
   int result = KERNEL_STATUS_CONTINUE;
   int position;
   unsigned long readLength;
   unsigned char* readValue = NULL;
   unsigned char customStep;
   T_SHARED_DATA_STRUCT* sharedData;
   (void) size;

   sharedData = (__GetSharedStructFromServiceCall(data))->pDataStruct;

   // Get the step to be customised
   position = SHARED_EXCHANGE_POSITION_NULL;
   cr = GTL_SharedExchange_FindNext (sharedData, &position, TAG_KERNEL_CUSTOM_STEP, &readLength, (const unsigned char **)&readValue);

   if (cr == STATUS_SHARED_EXCHANGE_OK) {
	  customStep = readValue[0];

	  switch (CLESS_Txn_GetCurrentPaymentScheme()) {
		 case APCLESS_SCHEME_PAYPASS:
			result = CLESS_PayPass_KernelCustomiseStep (sharedData, customStep);
			break;

		 case APCLESS_SCHEME_PAYWAVE:
			result = CLESS_PayWave_KernelCustomiseStep(sharedData, customStep);
			break;

		 case APCLESS_SCHEME_EXPRESSPAY:
			 result = ClessSample_ExpressPay_CustomiseStep (sharedData, customStep);
			 break;

		 case APCLESS_SCHEME_DISCOVER_DPAS:
			 result = CLESS_DiscoverDPAS_CustomiseStep(sharedData, customStep);
			 break;

		 case APCLESS_SCHEME_DISCOVER:
			 result = CLESS_Discover_CustomiseStep (sharedData, customStep);
			 break;

		 default:
			break;
	  }
  }
  return result;
}
