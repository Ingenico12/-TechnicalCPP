/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   06/30/2018   This module implements the EMV Engine services related        *
 * 									to Cardholder Verification.                                   *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "SEC_interface.h"
#include "GL_GraphicLib.h"
#include "TlvTree.h"
#include "GTL_Assert.h"
#include "_emvdctag_.h"
#include "def_tag.h"
#include "EngineInterface.h"
#include "EngineInterfaceLib.h"
#include "servcomm.h"

#include "EPSTOOL_TlvTree.h"
#include "EPSTOOL_PinEntry.h"

#include "EMV.h"
#include "transaction.h"

static void emvPinEntry (int pinType, unsigned short *statusCode, int *methodResult, TLV_TREE_NODE outputTlvTree);
static void emvStepCardholderVerification (int firstCall, unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree);

/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Ask for a PIN entry and analyse the status.                                           *
 * 			                                                                                      *
 * [in] :   pinType The type of the PIN entry: INPUT_PIN_OFF/INPUT_PIN_ON                         *
 * [out]:   methodResult The result of the PIN entry. To be set in tag TAG_AUTOMATE               *
 * 			outputTlvTree Will be filled with all necessary data for the PIN entry process        *
 * 			(PIN bypass indicator ...).                                                           *
 * ---------------------------------------------------------------------------------------------- */
static void emvPinEntry (int pinType, unsigned short *statusCode, int *methodResult, TLV_TREE_NODE outputTlvTree) {
	const char pinCode[] = "************";
	int pinLength;
	unsigned char bypass;
	int pinTryCounter;
	EPSTOOL_Data_t dataPinTryCounter;

	ASSERT((pinType == INPUT_PIN_OFF) || (pinType == INPUT_PIN_ON));
	ASSERT(statusCode != NULL);
	ASSERT(methodResult != NULL);
	ASSERT(outputTlvTree != NULL);

	pinTryCounter = -1;
	if (pinType == INPUT_PIN_OFF) {
		TLV_TREE_NODE tlvTree;

		// Retrieve the PIN Try Counter
		tlvTree = Engine_GetDataElement(TAG_REMAINING_PIN);
		if (tlvTree != NULL) {
			if (EPSTOOL_TlvTree_FindFirstData(tlvTree, TAG_REMAINING_PIN, &dataPinTryCounter) != NULL) {
				if ((dataPinTryCounter.length == 1) && (dataPinTryCounter.value != NULL)) {
					pinTryCounter = *dataPinTryCounter.value;
				}
			}
			EPSTOOL_TlvTree_Release(&tlvTree);
		}
	}

	// Ask for the PIN entry
	switch(APEMV_UI_PinEntry(pinType, pinTryCounter, &pinLength)) {
	case EPSTOOL_PINENTRY_SUCCESS:
		if(pinType == INPUT_PIN_ON){
			if (encryptPIN() == FALSE)
				setErrorCode("ERROR:033");
		}
		// PIN has been entered => give the length of the PIN in TAG_PIN_CODE
		VERIFY(TlvTree_AddChild(outputTlvTree, TAG_PIN_CODE, (unsigned char *)pinCode, pinLength) != NULL);
		*methodResult = pinType;
		break;
	case EPSTOOL_PINENTRY_BYPASS:
		// PIN bypass is requested by the cardholder
		bypass = 0x01;
		VERIFY(TlvTree_AddChild(outputTlvTree, TAG_BYPASS_PIN, &bypass, 1) != NULL);
		*methodResult = NO_INPUT;
		break;
	case EPSTOOL_PINENTRY_TIMEOUT:
		// Timeout
		*methodResult = TO_INPUT;
		break;
	case EPSTOOL_PINENTRY_ERROR:
		// Error => the pinpad is out of order
		*methodResult = PP_HS;
		break;
	case EPSTOOL_PINENTRY_EVENT:
		// An external event occurred, in our case it is because the card has been removed
		*statusCode = TAG_CUST_REMOVED_CARD;
		*methodResult = NO_INPUT;
		break;
	case EPSTOOL_PINENTRY_CANCEL:
		// PIN entry has been cancelled by the cardholder
		*methodResult = CANCEL_INPUT;
		setPINEntryCancelbyCardholder(PIN_ENTRY_CANCELLED_BY_CARDHOLDER);
		break;
	default:
		// PIN entry has been cancelled by the cardholder, or an unknown error occurred => stop
		*statusCode = TAG_CUST_PROCESSING_ERROR;
		*methodResult = NO_INPUT;
		break;
	}
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose: Called when the cardholder must be authenticated.                                 *
 * 			                                                                                  *
 * [in] :   firstCall = TRUE if it is the first call. StepCardholderVerificationFirst()       *
 * 			inputTlvTree Input TlvTree. That especially contains the method to use in         *
 * 			TAG_STATUS_CVP and the signature requested indicator in TAG_SIGNATURE. These      *
 * 	        indicators are set by EMV Engine.                                                 *
 * [out]:   outputTlvTree Output TlvTree must be filled with at least TAG_AUTOMATE (set it to *
 *  		0 to terminate CVM). Others tags may be given depending on the method such as     *
 *  		TAG_BYPASS_PIN and TAG_PIN_CODE for PIN, or PROPRIETARY_METHOD for a proprietary  *
 *  		method.	                                                                          *
 * ------------------------------------------------------------------------------------------ */
static void emvStepCardholderVerification (int firstCall, unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	static int offlinePinTries = 0;
	EPSTOOL_Data_t dataSignature;
	EPSTOOL_Data_t dataCvp;
	int signature;
	int methodResult;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	if (*statusCode == TAG_CUST_PROCESS_COMPLETED) {
		if (firstCall) {
			offlinePinTries = 0;
		}

		// Retrieve TAG_SIGNATURE
		signature = FALSE;
		if (EPSTOOL_TlvTree_FindFirstData(inputTlvTree, TAG_SIGNATURE, &dataSignature) != NULL) {
			if ((dataSignature.length == 1) && (dataSignature.value != NULL)) {
				signature = (*(dataSignature.value) != 0);
			}
		}

		// Retrieve TAG_STATUS_CVP
		if (EPSTOOL_TlvTree_FindFirstData(inputTlvTree, TAG_STATUS_CVP, &dataCvp) != NULL) {
			if ((dataCvp.length == 1) && (dataCvp.value != NULL)) {
				//*dataCvp.value=NO_INPUT;
				switch(*dataCvp.value) {
				case NO_INPUT:
					if(offlinePinTries > 3){
						setErrorCode("ERROR:046");
						break;
					}
					if (signature) {
						// Only signature is required
						// TODO: Request signature ?
						APEMV_UI_RequestSignature ();
					}
					methodResult = NO_INPUT;
					break;
				case NO_REMAINING_PIN:
					// There is no remaining PIN => display message
					APEMV_UI_MessageNoRemainingPin();

					if (signature) {
						// TODO: Request signature ?
						APEMV_UI_RequestSignature ();
					}
					methodResult = NO_REMAINING_PIN;
					break;
				case INPUT_PIN_OFF:
					if (offlinePinTries > 0) {
						// The previous entered PIN is wrong => display message
						APEMV_UI_MessageWrongPin();
					}
					offlinePinTries++;

					// Ask for an offline PIN
					emvPinEntry (INPUT_PIN_OFF, statusCode, &methodResult, outputTlvTree);
					if(offlinePinTries == 3){
						offlinePinTries++;
					}
					break;

				case INPUT_PIN_ON:
					// Ask for an online PIN
					emvPinEntry (INPUT_PIN_ON, statusCode, &methodResult, outputTlvTree);

					// Request a signature if requested and if PIN entry was done successfully
					if ((signature) && (methodResult == INPUT_PIN_ON)) {
						// Request signature
						// TODO: Request signature ?
						APEMV_UI_RequestSignature();
					}
					break;

				case INPUT_PIN_OK:
					// The previous entered PIN is correct => display message
					APEMV_UI_MessageCorrectPin();

					if (signature) {
						// Request signature
						// TODO: Request signature ?
						APEMV_UI_RequestSignature();
					}
					methodResult = 0;
					break;

				case PROPRIETARY_METHOD:
					// The selected method is a proprietary one

					// TODO: Set TAG_RESULT_PROPRIETARY_METHOD
					methodResult = PROPRIETARY_METHOD;
					break;

				default:
					// Unknown method
					methodResult = 0;
					break;
				}

				// Set TAG_AUTOMATE
				if (!TlvTree_AddChild(outputTlvTree, TAG_AUTOMATE, &methodResult, 1)) {
					*statusCode = TAG_CUST_PROCESSING_ERROR;
				}
			}
			else {
				*statusCode = TAG_CUST_PROCESSING_ERROR;
			}
		}
		else {
			*statusCode = TAG_CUST_PROCESSING_ERROR;
		}
	}
	emvTransacStatusSet (*statusCode);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose: Called when the cardholder must be authenticated.                                 *
 * 			                                                                                  *
 * [in] :   inputTlvTree Input TlvTree. That especially contains the method to use in         *
 * 			TAG_STATUS_CVP and the signature requested indicator in TAG_SIGNATURE. These      *
 * 	        indicators are set by EMV Engine.                                                 *
 * [out]:   outputTlvTree Output TlvTree must be filled with at least TAG_AUTOMATE (set it to *
 *  		0 to terminate CVM). Others tags may be given depending on the method such as     *
 *  		TAG_BYPASS_PIN and TAG_PIN_CODE for PIN, or PROPRIETARY_METHOD for a proprietary  *
 *  		method.	                                                                          *
 * ------------------------------------------------------------------------------------------ */
void emvStepCardholderVerificationFirst (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	emvStepCardholderVerification (TRUE, statusCode, inputTlvTree, outputTlvTree);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose: Called when the cardholder must be authenticated.                                 *
 * 			                                                                                  *
 * [in] :	inputTlvTree Input TlvTree that especially contains the method to use in          *
 * 			TAG_STATUS_CVP and the signature requested indicator in TAG_SIGNATURE.	          *
 * [out]:	outputTlvTree Output TlvTree must be filled with at least TAG_AUTOMATE            *
 *  		(set it to 0 to terminate CVM).                                                   *
 *  		Others tags may be given depending on the method such as TAG_BYPASS_PIN and       *
 *  		TAG_PIN_CODE for PIN, or PROPRIETARY_METHOD for a proprietary method.             *
 * ------------------------------------------------------------------------------------------ */
void emvStepCardholderVerificationOther (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	emvStepCardholderVerification (FALSE, statusCode, inputTlvTree, outputTlvTree);
}
