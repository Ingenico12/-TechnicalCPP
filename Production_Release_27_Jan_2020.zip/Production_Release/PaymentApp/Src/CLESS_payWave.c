/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   12/31/2018   This module manages Visa payWave transactions.                *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "CLESS.h"
#include "sec_interface.h"
#include "EPSTOOL_PinEntry.h"
#include "transaction.h"

#define __APCLESS_PAYWAVE_CARD_REPRESENT_TO           20    ///< Time out in seconds for representing the card

static int  CLESS_payWave_AddpayWaveSpecificData(T_SHARED_DATA_STRUCT* dataStruct);
static int  CLESS_payWave_IsPinOnLineRequested(T_SHARED_DATA_STRUCT* resultDataStruct);
static int  CLESS_payWave_IsSignatureRequested (T_SHARED_DATA_STRUCT* resultDataStruct);
static int  CLESS_payWave_DisplaySreenWithBalance(unsigned long screenId, T_SHARED_DATA_STRUCT* dataStruct);
static int  CLESS_payWave_CheckISPConditions(T_SHARED_DATA_STRUCT* sharedStructure);
static int  CLESS_payWave_WaitClessCard(T_SHARED_DATA_STRUCT* dataStruct);
static void CLESS_payWave_StopClessCard(void);
static int  CLESS_payWave_ManageAfterTrn(T_SHARED_DATA_STRUCT* dataStruct, int* stepExecuted);
static int  CLESS_payWave_CallAuthorisationHost(T_SHARED_DATA_STRUCT* dataStruct);
static int  CLESS_payWave_ManageOnLineAuthorisation(T_SHARED_DATA_STRUCT* dataStruct);
static const char gsTerminalSupportedLanguage[] =
{
	"en"
	"fr"
};

/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Fill buffer with specific payWave for transaction.                                    *
 * 			                                                                                      *
 * [out]: 	dataStruct Shared exchange structure filled with the specific payWave data.           *
 * [return]: TRUE if correctly performed.                                                         *
 * 			 FALSE if an error occurred.                                                          *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_payWave_AddpayWaveSpecificData(T_SHARED_DATA_STRUCT* dataStruct) {
	int cr, nResult;
	T_KERNEL_TRANSACTION_FLOW_CUSTOM sTransactionFlowCustom;
	object_info_t ObjectInfo;
	unsigned char StepInterruption[KERNEL_PAYMENT_FLOW_STOP_LENGTH];// Bit field to stop payment flow,
																	// if all bit set to 0 => no stop during payment process
									                                // if right bit set to 1 : stop after payment step number 1
	unsigned char StepCustom[KERNEL_PAYMENT_FLOW_CUSTOM_LENGTH]; 	// Bit field to custom payment flow,
																	// if all bit set to 0 => no stop during payment process
									                                // if right bit set to 1 : stop after payment step number 1
	if (dataStruct == NULL)
	{
		GTL_Traces_TraceDebug("__ClessSample_payWave_AddpayWaveSpecificData : Invalid Input data");
		nResult = FALSE;
		goto End;
	}

	// Init parameteters
	memset(StepInterruption, 0, sizeof(StepInterruption)); // Default Value : not stop on process
	memset(StepCustom, 0, sizeof(StepCustom)); // Default Value : not stop on process
	nResult = TRUE;

	// Customize steps :
	ADD_STEP_CUSTOM(STEP_PAYWAVE_MSD_REMOVE_CARD,StepCustom); 			// To do GUI when MStripe card has been read
	ADD_STEP_CUSTOM(STEP_PAYWAVE_QVSDC_REMOVE_CARD,StepCustom); 		// To do GUI when MChip card has been read
	ADD_STEP_CUSTOM(STEP_PAYWAVE_QVSDC_GET_CERTIFICATE,StepCustom); 	// To get the certificate for ODA step

	//if (ClessSample_IsBlackListPresent())
		ADD_STEP_CUSTOM(STEP_PAYWAVE_QVSDC_BLACK_LIST_CONTROL,StepCustom);	// To check Pan in Black list

	ObjectGetInfo(OBJECT_TYPE_APPLI, ApplicationGetCurrent(), &ObjectInfo);


	// Add a tag for Do_Txn management
	cr = GTL_SharedExchange_AddTag(dataStruct, TAG_KERNEL_PAYMENT_FLOW_STOP, KERNEL_PAYMENT_FLOW_STOP_LENGTH, (const unsigned char *)StepInterruption);
	if (cr != STATUS_SHARED_EXCHANGE_OK)
	{
		GTL_Traces_TraceDebug("__ClessSample_payWave_AddpayWaveSpecificData : Unable to add TAG_KERNEL_PAYMENT_FLOW_STOP in shared buffer (cr=%02x)", cr);
		nResult = FALSE;
		goto End;
	}

	// Add a tag for Do_Txn management
	memcpy ((void*)&sTransactionFlowCustom, (void*)StepCustom, KERNEL_PAYMENT_FLOW_CUSTOM_LENGTH);
	sTransactionFlowCustom.usApplicationType = ObjectInfo.application_type; // Kernel will call this application for customisation
	sTransactionFlowCustom.usServiceId = SERVICE_CUSTOM_KERNEL; // Kernel will call SERVICE_CUSTOM_KERNEL service id for customisation

    cr = GTL_SharedExchange_AddTag(dataStruct, TAG_KERNEL_PAYMENT_FLOW_CUSTOM, sizeof(T_KERNEL_TRANSACTION_FLOW_CUSTOM), (const unsigned char *)&sTransactionFlowCustom);
	if (cr != STATUS_SHARED_EXCHANGE_OK)
	{
		GTL_Traces_TraceDebug("__ClessSample_payWave_AddpayWaveSpecificData : Unable to add TAG_KERNEL_PAYMENT_FLOW_CUSTOM in shared buffer (cr=%02x)", cr);
		nResult = FALSE;
		goto End;
	}

	// Add Tag TAG_KERNEL_TERMINAL_SUPPORTED_LANGUAGES
    cr = GTL_SharedExchange_AddTag(dataStruct, TAG_KERNEL_TERMINAL_SUPPORTED_LANGUAGES, sizeof(gsTerminalSupportedLanguage), (const unsigned char *)&gsTerminalSupportedLanguage);
	if (cr != STATUS_SHARED_EXCHANGE_OK)
	{
		GTL_Traces_TraceDebug("__ClessSample_payWave_AddpayWaveSpecificData : Unable to add TAG_KERNEL_TERMINAL_SUPPORTED_LANGUAGES in shared buffer (cr=%02x)", cr);
		nResult = FALSE;
		goto End;
	}

End:
	return (nResult);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the payWave PinOnLineRequested state.                                             *
 * 			                                                                                      *
 * [in] :   resultDataStruct kernel shared buffer                                                 *
 * [return]: TRUE if required.                                                                    *
 *           FALSE if not required or an error occurred.                                          *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_payWave_IsPinOnLineRequested(T_SHARED_DATA_STRUCT* resultDataStruct) {
   int position;
   unsigned long readLength;
   const unsigned char* readValue;

   position = SHARED_EXCHANGE_POSITION_NULL;
   if(GTL_SharedExchange_FindNext(resultDataStruct, &position, TAG_KERNEL_ONLINE_PIN_REQUESTED, &readLength, &readValue) != STATUS_SHARED_EXCHANGE_OK) {
      return FALSE;
   }
   return readValue[0];
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the payWave signature state.                                                      *
 * 			                                                                                      *
 * [in] :   resultDataStruct Structure containing the kernel output.                              *
 * [return]: TRUE if signature is requested                                                       *
 *           FALSE if signature is not requested or an error occurred.                            *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_payWave_IsSignatureRequested(T_SHARED_DATA_STRUCT* resultDataStruct) {
   int position;
   unsigned long readLength;
   const unsigned char* readValue;

   position = SHARED_EXCHANGE_POSITION_NULL;
   if(GTL_SharedExchange_FindNext(resultDataStruct, &position, TAG_KERNEL_SIGNATURE_REQUESTED, &readLength, &readValue) != STATUS_SHARED_EXCHANGE_OK) {
      return FALSE;
   }
   return readValue[0];
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: If a balance amount is available, it displays the message with the balance. Otherwise *
 *          nothing is displayed.                                                                 *
 * 			                                                                                      *
 * [in] :   screenId screen identifier of the message to display                                  *
 * [in] :   dataStruct shared buffer containing the balance amount.                               *
 *          TAG_PAYWAVE_AVAILABLE_OFFLINE_SPENDING_AMOUNT                                         *
 * [return]: TRUE if no problem occurred (display done).                                          *
 *           FALSE if not displayed (balance not available or an error occurred).                 *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_payWave_DisplaySreenWithBalance(unsigned long screenId, T_SHARED_DATA_STRUCT* dataStruct) {
   int isFound;
   unsigned char* info;

   isFound = APCLESS_Tools_SharedBufferRetrieveInfo(dataStruct, TAG_PAYWAVE_AVAILABLE_OFFLINE_SPENDING_AMOUNT, &info);
   if (isFound) {
	   CLESS_GUI_DisplayScreenWithBalance (screenId, "USD", 2, info, 6);
	  return TRUE;
   }
   return FALSE;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Check if Issuer Script could be executed.                                             *
 * 			                                                                                      *
 * [in] :   sharedStructure Shared buffer of the current transaction tags.                        *
 * [return]: TRUE if ISP could be executed.                                                       *
 *           FALSE else.                                                                          *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_payWave_CheckISPConditions(T_SHARED_DATA_STRUCT* sharedStructure) {
   int position, cr;
   unsigned long readLength;
   const unsigned char* readValue;

   // Verify Terminal can manage ISP
   position = SHARED_EXCHANGE_POSITION_NULL;
   cr = GTL_SharedExchange_FindNext(sharedStructure, &position, TAG_PAYWAVE_TERMINAL_TRANSACTION_QUALIFIERS, &readLength, &readValue);
   if (cr == STATUS_SHARED_EXCHANGE_OK)
   {
	  if ((readValue[2] & 0x80) == 0)
	  {  // Sorry, TTQ not configured for ISP management => end
		 return FALSE;
	  }
   }

   // Verify Card can manage ISP
   position = SHARED_EXCHANGE_POSITION_NULL;
   cr = GTL_SharedExchange_FindNext(sharedStructure, &position, TAG_PAYWAVE_CARD_TRANSACTION_QUALIFIERS, &readLength, &readValue);
   if (cr == STATUS_SHARED_EXCHANGE_OK)
   {
	  if ((readValue[1] & 0x40) == 0)
	  {  // Sorry, CTQ not configured for ISP management => end
		 return FALSE;
	  }
   }

   return TRUE;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Wait for the card to be represented.                                                  *
 * 			                                                                                      *
 * [in] :   dataStruct Shared buffer of the current transaction tags.                             *
 * [return]: TRUE if appropriate card has been put in field.                                      *
 *           FALSE else.                                                                          *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_payWave_WaitClessCard(T_SHARED_DATA_STRUCT* dataStruct) {
   unsigned char sw1, sw2;
   unsigned char response[257];
   unsigned int responseLength;
   unsigned int timeout, event;
   unsigned int key, numOfCards;
   int isAppropriateCardFound;
   int result;
   int position;
   unsigned long readLength;
   const unsigned char* readValue;
   int loop = TRUE;
   unsigned long startTime;
   Telium_File_t* keyboard = NULL;


   // Local variables initialization
   isAppropriateCardFound = FALSE; // Default result : card hasn't been found

   // get the Final Select command already sent to the card
   position = SHARED_EXCHANGE_POSITION_NULL;
   if(STATUS_SHARED_EXCHANGE_OK != GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EP_FINAL_SELECT_COMMAND_SENT, &readLength, &readValue))
   {
	  // We can't find the last select command
	  goto EndCardTreatment;
   }

   // Ask user to represent the card
   CLESS_GUI_DisplayScreen (APCLESS_SCREEN_REPRESENT_CARD);

   // Loop to wait the appropriate card (with good AID ....)
   startTime = GTL_StdTimer_GetCurrent();
   timeout =  __APCLESS_PAYWAVE_CARD_REPRESENT_TO *100;
   while(loop == TRUE)
   {
	  // Close driver ( and cless field)
	  ClessEmv_CloseDriver();

	  // Open driver (and cless field)
	  result = ClessEmv_OpenDriver ();
	  if (result != CL_OK)              // can't open driver / cless field
		 goto EndCardTreatment;

	  // Start the asynchronous ISO14443-4 contactless detection
	  result = ClessEmv_DetectCardsStart(1, CL_TYPE_AB);
	  if (result != CL_OK)
		 goto EndCardTreatment;

	  // Open keyboard
	  keyboard = Telium_Fopen("KEYBOARD", "r*");

	  // Loop to wait a contactless card detection or cancel key
	  timeout =  GTL_StdTimer_GetRemaining(startTime, __APCLESS_PAYWAVE_CARD_REPRESENT_TO *100);
	  while(timeout)
	  {
		 event = Telium_Ttestall (CLESS | KEYBOARD, timeout);

		 if(event & CLESS)
		 {  // cless driver has detected something, get the result
			numOfCards = 1;
			result = ClessEmv_DetectCards(CL_TYPE_AB, &numOfCards, 0);
			break; // exit timeout loop
		 }

		 if(event & KEYBOARD)
		 {
			key = Telium_Getchar();
			if (key == T_ANN)
			{  // cancel key has been pressed -> end
			   timeout = 0;
			   break; //  exit timeout loop
			}
		 }

		 //case time out or key pressed -> try to continue the loop
		 timeout =  GTL_StdTimer_GetRemaining(startTime, __APCLESS_PAYWAVE_CARD_REPRESENT_TO *100);
	  }

	  // Close keyboard (if we manage to open it)
	  if(NULL != keyboard)
		  Telium_Fclose(keyboard);

	  // Check card detection loop result
	  if(timeout == 0)
	  {  // case timeout or cancel -> stop cless detection and end
		 ClessEmv_DetectCardsStop();
		 goto EndCardTreatment;
	  }

	  if (result != CL_OK)
	  {  //  case cless detection error  -> retry
		 continue;
	  }

	  // Next step : Activate the card
	  if (ClessEmv_ActiveCard(0, CL_ISO14443_4) != CL_OK)
	  {  // case activation error -> retry
		 continue;
	  }

	  // Send Final Select command to the contactless card.
	  responseLength = sizeof(response);
	  result = ClessEmv_Apdu(0, (void*)readValue, readLength, response, &responseLength);
	  if ((result != CL_OK) || (responseLength < 2))
		 goto EndCardTreatment; // A problem occurs

	  // Check card response
	  sw1 = ((unsigned char*)response)[responseLength-2];
	  sw2 = ((unsigned char*)response)[responseLength-1];
	  if ((sw1 == 0x90) && (sw2 == 0x00))
	  {  // The appropriate card is found
		 isAppropriateCardFound = TRUE;
		 loop = FALSE;
	  }
	  else // wrong card response (not the good card)
	  {
		 CLESS_GUI_DisplayScreen(APCLESS_SCREEN_REMOVE_CARD);

		 result = ClessEmv_DeselectCard(0, TRUE, TRUE); // Deselect card with wait a card removal
		 if (result == CL_OK)
		 {  // card correctly removed -> retry
			 CLESS_GUI_DisplayScreen(APCLESS_SCREEN_REPRESENT_CARD);
		 }
		 else
		 {  // A problem occurs -> end
			loop = FALSE;
		 }
	  }
   }

EndCardTreatment:

   return isAppropriateCardFound;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Stop Cless field without waiting card removal.                                        *
 * ---------------------------------------------------------------------------------------------- */
static void CLESS_payWave_StopClessCard(void) {
   int result;

   // Card deselection
   result = ClessEmv_DeselectCard(0, TRUE, FALSE); // Deselect card without wait a card removal
   if (result != CL_OK)
   {
      // A problem occurs !
      // ..
   }

   // close cless field
   ClessEmv_CloseDriver();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose:  Perform the step after the transaction (Issuer Script Processing)                    *
 * 			                                                                                      *
 * [in,out]: dataStruct shared buffer containing the host response.                               *
 * [out]:    stepExecuted                                                                         *
 *           TRUE if payWave_AfterTransaction has been called.                                    *
 *           FALSE otherwise.                                                                     *
 * [return]: KERNEL_STATUS_OK or status of payWave_AfterTransaction() if it has been called.      *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_payWave_ManageAfterTrn(T_SHARED_DATA_STRUCT* dataStruct, int* stepExecuted) {
   int result, cr, cr2;
   int position;
   int nIssuerScriptPresent = FALSE;
   unsigned long readLength;
   const unsigned char* readValue;
   T_SHARED_DATA_STRUCT* issuerData;
   T_SHARED_DATA_STRUCT* tmpShared;

   // Local variable initialization
   *stepExecuted = FALSE; // Default value : afterTxn hasn't been executed;

   issuerData = GTL_SharedExchange_InitShared(1024);
   tmpShared = GTL_SharedExchange_InitShared(2048);

   // Default Result
   cr = KERNEL_STATUS_OK;

   if ((issuerData != NULL) && (tmpShared != NULL)) {
	  // Add TAG_EMV_ISSUER_AUTHENTICATION_DATA tag, this tag must be treated first !
	  position = SHARED_EXCHANGE_POSITION_NULL;
	  cr = GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_ISSUER_AUTHENTICATION_DATA, &readLength, &readValue);
	  if (cr == STATUS_SHARED_EXCHANGE_OK) {
		 result = GTL_SharedExchange_AddTag(issuerData, TAG_EMV_ISSUER_AUTHENTICATION_DATA, readLength, readValue);

		 if (result == STATUS_SHARED_EXCHANGE_OK)
			nIssuerScriptPresent = TRUE;
	  }

	  // Look for Issuer Script data
	  {
		  T_BER_TLV_DECODE_STRUCT BerTlvStruct;

		  GTL_BerTlvDecode_Init (&BerTlvStruct, dataStruct->nPtrData, dataStruct->ulDataLength);

		  // Parse Script  T1:71 or 72 L1 V1 ... Tn:71 or 72 Ln Vn
		  for (;;)
		  {
			  /* Problem of script overwriting */
			  int BytesRead;
			  BER_TLV_TAG ReadTag;
			  T_TI_LENGTH ReadLength;
			  T_TI_VALUE  ReadValue;


			  // Parse the next tag in the BER-TLV structure.
			  cr = GTL_BerTlvDecode_ParseTlv (&BerTlvStruct, &ReadTag, &ReadLength, (BER_TLV_VALUE*)&ReadValue, (unsigned char)FALSE, &BytesRead);

			  if (cr == STATUS_BER_TLV_END)
				  break ;

			  if (cr == STATUS_BER_TLV_OK)
			  {
				 if ((ReadTag == TAG_EMV_ISSUER_SCRIPT_TEMPLATE_1) || (ReadTag == TAG_EMV_ISSUER_SCRIPT_TEMPLATE_2))
				 {
					result = GTL_SharedExchange_AddTag(tmpShared, ReadTag, ReadLength, ReadValue);
					if (result != STATUS_SHARED_EXCHANGE_OK) {
					   // continue processing ? see application requirements
					}
				 }
			  }
			  else
				 break; // An error occurs
		  } // end of loop about Script parsing
	  }

	  // If Issuer Script data are present, add them under TAG_PAYWAVE_ISSUER_SCRIPT_LIST
	  if(tmpShared->ulDataLength) {
		 result = GTL_SharedExchange_AddTag(issuerData, TAG_PAYWAVE_ISSUER_SCRIPT_LIST, tmpShared->ulDataLength, tmpShared->nPtrData);
		 if (result == STATUS_SHARED_EXCHANGE_OK)
			nIssuerScriptPresent = TRUE;
	  }

	  // Default Result
	  cr = KERNEL_STATUS_OK;

	  // If Issuer authorization and/or script must be executed
	  if (nIssuerScriptPresent) {
		 payWave_GetAllData(tmpShared); // Get all the kernel data

		 if (CLESS_payWave_CheckISPConditions(tmpShared) == TRUE)
		 {
			if (CLESS_payWave_WaitClessCard(tmpShared) == TRUE)
			{
			   // Perform the payWave transaction
			   cr = payWave_AfterTransaction(issuerData);

			   *stepExecuted = TRUE; // afterTxn has been executed;

			   // Get Issuer Script Result
			   position = SHARED_EXCHANGE_POSITION_NULL;
			   cr2 = GTL_SharedExchange_FindNext(issuerData, &position, TAG_PAYWAVE_ISSUER_SCRIPT_RESULT, &readLength, &readValue);
			   if (cr2 == STATUS_SHARED_EXCHANGE_OK)
			   {
				  // Put Issuer Script Result in exchange struct given in parameter
				  GTL_SharedExchange_AddTag(dataStruct, TAG_PAYWAVE_ISSUER_SCRIPT_RESULT, readLength, readValue);
			   }
			}
			CLESS_payWave_StopClessCard();
		 }
	  }
   }
   // Destroy the shared buffers
   if (tmpShared != NULL)
	  GTL_SharedExchange_DestroyShare(tmpShared);
   if (issuerData != NULL)
	  GTL_SharedExchange_DestroyShare(issuerData);

   return cr;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Call the authorization host.                           				                  *
 * 			                                                                                      *
 * [in,out]: dataStruct Data to be sent to the host for online authorization (input) and response *
 *           tags are added to it (output).                                                       *
 * [return]: TRUE if correctly performed.                                                         *
 *           FALSE if an error occurred.                                                          *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_payWave_CallAuthorisationHost(T_SHARED_DATA_STRUCT* dataStruct) {
	CLESS_GUI_DisplayScreen(APCLESS_SCREEN_ONLINE_PROCESSING);
	payWave_GetAllData (dataStruct);

/*TEMP
   // Here we simulate an accepted authorisation with Issuer Script Processing
   GTL_SharedExchange_AddTag(dataStruct,TAG_EMV_ISSUER_AUTHENTICATION_DATA, 10,
                             (unsigned char*) "\x11\x22\x33\x44\x55\x66\x77\x88\x30\x30");
   GTL_SharedExchange_AddTag(dataStruct,TAG_EMV_ISSUER_SCRIPT_TEMPLATE_2, 33,
                             (unsigned char*) "\x9F\x18\x04\x11\x22\x33\x44\x86\x0D\x84\x24\x00\x00\x08\xAA\xBB\xCC\xDD\x11\x22\x33\x44\x86\x09\x84\x24\x00\x00\x04\x55\x66\x77\x88");
   GTL_SharedExchange_AddTag(dataStruct, TAG_EMV_AUTHORISATION_RESPONSE_CODE, 2,
                             (unsigned char*) "\x30\x30");
TEMP*/
   return TRUE;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Manage the online authorization call and response. 									  *
 * 			                                                                                      *
 * [in,out]: dataStruct shared buffer of the transaction data                                     *
 * [return]: TRUE if transaction has to be saved                                                  *
 *           FALSE otherwise                                                                      *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_payWave_ManageOnLineAuthorisation(T_SHARED_DATA_STRUCT* dataStruct) {
   int position;
   unsigned long readLength;
   const unsigned char* readValue;
   int isAfterTrnExecuted = FALSE;

   // Manage case PIN online
   if(CLESS_payWave_IsPinOnLineRequested(dataStruct)) {
	  // TODO: Ask/get the user PIN
	   int pinLength;
	   switch (APEMV_UI_PinEntry (INPUT_PIN_ON, 3, &pinLength)) {
	   		case EPSTOOL_PINENTRY_SUCCESS:
	   			if (encryptPIN() == FALSE)
	   				setErrorCode("ERROR:033");
	   			break;
	   		case EPSTOOL_PINENTRY_TIMEOUT:
	   			setErrorCode("ERROR:013");
	   			break;
	   		case EPSTOOL_PINENTRY_ERROR:
	   		case EPSTOOL_PINENTRY_CANCEL:
	   			setErrorCode("ERROR:044");
	   			break;
	   		case EPSTOOL_PINENTRY_EVENT:
	   		case EPSTOOL_PINENTRY_BYPASS:
	   		default:
	   			break;
	   		}
   }
   if(TRUE == CLESS_payWave_CallAuthorisationHost(dataStruct)) {
	  position = SHARED_EXCHANGE_POSITION_NULL;
	  if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_AUTHORISATION_RESPONSE_CODE, &readLength, &readValue) == STATUS_SHARED_EXCHANGE_OK) {
		 if ((readValue[0] == 0x30) && (readValue[1] == 0x30)) {
			// Do card post processing (issuer script)
			CLESS_payWave_ManageAfterTrn(dataStruct, &isAfterTrnExecuted); // Result not used to known if transaction is accepted or not

			CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ONLINE_APPROVED);

			// transaction has to be saved in the batch
			return TRUE;
		 }
	  }
   }
   CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ONLINE_DECLINED);
   return FALSE;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Calls the payWave kernel to perform the transaction.                                  *
 * 			                                                                                      *
 * [in] :   dataStruct Data buffer to be filled and used for payWave transaction.                 *
 * [return]: payWave kernel result.                                                               *
 * ---------------------------------------------------------------------------------------------- */
int CLESS_PayWave_PerformTransaction(T_SHARED_DATA_STRUCT* dataStruct) {
   int cr;
   int result = C_CLESS_CR_END;
   unsigned char signature;
   unsigned char* info;
   int saveInBatch = FALSE;

   CLESS_Txn_SetCurrentPaymentScheme (APCLESS_SCHEME_PAYWAVE);

   if (CLESS_payWave_AddpayWaveSpecificData(dataStruct)) {
	  cr = payWave_DoTransaction(dataStruct);

	  // Specific treatment for Pin management
	  if (cr == KERNEL_STATUS_OFFLINE_APPROVED) {
		 if (CLESS_payWave_IsPinOnLineRequested(dataStruct)) // If pin asked
			cr = KERNEL_STATUS_ONLINE_AUTHORISATION; // => mandatory to go on-line
	  }
	  // Check if signature is requested or not
	  signature = CLESS_payWave_IsSignatureRequested (dataStruct);

	  switch (cr) {
		  case KERNEL_STATUS_OK:
			  // A good transaction state must be finished by a approved, declined, ...
			  CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ERROR_STATUS);
			  break;

		  case KERNEL_STATUS_OFFLINE_APPROVED:
			  if(CLESS_payWave_DisplaySreenWithBalance(APCLESS_SCREEN_OFFLINE_APPROVED, dataStruct) == FALSE)
				  CLESS_GUI_DisplayScreen (APCLESS_SCREEN_OFFLINE_APPROVED);
			  saveInBatch = TRUE;
			  break;

			case KERNEL_STATUS_OFFLINE_DECLINED:
			   if(CLESS_payWave_DisplaySreenWithBalance(APCLESS_SCREEN_OFFLINE_DECLINED, dataStruct) == FALSE)
				   CLESS_GUI_DisplayScreen (APCLESS_SCREEN_OFFLINE_DECLINED);
			   break;

			case KERNEL_STATUS_ONLINE_AUTHORISATION:
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ONLINE_PROCESSING);
				payWave_GetAllData (dataStruct);
				PayWave_OnlineRequestData (dataStruct);
				if(CLESS_payWave_IsPinOnLineRequested(dataStruct)) {
					if (getCHVerificationMethod() == ONLINE_PIN ){
						int pinLength;
						switch (APEMV_UI_PinEntry (INPUT_PIN_ON, 3, &pinLength)) {
							case EPSTOOL_PINENTRY_SUCCESS:
								if (encryptPIN() == FALSE)
									setErrorCode("ERROR:033");
								break;
							case EPSTOOL_PINENTRY_TIMEOUT:
								setErrorCode("ERROR:013");
								break;
							case EPSTOOL_PINENTRY_ERROR:
							case EPSTOOL_PINENTRY_CANCEL:
								setErrorCode("ERROR:044");
								break;
							case EPSTOOL_PINENTRY_EVENT:
							case EPSTOOL_PINENTRY_BYPASS:
							default:
								break;
							}
						}
				}
				break;

			case KERNEL_STATUS_USE_CONTACT_INTERFACE:
			   CLESS_GUI_DisplayScreen (APCLESS_SCREEN_USE_CONTACT);
			   result = CLESS_CR_MANAGER_RESTART_WO_CLESS;
			   break;

			case KERNEL_STATUS_COMMUNICATION_ERROR:
			   result = CLESS_CR_MANAGER_RESTART;
			   break;

			case KERNEL_STATUS_REMOVE_AID:
			   result = CLESS_CR_MANAGER_REMOVE_AID;
			   break;

			case KERNEL_STATUS_MOBILE:
			   if (APCLESS_Tools_SharedBufferRetrieveInfo(dataStruct, TAG_PAYWAVE_TERMINAL_TRANSACTION_QUALIFIERS, &info))
			   {
				  if (info[0] & 0x20) // If qVSDC supported
				  {
					 ClessEmv_CloseDriver(); // Stop Cless Field
					 result = CLESS_CR_MANAGER_RESTART_DOUBLE_TAP;
				  }
				  else
				  {
					 // display error
					 CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ERROR_STATUS);
					 result = CLESS_CR_MANAGER_END;
				  }
			   }
			   else
			   {
				  result = CLESS_CR_MANAGER_RESTART_DOUBLE_TAP;
			   }
			   break;

			default:
			   // For Visa Europe, no error should be displayed.
			   // transaction shall be conducted over another interface
			   result = CLESS_CR_MANAGER_RESTART_WO_CLESS;
			   break;
	  }
   }

   // Cless field must be stopped only if we don't try to work with an another AID
   if ((result != CLESS_CR_MANAGER_REMOVE_AID) && (result != CLESS_CR_MANAGER_RESTART_WO_CLESS) && (result != CLESS_CR_MANAGER_RESTART_DOUBLE_TAP)) {
	   // Deselect the card
	   if (ClessEmv_IsDriverOpened())
		   ClessEmv_DeselectCard(0, TRUE, FALSE);
   }

   // If the transaction does not restart from the beginning, set the LEDs into the idle state
   if ((result != CLESS_CR_MANAGER_RESTART) && (result != CLESS_CR_MANAGER_REMOVE_AID)) {
	   // Check if transaction shall be saved in the batch
	   if (saveInBatch) {
		   // TODO: Add record to the batch
	   }
	   // Increment the transaction sequence counter
	   CLESS_Txn_IncrementTsc ();
   }

   // Additional possible processing :
   // - Perform an online authorisation if necessary
   // - Save the transaction in the batch if transaction is accepted
   // - Perform CVM processing if necessary

   // Transaction is completed, clear payWave kernel transaction data
   payWave_Clear();

   return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Perform the payWave kernel customization.                                             *
 * 			                                                                                      *
 * [in] :    ucCustomisationStep Step to be customized.                                           *
 * [in,out]: sharedData Shared buffer used for customization.                                     *
 * ---------------------------------------------------------------------------------------------- */
int CLESS_PayWave_KernelCustomiseStep(T_SHARED_DATA_STRUCT* sharedData, const unsigned char ucCustomisationStep) {
   int result = KERNEL_STATUS_CONTINUE;
   int position;
   unsigned char keyIndex = 0;
   unsigned char rid[7] = {0};
   unsigned char Modulus [255] = {0};
   unsigned int ModulusLength = 0;
   unsigned char Exponent [3] = {0};
   unsigned int ExponentLength = 0;
   unsigned long readLength;
   const unsigned char* readValue;
   unsigned short found;

	switch (ucCustomisationStep) {
	   case STEP_PAYWAVE_MSD_REMOVE_CARD:
	   case STEP_PAYWAVE_QVSDC_REMOVE_CARD:
		 CLESS_GUI_DisplayScreen (APCLESS_SCREEN_REMOVE_CARD);
		 GTL_SharedExchange_ClearEx (sharedData, FALSE);
		 result = KERNEL_STATUS_CONTINUE;
		 break;

	  case STEP_PAYWAVE_QVSDC_GET_CERTIFICATE:
		 position = SHARED_EXCHANGE_POSITION_NULL;
		 if (GTL_SharedExchange_FindNext (sharedData, &position, TAG_EMV_CA_PUBLIC_KEY_INDEX_CARD, &readLength, (const unsigned char **)&readValue) == STATUS_SHARED_EXCHANGE_OK)
			keyIndex = readValue[0];

		 position = SHARED_EXCHANGE_POSITION_NULL;
		 if (GTL_SharedExchange_FindNext (sharedData, &position, TAG_EMV_DF_NAME, &readLength, (const unsigned char **)&readValue) == STATUS_SHARED_EXCHANGE_OK) {
			memcpy (rid+1, readValue, 5);
			memcpy (rid, "\x05", 1);
		 }

		 GTL_SharedExchange_ClearEx (sharedData, FALSE);
		 if (strlen(rid) && keyIndex != 0) {
			 found = getCertificationAuthorityPublicKey (rid,
														keyIndex,
														Modulus,
														&ModulusLength,
														Exponent,
														&ExponentLength);
			 if (found) {
				 if (GTL_SharedExchange_AddTag(sharedData, TAG_EMV_INT_CAPK_MODULUS, ModulusLength, Modulus) != STATUS_SHARED_EXCHANGE_OK) {
					 GTL_SharedExchange_ClearEx(sharedData, FALSE);
					 return;
				 }
				 if (GTL_SharedExchange_AddTag(sharedData, TAG_EMV_INT_CAPK_EXPONENT, ExponentLength, Exponent) != STATUS_SHARED_EXCHANGE_OK) {
					 GTL_SharedExchange_ClearEx(sharedData, FALSE);
					 return;
				 }
			 }
		 }
		 result = KERNEL_STATUS_CONTINUE;
		 break;

	  case STEP_PAYWAVE_QVSDC_BLACK_LIST_CONTROL:
		 // TODO: Check if PAN is in the exception file
		 result = KERNEL_STATUS_CONTINUE;
		 break;

	  default:
		 break;
	}
	return result;
}
/* --------------------------------------------------------------------------------------------- *
* Purpose: Prepare EMV Data block. The following EMV tag may be sent in EMV request block.   	 *
* ---------------------------------------------------------------------------------------------- */
int PayWave_OnlineRequestData (T_SHARED_DATA_STRUCT* dataStruct) {
	int result = TRUE;
	unsigned long length;
	const unsigned char* ptValue;
	int position;

	typedef struct{
		unsigned long tagNum;
		unsigned char tagName[2];
		int tagNameLength;
		int tagDataMinLen;
		int mandatoryFlag;
	}EMVTags;

	EMVTags PayWaveRequestTags [] =
     	 {{TAG_EMV_AIP,                        				"\x82",     1, 2, TRUE},
    	  {TAG_EMV_DF_NAME,                    				"\x84",     1, 5, TRUE},
		  {TAG_EMV_TVR,                        				"\x95",     1, 5, TRUE},
		  {TAG_EMV_TRANSACTION_DATE,           				"\x9A",     1, 3, TRUE},
		  {TAG_EMV_TRANSACTION_TYPE,           				"\x9C",     1, 1, TRUE},
		  {TAG_EMV_TRANSACTION_CURRENCY_CODE,  				"\x5F\x2A", 2, 2, TRUE},
		  {TAG_EMV_AMOUNT_AUTH_NUM,            				"\x9F\x02", 2, 6, TRUE},
		  {TAG_EMV_AMOUNT_OTHER_NUM,           				"\x9F\x03", 2, 6, TRUE},
		  {TAG_EMV_ISSUER_APPLI_DATA,    					"\x9F\x10", 2, 0, TRUE},
		  {TAG_EMV_TERMINAL_COUNTRY_CODE,      				"\x9F\x1A", 2, 2, TRUE},
		  {TAG_EMV_APPLICATION_CRYPTOGRAM,      			"\x9F\x26", 2, 8, TRUE},
		  {TAG_EMV_CRYPTOGRAM_INFO_DATA,					"\x9F\x27", 2, 1, TRUE},
		  {TAG_EMV_ATC,                        				"\x9F\x36", 2, 2, TRUE},
		  {TAG_EMV_UNPREDICTABLE_NUMBER,       				"\x9F\x37", 2, 4, TRUE},
		  {TAG_EMV_POS_ENTRY_MODE, 		 					"\x9F\x39", 2, 1, TRUE},
		  {TAG_EMV_TERMINAL_CAPABILITIES,      				"\x9F\x33", 2, 3, FALSE},
		  {TAG_EMV_CVM_RESULTS,                 			"\x9F\x34", 2, 3, FALSE},
		  {TAG_EMV_TERMINAL_TYPE,              				"\x9F\x35", 2, 1, FALSE},
		  {TAG_EMV_ADD_TERMINAL_CAPABILITIES,  				"\x9F\x40", 2, 5, FALSE},
		  {TAG_EMV_AID_CARD, 				 				"\x4F",     1,16, FALSE},
		  {TAG_EMV_AID_TERMINAL, 		        			"\x9F\x06", 2,16, FALSE},
		  {TAG_EMV_TSI, 									"\x9B",     1, 2, FALSE},
		  {TAG_EMV_TRANSACTION_TIME, 		    			"\x9F\x21", 2, 3, FALSE},
		  {TAG_EMV_APPLI_PAN_SEQUENCE_NUMBER,				"\x5F\x34", 2, 1, FALSE},
		  {TAG_EMV_IFD_SERIAL_NUMBER,						"\x9F\x1E", 2, 8, FALSE},
		  {TAG_EMV_TRANSACTION_CURRENCY_EXPONENT,			"\x5F\x36", 2, 1, FALSE},
		  {TAG_EMV_APPLI_VERSION_NUMBER_TERM,				"\x9F\x09", 2, 2, FALSE},
		  {TAG_EMV_APPLI_PAN,								"\x5A", 	1,10, FALSE},
		  {TAG_EMV_TRANSACTION_SEQUENCE_COUNTER,			"\x9F\x41", 2, 4, FALSE},
		  {TAG_EMV_APPLI_EXPIRATION_DATE,					"\x5F\x24", 2, 3, FALSE},
		  {TAG_EMV_TRACK_2_EQU_DATA,						"\x57",     1,37, FALSE},
		  {TAG_EMV_SERVICE_CODE,							"\x5F\x30", 2, 2, FALSE},
		  {TAG_EMV_CARDHOLDER_NAME,							"\x5F\x20", 2,26, FALSE},
		  {TAG_EMV_ICC_DYNAMIC_NUMBER,						"\x9F\x4C", 2, 0, FALSE},
		  {TAG_PAYWAVE_CARD_CVM_LIMIT,						"\x9F\x6B", 2, 0, FALSE},
		  {TAG_PAYWAVE_CUSTOMER_EXCLUSIVE_DATA,				"\x9F\x7C", 2, 0, FALSE},
		  {TAG_PAYWAVE_CONSECUTIVE_TR_COUNTER_INTER_LIMIT, 	"\x9F\x53", 2, 0, FALSE},
		  {TAG_PAYWAVE_FORM_FACTOR_INDICATOR,          		"\x9F\x6E", 2, 0, FALSE}};

	position = SHARED_EXCHANGE_POSITION_NULL;
	if(GTL_SharedExchange_FindNext(dataStruct, &position, TAG_KERNEL_CARD_TYPE, &length, &ptValue) != STATUS_SHARED_EXCHANGE_OK) {
		result = FALSE;
		goto End;
	}
	unsigned short cardType = 0;
	cardType = (ptValue[0] << 8) + ptValue[1];

	if (cardType == 0x0001) {
		setCardInputMode (EMVCONTACTLESS);
    	unsigned char dataEMV[256] = {0};
    	int i, j = 0;
    	int tagCount = sizeof(PayWaveRequestTags) / sizeof(PayWaveRequestTags[0]);

    	for (i = 0; i < tagCount; i++){
    		length = 0;
    		position = SHARED_EXCHANGE_POSITION_NULL;
    		if (dataStruct->ulDataLength)
    			GTL_SharedExchange_FindNext(dataStruct, &position, PayWaveRequestTags[i].tagNum, &length, &ptValue);

    		if (length != 0){
    			memcpy (&dataEMV[j], PayWaveRequestTags[i].tagName, PayWaveRequestTags[i].tagNameLength);
    			memcpy (&dataEMV[j + PayWaveRequestTags[i].tagNameLength], &length, 1);
    			memcpy (&dataEMV[j + PayWaveRequestTags[i].tagNameLength + 1], ptValue, length);
    			j = j + PayWaveRequestTags[i].tagNameLength + 1 + length;
    		}
    		else {
    			if (PayWaveRequestTags[i].mandatoryFlag == TRUE) {
    				memcpy (&dataEMV[j], PayWaveRequestTags[i].tagName, PayWaveRequestTags[i].tagNameLength);
    				memcpy (&dataEMV[j + PayWaveRequestTags[i].tagNameLength], &PayWaveRequestTags[i].tagDataMinLen, 1);
    				memset (&dataEMV[j + PayWaveRequestTags[i].tagNameLength + 1], 0, PayWaveRequestTags[i].tagDataMinLen);
    				j = j + PayWaveRequestTags[i].tagNameLength + 1 + PayWaveRequestTags[i].tagDataMinLen;
    			}
    		}
    	}
    	setRequestEMVData(dataEMV, j);

    	// Get Card Number (Tag 5A)
    	length = 0;
    	position = SHARED_EXCHANGE_POSITION_NULL;
    	if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_APPLI_PAN, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
    		char cardNo [20] = {0};
    		Hexasc (cardNo, ptValue, length*2);
    		int n;
    		for (n = 0; n < length*2; n++) {
    			if ((int)cardNo[n] < 48 || (int)cardNo[n] > 57)
    				cardNo[n] = '\x00';
    		}
    		setCardNumber(cardNo, strlen(cardNo));
    	}
    	// Get Card Holder Name
    	length = 0;
    	position = SHARED_EXCHANGE_POSITION_NULL;
    	if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_CARDHOLDER_NAME, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
    		  if(length >8)
			   setCardHolderName (ptValue, length);
    	}
    	// Set Expiration Date
    	length = 0;
    	position = SHARED_EXCHANGE_POSITION_NULL;
    	if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_APPLI_EXPIRATION_DATE, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
    		char cardAppExp[5] = {0};
    		Hexasc(cardAppExp, ptValue, 4);
    		setCardExpiryDate(cardAppExp);
    	}
    	// Get Track Data (Tag 57)
       	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_TRACK_2_EQU_DATA, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char tag57 [40] = {0};
			memcpy (tag57, unsignedCharToASCII(ptValue,length), length*2);
			int trackLength = 0;
			if (tag57 [0] != 'B'){
				char temp [40] = {0};
				temp [0] = 'B';
				memcpy (temp+1, tag57, length*2);
				trackLength = length*2 + 1;
				memcpy (tag57, temp, trackLength);
				if (tag57 [strlen(tag57) - 1] != 'F'){
					tag57 [strlen(tag57)] = 'F';
					trackLength = trackLength + 1;
				}
			}
			else
				trackLength = length*2;

			char *pcSrc = NULL, *pcDst = NULL;
			char tcTrk2[40] = {'\0'};
			pcSrc = tag57;
			pcDst = tcTrk2;
			while(*pcSrc) {                                  // Find start sentinel
				if(*pcSrc++ == 'B'){
					*pcDst++ = ';';
					break;
				}
			}
			while(*pcSrc) {                                  // Copy all data between start and end sentinels
				if(*pcSrc == 'F'){
					*pcDst = '?';
					break;
				}
				if(*pcSrc == 'D')
					*pcSrc = '=';
				*pcDst++ = *pcSrc++;
			}
			setTrack2Data(tcTrk2, trackLength);
		}
		// Set EMV Application Label
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_APPLICATION_LABEL, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char app[17] = {0};
			memcpy(app,ptValue,length);
			setEMVApplicationLabel(app);
		}
		// set EMV Application Identifier (AID)
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_DF_NAME, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char aid[33] = {0};
			memcpy (aid, hexToASCII(ptValue,length), length*2);
			setEMVApplicationIdentifier (aid);
		}
		// Set Transaction Status Information(TSI)
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_TSI, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char tsi[5] = {0};
			memcpy(tsi,ptValue,length);
			setEMVTransactionStatusInformation(tsi);
		}
		// Get Cardholder Verification Method (Tag 9F34).
		int cvmSetFlag = FALSE;
    	length = 0;
        unsigned char cvr [2];
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_KERNEL_SIGNATURE_REQUESTED, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			if (length != 0){
				memset(cvr,0,sizeof(cvr));
				memcpy (cvr, unsignedCharToASCII(ptValue,length), length*2);
				if(!memcmp(cvr,"01",2)){
					setCHVerificationMethod(PAPER_SIGNATURE);
					cvmSetFlag = TRUE;
				}
			}
		}
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_KERNEL_ONLINE_PIN_REQUESTED, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			if (length != 0){
				memset(cvr,0,sizeof(cvr));
				memcpy (cvr, unsignedCharToASCII(ptValue,length), length*2);
				if(!memcmp(cvr,"01",2)){
					setCHVerificationMethod(ONLINE_PIN);
					cvmSetFlag = TRUE;
				}
			}
		}
		if (cvmSetFlag == FALSE)
			setCHVerificationMethod(NO_AUTHENTICATION);
	}
	else if (cardType == 0x0002) {
		setCardInputMode (MSRCONTACTLESS);

		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_PAYWAVE_MAGSTRIPE_TRACK_2, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char track2Raw [40] = {0};
			memcpy(track2Raw, ptValue, length);

			char track2Token[40] = {0};
			memcpy(track2Token, ptValue, length);
			char * tr2Token = strtok(track2Token, "?");
			strcpy (track2Token, tr2Token);
			int tr2Length = strlen(tr2Token);
			track2Token [tr2Length] = '?';
			setTrack2Data (track2Token, tr2Length + 1);

	        char * token = strtok(&track2Raw[1],"=");
	        setCardNumber (token, strlen(token));

	        token = strtok(NULL,"?");
	        char cardExpiryDate [4] = {0};
	        memcpy (cardExpiryDate, token, sizeof(cardExpiryDate));
	        setCardExpiryDate (cardExpiryDate);

    		setCHVerificationMethod (getCardType() == CREDIT	? PAPER_SIGNATURE 	:
    								(getCardType() == DEBIT  	? ONLINE_PIN 		:
    										 	 	 	 	 	  NO_AUTHENTICATION));
		}
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_PAYWAVE_TRACK_1, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			if (strtok(ptValue,"^")) {
			   char * token = strtok(NULL,"/^");
			   setCardHolderName(token, sizeof(token));
			}
		}
	}
	else {
		result = FALSE;
		goto End;
	}
End:
	return result;
}
