/* ------------------------------------------------------------------------------------------ *
 *                            PROGRAM HISTORY                                                 *
 * ------------------------------------------------------------------------------------------ *
 * Ver.  Author(s)     Date         Description                                               *
 * ---   ---------     ----         -----------                                               *
 * V01   RS Software   06/30/2018   This module implements the EMV Engine services related to *
 * 									the transaction initialization.                           *
 * 									(Get Processing Options, Read Records, Offline Data       *
 * 									 Authentication and Processing Restriction).              *
 * ------------------------------------------------------------------------------------------ */
#include "sdk.h"
#include "SEC_interface.h"
#include "GL_GraphicLib.h"
#include "TlvTree.h"
#include "GTL_Assert.h"
#include "_emvdctag_.h"
#include "def_tag.h"
#include "EngineInterface.h"
#include "EngineInterfaceLib.h"
#include "servcomm.h"

#include "EPSTOOL_TlvTree.h"
#include "EPSTOOL_PinEntry.h"

#include "EMV.h"
#include "emvparameter.h"
#include "Transaction.h"
/* ------------------------------------------------------------------------------------------ *
 * Purpose: Called after Initiate Application Process (GET PROCESSING OPTIONS command) which  *
 *          return AIP and AFL                                                                *
 * 			                                                                                  *
 * [in] :   inputTlvTree Input TlvTree.                                                       *
 * [out]:   outputTlvTree Output TlvTree.                                                     *
 * ------------------------------------------------------------------------------------------ */
void emvStepInitiateApplicationProcessing (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	emvTransacStatusSet (*statusCode);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose: Called just after Read Application Data (READ RECORD commands).                   *
 * 			                                                                                  *
 * [in] :   inputTlvTree Input TlvTree.                                                       *
 * [out]:   outputTlvTree Output TlvTree. Usually contains the CA Public Key and PAN related  *
 * 			data (such as exception file indicator).                                          *
 * ------------------------------------------------------------------------------------------ */
void emvStepReadApplicationData (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	static const unsigned long RequiredTags[] = {
			TAG_APPLI_PRIM_ACCOUNT_NB,
			TAG_APPLI_PRIM_ACCOUNT_NB_SEQ_NB,
			TAG_AID_PROPRIETARY,
			TAG_CERT_AUTH_PUB_KEY_INDEX_ICC,
			TAG_CARDHOLDER_NAME,
			TAG_APPLI_EXPIRATION_DATE,
			TAG_TRACK2_EQU_DATA,
			TAG_APPLICATION_LABEL,
			TAG_AID_ICC
	};

	unsigned short found;
	DataElement Data_Elt;
	TLV_TREE_NODE hTree;

	hTree = Engine_GetDataElement(TAG_LAST_APDU_CMD_RESPONSE);
	TLV_TREE_NODE hFoundNode=NULL;
	found = FALSE;

	if(&hTree != NULL){
		hFoundNode = TlvTree_Find(hTree, TAG_LAST_APDU_CMD_RESPONSE, 0);
		if(hFoundNode != NULL){
			Data_Elt.tag = TlvTree_GetTag(hFoundNode);
			Data_Elt.length = TlvTree_GetLength(hFoundNode);
			Data_Elt.ptValue = TlvTree_GetData(hFoundNode);
			found = TRUE;
		}
	}
	if (found){
		// Check if it was a Read Record
		if ((Data_Elt.ptValue [0] == 0x00)  &&     // CLA command
			(Data_Elt.ptValue [1] == 0xB2))        // INS command
		{
			unsigned char cmd_ok;
			// Check Response bytes SW1 SW2 for Exception handling
			cmd_ok =((Data_Elt.ptValue [4] == 0x90) && (Data_Elt.ptValue [5] == 0x00))  ||
					((Data_Elt.ptValue [4] == 0x62) && (Data_Elt.ptValue [5] == 0x83))  ||
					((Data_Elt.ptValue [4] == 0x63) && (Data_Elt.ptValue [5] == 0x00))  ||
					((Data_Elt.ptValue [4] == 0x63) && ((Data_Elt.ptValue [5] & 0xF0) == 0xC0));
			if (!cmd_ok){
				*statusCode = STATUS_TR_CARD_ERROR;
			}
			// else we don't change error_code
		}
	}

	TLV_TREE_NODE cardDataTree;
	DataElement cardData_Elt;
	unsigned short cardDatafound;
	cardDataTree = Engine_GetDataElements(sizeof(RequiredTags) / sizeof(RequiredTags[0]), RequiredTags);

	// Set Card Number
	cardDatafound = EPSTOOL_TlvTree_FindFirstData(cardDataTree, TAG_APPLI_PRIM_ACCOUNT_NB, &cardData_Elt);
	if (cardDatafound != 0) {
		char cardNo [20] = {0};
		Hexasc (cardNo, cardData_Elt.ptValue,cardData_Elt.length*2);
		int n;
		for (n = 0; n < cardData_Elt.length*2; n++) {
			if ((int)cardNo[n] < 48 || (int)cardNo[n] > 57)
				cardNo[n] = '\x00';
		}
		setCardNumber(cardNo, strlen(cardNo));
	}
	// Set CardHolder Name
	cardDatafound = EPSTOOL_TlvTree_FindFirstData(cardDataTree, TAG_CARDHOLDER_NAME, &cardData_Elt);
	if (cardDatafound != 0) {
		setCardHolderName (cardData_Elt.ptValue,cardData_Elt.length);
	}
	// Set Expiration Date.
	cardDatafound = EPSTOOL_TlvTree_FindFirstData(cardDataTree, TAG_APPLI_EXPIRATION_DATE, &cardData_Elt);
	if (cardDatafound != 0) {
		char cardAppExp[5] = {0};
		Hexasc(cardAppExp, cardData_Elt.ptValue, 4);
		setCardExpiryDate(cardAppExp);
	}
	// Get Track Data (Tag 57)
	cardDatafound = EPSTOOL_TlvTree_FindFirstData(cardDataTree, TAG_TRACK2_EQU_DATA, &cardData_Elt);
	if (cardDatafound != 0) {
		char tag57 [40] = {0};
		memcpy (tag57, unsignedCharToASCII(cardData_Elt.ptValue,cardData_Elt.length), cardData_Elt.length*2);
		int trackLength = 0;
		if (tag57 [0] != 'B'){
			char temp [40] = {0};
			temp [0] = 'B';
			memcpy (temp+1, tag57, cardData_Elt.length*2);
			trackLength = cardData_Elt.length*2 + 1;
			memcpy (tag57, temp, trackLength);
			if (tag57 [strlen(tag57) - 1] != 'F'){
				tag57 [strlen(tag57)] = 'F';
				trackLength = trackLength + 1;
			}
		}
		else
			trackLength = cardData_Elt.length*2;

		char *pcSrc = NULL, *pcDst = NULL;
		char tcTrk2[40] = {'\0'};
		pcSrc = tag57;
		pcDst = tcTrk2;
		while(*pcSrc) {                                  // Find start sentinel
			if(*pcSrc++ == 'B'){
				*pcDst++ = ';';
				break;
			}
		}
		while(*pcSrc) {                                  // Copy all data between start and end sentinels
			if(*pcSrc == 'F'){
				*pcDst = '?';
				break;
			}
			if(*pcSrc == 'D')
				*pcSrc = '=';
			*pcDst++ = *pcSrc++;
		}
		setTrack2Data(tcTrk2, trackLength);
	}
	// Set EMV Application Label
	cardDatafound = EPSTOOL_TlvTree_FindFirstData(cardDataTree, TAG_APPLICATION_LABEL, &cardData_Elt);
	if (cardDatafound != 0) {
		char app[17] = {0};
		if(cardData_Elt.length !=14)
		memcpy (app, cardData_Elt.ptValue, cardData_Elt.length);
		setEMVApplicationLabel (app);
	}
	// set EMV Application Identifier (AID)
	cardDatafound = EPSTOOL_TlvTree_FindFirstData(cardDataTree, TAG_AID_ICC, &cardData_Elt);
	if (cardDatafound != 0) {
		char aid[33] = {0};
		memcpy (aid, hexToASCII(cardData_Elt.ptValue, cardData_Elt.length), cardData_Elt.length*2);
		setEMVApplicationIdentifier (aid);
	}

	// Refund Transaction - ODA Not applicable
	if (strcmp(getTransactionType(), REFUND)){
		TLV_TREE_NODE tlvTree;
		DataElement Data_Elt3, Data_Elt4;
		unsigned short found3, found4;
		unsigned char Aid [LEN_AID];
		static unsigned char lg_Aid;
		unsigned char Modulus [255];
		unsigned int ModulusLength;
		unsigned char Exponent [3];
		unsigned int ExponentLength;

		if (*statusCode != STATUS_TR_CARD_ERROR){
			tlvTree = Engine_GetDataElements(sizeof(RequiredTags) / sizeof(RequiredTags[0]), RequiredTags);
			found3 = EPSTOOL_TlvTree_FindFirstData(tlvTree, TAG_AID_PROPRIETARY, &Data_Elt3);
			if (found3){
				memcpy (Aid, Data_Elt3.ptValue, Data_Elt3.length);
				lg_Aid = Data_Elt3.length;
			}
			found4 = EPSTOOL_TlvTree_FindFirstData(tlvTree, TAG_CERT_AUTH_PUB_KEY_INDEX_ICC, &Data_Elt4);
		}
		// Exception file checking - IsInBlackList need to implement
		// Default: NO BLACK LIST.
		static const unsigned char inBlackList[2] = { 0x00, 0x00 };
		TlvTree_AddChild(outputTlvTree, TAG_CUST_PAN_IN_BLACK_LIST, inBlackList, sizeof(inBlackList));

		found = FALSE;
		if (found4){
			found = getCertificationAuthorityPublicKey (Aid,
														(unsigned char) *(Data_Elt4.ptValue),
														Modulus,
														&ModulusLength,
														Exponent,
														&ExponentLength);
			if (found) {
				TlvTree_AddChild(outputTlvTree, TAG_CERT_AUTH_PUB_KEY_MODULUS, Modulus, ModulusLength);
				TlvTree_AddChild(outputTlvTree, TAG_CERT_AUTH_PUB_KEY_EXPONENT, Exponent, ExponentLength);
			}
		}
		EPSTOOL_TlvTree_Release(&tlvTree);
	}
	EPSTOOL_TlvTree_Release(&hTree);
	emvTransacStatusSet (*statusCode);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose: Called just after the Offline Data Authentication (SDA, DDA or first part of CDA) *
 * 			                                                                                  *
 * [in] :   inputTlvTree Input TlvTree.                                                       *
 * [out]:   outputTlvTree Output TlvTree.                                                     *
 * ------------------------------------------------------------------------------------------ */
void emvStepOfflineDataAuthentication (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	unsigned short found;
	DataElement Data_Elt;
	TLV_TREE_NODE hTree;

	hTree = Engine_GetDataElement(TAG_LAST_APDU_CMD_RESPONSE);
	TLV_TREE_NODE hFoundNode=NULL;
	found = FALSE;

	if(&hTree != NULL){
		hFoundNode = TlvTree_Find(hTree, TAG_LAST_APDU_CMD_RESPONSE, 0);
		if(hFoundNode != NULL){
			Data_Elt.tag = TlvTree_GetTag(hFoundNode);
			Data_Elt.length = TlvTree_GetLength(hFoundNode);
			Data_Elt.ptValue = TlvTree_GetData(hFoundNode);
			found = TRUE;
		}
	}
	if (found){
		// Check if it was an Internal Authenticate
		if ((Data_Elt.ptValue [0] == 0x00)  &&    // CLA command
			(Data_Elt.ptValue [1] == 0x88)  &&    // INS command
			(Data_Elt.ptValue [2] == 0x00)  &&    // P1 command
			(Data_Elt.ptValue [3] == 0x00))       // P2 command
		{
			unsigned char cmd_ok;
			// Check Response bytes SW1 SW2 for Exception handling
			cmd_ok = ((Data_Elt.ptValue [4] == 0x90) && (Data_Elt.ptValue [5] == 0x00))  ||
				((Data_Elt.ptValue [4] == 0x62) && (Data_Elt.ptValue [5] == 0x83))  ||
				((Data_Elt.ptValue [4] == 0x63) && ((Data_Elt.ptValue [5] & 0xF0) == 0xC0));
			if (!cmd_ok){
				*statusCode = STATUS_TR_CARD_ERROR;
			}
		}
	}
	emvTransacStatusSet (*statusCode);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose: Called just after the Processing Restriction step.                                *
 * 			                                                                                  *
 * [in] :   inputTlvTree Input TlvTree.                                                       *
 * [out]:   outputTlvTree Output TlvTree.                                                     *
 * ------------------------------------------------------------------------------------------ */
void emvStepProcessingRestrictions (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);


	const unsigned long cst_tag_list[] = {
		TAG_TERMINAL_CAPABILITIES,
	};
	EMVDataElement termParam[] = {ContactEMVParameter};
	int emvTagCount =  sizeof (cst_tag_list) / sizeof(unsigned long);
	int emvParam = sizeof (termParam) / sizeof (EMVDataElement);
	int x, y;
	for (x = 0; x < emvTagCount; x++){
		for (y = 0; y < emvParam; y++){
			if (!memcmp(&cst_tag_list[x],&termParam[y].tag, sizeof(unsigned long))){
				VERIFY(TlvTree_AddChild(outputTlvTree, termParam[y].tag, termParam[y].ptValue, termParam[y].length) != NULL);
			}
		}
	}

#ifdef DEBUG
	DataElement Data_Elt;
	TLV_TREE_NODE hTree;

	hTree = Engine_GetDataElement(TAG_TVR);
	TLV_TREE_NODE hFoundNode=NULL;
	found = FALSE;

	if(&hTree != NULL){
		hFoundNode = TlvTree_Find(hTree, TAG_TVR, 0);
		if(hFoundNode != NULL){
			Data_Elt.tag = TlvTree_GetTag(hFoundNode);
			Data_Elt.length = TlvTree_GetLength(hFoundNode);
			Data_Elt.ptValue = TlvTree_GetData(hFoundNode);
			found = TRUE;
		}
	}
#endif

	emvTransacStatusSet (*statusCode);
}
