#include <sdk_tplus.h>
#include "IP_.h"
#include "HTTP_.h"

static HTTP_SERVER_HANDLE hServerHTTP;


int httpServerWaitForRequest(HTTP_SERVER_DATA **pRequest){
	 int nError;
	 char localIP[15+1]={0};
	 unsigned int local_addr = 0;
	 unsigned char *p;
	 EthernetGetOption(ETH_IFO_ADDR, &local_addr );
	   p = (char *) &local_addr;
	   sprintf(localIP, "%d.%d.%d.%d", p[0], p[1], p[2], p[3] );

	 if( HTTP_Server_Open( &hServerHTTP, 80, "/HOST" ) != HTTP_SERVER_OK )
	 {       // Error.
	    return FALSE;
	 }
	 while(1){       // Wait for a request.
		nError = HTTP_Server_WaitRequest ( hServerHTTP, 80, pRequest );
		 //...
		if ( nError == HTTP_SERVER_OK )
		{
			if ( (*pRequest)->m_nCommand == HTTP_SERVER_POST )
			{
				return TRUE;

			}

		}
	 }
 }
