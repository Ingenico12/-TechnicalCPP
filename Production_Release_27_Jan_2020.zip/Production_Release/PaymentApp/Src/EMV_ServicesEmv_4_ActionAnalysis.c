/* ------------------------------------------------------------------------------------------ *
 *                            PROGRAM HISTORY                                                 *
 * ------------------------------------------------------------------------------------------ *
 * Ver.  Author(s)     Date         Description                                               *
 * ---   ---------     ----         -----------                                               *
 * V01   RS Software   06/30/2018   This module implements the EMV Engine services related to *
 * 									action analysis (Terminal Risk Management, Terminal Action*
 * 									Analysis and Card Action Analysis).                       *
 * ------------------------------------------------------------------------------------------ */
#include "sdk.h"
#include "SEC_interface.h"
#include "GL_GraphicLib.h"
#include "TlvTree.h"
#include "GTL_Assert.h"
#include "_emvdctag_.h"
#include "def_tag.h"
#include "EngineInterface.h"
#include "EngineInterfaceLib.h"
#include "servcomm.h"

#include "EPSTOOL_TlvTree.h"
#include "EPSTOOL_PinEntry.h"

#include "EMV.h"
#include "emvparameter.h"

/* ------------------------------------------------------------------------------------------ *
 * Purpose: Retrieve the last transaction performed with the same card.                       *
 * 			                                                                                  *
 * [in] :   inputTlvTree Input TlvTree. Usually contains the PAN.                             *
 * [out]:   outputTlvTree Output TlvTree. If a transaction is found, it must be filled with	  *
 * 			TAG_LAST_TR_AMOUNT_BIN and TAG_LAST_TR_CURRENCY_CODE.                             *
 * ------------------------------------------------------------------------------------------ */
void emvGetLastTransaction (TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	static const EPSTOOL_Tag_t tagsToGet[] = { TAG_APPLI_PRIM_ACCOUNT_NB, TAG_APPLI_PRIM_ACCOUNT_NB_SEQ_NB };
	TLV_TREE_NODE tlvTree;
	//TLV_TREE_NODE nodePan;
	//TLV_TREE_NODE nodePanSeqNumber;
	//EPSTOOL_Data_t dataPan;
	//EPSTOOL_Data_t dataPanSeqNumber;

	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	// Retrieve the PAN and the PAN Sequence Counter
	tlvTree = Engine_GetDataElements(sizeof(tagsToGet) / sizeof(tagsToGet[0]), tagsToGet);
	if (tlvTree != NULL) {
		// TODO: Uncomment if PAN is needed
		//nodePan = EPSTOOL_TlvTree_FindFirstData(tlvTree, TAG_APPLI_PRIM_ACCOUNT_NB, &dataPan);
		// TODO: Uncomment if PAN Sequence Number is needed
		//nodePanSeqNumber = EPSTOOL_TlvTree_FindFirstData(tlvTree, TAG_APPLI_PRIM_ACCOUNT_NB_SEQ_NB, &dataPanSeqNumber);

		// TODO: Get the last transaction amount
		// Set tags TAG_LAST_TR_AMOUNT_BIN and TAG_LAST_TR_CURRENCY_CODE

		// Free the memory
		EPSTOOL_TlvTree_Release(&tlvTree);
	}
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose: Called just after the Terminal Risk Management step.                              *
 * 			                                                                                  *
 * [in] :   inputTlvTree Input TlvTree.                                                       *
 * [out]:   outputTlvTree Output TlvTree.                                                     *
 * ------------------------------------------------------------------------------------------ */
void emvStepTerminalRiskManagement (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	emvTransacStatusSet (*statusCode);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose: Called just after the Terminal Action Analysis step and before 1st Gen AC         *
 * 			                                                                                  *
 * [in] :   inputTlvTree Input TlvTree.                                                       *
 * [out]:   outputTlvTree Output TlvTree.Standard result from the EMV kernel can be overridden*
 * 			by setting the tag TAG_TAA_RESULT.                                                *
 * ------------------------------------------------------------------------------------------ */
void emvStepTerminalActionAnalysis (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	emvTransacStatusSet (*statusCode);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose: Called just after the first GENERATE AC command.                                  *
 * 			                                                                                  *
 * [in] :   inputTlvTree Input TlvTree.                                                       *
 * [out]:   outputTlvTree Output TlvTree.                                                     *
 * ------------------------------------------------------------------------------------------ */
void emvStepCardActionAnalysis (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	emvTransacStatusSet (*statusCode);
}
