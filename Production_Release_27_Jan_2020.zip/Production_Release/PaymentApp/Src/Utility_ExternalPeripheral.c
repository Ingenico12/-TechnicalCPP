#include <sdk_tplus.h>
#include "TlvTree.h"
#include "LinkLayer.h"
#include "Transaction.h"

extern struct sUserData * pUserData;

extern struct sPinPadData *pPinPadData;
static LL_HANDLE hSession = NULL;                                        // Session handle

void getDataToSendPinPad(){
	int i=0;
	pPinPadData->feeCount = pUserData->mFeeCount;
	for(i;i<pUserData->mFeeCount;i++){
		memcpy(pPinPadData->feeData[i].mFeeType,pUserData->feeList[i].feeType,sizeof(pPinPadData->feeData[i].mFeeType));
		memcpy(pPinPadData->feeData[i].mFeeMid,pUserData->feeList[i].feeMID,sizeof(pPinPadData->feeData[i].mFeeMid));
		memcpy(pPinPadData->feeData[i].mAmount,pUserData->feeList[i].feeAmount,sizeof(pPinPadData->feeData[i].mAmount));
	}
	memcpy(pPinPadData->mTranType,pUserData->mTransactionType,sizeof(pPinPadData->mTranType));
}

LL_HANDLE OpenUSB(void) {

	if(hSession == NULL){
		// Local variables
		// ***************
		TLV_TREE_NODE piConfig=NULL;
		TLV_TREE_NODE piPhysicalConfig=NULL;

		int iRet;

		// Create the LinkLayer configuration parameters tree
		// **************************************************

		// Create parameters tree
		// ======================
		piConfig = TlvTree_New(LL_TAG_LINK_LAYER_CONFIG);                 // LinkLayer parameters Root tag of the configuration tree

		// Physical layer parameters
		// =========================
		piPhysicalConfig = TlvTree_AddChild(piConfig,
											LL_TAG_PHYSICAL_LAYER_CONFIG, // TAG Physical layer parameters
											NULL,                         // VALUE (Null)
											0);                           // LENGTH 0

		// Port USB
		// --------
		if (IsIPP3XX()){
			TlvTree_AddChildInteger(piPhysicalConfig,
									LL_PHYSICAL_T_LINK,                       // TAG
									LL_PHYSICAL_V_USB,                        // VALUE
									LL_PHYSICAL_L_LINK);                      // LENGTH 1 byte
		}
		else {
			TlvTree_AddChildInteger(piPhysicalConfig,
									LL_PHYSICAL_T_LINK,                   // TAG
									LL_PHYSICAL_V_USB_HOST,               // VALUE
									LL_PHYSICAL_L_LINK);                  // LENGTH 1 byte
		}

		// Link Layer configuration
		// ************************
		iRet = LL_Configure(&hSession, piConfig);                         // Initialize the handle of the session

		goto lblEnd;

		// Errors treatment
		// ****************
	lblKOConfigure:                                                       // Configuration failed
		hSession=NULL;
		goto lblEnd;
	lblEnd:
		if (piConfig)
			TlvTree_Release(piConfig);                                    // Release tree to avoid memory leak
	}
	return hSession;                                                  // Return the handle of the session
}
int ConnectUSB(LL_HANDLE hSession) {
    int iRet;
    iRet = LL_Connect(hSession);     // Link Layer connection
    return iRet;
}
int SendUSB(LL_HANDLE hSession, const char *pcMsg, word usLen) {
    int iRet;
    iRet = LL_Send(hSession, usLen, pcMsg, 20*10);
    return iRet;
}
int ReceiveUSB(LL_HANDLE hSession,unsigned char *rsp,int timeOut) {
    int iRet=0,iNbrBytes=0,lTimeOut=0,idx=0,iLength;
    char recvData[sizeof (struct sUserData) + 1]={0};
    iRet = TimerStart(0, timeOut);                                            // Timer0 starts
   	do {

   			iNbrBytes = LL_Receive(hSession, sizeof (struct sUserData), recvData, 10*10);
		if (iNbrBytes != 0)
		{
			// Receiving next block until timeout (Inter block 500ms)
			// ======================================================
			while(1)
			{
				iLength = LL_Receive(hSession, sizeof (struct sUserData)-iNbrBytes, recvData+iNbrBytes, 50);
				iNbrBytes += iLength;
				iRet = LL_GetLastError(hSession);
				/*if((iRet!=LL_ERROR_OK) || (iRet!=LL_ERROR_TIMEOUT))
					break;
				if ((iRet==LL_ERROR_TIMEOUT) || (iNbrBytes==0))
					break;*/
				if(iLength==0)
					break;
				else if(iLength>0)
					continue;
			}
		}
       	if (iNbrBytes != 0)
       		break;                                                         // Bytes received
   			lTimeOut = TimerGet(0);                                        // Retrieve timer value
   	} while (lTimeOut>0);
   	memcpy(rsp,recvData,sizeof (struct sUserData));
    return iNbrBytes;
}
int DisconnectUSB(LL_HANDLE hSession) {
	int iRet;
	iRet = LL_Disconnect(hSession);
	return iRet;
}
int CloseUSB() {
    int iRet;
    iRet = LL_Configure(&hSession, NULL);
    return iRet;
}
int connectExternalPINPad (){
	LL_HANDLE hUSB=NULL;
	int iRet=0;
	char tcSnd[100]={0};
	//getDataToSendPinPad();
	char tcRsp[sizeof (struct sUserData) + 1] = {0};
	memset(tcRsp, 0, sizeof (struct sUserData) + 1);
	hUSB = OpenUSB();
	iRet = ConnectUSB(hUSB);
	if(iRet==LL_ERROR_OK){
		LL_ClearSendBuffer(hUSB);
		LL_ClearReceiveBuffer(hUSB);

		//iRet = SendUSB(hUSB, pPinPadData, (word) sizeof (struct sPinPadData));            // ** Send data **
		iRet = SendUSB(hUSB, pUserData, (word) sizeof (struct sUserData));            // ** Send data **
		if (iRet > 0){
			iRet = ReceiveUSB(hUSB, tcRsp,60*GL_TIME_SECOND);       // ** Receive data **
			if (iRet > 0){
				memcpy (pUserData, tcRsp, sizeof (struct sUserData));
				GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, pUserData->mUserText, GL_ICON_INFORMATION, GL_BUTTON_NONE, 1 * GL_TIME_SECOND);
				memset(tcRsp, 0, sizeof (struct sUserData) + 1);
			}
			else
				goto lblError;
		}
		else
			goto lblError;
		iRet = ReceiveUSB(hUSB, tcRsp,300*GL_TIME_SECOND);       // ** Receive data **
		if (iRet > 0){
			GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "DATA RECEIVED", GL_ICON_INFORMATION, GL_BUTTON_ALL, 1 * GL_TIME_SECOND);
			memcpy (pUserData, tcRsp, sizeof (struct sUserData));
			memset(tcRsp, 0, sizeof (struct sUserData) + 1);
			DisconnectUSB(hUSB);
			//CloseUSB();                                            // ** Close **
			return TRUE;
		}
		else
			goto lblError;
	}
	else
		goto lblError;

	lblError:
	DisconnectUSB(hUSB);
	//CloseUSB();
	return FALSE;
}
void acknowledgePINPad (){
	LL_HANDLE hUSB=NULL;
	int iRet;
	hUSB = OpenUSB();
	if (hUSB != NULL) {
		iRet = ConnectUSB(hUSB);
		if (iRet == LL_ERROR_OK) {
			memset(pUserData->mUserText,0,sizeof(pUserData->mUserText));
			strcpy(pUserData->mUserText,getResponseText());
			iRet = SendUSB(hUSB, pUserData, (word) sizeof (struct sUserData));   // Send data
			DisconnectUSB(hUSB);
		}
		//CloseUSB();
	}
}
void acknowledgeClerk (){
	LL_HANDLE hUSB=NULL;
	int iRet;
	hUSB = OpenUSB();
	if (hUSB != NULL) {
		iRet = ConnectUSB(hUSB);
		if (iRet == LL_ERROR_OK) {
			iRet = SendUSB(hUSB, pUserData, (word) sizeof (struct sUserData));   // Send data
			DisconnectUSB(hUSB);
		}
		//CloseUSB();
	}
}

