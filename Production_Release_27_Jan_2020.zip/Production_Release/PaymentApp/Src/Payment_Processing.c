#include <sdk_tplus.h>
#include <OSL_Logger.h>
#include <GL_GraphicLib.h>
#include "LinkLayer.h"
#include "EMV.h"
#include "GL_Types.h"
#include "Transaction.h"

int processPaymentTransaction (char *transactionType) {
	processOnlineTransaction (transactionType);
	return TRUE;
}


