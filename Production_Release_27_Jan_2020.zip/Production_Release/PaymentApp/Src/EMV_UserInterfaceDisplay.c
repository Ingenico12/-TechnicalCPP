/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   06/30/2018   This module manages the EMV user interface.                   *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "SEC_interface.h"
#include "GL_GraphicLib.h"
#include "TlvTree.h"
#include "GTL_Assert.h"
#include "GTL_Convert.h"

#include "_emvdctag_.h"
#include "def_tag.h"
#include "EngineInterface.h"
#include "EngineInterfaceLib.h"

#include "EPSTOOL_TlvTree.h"
#include "EPSTOOL_PinEntry.h"
#include "EPSTOOL_Unicode.h"

#include "EMV.h"
static T_GL_COORD __APEMV_UI_MessageAuthorisationUpdate(T_GL_COORD value);
static void __APEMV_UI_PinEntry_Refresh(struct EPSTOOL_PinEntry_Infos_t *interface, T_GL_HWIDGET label, int pinLength);

T_GL_HGRAPHIC_LIB idleGraphicInstance;
static unsigned long __APEMV_UI_AuthorisationStartTime;		//!< Used to display a fake progress bar during authorisation.

static T_GL_HGRAPHIC_LIB __APEMV_UI_goalHandle = NULL;	    //!< The GOAL handle.
static Telium_File_t *__APEMV_UI_displayDriver = NULL;		//!< The display driver handle.
static Telium_File_t *__APEMV_UI_keyboardDriver = NULL;		//!< The keyboard driver handle.
static Telium_File_t *__APEMV_UI_touchDriver = NULL;		//!< The touch screen driver handle.

/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Create the graphic library instance.                                                  *
 * [Return]: pointer to graphic library handle.                                                   *
 * ---------------------------------------------------------------------------------------------- */
T_GL_HGRAPHIC_LIB APEMV_UI_GoalHandle(void) {
	if (__APEMV_UI_goalHandle == NULL) {
		__APEMV_UI_goalHandle = GL_GraphicLib_Create();
	}
	return __APEMV_UI_goalHandle;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Destroy the graphic library instance.                                                 *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_GoalDestroy(void) {
	if (__APEMV_UI_goalHandle != NULL ) {
		GL_GraphicLib_Destroy(__APEMV_UI_goalHandle);
		__APEMV_UI_goalHandle = NULL;
	}
	if(idleGraphicInstance != NULL ){
		GL_GraphicLib_Destroy(idleGraphicInstance);
		idleGraphicInstance = NULL;
	}
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Open the GOAL interface (open drivers ...).                                           *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_GoalOpen(void) {
	if (__APEMV_UI_displayDriver == NULL)
		__APEMV_UI_displayDriver = Telium_Fopen("DISPLAY", "w*");
	if (__APEMV_UI_keyboardDriver == NULL)
		__APEMV_UI_keyboardDriver = Telium_Fopen("KEYBOARD", "r*");
	if (__APEMV_UI_touchDriver == NULL)
		__APEMV_UI_touchDriver = Telium_Fopen("TSCREEN", "r*");
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Close the GOAL interface (close drivers ...).                                         *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_GoalClose(void) {
	if (__APEMV_UI_displayDriver != NULL) {
		Telium_Fclose(__APEMV_UI_displayDriver);
		__APEMV_UI_displayDriver = NULL;
	}
	if (__APEMV_UI_keyboardDriver != NULL) {
		Telium_Fclose(__APEMV_UI_keyboardDriver);
		__APEMV_UI_keyboardDriver = NULL;
	}
	if (__APEMV_UI_touchDriver != NULL) {
		Telium_Fclose(__APEMV_UI_touchDriver);
		__APEMV_UI_touchDriver = NULL;
	}
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Setup the user interface environment to perform a transaction.                        *
 * ---------------------------------------------------------------------------------------------- */
int APEMV_UI_TransactionBegin(void) {
	idleGraphicInstance = APEMV_UI_GoalHandle();
	int result;

	result = 0;
	if (DisplayHeader(_OFF_) == _ON_)
		result |= 0x01;
	if (DisplayFooter(_OFF_) == _ON_)
		result |= 0x02;

	GL_GraphicLib_OpenApplicationWindow(idleGraphicInstance);

	return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Restore the user interface environment as it was before the transaction.              *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_TransactionEnd(int previous) {
	DisplayHeader((previous & 0x01) ? _ON_ : _OFF_);
	DisplayFooter((previous & 0x02) ? _ON_ : _OFF_);

	GL_GraphicLib_CloseApplicationWindow(idleGraphicInstance);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called when "Insert card" message to be displayed on Terminal Screen                  *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageInsertCard(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Insert card", GL_ICON_INFORMATION, GL_BUTTON_NONE, 0);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called when "Remove card" message to be displayed on Terminal Screen                  *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageRemoveCard(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Remove card", GL_ICON_INFORMATION, GL_BUTTON_NONE, 0);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called when "Please wait" message to be displayed on Terminal Screen                  *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessagePleaseWait(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Please wait", GL_ICON_INFORMATION, GL_BUTTON_NONE, 0);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called when "No remaining PIN" message to be displayed on Terminal Screen             *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageNoRemainingPin(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "No remaining PIN", GL_ICON_WARNING, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the "Wrong PIN" message.                                                      *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageWrongPin(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Wrong PIN", GL_ICON_WARNING, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the "Correct PIN" message.                                                    *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageCorrectPin(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Correct PIN", GL_ICON_INFORMATION, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the "Approved" message.                                                       *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageApproved(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Approved", GL_ICON_INFORMATION, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the "Declined" message.                                                       *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageDeclined(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Declined", GL_ICON_ERROR, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the "Service not allowed" message.                                            *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageServiceNotAllowed(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Service\nnot allowed", GL_ICON_ERROR, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the "Transaction Cancelled" message.                                          *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageTransactionCancelled(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Transaction\ncancelled", GL_ICON_ERROR, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the "PIN Entry Cancelled by Card Holder" message.                                          *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_PINEntryCancelledbyCardholder(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "PIN Entry Cancelled by\n Card Holder", GL_ICON_ERROR, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	APEMV_UI_GoalClose();
}

/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the "Card blocked" message.                                                   *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageCardBlocked(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Card blocked", GL_ICON_ERROR, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the "Card removed" message.                                                   *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageCardRemoved(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Card removed", GL_ICON_ERROR, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the "Invalid card" message.                                                   *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageCardError(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "EMV Chip Error", GL_ICON_ERROR, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the "Card Not Supported For EMV" message.                                              *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageCardNotSupportedEMV(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Card is Not EMV Supported", GL_ICON_ERROR, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	APEMV_UI_GoalClose();
}

/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the "Transaction error" message.                                              *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MessageTransactionError(void) {
	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Transaction\nerror", GL_ICON_ERROR, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	APEMV_UI_GoalClose();
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called regularly by GOAL, from function APEMV_UI_MessageAuthorisation.                *
 * 			Used to update the authorisation progress bar.	                                      *
 * 			This function is used to simulate an authorisation of 1 second.                       *
 * [in] :   value The actual value of the progress bar.                                           *
 * [return]: The new value of the progress bar.                                                   *
 * ---------------------------------------------------------------------------------------------- */
static T_GL_COORD __APEMV_UI_MessageAuthorisationUpdate(T_GL_COORD value) {
	value = ((100 * (TMT_Retrieve_Clock() - __APEMV_UI_AuthorisationStartTime)) / 100);
	if (value > 100)
		value = 100;
	return value;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the "Authorisation in progress" message with a progress bar.                NU*
 * 			This function is used to simulate an authorisation of 1 second.                       *
 * [return]: TRUE if successful.                                                                  *
 * 			 FALSE if it has been cancelled.                                                      *
 * ---------------------------------------------------------------------------------------------- */
int APEMV_UI_MessageAuthorisation(void) {
	int cancel;

	APEMV_UI_GoalOpen();
	__APEMV_UI_AuthorisationStartTime = TMT_Retrieve_Clock();
	cancel = (GL_Dialog_Progress(idleGraphicInstance, NULL, "Authorisation...", NULL, NULL, 0, 100,
			__APEMV_UI_MessageAuthorisationUpdate, GL_BUTTON_CANCEL, GL_TIME_INFINITE) != GL_KEY_NONE);
	APEMV_UI_GoalClose();

	return !cancel;
}
/*
void APEMV_UI_MessageReferral(void)
{
}
*/
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Perform the signature capture and stores the signature in a file.                     *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_RequestSignature(void) {
	int previousHeader;
	int previousFooter;

	if (GL_GraphicLib_IsTouchPresent(idleGraphicInstance))
	{
		APEMV_UI_GoalOpen();

		// Remove the header and footer if present
		previousHeader = DisplayHeader(_OFF_);
		previousFooter = DisplayFooter(_OFF_);

		// Request for signature
		// TODO: Store the signature with the transaction data
		GL_Dialog_Signature(idleGraphicInstance, NULL, "Signature", "file://flash/HOST/SIGNATURE.SIG", 3*GL_TIME_MINUTE);
		GL_File_Delete( "file://flash/HOST/SIGNATURE.SIG" );

		// Restore the header and footer context
		DisplayFooter(previousFooter);
		DisplayHeader(previousHeader);

		APEMV_UI_GoalClose();
	}
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display a screen with list of Application Preferred Name(s)/ Application Label(s) to  *
 * 			select an AID by cardholder													          *
 * 			                                                                                      *
 * [in] :   numOfAids - Number of matched AIDs.							             		      *
 * 			aids Possible AIDs.																      *
 * [out]:   Index of the selected AID (starting from 0) or (-1) if the input is cancelled         *
 * ---------------------------------------------------------------------------------------------- */
int APEMV_UI_MenuSelectAid(int numOfAids, const APEMV_UI_SelectAidItem_t *aids) {
	int result;
	char **menu;
	int index;
	int usePreferredName;

	ASSERT(numOfAids > 0);
	ASSERT(aids != NULL);

	// Allocate memory to fill with the menu data
	menu = umalloc((numOfAids + 1) * sizeof(char*));
	if (menu != NULL) {
		memclr(menu, (numOfAids + 1) * sizeof(char*));

		// Set the menu item with the Application Label or with to Application Preferred Name
		result = 0;
		index = 0;
		while((index < numOfAids) && (result >= 0)) {
			// Check if label or preferred name must be used
			usePreferredName = FALSE;
			if (aids[index].preferredName[0] != '\0') {
				// There is a Preferred Name

				// TODO: Check if the Issuer Code Table Index is supported or not.
				// By default, GOAL support ISO8859 1, 2, 3, 4, 9, 10, 13, 14, 15, 16.
				// But EMVCo limits it from ISO8859 1 to 10.
				switch(aids[index].issuerCodeTableIndex)
				{
					case 1:
					//case 2:
					//case 3:
					//case 4:
					//case 9:
					//case 10:
						usePreferredName = TRUE;
						break;
				}
			}

			if (usePreferredName) {
				// Use the Application Preferred Name
				// Convert 'aids[index].preferredName' into UTF-8
				menu[index] = EPSTOOL_Unicode_CharsetToNewUtf8(aids[index].preferredName,
						sizeof(aids[index].preferredName),
						aids[index].issuerCodeTableIndex - 1 + EPSTOOL_UNICODE_ISO_8859_1);
				if (menu[index] == NULL) {
					result = -2;
				}
			}
			else if (aids[index].applicationLabel[0] != '\0') {
				// Use the Application Label (there is no need to convert it in UTF-8 as it is ASCII with no special characters)
				menu[index] = umalloc(strlen(aids[index].applicationLabel) + 1);
				if (menu[index] != NULL) {
					strcpy(menu[index], aids[index].applicationLabel);
				}
				else {
					result = -2;
				}
			}
			else {
				// There is neither Application Label nor Application Preferred Name
				// Use the AID instead
				menu[index] = umalloc(2 * aids[index].aidLength + 1);
				if (menu[index] != NULL) {
					// Convert the AID into an ASCII string
					GTL_Convert_DcbToAscii(aids[index].aid, menu[index], 0, 2 * aids[index].aidLength);
				}
				else {
					result = -2;
				}
			}
			index++;
		}

		if (index >= 0) {
			APEMV_UI_GoalOpen();

			// Display the menu
			// Note that last item 'menu[numOfAids]' is equal to NULL because of the memclr(menu)
			result = GL_Dialog_Menu(idleGraphicInstance, "Select Application",
					(const char * const *)menu, 0, GL_BUTTON_VALID_CANCEL, GL_KEY_NONE, 2 * GL_TIME_MINUTE);
			if ((result < 0) || (result > numOfAids)) {
				// Cancelled
				result = -1;
			}
			APEMV_UI_GoalClose();
		}

		// Free the memory
		for(index = 0; index < numOfAids; index++) {
			if (menu[index] != NULL) {
				ufree(menu[index]);
			}
		}
		ufree(menu);
	}
	else {
		result = -2;
	}
	return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: UI functionalities to Perform the cardholder language selection.                      *
 * [Note] : Not implemented. Will update the functionalities as required.                         *
 * ---------------------------------------------------------------------------------------------- */
void APEMV_UI_MenuSelectLanguage(char language[2]) {
	ASSERT(language != NULL);
	language[0] = 'e';
	language[1] = 'n';
	// TODO: Select the cardholder language
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Select the account type by user. 		                                              *
 * [out]:   accountType The selected account type:					                              *
 *          ACCOUNT_TYPE_DEFAULT for "No choice".                                                 *
 *          ACCOUNT_TYPE_CHEQUE_DEBIT for check or debit account.                                 *
 *          ACCOUNT_TYPE_CREDIT for a credit account.                                             *
 *          ACCOUNT_TYPE_SAVINGS for a saving account.                                            *
 * ---------------------------------------------------------------------------------------------- */
int APEMV_UI_MenuSelectAccountType(unsigned char *accountType) {
	static const char *menu[] =
	{
			"No choice",
			"Check / Debit",
			"Credit",
			"Saving",
			NULL
	};
	int result;

	ASSERT(accountType != NULL);

	APEMV_UI_GoalOpen();

	result = TRUE;
	switch(GL_Dialog_Menu(idleGraphicInstance, "Account Type", menu, 0, GL_BUTTON_VALID_CANCEL, GL_KEY_NONE, 2 * GL_TIME_MINUTE))
	{
	case 0:
		*accountType = ACCOUNT_TYPE_DEFAULT;
		break;
	case 1:
		*accountType = ACCOUNT_TYPE_CHEQUE_DEBIT;
		break;
	case 2:
		*accountType = ACCOUNT_TYPE_CREDIT;
		break;
	case 3:
		*accountType = ACCOUNT_TYPE_SAVINGS;
		break;
	default:
		*accountType = ACCOUNT_TYPE_DEFAULT;
		result = FALSE;
		break;
	}

	APEMV_UI_GoalClose();

	return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: UI functionalities to ask the merchant to force accept the declined transaction.      *
 * [Note] : if the merchant asked to force the acceptance of the transaction.                     *
 * 			TAG_CUST_FORCED_ACCEPTANCE_REQUEST = TRUE                                             *
 * ---------------------------------------------------------------------------------------------- */
int APEMV_UI_MenuForceAcceptance(void) {
	const char *menu[]={
			"No",
			"Yes",
			NULL
	};
	int result;

	APEMV_UI_GoalOpen();
	GL_Dialog_Message(idleGraphicInstance, NULL, "Declined", GL_ICON_WARNING, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
	result = (GL_Dialog_Menu(idleGraphicInstance, "Force transaction?", menu, 0, GL_BUTTON_VALID_CANCEL, GL_KEY_NONE, 2 * GL_TIME_MINUTE) == 1);
	APEMV_UI_GoalClose();

	return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Ask for an amount.                                                                  NU*
 * [out]:   amount Entered amount.         				                                          *
 * [return]: TRUE if the amount is entered.                                                       *
 *           FALSE if not (cancelled ...).                                                        *
 * ---------------------------------------------------------------------------------------------- */
int APEMV_UI_AmountEntry(unsigned long *amount) {
	int result;
	const char entryMask[] = "/d/d/d,/d/d/D./D/D";
	const char currencyLabel[] = "EUR";
	char amountString[32 + 1];

	ASSERT(amount != NULL);

	APEMV_UI_GoalOpen();

	result = (GL_Dialog_Amount(idleGraphicInstance, NULL, "Amount:", entryMask, amountString,
			sizeof(amountString) - 1, currencyLabel, GL_ALIGN_RIGHT, 2 * GL_TIME_MINUTE) == GL_KEY_VALID);
	if (result)
	{
		EPSTOOL_Convert_AsciiToUl(amountString, -1 , amount);
	}

	APEMV_UI_GoalClose();

	return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called when the display must be updated during a PIN entry.                           *
 * [in]:    - interface PIN entry parameters.                                                     *
 * 			- label Handle of the GOAL widget that is used to display the PIN entry.              *
 * 			- pinLength Current length of the entered PIN.                                        *
 * ---------------------------------------------------------------------------------------------- */
static void __APEMV_UI_PinEntry_Refresh(struct EPSTOOL_PinEntry_Infos_t *interface, T_GL_HWIDGET label, int pinLength) {
	const char defaultString[] = "- - - -";
	char string[64];
	int index;

	ASSERT(interface != NULL);
	ASSERT(label != NULL);

	if (pinLength <= 0) {
		// No PIN entered => display a default message
		GL_Widget_SetText(label, defaultString);
	}
	else {
		// PIN entry is in progress
		//  => Update the display

		// Check PIN length to avoid buffer overflows
		if (pinLength > (sizeof(string) / 2))
			pinLength = sizeof(string) / 2;

		// Format a string to have a star '*' and a space ' ' for each digit
		// Ex: for a 4 digits PIN, the string will be "* * * *"
		for(index = 0; index < pinLength; index++) {
			string[2 * index] = '*';
			string[(2 * index) + 1] = ' ';
		}
		string[(2 * (pinLength - 1)) + 1] = '\0';

		// Display the string that contains the stars
		GL_Widget_SetText(label, string);
	}
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Ask for a PIN entry.                                                                  *
 * [in]:    - pinType                                                                             *
 * 				INPUT_PIN_OFF for an offline PIN entry or                                         *
 * 				INPUT_PIN_ON for an online PIN entry.                                             *
 * 			- pinTryCounter The PIN try counter from the card. Give (-1) if unknown.              *
 * [out]:   pinLength Length of entered PIN.                                                      *
 * [return]: Any value of EPSTOOL_PinEntry_Status_e.                                              *
 * ---------------------------------------------------------------------------------------------- */
EPSTOOL_PinEntry_Status_e APEMV_UI_PinEntry(int pinType, int pinTryCounter, int *pinLength) {
	EPSTOOL_PinEntry_Infos_t pinEntryInfo;
	EPSTOOL_PinEntry_Status_e status;

	APEMV_UI_GoalOpen();
	if(idleGraphicInstance==NULL)
		idleGraphicInstance = APEMV_UI_GoalHandle();

	// Setup the PIN entry parameters
	pinEntryInfo.pinEntryConfig.ucEchoChar = '*';
	pinEntryInfo.pinEntryConfig.ucFontWidth = 0;
	pinEntryInfo.pinEntryConfig.ucFontHeight = 0;
	pinEntryInfo.pinEntryConfig.ucEchoLine = 0;
	pinEntryInfo.pinEntryConfig.ucEchoColumn = 0;
	pinEntryInfo.pinEntryConfig.ucMinDigits = 4;
	pinEntryInfo.pinEntryConfig.ucMaxDigits = 6;
	pinEntryInfo.pinEntryConfig.iFirstCharTimeOut = 60000;
	pinEntryInfo.pinEntryConfig.iInterCharTimeOut = 10000;
	if (pinType == INPUT_PIN_OFF) {
		// Offline PIN goes to the card reader
		pinEntryInfo.secureType = C_SEC_CARD;
	}
	else
	{
		// Online PIN goes to the PIN encryption module
		pinEntryInfo.secureType = C_SEC_PINCODE;
	}
	// TODO: Set here if PIN bypass is allowed or not
	pinEntryInfo.pinBypassAllowed = FALSE;
	// TODO: Set here some cancel events (CAM0 ...)
	pinEntryInfo.eventsToWait = CAM0 | CAM2;

	// Customisation functions
	pinEntryInfo.userEvents = NULL;
	pinEntryInfo.refresh = __APEMV_UI_PinEntry_Refresh;
	pinEntryInfo.privateData = NULL;

	do
	{
		// Ask for the PIN
		if (pinTryCounter == 1)
		{
			status = EPSTOOL_PinEntry(idleGraphicInstance, NULL, "Last Try",
					" ", &pinEntryInfo, pinLength);
		}
		else
		{
			status = EPSTOOL_PinEntry(idleGraphicInstance, NULL, "Enter PIN",
					" ", &pinEntryInfo, pinLength);
		}

		// If the PIN is not valid (too short), restart the PIN entry
		if (status == EPSTOOL_PINENTRY_INVALID)
		{
			GL_Dialog_Message(idleGraphicInstance, NULL, "Invalid PIN", GL_ICON_WARNING, GL_BUTTON_NONE, 2 * GL_TIME_SECOND);
		}
	} while(status == EPSTOOL_PINENTRY_INVALID);

	APEMV_UI_GoalClose();

	return status;
}
