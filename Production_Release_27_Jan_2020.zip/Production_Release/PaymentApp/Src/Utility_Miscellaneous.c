/* --------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                  *
 * --------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                *
 * ---   ---------     ----         -----------                                *
 * V01   RS Software   12/31/2017   Initial Creation                           *
 * --------------------------------------------------------------------------- */
#include <sdk_tplus.h>
#include "GL_GraphicLib.h"
#include "GL_Types.h"
#include "GTL_Assert.h"
#include "transaction.h"
#include "Utils.h"
#include "EMV.h"
#include "CLESS.h"
#include "XMLs.h"

static T_OSL_TIMESTP tllTimer[TMR_NBR];
static int __APCLESS_Tools_DayOfYear (Telium_Date_t *date);

int luhnCheck(char *cardNumber){

    byte idx;                   //current character index
    byte len;                   //pan length
    byte sum;                   //check sum
    byte odd;                   //odd/even flag
    byte tmp;

    len = strlen(cardNumber);
    if(!len)
        return 0;               //empty pan
    idx = len;
    sum = 0;
    odd = 1;
    while(idx--) {
        tmp = cardNumber[idx] - '0';
        if(!odd) {
            tmp += tmp;
            tmp = (tmp % 10) + (tmp / 10);
        }
        sum += tmp;
        odd = !odd;
    }
    if(sum % 10 == 0)
        return 1;
    return 0;
}
void UintToIp(doubleword uiVal, char*tcIp) {
	// Local variables
	// ***************
	byte ucVal1, ucVal2, ucVal3, ucVal4;

	// Conversion unsigned long to Ip address
	// **************************************
	ucVal1 = uiVal % 256;
	ucVal2 = (uiVal / 256) % 256;
	ucVal3 = (uiVal / (256 * 256)) % 256;
	ucVal4 = (uiVal / (256 * 256 * 256)) % 256;

	memset(tcIp, 0, 16 * sizeof(char));
	sprintf(tcIp, "%.3d.%.3d.%.3d.%.3d", ucVal4, ucVal3, ucVal2, ucVal1);

}
const char *parseStr(char ucToken, char *pcDst, const char *pcSrc, int iDim) {
	while (*pcSrc) {
		if (iDim == 0)        // Buffer pcDst overflow
			return NULL;      // Parsing failed

		if (*pcSrc == ucToken) // Token found
				{
			pcSrc++;          // Skip token
			break;
		}

		*pcDst++ = *pcSrc++;
		iDim--;
	}

    *pcDst=0;
    return pcSrc;
}

doubleword IpToUint(const char *pcStr) {
	// Local variables
	// ***************
	char tcStr1[3 + 2], tcStr2[3 + 2], tcStr3[3 + 2], tcStr4[3 + 2];
	doubleword uiVal = 0;

	// Conversion Ip address to unsigned int
	// *************************************
	if (*pcStr) {
		memset(tcStr4, 0, sizeof(tcStr4));
		pcStr = parseStr('.', tcStr4, pcStr, sizeof(tcStr4));
		if (pcStr == NULL)
			return 0;
		memset(tcStr3, 0, sizeof(tcStr3));
		pcStr = parseStr('.', tcStr3, pcStr, sizeof(tcStr3));
		if (pcStr == NULL)
			return 0;
		memset(tcStr2, 0, sizeof(tcStr2));
		pcStr = parseStr('.', tcStr2, pcStr, sizeof(tcStr2));
		if (pcStr == NULL)
			return 0;
		memset(tcStr1, 0, sizeof(tcStr1));
		pcStr = parseStr('.', tcStr1, pcStr, sizeof(tcStr1));
		if (pcStr == NULL)
			return 0;

		uiVal = atoi(tcStr4) * 256 * 256 * 256 + atoi(tcStr3) * 256 * 256
				+ atoi(tcStr2) * 256 + atoi(tcStr1);
	}

	return uiVal;
}
int bitTest(int bit, unsigned char *bitmap){
     unsigned char mask = 1;
     long offset;
     int i;                     //loop counter

     /*Position of the byte containing the bit from the start of bitmap   */
     offset = (bit-1)/8;
     /*   The mask bit is derived as a function of bit no.                */
     for (i=1; i<= (8-bit+8*((bit-1)/8)); i++)
          mask *= 2;

     return (((*((char *)bitmap + offset))& mask)? TRUE : FALSE);
}
int bitOff(int bit, unsigned char *bitmap){
     unsigned char mask = 1;
     long offset;
     int i;                     //loop counter

     /*Position of the byte containing the bit from the start of bitmap   */
     offset = (bit-1)/8;
     /*   The mask bit is derived as a function of bit no.                */
     for (i=1; i<= (8-bit+8*((bit-1)/8)); i++)
          mask *= 2;

     (*((char *)bitmap + offset)) &= (255-mask);
     return TRUE;
}
int bitOn(int bit, unsigned char *bitmap){
     unsigned char mask = 1;
     long offset;
     int i;                     //loop counter

     /*Position of the byte containing the bit from the start of bitmap   */
     offset = (bit-1)/8;
     /*   The mask bit is derived as a function of bit no.                */
     for (i=1; i<= (8-bit+8*((bit-1)/8)); i++)
          mask *= 2;

     (*((char *)bitmap + offset))|= mask;
     return TRUE;
}
char * hexToASCII (unsigned char * pFieldData, int len){
     int i, j=0;
     unsigned char dec[len];
     memcpy (&dec, pFieldData, len);
     char buffer[(len*2)+1];
     for (i=0; i < len; i++){
         memset (&buffer[i*2], dec[i], 2);
         buffer[i*2] = buffer[i*2] >> 2*2;
         buffer[(i*2)+1] &= '\x0F';
     }
     buffer[len*2] = '\x00';
     i = 0;
     while (buffer [i] == "\x00") {j++; i++;}
     for (i = 0; i < len*2; i++) {
         if ((int) buffer [i] > 9) {
        	 buffer [i] = (int) buffer [i] + 55;
         }
         else
        	 buffer [i] = (int) buffer [i] + 48;
     }
     memcpy (buffer, &buffer[j], sizeof(buffer));
     return buffer;
}


int hexadecimalToDecimal(char hexVal[]){
     int len = strlen(hexVal);
     int base = 1;
     int dec_val = 0;
     int i;
     for (i=len-1; i>=0; i--){
         if (hexVal[i]>='0' && hexVal[i]<='9'){
             dec_val += (hexVal[i] - 48)*base;
             base = base * 16;
         }
         else if (hexVal[i]>='A' && hexVal[i]<='F'){
             dec_val += (hexVal[i] - 55)*base;
             base = base*16;
         }
     }
     return dec_val;
}
int unsignedCharToInteger (unsigned char * pFieldData, int len){
     int i, j=0;
     unsigned char dec[2];
     memcpy (&dec, pFieldData, 2);
     char buffer[(len*2)+1];
     for (i=0; i < len; i++){
         memset (&buffer[i*2], dec[i], 2);
         buffer[i*2] = buffer[i*2] >> 2*2;
         buffer[(i*2)+1] &= '\x0F';
     }
     buffer[len*2] = '\x00';
     i = 0;
     while (buffer [i] == "\x00") {j++; i++;}
     for (i = 0; i < len*2; i++) {
         buffer [i] = (int) buffer [i] | 48;
     }
     memcpy (buffer, &buffer[j], sizeof(buffer));
     return atoi(buffer);
}
char * unsignedCharToASCII (unsigned char * pFieldData, int len){
    int i, j=0;
    unsigned char dec[len];
    memcpy (&dec, pFieldData, len);
    char buffer[(len*2)+1];
    for (i=0; i < len; i++){
        memset (&buffer[i*2], dec[i], 2);
        buffer[i*2] = buffer[i*2] >> 2*2;
        buffer[(i*2)+1] &= '\x0F';
    }
    buffer[len*2] = '\x00';
    i = 0;
    while (buffer [i] == "\x00") {j++; i++;}
    for (i = 0; i < len*2; i++) {
        if ((int) buffer [i] > 9) {
       	 buffer [i] = (int) buffer [i] + 55;
        }
        else
       	 buffer [i] = (int) buffer [i] + 48;
    }
    memcpy (buffer, &buffer[j], sizeof(buffer));
    return buffer;
}

//****************************************************************************
//             int TimerStart (byte ucTimerNbr, long lDelay)
//  This function starts a timer number for lDelay/1000 seconds.
//  After starting a timer a function TimerGet() should be called to know
//  whether it is over or not.
//  The timer should be over after iDelay/1000 seconds.
//   - OSL_TimeStp_Now() : Returns number of elapsed ticks since startup(1tick=1ns).
//  This function has parameters.
//     ucTimerNbr (I-) : Timer number 0..3
//     iDelay (I-) : Initial timer value in thousandth of second (ms)
//  This function has return value.
//     >=0 : TimerStart done
//     <0  : TimerStart failed
//****************************************************************************
long TimerStart(byte ucTimerNbr, long lDelay)
{
	// Local variables
    // ***************
	T_OSL_TIMESTP llTimer;

    // Start timer in progress
    // ***********************
  //  CHECK(ucTimerNbr<TMR_NBR, lblKO);

    // Get the current timer value
    // ===========================
    llTimer = OSL_TimeStp_Now();    // In 1ns ticks.

    // Set the timer to a 'period' into the future
    // ===========================================
    llTimer += (T_OSL_TIMESTP) lDelay*1000*1000;

    // Assign it to the proper timer
    // =============================
    tllTimer[ucTimerNbr]= llTimer;

    goto lblEnd;

	// Errors treatment
    // ****************
lblKO:
    lDelay=-1;
lblEnd:
    return lDelay;
}
//****************************************************************************
//             int TimerGet (byte ucTimerNbr)
//  This function returns the state of the timer number.
//   - OSL_TimeStp_Now() : Returns number of elapsed ticks since startup(1tick=1ns).
//   - OSL_TimeStp_ElapsedMs() : Gets elapsed time between 2 time stamp (end-begin in ms)
//  This function has parameters.
//     ucTimerNbr (I-) : Timer number 0..3
//  This function has return value.
//     >=0 : The number of milliseconds rest
//     <0  : TimerGet failed
//****************************************************************************
long TimerGet(byte ucTimerNbr)
{
	// Local variables
    // ***************
	T_OSL_TIMESTP llTimerEnd, llTimer;
    long lRet;

    // Get timer in progress
    // *********************
   // CHECK(ucTimerNbr<TMR_NBR, lblKO);

    // Get the remaining timer value before expiration
    // ===============================================
    llTimerEnd = tllTimer[ucTimerNbr];  // Retrieve the timer value to reach (ns)

    llTimer = OSL_TimeStp_Now();        // Get the current timer value (ns).

    if(llTimer < llTimerEnd)
    	lRet = OSL_TimeStp_ElapsedMs(llTimer, llTimerEnd);  // Return the remaining value (ms)
    else
    	lRet = 0;                                           // Timer expired

    goto lblEnd;

	// Errors treatment
    // ****************
lblKO:
    lRet=-1;
lblEnd:
    return lRet;
}
//****************************************************************************
//               int TimerStop (byte ucTimerNbr)
//  This function should be called when the timer number is no more needed.
//  This function has parameters.
//     ucTimerNbr (I-) : Timer number 0..3
//  This function has return value.
//     >=0 : TimerStop done
//     <0  : TimerStop failed
//****************************************************************************
int TimerStop(byte ucTimerNbr)
{
	// Local variables
    // ***************
    int iRet;

	// Stop timer in progress
	// **********************
 //   CHECK(ucTimerNbr<TMR_NBR, lblKO);

    tllTimer[ucTimerNbr] = 0;

    iRet=0;
    goto lblEnd;

	// Errors treatment
    // ****************
lblKO:
    iRet=-1;
lblEnd:
    return iRet;
}
char *ulltostr(unsigned long long value, char *ptr, int base)
{
	unsigned long long t = 0, res = 0;
	unsigned long long tmp = value;
  int count = 0;

  if (NULL == ptr)
  {
    return NULL;
  }

  if (tmp == 0)
  {
    count++;
  }

  while(tmp > 0)
  {
    tmp = tmp/base;
    count++;
  }

  ptr += count;

  *ptr = '\0';

  do
  {
    res = value - base * (t = value / base);
    if (res < 10)
    {
      * --ptr = '0' + res;
    }
    else if ((res >= 10) && (res < 16))
    {
        * -- ptr = 'A' - 10 + res;
    }
  } while ((value = t) != 0);

  return(ptr);
}
void callTerminalDisplay (char * displayText){
	// Display Text on Terminal Screen
	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, displayText, NULL, GL_BUTTON_ALL, 30*GL_TIME_SECOND);
	return;
}
void  make_date(int *d,int *m,int *y,int days)
{
  int flag=0,temp=0;
// variable days must have positive integer value

while(flag <days)
{
 (*d) ++;
 if( (*m) == 4 || (*m) == 6 || (*m) == 9 || (*m) == 11)
  {
       temp=30;
  }
 else if( (*m) == 2)
  {
       if( (*y) % 400 == 0 || ( (*y) % 100 != 0 && (*y) % 4 == 0 ))

           temp = 29;
       else
           temp = 28;
  }
 else
      temp=31;

 if( (*d) > temp)
  {
      (*m) ++;
      (*d) = 1;
  }
 if( (*m) == 13)
  {
      (*y) ++;
      (*m) = 1;
  }
 flag++;
}  // end of while
if(days<0)
{
	if(*m==1)
		*m=12;
	else
	(*m) --;

	if( (*m) == 4 || (*m) == 6 || (*m) == 9 || (*m) == 11)
	  {
	       temp=30;
	  }
	 else if( (*m) == 2)
	  {
	       if( (*y) % 400 == 0 || ( (*y) % 100 != 0 && (*y) % 4 == 0 ))

	           temp = 29;
	       else
	           temp = 28;
	  }
	 else
	      temp=31;

	*d=temp;
	if(*m==12)
		(*y) --;
}
return;
} // end of function

//! \brief Convert an unsigned long number into a big endian encoded number.
//! \param[in] number Number to convert.
//! \param[out] bigEndian Converted number. It must be a 4 bytes buffer.
void EPSTOOL_Convert_ULongToBigEndian(unsigned long number, unsigned char *bigEndian)
{
	// Check input parameters
	ASSERT(bigEndian != NULL);

	bigEndian[0] = (unsigned char)(number >> 24);
	bigEndian[1] = (unsigned char)(number >> 16);
	bigEndian[2] = (unsigned char)(number >> 8);
	bigEndian[3] = (unsigned char)(number);
}
//! \brief Convert an unsigned long number into a little endian encoded number.
//! \param[in] number Number to convert.
//! \param[out] littleEndian Converted number. It must be a 4 bytes buffer.
void EPSTOOL_Convert_ULongToLittleEndian(unsigned long number, unsigned char *littleEndian)
{
	// Check input parameters
	ASSERT(littleEndian != NULL);

	littleEndian[0] = (unsigned char)(number);
	littleEndian[1] = (unsigned char)(number >> 8);
	littleEndian[2] = (unsigned char)(number >> 16);
	littleEndian[3] = (unsigned char)(number >> 24);
}
//! \brief Convert an unsigned short number into a big endian encoded number.
//! \param[in] number Number to convert.
//! \param[out] bigEndian Converted number. It must be a 2 bytes buffer.
void EPSTOOL_Convert_UShortToBigEndian(unsigned short number, unsigned char *bigEndian)
{
	// Check input parameters
	ASSERT(bigEndian != NULL);

	bigEndian[0] = (unsigned char)(number >> 8);
	bigEndian[1] = (unsigned char)(number);
}
//! \brief Convert an unsigned short number into a little endian encoded number.
//! \param[in] number Number to convert.
//! \param[out] littleEndian Converted number. It must be a 2 bytes buffer.
void EPSTOOL_Convert_UShortToLittleEndian(unsigned short number, unsigned char *littleEndian)
{
	// Check input parameters
	ASSERT(littleEndian != NULL);

	littleEndian[0] = (unsigned char)(number);
	littleEndian[1] = (unsigned char)(number >> 8);
}
//! \brief Convert a big endian encoded number into an unsigned long number.
//! \param[in] bigEndian Big endian number to convert.
//! \return The converted number.
unsigned long int EPSTOOL_Convert_BigEndianToULong(const unsigned char *bigEndian)
{
	// Check input parameters
	ASSERT(bigEndian != NULL);

	return (((unsigned long)bigEndian[0]) << 24) | (((unsigned long)bigEndian[1]) << 16)
			| (((unsigned long)bigEndian[2]) << 8) | ((unsigned long)bigEndian[3]);
}

//! \brief Convert a little endian encoded number into an unsigned long number.
//! \param[in] littleEndian Little endian number to convert.
//! \return The converted number.
unsigned long int EPSTOOL_Convert_LittleEndianToULong(const unsigned char *littleEndian)
{
	// Check input parameters
	ASSERT(littleEndian != NULL);

	return ((unsigned long)littleEndian[0]) | (((unsigned long)littleEndian[1]) << 8)
			| (((unsigned long)littleEndian[2]) << 16) | (((unsigned long)littleEndian[3]) << 24);
}
//! \brief Convert a big endian encoded number into an unsigned short number.
//! \param[in] bigEndian Big endian number to convert.
//! \return The converted number.
unsigned short int EPSTOOL_Convert_BigEndianToUShort(const unsigned char *bigEndian)
{
	// Check input parameters
	ASSERT(bigEndian != NULL);

	return (((unsigned short)bigEndian[0]) << 8) | ((unsigned short)bigEndian[1]);
}

//! \brief Convert a little endian encoded number into an unsigned short number.
//! \param[in] littleEndian Little endian number to convert.
//! \return The converted number.
unsigned short int EPSTOOL_Convert_LittleEndianToUShort(const unsigned char *littleEndian)
{
	// Check input parameters
	ASSERT(littleEndian != NULL);

	return ((unsigned short)littleEndian[0]) | (((unsigned short)littleEndian[1]) << 8);
}
//! \brief Convert an ASCII coded number into an unsigned long number.
//! \param[in] asciiString ASCII string number to convert.
//! \param[in] length Length of \a asciiString. If set to (-1), the length of the string is calculated (so the string must be zero terminated).
//! \param[out] number Converted unsigned long number.
//! \return \a TRUE if the convertion is successful. \a FALSE if an invalid character is found.
int EPSTOOL_Convert_AsciiToUl(const char* asciiString, int length, unsigned long* number)
{
	int result;
	int index;

	ASSERT(asciiString != NULL);
	ASSERT(number != NULL);

	if (length < 0)
		length = strlen(asciiString);

	*number = 0;
	index = 0;
	result = TRUE;
	while((result) && (index < length))
	{
		if ((*asciiString >= '0') && (*asciiString <= '9'))
			*number = (*number * 10) + (unsigned long)(*asciiString - '0');
		else result = FALSE;

		index++;
		asciiString++;
	}

	return result;
}

//! \brief Convert an unsigned 64 bits number into a DCB number.
//! \param[in] value Unsigned 64 bits number.
//! \param[out] dcb Convert DCB number.
//! \param[in] dcbLength Length in bytes of \a dcb.
void EPSTOOL_Convert_UllToDcbNumber(unsigned long long value, void *dcb, int dcbLength)
{
	unsigned char* ptr;
	int firstHalf;
	unsigned long long maxValue;

	ASSERT(dcb != NULL);
	ASSERT(dcbLength > 0);

	switch(dcbLength)
	{
	case 0:		maxValue = 0ULL;					break;
	case 1:		maxValue = 99ULL;					break;
	case 2:		maxValue = 9999ULL;					break;
	case 3:		maxValue = 999999ULL;				break;
	case 4:		maxValue = 99999999ULL;				break;
	case 5:		maxValue = 9999999999ULL;			break;
	case 6:		maxValue = 999999999999ULL;			break;
	case 7:		maxValue = 99999999999999ULL;		break;
	case 8:		maxValue = 9999999999999999ULL;		break;
	case 9:		maxValue = 999999999999999999ULL;	break;
	default:	maxValue = 0xffffffffffffffffULL;	break;
	}

	// Truncate by removing extra ending digits
	while(value > maxValue)
		value /= 10;

	ptr = ((unsigned char*)dcb) + (dcbLength - 1);
	dcbLength *= 2;
	firstHalf = FALSE;
	while(dcbLength > 0)
	{
		if (firstHalf)
		{
			*ptr |= (unsigned char)((value % 10) << 4);
			ptr--;
		}
		else *ptr = (unsigned char)(value % 10);

		firstHalf = !firstHalf;

		value /= 10;
		dcbLength--;
	}
}
/**
 * Convert an ASCII string into a BCD string
 * @param[in] ascii input number buffer
 * @param[in] asciiLen length of \a ascii
 * @param[out] bcd output buffer
 * @param[in] shift number of '0' digits to add at the beginning of \a bcd
 * Example
 *    -  ascii: "3"   shift:0  -> bcd=0x30
 *    -  ascii: "123" shift:1  -> bcd=0x01 0x23
 * @note \a bcd should be large enough to contain the shift digits and the converted digits.
 */
void APCLESS_Tools_ConvertAsciiToBcd(char* ascii, int asciiLen, unsigned char* bcd, int shift)
{
   int i, j;
   unsigned char digit;

   // put the '0' padding
   j = shift/2;
   if(j > 0)
   {
      memset(bcd, 0, j);
      bcd += j;
   }

   // convert
   *bcd = 0;
   i = shift & 1;
   while(asciiLen-- > 0)
   {
      digit = *(ascii++);
      if((i++) & 1)
      {
         *(bcd++) |= (digit & 0x0F);
      }
      else
      {
         *bcd = digit << 4;
      }
   }
}


/**
 * Search and get a specific information in a shared buffer.
 * @param[in] sharedData input buffer where to search
 * @param[in] tag tag number to look for
 * @param[out] info
 * @return
 *    - \a TRUE if correctly retrieved.
 *    - \a FALSE if an error occurred.
 */
int APCLESS_Tools_SharedBufferRetrieveInfo(T_SHARED_DATA_STRUCT* sharedData, unsigned long tag, unsigned char** info)
{
   int result = TRUE;
   int position, cr;
   unsigned long readLength;
   const unsigned char* readValue;

   if((sharedData == NULL) || (info == NULL))
      return FALSE;

   position = SHARED_EXCHANGE_POSITION_NULL;

   cr = GTL_SharedExchange_FindNext(sharedData, &position, tag, &readLength, &readValue);
   if (cr == STATUS_SHARED_EXCHANGE_OK)
   {
      // Set the result
      result = TRUE;
      *info = (unsigned char*) readValue;
   }
   else
   {
      result = FALSE;
      *info = NULL; // Default result : no information
   }

   return result;
}




//! \brief Calculate the day number in the year, based on the date.
//! \param[in] date Date.
//! \return The day number in the year.

static int __APCLESS_Tools_DayOfYear (Telium_Date_t *date)
{
	unsigned long year;
	unsigned long month;
	unsigned long day;
	unsigned int i;
	int leap_year;

	const unsigned char day_per_month[2][13] = {
		{0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
		{0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
	};

	Ascbin (&year, date->year, 2);
	Ascbin (&month, date->month, 2);
	Ascbin (&day, date->day, 2);

	// Determine if it is a leap year or not
	leap_year = (year % 4) == 0;

	// Calculate the days
	for (i=1; i<month; i++)
		day = day + day_per_month[leap_year][i];

	return (day);
}



//! \brief This function returns the number of days between two dates.
//! \param[in] date1 First date
//! \param[in] date2 Second date
//! \returns the number of days between date1 and date2.
//! \note No date check is done, so the provided dates shall be valid !

int APCLESS_Tools_NumberOfDaysBetweenTwoDates (Telium_Date_t *date1, Telium_Date_t *date2)
{
	int  day1, day2;
	unsigned long  year1, year2, year;
	Telium_Date_t temp;
	int result;

	// Prepare temporary data set to 31/12, allowing to calculate the number of days or a given year
	Binasc(temp.day, 31, 2);
	Binasc(temp.month, 12, 2);

	// Calculate the delta in days
	day1 = __APCLESS_Tools_DayOfYear(date1);
	day2 = __APCLESS_Tools_DayOfYear(date2);
	result = day2 - day1;

	// Add the delat in years, if necessary
	Ascbin (&year1, date1->year, 2);
	Ascbin (&year2, date2->year, 2);

	// Management of year 2000
	if (year1 <= 50)
		year1 = year1 + 2000;
	else
		year1 = year1 + 1900;
	if (year2 <= 50)
		year2 = year2 + 2000;
	else
		year2 = year2 + 1900;

	// Determine the most recent year to determine the loop
	if (year2  <= year1 )
	{
		for (year=year2; year<year1; year++)
		{
			Binasc(temp.year, year % 100, 2);
			result = result - __APCLESS_Tools_DayOfYear(&temp); // Negative delta
		}
	}
	else
	{
		for (year=year1; year<year2; year++)
		{
			Binasc(temp.year, year % 100, 2);
			result = result + __APCLESS_Tools_DayOfYear(&temp); // Positive delta
		}
	}

	return (result);
}


void logTestData (char * msg, int msgLength) {
	char testMsg [2048] = {0};

	char newline[2] = {0};
	sprintf(newline,"\n");

	T_GL_HFILE mFile;
		mFile = GL_File_Open("file://flash/HOST/TESTLOG.TXT",GL_FILE_OPEN_ALWAYS,GL_FILE_ACCESS_READ_WRITE);

	if(mFile==NULL)
		return;

	GL_File_Seek(mFile, 0, GL_FILE_SEEK_END);
	GL_File_Write (mFile,msg, strlen(msg));
	GL_File_Write (mFile,newline, strlen(newline));

	GL_File_Close(mFile);
}



