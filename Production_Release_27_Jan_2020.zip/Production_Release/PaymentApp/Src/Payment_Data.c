/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   07/31/2018   Initial Creation                                              *
 * ---------------------------------------------------------------------------------------------- */
#include <sdk_tplus.h>
#include "transaction.h"
#include "MerchantData.h"

extern struct sUserData * pUserData;
extern struct sHostData * pHostData;

char * getUserText 			() {return pUserData->mUserText;}
void   setUserText 			(char * userText) {strcpy(pUserData->mUserText, userText);}
char * getTransactionType 	() {return pUserData->mTransactionType;}
void   setTransactionType 	(char * transactionType) {
	memset(pUserData->mTransactionType,0,sizeof(pUserData->mTransactionType));
	strcpy (pUserData->mTransactionType, transactionType);
}
char * getResponseTxnType(){return pUserData->mResponseTxnType;}
void setResponseTxnType		(char * txnType ) {
	memset(pUserData->mResponseTxnType,0,sizeof(pUserData->mResponseTxnType));
	strcpy (pUserData->mResponseTxnType, txnType);
}
void setMerchantAddress(char *address){
	strcpy(pUserData->mMerchantAddres,address);
}
void setMerchantCity(char *city){
	strcpy(pUserData->mMerchantCity,city);
}
void setMerchantState(char *State){
	strcpy(pUserData->mMerchantState,State);
}
void setMerchantPhone(char *Phone){
	strcpy(pUserData->mMerchantPhone,Phone);
}
void setMerchantZip(char *zip){
	strcpy(pUserData->mMerchantZip,zip);
}
void   setDepartmentName    (char *deptName) {
	strcpy (pUserData->mDepartmentName,deptName);
}
int getMerchantAddress(char *mMerchantAddres){
strcpy(mMerchantAddres, pUserData->mMerchantAddres);
}
int getMerchantCity(char *mMerchantCity){
	strcpy(mMerchantCity, pUserData->mMerchantCity);
}
int getMerchantState(char *mMerchantState){
	strcpy(mMerchantState,pUserData->mMerchantState);
}
int getMerchantZIP(char *mMerchantZip){
	strcpy(mMerchantZip, pUserData->mMerchantZip);
}
int getMerchantPhone(char *mMerchantPhone){
	strcpy(mMerchantPhone, pUserData->mMerchantPhone);
}
int getDepartmentName 	(char *depname) {strcpy(depname,pUserData->mDepartmentName); return TRUE;}
void   setDeptMID    (char *deptMID) {
	char *token;
	token = strtok(deptMID," ");
	strcpy (pUserData->mDeptMID,token);
}
char * getDeptMID 	() {return pUserData->mDeptMID;}
void   setDeptAPIKey    (char *apiKey) {
	char *token;
	token = strtok(apiKey," ");
	strcpy (pUserData->mDeptAPIKey,token);
}
char * getDeptAPIKey 	() {return pUserData->mDeptAPIKey;}
void   setReferenceNo   (char *refid){memcpy(pUserData->mReferenceNo,refid,strlen(refid));}
char * getReferenceNo   (){return pUserData->mReferenceNo;}
void   setClerkID           (char *clerkID)	 {
	memset(pUserData->mClerkID, 0, sizeof(pUserData->mClerkID));
	memcpy (pUserData->mClerkID,clerkID,strlen(clerkID));
}
char * getInputAmount 		() {return pUserData->mInputAmount;}
void   setInputAmount 		(char * inputAmount) {memcpy (pUserData->mInputAmount, inputAmount, sizeof (pUserData->mInputAmount));}
char * getCashBackAmount 	() {return pUserData->mCashBackAmount;}
void   setCashBackAmount 	(char * cashBackAmount){strcpy (pUserData->mCashBackAmount, cashBackAmount);}
char * getSettledAmount		() {return pUserData->mSettledAmount;}
void   setSettledAmount 	(char * settledAmount) {strcpy (pUserData->mSettledAmount, settledAmount);}
char * getTotalAmount 		() {return pUserData->mTotalAmount;}
void   setTotalAmount 		(char * totalAmount) {strcpy (pUserData->mTotalAmount, totalAmount);}
char * getAuthCode 			() {return pUserData->mAuthCode;}
void   setAuthCode 			(char * authCode) {strcpy (pUserData->mAuthCode, authCode);}
char * getMessageReasonCode () {return pUserData->mMessageReasonCode;}
void   setMessageReasonCode	(char * messageReasonCode) {strcpy (pUserData->mMessageReasonCode,messageReasonCode);}
char * getTransReferenceNo 	() {return pUserData->mTxnReferenceID;}
char * getLastFourDigitCardNo(){return pUserData->mLastFourDigitCardNo;}
void   setTransReferenceNo	(char * txnSequenceNo) {strcpy (pUserData->mTxnReferenceID,txnSequenceNo);}
void   setLastFourDigitCardNo (char * lastFourDigitOfCardNo) {strcpy (pUserData->mLastFourDigitCardNo,lastFourDigitOfCardNo);}
char   getCardType 			() {return pUserData->mCardType;}
void   setCardType 			(char cardType) {pUserData->mCardType = cardType;}
char * getCardInputMode 	() {return pUserData->mCardInputMode;}
void   setCardInputMode 	(char * cardInputMode) {
	memset(pUserData->mCardInputMode,0,sizeof(pUserData->mCardInputMode));
	strcpy (pUserData->mCardInputMode, cardInputMode);
}
int    getCardNumber (char * cardNum, int * cardNumLength) {
	if (pUserData->mCardNumberLength != 0) {
		memcpy (cardNum, pUserData->mCardNumber, pUserData->mCardNumberLength);
		*cardNumLength = pUserData->mCardNumberLength;
		return TRUE;
	}
	return FALSE;
}
void   setCardNumber (char * cardNum, int cardNumLength) {
	memcpy (pUserData->mCardNumber, cardNum, cardNumLength);
	pUserData->mCardNumberLength = cardNumLength;
}
char * getCardExpiryDate	() {return pUserData->mCardExpiryDate;}
void   setCardExpiryDate	(char * expiryDate) {memcpy (pUserData->mCardExpiryDate, expiryDate,sizeof(pUserData->mCardExpiryDate));}
char * getSVC				() {return pUserData->mSVC;}
void   setSVC				(char * svc) {memcpy (pUserData->mSVC, svc,sizeof(pUserData->mSVC));}
int    getTrack2Data		(char * track2Data, int * track2DataLength) {
	if (pUserData->mTrack2Length != 0) {
		memcpy (track2Data, pUserData->mTrack2, pUserData->mTrack2Length);
		*track2DataLength = pUserData->mTrack2Length;
		return TRUE;
	}
	return FALSE;
}
void   setTrack1Data		(char * track1Data, int track1DataLength) {
	memcpy (pUserData->mTrack1, track1Data, track1DataLength);
	pUserData->mTrack1Length = track1DataLength;
}
int    getTrack1Data		(char * track1Data, int * track1DataLength) {
	if (pUserData->mTrack1Length != 0) {
		memcpy (track1Data, pUserData->mTrack1, pUserData->mTrack1Length);
		*track1DataLength = pUserData->mTrack1Length;
		return TRUE;
	}
	return FALSE;
}
void   setTrack2Data		(char * track2Data, int track2DataLength) {
	memcpy (pUserData->mTrack2, track2Data, track2DataLength);
	pUserData->mTrack2Length = track2DataLength;
}
char * getCVV				() {return pUserData->mCVV;}
void   setCVV				(char * cvv) {memcpy (pUserData->mCVV, cvv,sizeof(pUserData->mCVV));}
void   setCVVByPassReason	(char reason){pUserData->mCVVByPassReason=reason;}
char   getCVVByPassReason	() {return pUserData->mCVVByPassReason;}
char * getAVS				() {return pUserData->mAVS;}
void   setAVS				(char * avs) {memcpy (pUserData->mAVS, avs, sizeof(pUserData->mAVS));}
int    getRequestEMVData    (unsigned char * emvData, int * length) {
	if (pUserData->mEMVRequestDataLength != 0) {
		memcpy (emvData, &pUserData->emvData, pUserData->mEMVRequestDataLength);
		*length = pUserData->mEMVRequestDataLength;
		return TRUE;
	}
	return FALSE;
}
void   setRequestEMVData    (unsigned char * emvData, int length) {
	memset(pUserData->emvData, 0, sizeof(pUserData->emvData));
	memcpy(pUserData->emvData, emvData, length);
	pUserData->mEMVRequestDataLength = length;
}
char * getEMVApplicationLabel () {
	char emvApp [17] = {0};
	memcpy (emvApp, pUserData->mEMVApp, sizeof(emvApp) - 1);
	return emvApp;
}
void   setEMVApplicationLabel (char * emvApp) {strcpy (pUserData->mEMVApp, emvApp);}
char * getEMVApplicationIdentifier () {
	char emvAID [33] = {0};
	memcpy (emvAID, pUserData->mEMVAID, sizeof(emvAID) - 1);
	return emvAID;
}
void   setEMVApplicationIdentifier (char * emvAID) {strcpy (pUserData->mEMVAID, emvAID);}
char * getEMVTerminalVerificationResult () {
	char emvTVR [11] = {0};
	memcpy (emvTVR, pUserData->mEMVTVR, sizeof(emvTVR) - 1);
	return emvTVR;
}
void   setEMVTerminalVerificationResult (char * emvTVR) {strcpy (pUserData->mEMVTVR, emvTVR);}
char * getEMVTransactionStatusInformation () {
	char emvTSI [5] = {0};
	memcpy (emvTSI, pUserData->mEMVTSI, sizeof(emvTSI) - 1);
	return emvTSI;
}
void   setEMVTransactionStatusInformation (char * emvTSI) {strcpy (pUserData->mEMVTSI, emvTSI);}
char * getEMVAuthorizationResponseCode () {
	char emvARC [3] = {0};
	memcpy (emvARC, pUserData->mEMVARC, sizeof(emvARC) - 1);
	return emvARC;
}
void   setEMVAuthorizationResponseCode (char * emvARC) {strcpy (pUserData->mEMVARC, emvARC);}
char * getCLESSStandard		() {return pUserData->mCLESSStandard;}
void   setCLESSStandard		(char * clessStd) {strcpy (pUserData->mCLESSStandard, clessStd);}
int    getFallBackCount 	() {return pUserData->fallBackCount;}
void   setFallBackCount 	(int count) { pUserData->fallBackCount = count; }
char * getCardHolderName	() {return pUserData->mCardHolderName;}
void   setCardHolderName	(char * cardHolderName, int cardHolderNameLength) {memcpy (pUserData->mCardHolderName, cardHolderName, cardHolderNameLength);}
void   setCardHolderAddress	(char * cardHolderAdd, int cardHolderAddLength) {memcpy (pUserData->mCardHolderAdd, cardHolderAdd, cardHolderAddLength);}
char * getCardHolderAddress	() {return pUserData->mCardHolderAdd;}
void   setCardHolderCity	(char * cardHolderCity, int cardHolderCityLength) {memcpy (pUserData->mCardHolderCity, cardHolderCity, cardHolderCityLength);}
char * getCardHolderCity	() {return pUserData->mCardHolderCity;}
void   setCardHolderState	(char * cardHolderState, int cardHolderStateLength) {memcpy (pUserData->mCardHolderState, cardHolderState, cardHolderStateLength);}
char * getCardHolderState	() {return pUserData->mCardHolderState;}
void   setCardHolderZip	(char * cardHolderZip, int cardHolderZipLength) {memcpy (pUserData->mCardHolderZip, cardHolderZip, cardHolderZipLength);}
char * getCardHolderZip	() {return pUserData->mCardHolderZip;}
int    getCHVerificationMethod() {return pUserData->mCHVerificationMethod;}
void   setCHVerificationMethod(int cvm) {pUserData->mCHVerificationMethod = cvm;}
char * getDUKPTPINBlock		() {return pUserData->mDUKPTPINBlock;}
void   setDUKPTPINBlock		(char * pinDataBlock) {memcpy (pUserData->mDUKPTPINBlock, pinDataBlock, sizeof(pUserData->mDUKPTPINBlock));}
char * getDUKPTKSN			() {return pUserData->mDUKPTKSN;}
void   setDUKPTKSN			(char * pinDUKPT_KSN) {memcpy (pUserData->mDUKPTKSN, pinDUKPT_KSN, sizeof(pUserData->mDUKPTKSN));}
char   getCardInputHighestCap() {return pUserData->mCardInputHighestCap;}
void   setCardInputHighestCap(char cardInputHighestCap){pUserData->mCardInputHighestCap = cardInputHighestCap;}
char   getCHAuthenticationHighestCap() {return pUserData->mCHAuthenticationHighestCap;}
void   setCHAuthenticationHighestCap(char chAuthenticationHighestCap) {pUserData->mCHAuthenticationHighestCap = chAuthenticationHighestCap;}
char   getCardCaptureCap	() {return pUserData->mCardCaptureCap;}
void   setCardCaptureCap	(char cardCaptureCap) {pUserData->mCardCaptureCap = cardCaptureCap;}
char   getOperatingEnvironment() {return pUserData->mOperatingEnvironment;}
void   setOperatingEnvironment(char operatingEnvironment) {pUserData->mOperatingEnvironment = operatingEnvironment;}
char   getCardholderPresenceIndicator() {return pUserData->mCardholderPresenceIndicator;}
void   setCardholderPresenceIndicator(char cardholderPresenceIndicator) {pUserData->mCardholderPresenceIndicator = cardholderPresenceIndicator;}
char   getCardPresenceIndicator() {return pUserData->mCardPresenceIndicator;}
void   setCardPresenceIndicator(char cardPresenceIndicator) {pUserData->mCardPresenceIndicator = cardPresenceIndicator;}
char   getCardDataOutputCap	() {return pUserData->mCardDataOutputCap;}
void   setCardDataOutputCap	(char cardDataOutputCap) {pUserData->mCardDataOutputCap = cardDataOutputCap;}
char   getTerminalDataOutputCap () {return pUserData->mTerminalDataOutputCap;}
void   setTerminalDataOutputCap (char terminalDataOutputCap) {pUserData->mTerminalDataOutputCap = terminalDataOutputCap;}
char   getPINCaptureCap		() {return pUserData->mPINCaptureCap;}
void   setPINCaptureCap		(char pinCaptureCap) {pUserData->mPINCaptureCap = pinCaptureCap;}
char * getErrorCode			() {return pUserData->errorCode;}
void   setErrorCode			(char * errorCode) {strcpy(pUserData->errorCode, errorCode);}

int    getProprietaryData 	(struct sFeesApplied * feelist,int *feeCount) {
	*feeCount = pUserData->mFeeCount;
	memcpy (feelist, pUserData->feeList, pUserData->mFeeCount * sizeof(struct sFeesApplied));
	return TRUE;
}

void   setProprietaryData 	(struct sFeesApplied * feelist,int feeCount) {
	pUserData->mFeeCount = feeCount;
	memcpy (pUserData->feeList, feelist, feeCount*sizeof(struct sFeesApplied));
}
int    getTxnListForRefund 	(struct refundTxnListBuffer * txnlist,int *txnCount) {
	*txnCount = pUserData->mTransactionCount;
	memcpy (txnlist, pUserData->txnList, pUserData->mTransactionCount * sizeof(struct refundTxnListBuffer));
	return TRUE;
}
void   setTxnListForRefund 	(struct refundTxnListBuffer * txnlist,int txnCount){
	pUserData->mTransactionCount = txnCount;
	memcpy (pUserData->txnList, txnlist, txnCount*sizeof(struct refundTxnListBuffer));
}
char * getFeeResult			() {return pUserData->feeResult;}
char * getFeeRespMsg			() {return pUserData->feeResponseMsg;}
char * getFeeResponseCode			() {return pUserData->feeResponsecode;}
void   setFeeResult 	(char *feeResult) {
	strcpy(pUserData->feeResult, feeResult);
}
void   setFeeResponseCode 	(char *respCode) {
	strcpy(pUserData->feeResponsecode, respCode);
}
void   setFeeRespMsg 	(char *rspMsg) {
	strcpy(pUserData->feeResponseMsg, rspMsg);
}

/***********************LEVEL 2 FIELDS**************************************************************************************/
void   setLevel2Flg(int flag) {
	pUserData->mLevel2Data = flag;
}
int   getLevel2Flg() {
	return pUserData->mLevel2Data;
}
void   setPurchaseIDFormat(char format) {
	pUserData->mPurchaseIDFormat = format;
}
char   getPurchaseIDFormat() {
	return pUserData->mPurchaseIDFormat;
}
void   setOptAmtID(char *optAmtId) {
	memcpy(pUserData->mOptAmtId,optAmtId,sizeof(pUserData->mOptAmtId));
}
char * getOptAmtID() {
	return pUserData->mOptAmtId;
}
void   setOptAmt(char *optAmt) {
	memcpy(pUserData->mOptAmt,optAmt,sizeof(pUserData->mOptAmt));
}
char * getOptAmt() {
	return pUserData->mOptAmt;
}
void   setPurchaseID(char *purchaseID) {
	memcpy(pUserData->mPurchaseID,purchaseID,sizeof(pUserData->mPurchaseID));
}
char * getPurchaseID() {
	return pUserData->mPurchaseID;
}
void   setLocalTaxInclFlag(char flag) {
	pUserData->mLocalTaxInclFlag = flag;
}
char   getLocalTaxInclFlag() {
	return pUserData->mLocalTaxInclFlag;
}
void   setLocalTax(char *amt) {
	memcpy(pUserData->mLocalTax,amt,sizeof(pUserData->mLocalTax));
}
char * getLocalTax() {
	return pUserData->mLocalTax;
}
void   setNatTaxInclFlag(char flag) {
	pUserData->mNatTaxInclFlag = flag;
}
char   getNatTaxInclFlag() {
	return pUserData->mNatTaxInclFlag;
}
void   setNatTax(char *amt) {
	memcpy(pUserData->mNatTax,amt,sizeof(pUserData->mNatTax));
}
char * getNatTax() {
	return pUserData->mNatTax;
}
void   setPONumber(char *number) {
	memcpy(pUserData->mPONumber,number,sizeof(pUserData->mPONumber));
}
char * getPONumber() {
	return pUserData->mPONumber;
}
void   setMVATRegNum(char *number) {
	memcpy(pUserData->mMVATRegNum,number,sizeof(pUserData->mMVATRegNum));
}
char * getMVATRegNum() {
	return pUserData->mMVATRegNum;
}
void   setCVATRegNum(char *number) {
	memcpy(pUserData->mCVATRegNum,number,sizeof(pUserData->mCVATRegNum));
}
char * getCVATRegNum() {
	return pUserData->mCVATRegNum;
}
void   setSumCommodityCd(char *number) {
	memcpy(pUserData->mSumCommodityCd,number,sizeof(pUserData->mSumCommodityCd));
}
char * getSumCommodityCd() {
	return pUserData->mSumCommodityCd;
}
void   setDiscAmt(char *amt) {
	memcpy(pUserData->mDiscAmt,amt,sizeof(pUserData->mDiscAmt));
}
char * getDiscAmt() {
	return pUserData->mDiscAmt;
}
void   setFreightAmt(char *amt) {
	memcpy(pUserData->mFreightAmt,amt,sizeof(pUserData->mFreightAmt));
}
char * getFreightAmt() {
	return pUserData->mFreightAmt;
}
void   setDutyAmt(char *amt) {
	memcpy(pUserData->mDutyAmt,amt,sizeof(pUserData->mDutyAmt));
}
char * getDutyAmt() {
	return pUserData->mDutyAmt;
}
void   setDestZip(char *zip) {
	memcpy(pUserData->mDestZip,zip,sizeof(pUserData->mDestZip));
}
char * getDestZip() {
	return pUserData->mDestZip;
}
void   setShippingZip(char *zip) {
	memcpy(pUserData->mShippingZip,zip,sizeof(pUserData->mShippingZip));
}
char * getShippingZip() {
	return pUserData->mShippingZip;
}
void   setDestCountryCode(char *code) {
	memcpy(pUserData->mDestCountryCode,code,sizeof(pUserData->mDestCountryCode));
}
char * getDestCountryCode() {
	return pUserData->mDestCountryCode;
}
void   setLineItemCnt(char *count) {
	memcpy(pUserData->mLineItemCount,count,sizeof(pUserData->mLineItemCount));
}
char* getLineItemCnt() {
	return pUserData->mLineItemCount;
}
void   setVATInvcRefNum(char *num) {
	memcpy(pUserData->mVATInvcRefNum,num,sizeof(pUserData->mVATInvcRefNum));
}
char * getVATInvcRefNum() {
	return pUserData->mVATInvcRefNum;
}
void   setOrderDate(char *num) {
	memcpy(pUserData->mOrderDate,num,sizeof(pUserData->mOrderDate));
}
char * getOrderDate() {
	return pUserData->mOrderDate;
}
void   setVATTaxAmt(char *amt) {
	memcpy(pUserData->mVATTaxAmt,amt,sizeof(pUserData->mVATTaxAmt));
}
char * getVATTaxAmt() {
	return pUserData->mVATTaxAmt;
}
void   setVATTaxRate(char *amt) {
	memcpy(pUserData->mVATTaxRate,amt,sizeof(pUserData->mVATTaxRate));
}
char * getVATTaxRate() {
	return pUserData->mVATTaxRate;
}
void   setAltAmtTaxId(char *id) {
	memcpy(pUserData->mAltTaxAmtID,id,sizeof(pUserData->mAltTaxAmtID));
}
char * getAltAmtTaxId() {
	return pUserData->mAltTaxAmtID;
}
void   setAltAmtTax(char *id) {
	memcpy(pUserData->mAltTaxAmt,id,sizeof(pUserData->mAltTaxAmt));
}
char * getAltAmtTax() {
	return pUserData->mAltTaxAmt;
}
void   setCostPerUnit(char *value) {
	memcpy(pUserData->mCostPerUnit,value,sizeof(pUserData->mCostPerUnit));
}
char * getCostPerUnit() {
	return pUserData->mCostPerUnit;
}
void   setLineItemTotCnt(char *value) {
	memcpy(pUserData->mLineItemTotCnt,value,sizeof(pUserData->mLineItemTotCnt));
}
char * getLineItemTotCnt() {
	return pUserData->mLineItemTotCnt;
}
void   setAltTaxID(char *value) {
	memcpy(pUserData->mAltTaxID,value,sizeof(pUserData->mAltTaxID));
}
char * getAltTaxID() {
	return pUserData->mAltTaxID;
}
void   setTaxTypeApplied(char *value) {
	memcpy(pUserData->mTaxTypeApplied,value,sizeof(pUserData->mTaxTypeApplied));
}
char * getTaxTypeApplied() {
	return pUserData->mTaxTypeApplied;
}
void   setDiscInd(char *value) {
	memcpy(pUserData->mDiscInd,value,sizeof(pUserData->mDiscInd));
}
char * getDiscInd() {
	return pUserData->mDiscInd;
}
void   setNetGrossInd(char *value) {
	memcpy(pUserData->mNetGrossInd,value,sizeof(pUserData->mNetGrossInd));
}
char * getNetGrossInd() {
	return pUserData->mNetGrossInd;
}
void   setExtItemAmt(char *value) {
	memcpy(pUserData->mExtItemAmt,value,sizeof(pUserData->mExtItemAmt));
}
char * getExtItemAmt() {
	return pUserData->mExtItemAmt;
}
void   setDrCrInd(char *value) {
	memcpy(pUserData->mDrCrInd,value,sizeof(pUserData->mDrCrInd));
}
char * getDrCrInd() {
	return pUserData->mDrCrInd;
}
void   setItemDiscRate(char *value) {
	memcpy(pUserData->mItemDiscRate,value,sizeof(pUserData->mItemDiscRate));
}
char * getItemDiscRate() {
	return pUserData->mItemDiscRate;
}
void   setItemQtyExpInd(char *value) {
	memcpy(pUserData->mItemQtyExpInd,value,sizeof(pUserData->mItemQtyExpInd));
}
char * getItemQtyExpInd() {
	return pUserData->mItemQtyExpInd;
}
void   setItemDisExpInd(char *value) {
	memcpy(pUserData->mItemDisExpInd,value,sizeof(pUserData->mItemDisExpInd));
}
char * getItemDisExpInd() {
	return pUserData->mItemDisExpInd;
}

void   setRequesterName(char *reqName) {
	memcpy(pUserData->mRequesterName,reqName,sizeof(pUserData->mRequesterName));
}
char * getRequesterName() {
	return pUserData->mRequesterName;
}
void   setTotalTaxAmount(char *totalTax) {
	memcpy(pUserData->mTotalTaxAmt,totalTax,sizeof(pUserData->mTotalTaxAmt));
}
char * getTotalTaxAmount() {
	return pUserData->mTotalTaxAmt;
}
void   setTaxTypeCode(char *taxTypeCode) {
	memcpy(pUserData->mTaxTypeCode,taxTypeCode,sizeof(pUserData->mTaxTypeCode));
}
char * getTaxTypeCode() {
	return pUserData->mTaxTypeCode;
}
/***********************END OFLEVEL 2 FIELDS**************************************************************************************/
/***********************LEVEL 3 FIELDS**************************************************************************************/

void   setLevel3Flg(int flag) {
	pUserData->mLevel3Data = flag;
}
int   getLevel3Flg() {
	return pUserData->mLevel3Data;
}
void   setProductCd(char *code) {
	memcpy(pUserData->mProductCd,code,sizeof(pUserData->mProductCd));
}
char * getProductCd() {
	return pUserData->mProductCd;
}
void   setProductCommodityCd(char *code) {
	memcpy(pUserData->mProductCommodityCd,code,sizeof(pUserData->mProductCommodityCd));
}
char * getProductCommodityCd() {
	return pUserData->mProductCommodityCd;
}
void   setProductDesc(char *desc) {
	memcpy(pUserData->mProductDesc,desc,sizeof(pUserData->mProductDesc));
}
char * getProductDesc() {
	return pUserData->mProductDesc;
}
void   setProductQuantity(char *quantity) {
	memcpy(pUserData->mProductQuantity,quantity,sizeof(pUserData->mProductQuantity));
}
char * getProductQuantity() {
	return pUserData->mProductQuantity;
}
void   setProductMeasurementUnit(char *unit) {
	memcpy(pUserData->mProductMeasurementUnit,unit,sizeof(pUserData->mProductMeasurementUnit));
}
char * getProductMeasurementUnit() {
	return pUserData->mProductMeasurementUnit;
}
void   setDiscountAmt(char *amt) {
	memcpy(pUserData->mDiscountAmt,amt,sizeof(pUserData->mDiscountAmt));
}
char * getDiscountAmt() {
	return pUserData->mDiscountAmt;
}

void   setSupplierRefNum(char *refNumber) {
	memcpy(pUserData->mSupplierRefNum,refNumber,sizeof(pUserData->mSupplierRefNum));
}
char * getSupplierRefNum() {
	return pUserData->mSupplierRefNum;
}
void   setCHRefNum(char *refNumber) {
	memcpy(pUserData->mCHRefNum,refNumber,sizeof(pUserData->mCHRefNum));
}
char * getCHRefNum() {
	return pUserData->mCHRefNum;
}
void   setShipToZip(char *shipZip) {
	memcpy(pUserData->mShipToZip,shipZip,sizeof(pUserData->mShipToZip));
}
char * getShipToZip() {
	return pUserData->mShipToZip;
}
void   setSalesTaxAmt(char *amt) {
	memcpy(pUserData->mSalesTaxAmt,amt,sizeof(pUserData->mSalesTaxAmt));
}
char * getSalesTaxAmt() {
	return pUserData->mSalesTaxAmt;
}
void   setChargeDesc1(char *desc) {
	memcpy(pUserData->mchargeDesc1,desc,sizeof(pUserData->mchargeDesc1));
}
char * getChargeDesc1() {
	return pUserData->mchargeDesc1;
}

/***********************END OFLEVEL 2 FIELDS**************************************************************************************/

void updateFeeDetailsWithResponse (struct responseFeeDetails *approvedFeeDetails){
	int i=0;
	memset(pUserData->feeList,0,sizeof(pUserData->mFeeCount*sizeof(struct sFeesApplied) ));
	for(i=0;i<pUserData->mFeeCount;i++){
		strcpy(pUserData->feeList[i].feeAmount,approvedFeeDetails->txnAmount);
		strcpy(pUserData->feeList[i].feeMID,approvedFeeDetails->txnMid);
		strcpy(pUserData->feeList[i].feeType,approvedFeeDetails->txnType);

	}

}

char* getUserTerminalID(){
	return pUserData->mTerminalID;
}
void setUserTerminalID(char *terminalID){
	memcpy (pUserData->mTerminalID, terminalID, strlen(terminalID));
}
char* getUserMerchantID(){
	return pUserData->mMerchantID;
}
void setUserMerchantID(char *merchantID){
	memcpy (pUserData->mMerchantID, merchantID, strlen(merchantID));
}
char* getUserAPIKey(){
	return pUserData->mGatewayAPIKey;
}
void setUserAPIKey(char *apiKey){
	memcpy (pUserData->mGatewayAPIKey, apiKey, strlen(apiKey));
}
char* getUserTxnSequnceNo(){
	return pUserData->mSequenceNo;
}
void setUserTxnSequnceNo (char *txnSequenceNo){
	strcpy(pUserData->mSequenceNo,txnSequenceNo);
}
char* getUserCurrencyCode(){
	return pUserData->mTxnCurrencyCode;
}
void setUserCurrencyCode (char *txnCurrencyCode){
	strcpy(pUserData->mTxnCurrencyCode,txnCurrencyCode);
}
int getUserReceiptFlag(){
	return pUserData->mReceiptEnable;
}
void setUserReceiptFlag (int receiptMode){
	pUserData->mReceiptEnable = receiptMode;
}


void setResponseResult(char *responseResult){
	memcpy (pHostData->mResponseResult, responseResult, strlen(responseResult));
}
char* getResponseResult(){
	return pHostData->mResponseResult;
}
void setResponseText(char *responseText){
	char buffer[63]={0};
	memcpy(buffer,responseText,sizeof(buffer));
	if(strlen(pHostData->mResponseText))
	memset(pHostData->mResponseText, 0, sizeof(pHostData->mResponseText));
	memcpy (pHostData->mResponseText, buffer, strlen(buffer));
}
char* getResponseText(){
	return pHostData->mResponseText;
}
void  setResponseDefination(char *responseDef){
	char buffer[71 +1]={0};
	memcpy(buffer,responseDef,sizeof(buffer) -1);
	memcpy (pHostData->mResponseDef, buffer, strlen(buffer));
}
char* getResponseDefination(){
	return pHostData->mResponseDef;
}
void setResponseCode(char *responseCode){
	memcpy (pHostData->mResponseCode, responseCode, strlen(responseCode));
}
char* getResponseCode(){
	return pHostData->mResponseCode;
}
void setResponseType(int responseType){
	pHostData->mResponseType = responseType;
}
int getResponseType(){
	return pHostData->mResponseType;
}
void setResponseMID(char *respMID){
	memcpy (pHostData->mResponseMID, respMID, strlen(respMID));
}
char* getResponseMID(){
	return pHostData->mResponseMID;
}
void setResponseTermID(char *respTermID){
	memcpy (pHostData->mResponseTermID, respTermID, strlen(respTermID));
}
char* getResponseTermID(){
	return pHostData->mResponseTermID;
}
void setTxnType(char *txnType){
	memcpy (pHostData->mTxnType, txnType, strlen(txnType));
}
char* getTxnType(){
	return pHostData->mTxnType;
}
void setRespCardNumber(char *cardNumber){
	memcpy (pHostData->mCardNumber, cardNumber, strlen(cardNumber));
}
char* getRespCardNumber(){
	return pHostData->mCardNumber;
}
void setCardBrand(char *cardBrand){
	memcpy (pHostData->mCardBrand, cardBrand, strlen(cardBrand));
}
char* getCardBrand(){
	return pHostData->mCardBrand;
}
void  setRespCardExpDate(char *expDate){
	memcpy (pHostData->mCardExpDate, expDate, strlen(expDate));
}
char* getRespCardExpDate(){
	return pHostData->mCardExpDate;
}
void  setRespTokenID(char *txnTokenID){
	memcpy (pHostData->mTokenID, txnTokenID, strlen(txnTokenID));
}
char* getRespTokenID(){
	return pHostData->mTokenID;
}
void setRespTxnSequenceNo(char *txnSequenceNo){
	memcpy (pHostData->mTxnSequenceNo, txnSequenceNo, strlen(txnSequenceNo));
}
char* getRespTxnSequenceNo(){
	return pHostData->mTxnSequenceNo;
}
void setRRN(char *txnRRN){
	memcpy (pHostData->mRRN, txnRRN, strlen(txnRRN));
}
char* getRRN(){
	return pHostData->mRRN;
}
void setRespAuthCode(char *authCode){
	memcpy (pHostData->mAuthCode, authCode, strlen(authCode));
}
char* getRespAuthCode(){
	return pHostData->mAuthCode;
}
void setTxnAmount(char *txnAmount){
	memcpy (pHostData->mTxnAmount, txnAmount, strlen(txnAmount));
}
char* getTxnAmount(){
	return pHostData->mTxnAmount;
}
void setTxnCurrency(char *txnCurrency){
	memcpy (pHostData->mTxnCurrency, txnCurrency, strlen(txnCurrency));
}
char* getTxnCurrency(){
	return pHostData->mTxnCurrency;
}
void setSettlementAmount(char *settlementAmount){
	memcpy (pHostData->mSettlementAmount, settlementAmount, strlen(settlementAmount));
}
char* getSettlementAmount(){
	return pHostData->mSettlementAmount;
}
void setSettlementCurrency(char *settlementCurrency){
	memcpy (pHostData->mSettlementCurrency, settlementCurrency, strlen(settlementCurrency));
}
char* getSettlementCurrency(){
	return pHostData->mSettlementCurrency;
}
void setConvenienceFee(char *convenienceFee){
	memcpy (pHostData->mConvenienceFee, convenienceFee, strlen(convenienceFee));
}
char* getConvenienceFee(){
	return pHostData->mConvenienceFee;
}
void setServiceFee(char *serviceFee){
	memcpy (pHostData->mServiceFee, serviceFee, strlen(serviceFee));
}
char* getServiceFee(){
	return pHostData->mServiceFee;
}
void setStateFee(char *stateFee){
	memcpy (pHostData->mStateFee, stateFee, strlen(stateFee));
}
char* getStateFee(){
	return pHostData->mStateFee;
}
void setTxnDateTime(char *txnDateTime){
	memcpy (pHostData->mTxnDateTime, txnDateTime, strlen(txnDateTime));
}
char* getTxnDateTime(){
	return pHostData->mTxnDateTime;
}
void setEMVRespDataLength(int emvRespDataLength){
	pHostData->mEMVRespDataLength=emvRespDataLength;
}
int getEMVRespDataLength(){
	return pHostData->mEMVRespDataLength;
}
void setEMVData(unsigned char *emvData){
	memcpy (pHostData->emvData, emvData, pHostData->mEMVRespDataLength);
}
unsigned char* getEMVData(){
	return pHostData->emvData;
}
void setBatchNetDeposit(char *netDeposit){
	memcpy (pHostData->batchNetDeposit, netDeposit, strlen(netDeposit));
}
char* getBatchNetDeposit(){
	return pHostData->batchNetDeposit;
}
void setBatchNumber(char *batchNo){
	memcpy (pHostData->batchNumber, batchNo, strlen(batchNo));
}
char* getBatchNumber(){
	return pHostData->batchNumber;
}
void setBatchRecordCount(char *batchRecCount){
	memcpy (pHostData->batchRecordCount, batchRecCount, strlen(batchRecCount));
}
char* getBatchRecordCount(){
	return pHostData->batchRecordCount;
}
// Start Core
void setCoreBatchResponseCode(char *batchResCode){
	memcpy (pHostData->batchCoreResponseCode, batchResCode, sizeof(pHostData->batchCoreResponseCode) -1);
}
char* getCoreBatchResponseCode(){
	return pHostData->batchCoreResponseCode;
}
void setCoreBatchResponseText(char *batchResTxt){
	memcpy (pHostData->batchCoreResponseText, batchResTxt, sizeof(pHostData->batchCoreResponseText) -1);
}
char* getCoreBatchResponseText(){
	return pHostData->batchCoreResponseText;
}

//End Core

/*** Start Conv **********/
void setConvBatchResponseCode(char *batchResCode){
	memcpy (pHostData->batchConvResponseCode, batchResCode, sizeof(pHostData->batchConvResponseCode) -1);
}
char* getConvBatchResponseCode(){
	return pHostData->batchConvResponseCode;
}
void setConvBatchResponseText(char *batchResTxt){
	memcpy (pHostData->batchConvResponseText, batchResTxt, sizeof(pHostData->batchConvResponseText) -1);
}
char* getConvBatchResponseText(){
	return pHostData->batchConvResponseText;
}

/***Env Conv**********/
void   setChipErrorFlag(int flag) {
	pUserData->chipErrorFlag = flag;
}
int   getChipErrorFlag() {
	return pUserData->chipErrorFlag;
}
void   setEmptyCandidateListFlag(int flag) {
	pUserData->emptyCandidateListFlag = flag;
}
int   getEmptyCandidateListFlag() {
	return pUserData->emptyCandidateListFlag;
}
void setPINEntryCancelbyCardholder(int flag){
	pUserData->pinEntryCancel = flag;
}
int getPINEntryCancelbyCardholder(){
	return pUserData->pinEntryCancel;
}
int houseKeeping(){
	APEMV_UI_GoalDestroy();
	memset(pHostData,0,sizeof(struct sHostData));
	memset(pUserData,0,sizeof(struct sUserData));
}




