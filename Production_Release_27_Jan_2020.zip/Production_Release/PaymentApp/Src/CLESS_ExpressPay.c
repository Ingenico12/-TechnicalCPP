/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   12/31/2018   Manages the interface with the ExpressPay contactless kernel. *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "CLESS.h"
#include "transaction.h"
#include "emvParameter.h"
#include "sec_interface.h"
#include "EPSTOOL_PinEntry.h"

const unsigned char ARC_00[]={0x30, 0x30};
const unsigned char ARC_08[]={0x30, 0x38};
const unsigned char ARC_10[]={0x31, 0x30};
const unsigned char ARC_11[]={0x31, 0x31};

// Period of time the contactless reader field is deactivated between the two taps of the Mobile CVM (Time in milliseconds)
#define	EXPRESSPAY_DOUBLE_TAP_TIME_DEFAULT		0x5DC		// Default value: : 1,5 seconds
#define	EXPRESSPAY_DOUBLE_TAP_TIME_MIN			0x3E8		// Min value: : 1 second
#define	EXPRESSPAY_DOUBLE_TAP_TIME_MAX			0xBB8		// Max value: : 3 seconds

#define C_TIME_100MS					10

word g_TimerTask;										// To store the different tasks ID.
t_topstack * g_tsTimer_task_handle;						// Handle of the timer task.
static word g_wCurrentTask;
static unsigned char g_bTimer_task_to_be_killed = FALSE;	// Global variable used to stop the timer task.
static int g_bTimerTaskRunning = FALSE;						// Indicates if the timer task is still running or if it is waiting to be killed.
static int g_bTimerExpired = FALSE;							// Global variable used to indicate that removal timer expired.
static unsigned long gs_ulStartRemovalTimerTime = 0;		// Removal Timer
static unsigned char gs_bTxnWentOnline = FALSE;				// Global variable that indicates if the transaction was able to go online during the first part of an EMV Full Online transaction.
static unsigned char gs_bMobileCVMperformed = FALSE;		// Global variable that indicates if Mobile CVM has been performed and if transaction must be restarted.


static int 		CLESS_ExpressPay_AddExpressPaySpecificData (T_SHARED_DATA_STRUCT * pDataStruct);
static void 	CLESS_ExpressPay_AddRecordToBatch (T_SHARED_DATA_STRUCT * pSharedData);
static int 		CLESS_ExpressPay_RetrieveCvmToApply (T_SHARED_DATA_STRUCT * pResultDataStruct, unsigned char * pCvm);
static T_Bool 	CLESS_ExpressPay_OnlinePinManagement (T_SHARED_DATA_STRUCT * pStructureForOnlineData, int nCardHolderLang);
static int 		CLESS_ExpressPay_ActionCodeDefaultCheck (void);
static int 		CLESS_ExpressPay_IsOnlineOnly (T_SHARED_DATA_STRUCT * pDataStruct);
static void 	CLESS_ExpressPay_KillTimerTask (void);
static int 		CLESS_ExpressPay_LaunchRemovalTimerTask (void);
static void 	CLESS_ExpressPay_InitTimerVariables (void);
static word 	CLESS_ExpressPay_StartTimerTask (void);
static void 	CLESS_ExpressPay_GetDoubleTapTime (unsigned long *pDoubleTapTime);
static void 	CLESS_ExpressPay_CloseFieldBefore2ndTap (void);
static void 	CLESS_ExpressPay_SetTxnRestartedIndicator (T_SHARED_DATA_STRUCT *pTransactionData);
static void 	CLESS_ExpressPay_AddIssuerScripts (T_SHARED_DATA_STRUCT *pTransactionData);


int ClessSample_ExpressPay_CustomiseStep (T_SHARED_DATA_STRUCT* dataStruct, const unsigned char ucCustomisationStep);
int ExpressPay3_OnlineRequestData (T_SHARED_DATA_STRUCT * dataStruct, int kernalStatusCode);

/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Unset the Mobile CVM global variable.                                                 *
 * ---------------------------------------------------------------------------------------------- */
void ClessSample_ExpressPay_UnsetMobileCVM (void) {
	gs_bMobileCVMperformed = FALSE;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the ExpressPay CVM to perform.                                                    *
 * 			                                                                                      *
 * [out] :  pCvm Retrieved transaction CVM :                                                      *
 * 			- EXPRESSPAY_CVM_NO_CVM : No CVM to be performed									  *
 * 			- EXPRESSPAY_CVM_SIGNATURE if signature shall be performed.                           *
 * 			- EXPRESSPAY_CVM_ONLINE_PIN if online PIN shall be performed.                         *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_ExpressPay_RetrieveCvmToApply (T_SHARED_DATA_STRUCT * pResultDataStruct, unsigned char * pCvm) {
	int nResult = TRUE;
	int nPosition;
	unsigned long ulReadLength;
	const unsigned char * pReadValue;

	nPosition = SHARED_EXCHANGE_POSITION_NULL;
	* pCvm = EXPRESSPAY_CVM_NO_CVM; // Default result

	if(GTL_SharedExchange_FindNext(pResultDataStruct, &nPosition, TAG_EXPRESSPAY_TRANSACTION_CVM, &ulReadLength, &pReadValue) != STATUS_SHARED_EXCHANGE_OK) {
		nResult = FALSE;
		goto End;
	}
	// Get the transaction outcome
	* pCvm = pReadValue[0];
End:
	return (nResult);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Fill buffer with specific ExpressPay for transaction.                                 *
 * 			                                                                                      *
 * [out]: 	pDataStruct Shared exchange structure filled with the specific ExpressPay data.       *
 * [return]: TRUE if correctly performed.                                                         *
 * 			 FALSE if an error occurred.                                                          *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_ExpressPay_AddExpressPaySpecificData (T_SHARED_DATA_STRUCT * pDataStruct) {
	int nResult;
	object_info_t ObjectInfo;
	T_KERNEL_TRANSACTION_FLOW_CUSTOM sTransactionFlowCustom;
	unsigned char StepInterruption[KERNEL_PAYMENT_FLOW_STOP_LENGTH];// Bit field to stop payment flow,
																	// if all bit set to 0 => no stop during payment process
									                                // if right bit set to 1 : stop after payment step number 1
	unsigned char StepCustom[KERNEL_PAYMENT_FLOW_CUSTOM_LENGTH]; 	// Bit field to custom payment flow,
																	// if all bit set to 0 => no stop during payment process
									                                // if right bit set to 1 : stop after payment step number 1
	if (pDataStruct == NULL) {
		nResult = FALSE;
		goto End;
	}
	memset(StepInterruption, 0, sizeof(StepInterruption)); // Default Value : not stop on process
	memset(StepCustom, 0, sizeof(StepCustom)); // Default Value : not stop on process
	ObjectGetInfo(OBJECT_TYPE_APPLI, ApplicationGetCurrent(), &ObjectInfo);
	nResult = TRUE;

	// Add a tag for Do_Txn management
	if(GTL_SharedExchange_AddTag(pDataStruct, TAG_KERNEL_PAYMENT_FLOW_STOP, KERNEL_PAYMENT_FLOW_STOP_LENGTH, (const unsigned char *)StepInterruption) != STATUS_SHARED_EXCHANGE_OK) {
		nResult = FALSE;
		goto End;
	}

	ADD_STEP_CUSTOM(STEP_EXPRESSPAY_REMOVE_CARD,StepCustom); 		// To do GUI when ExpressPay card has been read
	ADD_STEP_CUSTOM(STEP_EXPRESSPAY_GET_CERTIFICATE, StepCustom); 	// To provide the CA key data for ODA
	memcpy ((void*)&sTransactionFlowCustom, (void*)StepCustom, KERNEL_PAYMENT_FLOW_CUSTOM_LENGTH);
	sTransactionFlowCustom.usApplicationType = ObjectInfo.application_type; // Kernel will call this application for customisation
	sTransactionFlowCustom.usServiceId = SERVICE_CUSTOM_KERNEL; 			// Kernel will call SERVICE_CUSTOM_KERNEL service id for customisation
	if(GTL_SharedExchange_AddTag(pDataStruct, TAG_KERNEL_PAYMENT_FLOW_CUSTOM, sizeof(T_KERNEL_TRANSACTION_FLOW_CUSTOM), (const unsigned char *)&sTransactionFlowCustom) != STATUS_SHARED_EXCHANGE_OK) {
		nResult = FALSE;
		goto End;
	}
End:
	return (nResult);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Perform the Online PIN input and encipher PIN.                                        *
 * 			                                                                                      *
 * [out]: 	pStructureForOnlineData Data returned by the kernel in which the enciphered online    *
 * 			PIN would be added.                                                                   *
 * [return]: TRUE if correctly performed.                                                         *
 * 			 FALSE if an error occurred.                                                          *
 * ---------------------------------------------------------------------------------------------- */
static T_Bool CLESS_ExpressPay_OnlinePinManagement (T_SHARED_DATA_STRUCT * pStructureForOnlineData, int nCardHolderLang) {
	T_SHARED_DATA_STRUCT * pDataRequest;
	T_Bool nResult = B_TRUE;
	int cr;
	int nPosition;
	const unsigned char * pPan;
	unsigned long ulPanLength;
	const unsigned char * pAmount;
	unsigned long ulAmountLength;
	unsigned long ulAmount = 0;
	BUFFER_SIZE buffer_saisie;

	pDataRequest = GTL_SharedExchange_InitShared (128);

	if (pDataRequest != NULL) {
		// Clear shared buffer
		GTL_SharedExchange_ClearEx (pDataRequest, FALSE);

		// Indicate tag to be requested
		GTL_SharedExchange_AddTag (pDataRequest, TAG_EMV_APPLI_PAN, 0, NULL);
		GTL_SharedExchange_AddTag (pDataRequest, TAG_EMV_AMOUNT_AUTH_NUM, 0, NULL);

		cr = ExpressPay3_GetData (pDataRequest);

		if (cr != KERNEL_STATUS_OK) {
			nResult = B_FALSE;
			goto End;
		}

		// Tags have been got (if present), get the PAN
		nPosition = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext (pDataRequest, &nPosition, TAG_EMV_APPLI_PAN, &ulPanLength, &pPan) != STATUS_SHARED_EXCHANGE_OK) {
			nResult = B_FALSE;
			goto End;
		}

		// Get the transaction amount (numeric)
		nPosition = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext (pDataRequest, &nPosition, TAG_EMV_AMOUNT_AUTH_NUM, &ulAmountLength, &pAmount) != STATUS_SHARED_EXCHANGE_OK) {
			nResult = B_FALSE;
			goto End;
		}

		// Convert amount
		GTL_Convert_DcbNumberToUl(pAmount, &ulAmount, ulAmountLength);

		// Warning, erase display must be made only if Pin input will be made on customer screen
		/*if (ClessSample_IsPinpadPresent())
		{
			char acDummyMsg[] = "";

			// Display dummy message to erase display
			//tMsg.message = acDummyMsg;
			//tMsg.coding = _ISO8859_;
			//tMsg.file = GetCurrentFont();

			//Helper_DisplayTextCustomer(ERASE, HELPERS_CUSTOMER_LINE_1, &tMsg, CLESSSAMPLE_ALIGN_CENTER, LEDSOFF);
		}*/

		// Request online PIN entry
		cr = 0;// ClessSample_PinManagement_OnLinePinManagement ((unsigned char*)pPan, 1, ulAmount, 30000, 10000, nCardHolderLang, &buffer_saisie);
		if (cr == INPUT_PIN_ON) {
			cr = GTL_SharedExchange_AddTag(pStructureForOnlineData, TAG_SAMPLE_ENCIPHERED_PIN_CODE, buffer_saisie.nombre , (const unsigned char *)buffer_saisie.donnees);

			if (cr != STATUS_SHARED_EXCHANGE_OK) {
				nResult = B_FALSE;
				goto End;
			}
		}
		else if (cr == CANCEL_INPUT) {
				nResult = B_NON_INIT;
				goto End;
		}
	}

End:
	// Destroy the shared buffer if created
	if (pDataRequest != NULL)
		GTL_SharedExchange_DestroyShare (pDataRequest);

	return (nResult);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Perform the ExpressPay kernel customization.                                          *
 * 			                                                                                      *
 * [in] :    ucCustomisationStep Step to be customized.                                           *
 * [in,out]: pSharedData Shared buffer used for customization.                                    *
 * ---------------------------------------------------------------------------------------------- */
int ClessSample_ExpressPay_CustomiseStep (T_SHARED_DATA_STRUCT * pSharedData, const unsigned char ucCustomisationStep) {
	int result = KERNEL_STATUS_CONTINUE;
	unsigned char keyIndex;
	unsigned char rid[7] = {0};
	unsigned char Modulus [255] = {0};
	unsigned int ModulusLength = 0;
	unsigned char Exponent [3] = {0};
	unsigned int ExponentLength = 0;
	unsigned short found;
	unsigned long readLength;
	int position;
	const unsigned char* readValue;

	switch (ucCustomisationStep) {
		case STEP_EXPRESSPAY_REMOVE_CARD:
			CLESS_GUI_DisplayScreen (APCLESS_SCREEN_REMOVE_CARD);
			GTL_SharedExchange_ClearEx (pSharedData, FALSE);
			result = KERNEL_STATUS_CONTINUE;
			break;

		case STEP_EXPRESSPAY_GET_CERTIFICATE:
	         position = SHARED_EXCHANGE_POSITION_NULL;
	         if (GTL_SharedExchange_FindNext(pSharedData, &position, TAG_EMV_CA_PUBLIC_KEY_INDEX_CARD, &readLength, (const unsigned char **)&readValue) == STATUS_SHARED_EXCHANGE_OK)
	        	 keyIndex = readValue[0];
	         else
	        	 keyIndex = 0;

	         position = SHARED_EXCHANGE_POSITION_NULL;
	         if (GTL_SharedExchange_FindNext(pSharedData, &position, TAG_EMV_DF_NAME, &readLength, (const unsigned char **)&readValue) == STATUS_SHARED_EXCHANGE_OK) {
	        	 memcpy (rid+1, readValue, 5);
	        	 memcpy (rid, "\x05", 1);
	         }
	         GTL_SharedExchange_ClearEx (pSharedData, FALSE);

	         if (strlen(rid) && keyIndex != 0) {
	             found = getCertificationAuthorityPublicKey (rid,
	     													keyIndex,
	     													Modulus,
	     													&ModulusLength,
	     													Exponent,
	     													&ExponentLength);
	             if (found) {
	            	 if (GTL_SharedExchange_AddTag(pSharedData, TAG_EMV_INT_CAPK_MODULUS, ModulusLength, Modulus) != STATUS_SHARED_EXCHANGE_OK) {
	            		 GTL_SharedExchange_ClearEx(pSharedData, FALSE);
	            		 return;
	            	 }
	            	 if (GTL_SharedExchange_AddTag(pSharedData, TAG_EMV_INT_CAPK_EXPONENT, ExponentLength, Exponent) != STATUS_SHARED_EXCHANGE_OK) {
	            		 GTL_SharedExchange_ClearEx(pSharedData, FALSE);
	            		 return;
	            	 }
	             }
	         }
	         result = KERNEL_STATUS_CONTINUE;
	         break;

		case STEP_EXPRESSPAY_EXCEPTION_FILE_GET_DATA:
			// TODO:  Check if PAN is in the exception file
			result = KERNEL_STATUS_CONTINUE;
			break;

		default:
			break;
	}
	return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Calls the ExpressPay kernel to perform the transaction.                               *
 * 			                                                                                      *
 * [in] :   pDataStruct Data buffer to be filled and used for ExpressPay transaction.             *
 * ---------------------------------------------------------------------------------------------- */
int CLESS_ExpressPay_PerformTransaction (T_SHARED_DATA_STRUCT * pDataStruct) {
	int nResult = CLESS_CR_MANAGER_END;
	int cr;
	unsigned char ucCvm;
	T_Bool bContinueWithOnlineAuthorisation = B_TRUE;
	T_SHARED_DATA_STRUCT * pDataStructSav = NULL;

	gs_bTxnWentOnline = FALSE;

	// Indicate ExpressPay kernel is going to be used (for customisation purposes)
	CLESS_Txn_SetCurrentPaymentScheme (APCLESS_SCHEME_EXPRESSPAY);

	if (CLESS_ExpressPay_AddExpressPaySpecificData(pDataStruct)) {
		// If Mobile CVM has been performed, an indicator is set to identify that a transaction has been Restarted.
		if(gs_bMobileCVMperformed)
			CLESS_ExpressPay_SetTxnRestartedIndicator(pDataStruct);

		cr = ExpressPay3_DoTransaction(pDataStruct);

		// Get the TAG_EXPRESSPAY_TRANSACTION_CVM to identify the CVM to be performed :
		// 	- EXPRESSPAY_CVM_NO_CVM (0x01) : "No CVM" method has been applied.
		// 	- EXPRESSPAY_CVM_SIGNATURE (0x02) : "Signature" method has been applied.
		// 	- EXPRESSPAY_CVM_ONLINE_PIN (0x04) : "Online PIN" method has been applied.
		if (!CLESS_ExpressPay_RetrieveCvmToApply (pDataStruct, &ucCvm))
			ucCvm = EXPRESSPAY_CVM_NO_CVM;
		// Get Card holder Verification Method
		if(ucCvm == EXPRESSPAY_CVM_ONLINE_PIN)
			setCHVerificationMethod(ONLINE_PIN);
		else if(ucCvm == EXPRESSPAY_CVM_SIGNATURE)
			setCHVerificationMethod(PAPER_SIGNATURE);
		else
			setCHVerificationMethod(NO_AUTHENTICATION);


		switch (cr) {
			case KERNEL_STATUS_OFFLINE_APPROVED:
				ClessEmv_CloseDriver();
				if(CLESS_ExpressPay_IsOnlineOnly(pDataStruct)) {
					CLESS_GUI_DisplayScreen (APCLESS_SCREEN_OFFLINE_DECLINED);
				}
				else {
					CLESS_GUI_DisplayScreen (APCLESS_SCREEN_OFFLINE_APPROVED);
					ExpressPay3_GetAllData(pDataStruct);       // Get all the kernel data to print the receipt
				}
				break;

			case EXPRESSPAY_STATUS_EMV_FULL_ONLINE_APPROVED:
				ClessEmv_CloseDriver();
				if((cr == EXPRESSPAY_STATUS_EMV_FULL_ONLINE_APPROVED) && gs_bTxnWentOnline) {
					CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ONLINE_APPROVED);
					ExpressPay3_GetAllData(pDataStruct); // Get all the kernel data to print the receipt
				}
				break;

			case KERNEL_STATUS_OFFLINE_DECLINED:
			case EXPRESSPAY_STATUS_EMV_FULL_ONLINE_DECLINED:
				ClessEmv_CloseDriver();
				if((cr == EXPRESSPAY_STATUS_EMV_FULL_ONLINE_DECLINED) && gs_bTxnWentOnline)
					CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ONLINE_DECLINED);
				else
					CLESS_GUI_DisplayScreen (APCLESS_SCREEN_OFFLINE_DECLINED);
				break;

			case EXPRESSPAY_STATUS_MAGSTRIPE_ONLINE_AUTHORISATION:
			case EXPRESSPAY_STATUS_EMV_PARTIAL_ONLINE_AUTHORISATION:
			case EXPRESSPAY_STATUS_EMV_FULL_ONLINE_AUTHORISATION:
				ClessEmv_CloseDriver();
				ExpressPay3_GetAllData(pDataStruct);
				ExpressPay3_OnlineRequestData (pDataStruct, cr);
				//if PIN online is required and managed it.
				if (getCHVerificationMethod() == ONLINE_PIN ){
					int pinLength;
					switch (APEMV_UI_PinEntry (INPUT_PIN_ON, 3, &pinLength)) {
						case EPSTOOL_PINENTRY_SUCCESS:
							if (encryptPIN() == FALSE)
								setErrorCode("ERROR:033");
							break;
						case EPSTOOL_PINENTRY_TIMEOUT:
							setErrorCode("ERROR:013");
							break;
						case EPSTOOL_PINENTRY_ERROR:
						case EPSTOOL_PINENTRY_CANCEL:
							setErrorCode("ERROR:044");
							break;
						case EPSTOOL_PINENTRY_EVENT:
						case EPSTOOL_PINENTRY_BYPASS:
						default:
							break;
						}
					}
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ONLINE_PROCESSING);
				break;

			case KERNEL_STATUS_USE_CONTACT_INTERFACE:
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_USE_CONTACT);
				nResult = CLESS_CR_MANAGER_RESTART_WO_CLESS;
				break;

			case KERNEL_STATUS_COMMUNICATION_ERROR:
				nResult = CLESS_CR_MANAGER_RESTART;
				break;

			case (KERNEL_STATUS_MOBILE):
				// ExpressPay 3.0 Terminal Specification Section 19.2.2.1
				// The cardholder is notified to withdraw and/or consult the mobile device (Card)
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_PHONE_INSTRUCTIONS);
				// The contactless reader field must be deactivated for a period of time (configurable in the range of one to three seconds, default value to be 1.5 seconds).
				CLESS_ExpressPay_CloseFieldBefore2ndTap();
				// The cardholder is notified to re-present the mobile device.
				// An indicator is set to identify that a transaction has been Restarted.
				gs_bMobileCVMperformed = TRUE;
				nResult = CLESS_CR_MANAGER_RESTART_DOUBLE_TAP;
				break;

			case KERNEL_STATUS_CARD_BLOCKED:
			case KERNEL_STATUS_APPLICATION_BLOCKED:
			case KERNEL_STATUS_REMOVE_AID:
				nResult = CLESS_CR_MANAGER_REMOVE_AID;
				break;

			default: // Error case
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ERROR);
				break;
		}
		// Cless field must be stopped only if we don't try to work with an another AID
		if ((nResult != CLESS_CR_MANAGER_REMOVE_AID) && (nResult != CLESS_CR_MANAGER_RESTART_WO_CLESS)) {
			if(ClessEmv_IsDriverOpened())
				ClessEmv_DeselectCard(0, TRUE, FALSE);
		}

		// If the transaction does not restart from the begining, set the LEDs into the idle state
		if ((nResult != CLESS_CR_MANAGER_RESTART) && (nResult != CLESS_CR_MANAGER_REMOVE_AID) && (nResult != CLESS_CR_MANAGER_RESTART_DOUBLE_TAP)) {
			// Check if transaction shall be saved in the batch
			if (pDataStructSav != NULL)
				CLESS_ExpressPay_AddRecordToBatch (pDataStructSav);

			ExpressPay3_GetAllData(pDataStruct); // Get all the kernel data to print the receipt
		}

		if (pDataStructSav != NULL) {
			GTL_SharedExchange_DestroyShare(pDataStructSav);
			pDataStructSav = NULL;
		}
	}
	// Transaction is completed, clear ExpressPay kernel transaction data
	ExpressPay3_Clear ();

	return (nResult);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose:	Check if the Default Action Codes match or not                                        *
 * 			(TAG_EXPRESSPAY_INT_TAC_IAC_DEFAULT_MATCHED set to 1 by the ExpressPay kernel).       *
 * 			                                                                                      *
 * [return]:  TRUE if Default Action codes match (decline the transaction).                       *
 *            FALSE else (approve the transaction).                                             NU*
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_ExpressPay_ActionCodeDefaultCheck (void) {
	T_SHARED_DATA_STRUCT * pDataRequest;
	int nResult = FALSE;
	int nPosition;
	const unsigned char * pValue;
	unsigned long ulLength;

	pDataRequest = GTL_SharedExchange_InitShared (128);

	if (pDataRequest != NULL) {
		// Clear shared buffer
		GTL_SharedExchange_ClearEx (pDataRequest, FALSE);

		// Indicate tag to be requested
		GTL_SharedExchange_AddTag (pDataRequest, TAG_EXPRESSPAY_INT_TAC_IAC_DEFAULT_MATCHED, 0, NULL);

		if (ExpressPay3_GetData (pDataRequest) != KERNEL_STATUS_OK)  {
			nResult = FALSE;
			goto End;
		}

		nPosition = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext (pDataRequest, &nPosition, TAG_EXPRESSPAY_INT_TAC_IAC_DEFAULT_MATCHED, &ulLength, &pValue) != STATUS_SHARED_EXCHANGE_OK) {
			nResult = FALSE;
			goto End;
		}

		if(pValue[0])
			nResult = TRUE; // Default Action Codes match
	}
End:
	// Destroy the shared buffer if created
	if (pDataRequest != NULL)
		GTL_SharedExchange_DestroyShare (pDataRequest);

	return (nResult);
}


////////////////////////////////////////////
//// TASK FOR EMV FULL ONLINE TRANSACTION //
////////////////////////////////////////////
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the removal timeout value from the parameter file.                                *
 * 			                                                                                      *
 * [out]: 	pRemovalTimeOut the timeout value (in milliseconds).                                  *
 * [return]: TRUE if tag is present.                                                              *
 * 			 FALSE else.                                                                          *
 * ---------------------------------------------------------------------------------------------- */
static int __ClessSample_ExpressPay_GetRemovalTimeOut (unsigned long *pRemovalTimeOut) {
	TLV_TREE_NODE pTimeOut;
	unsigned char * pValue;
	unsigned int nDataLength;
	pValue = NULL;
	nDataLength = 0;

	pTimeOut = TlvTree_Find(pTreeCurrentParam, TAG_EXPRESSPAY_FULL_ONLINE_EMV_REMOVAL_TIMEOUT, 0);

	if (pTimeOut != NULL) {
		pValue = TlvTree_GetData(pTimeOut);
		nDataLength = TlvTree_GetLength(pTimeOut);
	}

	if ((pValue != NULL) && (nDataLength != 0)) {
		GTL_Convert_BinNumberToUl(pValue, pRemovalTimeOut, nDataLength);
		return (TRUE);
	}
	return (FALSE);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose:	Waits an event from custom (Online Authorization received) during XX seconds.         *
 * 			If the event is not received, ask for card removal.                                   *
 * ---------------------------------------------------------------------------------------------- */
static word CLESS_ExpressPay_StartTimerTask (void) {
	unsigned long ulRemovalTimeOut;	// Card removal timeout (in milliseconds)
	int nTimeout;

	g_bTimerTaskRunning = TRUE;		// Indicates the task is running
	g_TimerTask = Telium_CurrentTask();	// Get the Timer task ID and store it in a global variable

	// Start the removal timer
	gs_ulStartRemovalTimerTime = GTL_StdTimer_GetCurrent();

	//nLang = PSQ_Give_Language();
	//auCustomerDisplayAvailable = Helper_IsClessCustomerDisplayAvailable();

	// First, get the removal timeout value
	if(!__ClessSample_ExpressPay_GetRemovalTimeOut (&ulRemovalTimeOut))
		ulRemovalTimeOut = 0; // Perform a Partial Online transaction

	while (!g_bTimer_task_to_be_killed) // While the task is not to be killed by the custom application
	{
		if (g_bTimerExpired)	// Timeout expired, task is waiting to be killed
		{
			g_bTimerTaskRunning = FALSE; // Indicate to the custom application the task is waiting to be killed
			Telium_Ttestall (0,0);		// Wait to be killed
		}

		// Test if removal timer expired
		nTimeout = GTL_StdTimer_GetRemaining(gs_ulStartRemovalTimerTime, ulRemovalTimeOut/10);
		if (nTimeout == 0)
		{
			// Timer expires before a response is received from the Acquirer
			g_bTimerExpired = TRUE;
			// Prompt for the removal of the card
			//HelperRemoveCardSequence(NULL);

			// Clear the screen and display "Online request" message
			//ClessSample_GuiState_DisplayScreenText(CLESS_SAMPLE_SCREEN_ONLINE_PROCESSING, nLang, nLang);
		}

		if(!g_bTimerExpired)
			Telium_Ttestall (USER_EVENT, 1);	// User event (from main task), it indicates the task is going to be killed (because g_bTimer_task_to_be_killed has been set to TRUE by the custom application)

	} // End While

	// The task is stopped by the main application (Online Response received)
	g_bTimerTaskRunning = FALSE; // Update global variable

	// Send the event to the main task
	//if(Telium_SignalEvent (g_wCurrentTask, (tEvent)E_USER_EVENT) != cOK)
		//GTL_Traces_DiagnosticText ("Timer task: Error when setting the event\n");

	Telium_Ttestall (0,0); // Wait to be killed
	return TRUE;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Initialise removal timer global variables.                                            *
 * ---------------------------------------------------------------------------------------------- */
static void CLESS_ExpressPay_InitTimerVariables (void) {
	g_wCurrentTask = 0xFF;				// Init the custom application task number
	g_TimerTask = 0xFF;					// Init the scanning task number
	g_tsTimer_task_handle = NULL;		// Init the scanning task handle
	g_bTimer_task_to_be_killed = FALSE; // Task has not to be killed
	g_bTimerTaskRunning = FALSE;		//Task is not running
	g_bTimerExpired = FALSE;			// Removal timer has not expired
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Launch the removal timer task.                                                        *
 *                                                                                                *
 * [return]: OK if task correctly launch, KO else.                                                *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_ExpressPay_LaunchRemovalTimerTask (void) {
	CLESS_ExpressPay_InitTimerVariables();

	// Get the main task id
	g_wCurrentTask = Telium_CurrentTask();

	// Launch the timer task
	g_tsTimer_task_handle = Telium_Fork (&CLESS_ExpressPay_StartTimerTask, NULL, -1);

	// The task cannot be created
	//if (g_tsScanning_task_handle == NULL)
		//return KO;

	return OK;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Kill the removal timer task.                                                          *
 * ---------------------------------------------------------------------------------------------- */
static void CLESS_ExpressPay_KillTimerTask (void) {
	if (g_tsTimer_task_handle != NULL) // If the task is launched
	{
		g_bTimer_task_to_be_killed = TRUE; // To Stop the task (if not already waiting to be killed because of timeout expired)

		// Send an event to make the task ready to be killed
		//if (Telium_SignalEvent (g_TimerTask, (tEvent)E_USER_EVENT) != cOK)
			//GTL_Traces_DiagnosticText ("Main task: Error when setting the event\n");

		while (g_bTimerTaskRunning == TRUE) // While the task has not terminated processing
		{
			// Waits a little
			Telium_Ttestall (USER_EVENT,1);
		}

		// The task is ready to be killed, kill it
		Telium_Kill(g_tsTimer_task_handle, "-*");
		g_tsTimer_task_handle = NULL;
	}
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the double tap time value from the parameter file.                                *
 *                                                                                                *
 * [out]  : pDoubleTapTime the double tap time value (in milliseconds).                           *
 * ---------------------------------------------------------------------------------------------- */
static void CLESS_ExpressPay_GetDoubleTapTime (unsigned long *pDoubleTapTime) {
	TLV_TREE_NODE pTime;		// Node for Double Tap Time.
	unsigned char * pValue;
	unsigned int nDataLength;

	pValue = NULL;
	nDataLength = 0;

	pTime = TlvTree_Find(pTreeCurrentParam, TAG_SAMPLE_EXPRESSPAY_DOUBLE_TAP_TIME, 0);

	if (pTime != NULL) {
		pValue = TlvTree_GetData(pTime);
		nDataLength = TlvTree_GetLength(pTime);
	}

	if ((pValue != NULL) && (nDataLength != 0)) {
		GTL_Convert_BinNumberToUl(pValue, pDoubleTapTime, nDataLength);

		if((*pDoubleTapTime < EXPRESSPAY_DOUBLE_TAP_TIME_MIN) || (*pDoubleTapTime > EXPRESSPAY_DOUBLE_TAP_TIME_MAX))
			*pDoubleTapTime = EXPRESSPAY_DOUBLE_TAP_TIME_DEFAULT;
	}
	else {
		*pDoubleTapTime = EXPRESSPAY_DOUBLE_TAP_TIME_DEFAULT;
	}
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Deactivate the contactless field for a period of time between the two taps of the     *
 *          Mobile CVM.                                                                           *
 * ---------------------------------------------------------------------------------------------- */
static void CLESS_ExpressPay_CloseFieldBefore2ndTap (void) {
	unsigned long ulDoubleTapTime;		// Double Tap time (in milliseconds)

	CLESS_ExpressPay_GetDoubleTapTime(&ulDoubleTapTime);

	ClessEmv_CloseDriver();

	// Perform a double bip (600 ms)
	HelperErrorSequence (WITHBEEP);

	// Wait the remaining time
	Telium_Ttestall(0, (ulDoubleTapTime/10) - (6 * C_TIME_100MS));
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Add a tag in the transaction data to indicate to the Expresspay kernel that the       *
 *          transaction has been restarted.                                                       *
 * 			                                                                                      *
 * [in,out] :   pTransactionData Transaction data.                                                *
 * ---------------------------------------------------------------------------------------------- */
static void CLESS_ExpressPay_SetTxnRestartedIndicator (T_SHARED_DATA_STRUCT *pTransactionData) {
	unsigned char ucTxnRestarted;
	ucTxnRestarted = 0x01;
	GTL_SharedExchange_AddTag(pTransactionData, TAG_EXPRESSPAY_MOBILE_TRANSACTION_RESTARTED, 1, &ucTxnRestarted);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Add Issuer Scripts received from the authorization in the transaction data sent to    *
 *          the Expresspay kernel.                                                                *
 * 			                                                                                      *
 * [in,out] :   pTransactionData Transaction data.                                                *
 * ---------------------------------------------------------------------------------------------- */
static void CLESS_ExpressPay_AddIssuerScripts (T_SHARED_DATA_STRUCT *pTransactionData) {
	T_SHARED_DATA_STRUCT * pTmpScripts71, * pTmpScripts72;
	T_BER_TLV_DECODE_STRUCT BerTlvStruct;
	int nResult, cr;
	int BytesRead;
	BER_TLV_TAG ReadTag;
	T_TI_LENGTH ReadLength;
	T_TI_VALUE  ReadValue;


	pTmpScripts71 = GTL_SharedExchange_InitLocal(512);
	pTmpScripts72 = GTL_SharedExchange_InitLocal(512);

	if ((pTmpScripts71 != NULL) && (pTmpScripts72 != NULL)) {
		GTL_BerTlvDecode_Init (&BerTlvStruct, pTransactionData->nPtrData, pTransactionData->ulDataLength);

		// Parse Script  T1:71 or 72 L1 V1 ... Tn:71 or 72 Ln Vn
		for (;;)
		{
			//! \brief Parse the next tag in the BER-TLV structure.
			cr = GTL_BerTlvDecode_ParseTlv (&BerTlvStruct, &ReadTag, &ReadLength, (BER_TLV_VALUE*)&ReadValue, (unsigned char)FALSE, &BytesRead);

			if (cr == STATUS_BER_TLV_END)
				break ;

			if (cr == STATUS_BER_TLV_OK)
			{
				if (ReadTag == TAG_EMV_ISSUER_SCRIPT_TEMPLATE_1)
				{
					nResult = GTL_SharedExchange_AddTag(pTmpScripts71, ReadTag, ReadLength, ReadValue);
					if (nResult != STATUS_SHARED_EXCHANGE_OK) {

					}
				}
				if(ReadTag == TAG_EMV_ISSUER_SCRIPT_TEMPLATE_2)
				{
					nResult = GTL_SharedExchange_AddTag(pTmpScripts72, ReadTag, ReadLength, ReadValue);
					if (nResult != STATUS_SHARED_EXCHANGE_OK) {

					}
				}
			}
			else
				break; // An error occurs
		} // end of loop about Script parsing


		// Add TAG_EXPRESSPAY_ISSUER_SCRIPT_71_LIST and TAG_EXPRESSPAY_ISSUER_SCRIPT_72_LIST tags in the data sent to the kernel
		if (pTmpScripts71->ulDataLength)
		{
			nResult = GTL_SharedExchange_AddTag(pTransactionData, TAG_EXPRESSPAY_ISSUER_SCRIPT_71_LIST, pTmpScripts71->ulDataLength, pTmpScripts71->nPtrData);
			if (nResult != STATUS_SHARED_EXCHANGE_OK) {

			}
		}

		if (pTmpScripts72->ulDataLength)
		{
			nResult = GTL_SharedExchange_AddTag(pTransactionData, TAG_EXPRESSPAY_ISSUER_SCRIPT_72_LIST, pTmpScripts72->ulDataLength, pTmpScripts72->nPtrData);
			if (nResult != STATUS_SHARED_EXCHANGE_OK) {

			}
		}
	}

	// Destroy the local buffers
	if (pTmpScripts71)
		GTL_SharedExchange_DestroyLocal(pTmpScripts71);
	if (pTmpScripts72)
		GTL_SharedExchange_DestroyLocal(pTmpScripts72);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Check if the terminal is online only.                                                 *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_ExpressPay_IsOnlineOnly (T_SHARED_DATA_STRUCT * pDataStruct) {
	const unsigned char * pTerminalType;
	const unsigned char * pFloorLimit;
	int nPosition;
	unsigned long ulLength;
	int nResult = FALSE;

	nPosition = SHARED_EXCHANGE_POSITION_NULL;
	if (GTL_SharedExchange_FindNext (pDataStruct, &nPosition, TAG_EMV_TERMINAL_TYPE, &ulLength, &pTerminalType) == STATUS_SHARED_EXCHANGE_OK) {
		if((pTerminalType[0] == CLESS_SAMPLE_TERM_TYPE_FINANCIAL_ATT_ONLINE_ONLY) ||
			(pTerminalType[0] == CLESS_SAMPLE_TERM_TYPE_FINANCIAL_UNATT_ONLINE_ONLY) ||
			(pTerminalType[0] == CLESS_SAMPLE_TERM_TYPE_MERCHANT_ATT_ONLINE_ONLY) ||
			(pTerminalType[0] == CLESS_SAMPLE_TERM_TYPE_MERCHANT_UNATT_ONLINE_ONLY) ||
			(pTerminalType[0] == CLESS_SAMPLE_TERM_TYPE_CARDHOLDER_UNATT_ONLINE_ONLY)) {
			nResult = TRUE;
		}
	}
	nPosition = SHARED_EXCHANGE_POSITION_NULL;
	if (GTL_SharedExchange_FindNext (pDataStruct, &nPosition, TAG_EP_CLESS_FLOOR_LIMIT, &ulLength, &pFloorLimit) == STATUS_SHARED_EXCHANGE_OK) {
		if(!memcmp (pFloorLimit, "\x00\x00\x00\x00\x00\x00", ulLength)){
			nResult = TRUE;
		}
	}
	return (nResult);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Add the transaction record in the batch file.                                    *
 * 			                                                                                  *
 * [in] :    pSharedData Shared buffer to be used to get all the record data.                 *
 *           For ExpressPay, pSharedData is the one returned by the ExpressPay kernel on      *
 *           the DoTransaction function.                                                      *
 * ------------------------------------------------------------------------------------------ */
static void CLESS_ExpressPay_AddRecordToBatch (T_SHARED_DATA_STRUCT * pSharedData) {
	//ClessSample_Batch_AddTransactionToBatch (pSharedData);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Prepare the Online authorization request data for ExpressPay3 transactions       *
 * 			                                                                                  *
 * [in] :    dataStruct Data buffer to be filled and used for ExpressPay3 transaction.        *
 *           kernalStatusCode used in the ExpressPay3 MSR and EMV Mode transaction.           *
 * [out]:    Fill the userInput data                                                          *
 * ------------------------------------------------------------------------------------------ */
int ExpressPay3_OnlineRequestData (T_SHARED_DATA_STRUCT * dataStruct, int kernalStatusCode) {
	int result = TRUE;
	unsigned long length;
	const unsigned char* ptValue;
	int position;

	typedef struct{
		unsigned long tagNum;
		unsigned char tagName[2];
		int tagNameLength;
		int tagDataMinLen;
		int mandatoryFlag;
	}EMVTags;

	EMVTags ExpressPayRequestTags [] =
	   {{TAG_EMV_AIP,                        				"\x82",     1, 2, TRUE},
		{TAG_EMV_DF_NAME,                    				"\x84",     1, 5, TRUE},
		{TAG_EMV_TVR,                        				"\x95",     1, 5, TRUE},
		{TAG_EMV_TRANSACTION_DATE,           				"\x9A",     1, 3, TRUE},
		{TAG_EMV_TRANSACTION_TYPE,           				"\x9C",     1, 1, TRUE},
		{TAG_EMV_TRANSACTION_CURRENCY_CODE,  				"\x5F\x2A", 2, 2, TRUE},
		{TAG_EMV_AMOUNT_AUTH_NUM,            				"\x9F\x02", 2, 6, TRUE},
		{TAG_EMV_AMOUNT_OTHER_NUM,           				"\x9F\x03", 2, 6, TRUE},
		{TAG_EMV_ISSUER_APPLI_DATA,    						"\x9F\x10", 2, 0, TRUE},
		{TAG_EMV_TERMINAL_COUNTRY_CODE,      				"\x9F\x1A", 2, 2, TRUE},
		{TAG_EMV_APPLICATION_CRYPTOGRAM,      				"\x9F\x26", 2, 8, TRUE},
		{TAG_EMV_CRYPTOGRAM_INFO_DATA,						"\x9F\x27", 2, 1, TRUE},
		{TAG_EMV_ATC,                        				"\x9F\x36", 2, 2, TRUE},
		{TAG_EMV_UNPREDICTABLE_NUMBER,       				"\x9F\x37", 2, 4, TRUE},
		{TAG_EMV_POS_ENTRY_MODE, 		 					"\x9F\x39", 2, 1, TRUE},
		{TAG_EMV_TERMINAL_CAPABILITIES,      				"\x9F\x33", 2, 3, FALSE},
		{TAG_EMV_CVM_RESULTS,                 				"\x9F\x34", 2, 3, FALSE},
		{TAG_EMV_TERMINAL_TYPE,              				"\x9F\x35", 2, 1, FALSE},
		{TAG_EMV_ADD_TERMINAL_CAPABILITIES,  				"\x9F\x40", 2, 5, FALSE},
		{TAG_EMV_AID_CARD, 				 					"\x4F",     1,16, FALSE},
		{TAG_EMV_AID_TERMINAL, 		         				"\x9F\x06", 2,16, FALSE},
		{TAG_EMV_TSI, 						 				"\x9B",     1, 2, FALSE},
		{TAG_EMV_TRANSACTION_TIME, 		     				"\x9F\x21", 2, 3, FALSE},
		{TAG_EMV_APPLI_PAN_SEQUENCE_NUMBER,					"\x5F\x34", 2, 1, FALSE},
		{TAG_EMV_IFD_SERIAL_NUMBER,							"\x9F\x1E", 2, 8, FALSE},
		{TAG_EMV_TRANSACTION_CURRENCY_EXPONENT,				"\x5F\x36", 2, 1, FALSE},
		{TAG_EMV_APPLI_VERSION_NUMBER_TERM,					"\x9F\x09", 2, 2, FALSE},
		{TAG_EMV_APPLI_PAN,									"\x5A", 	1,10, FALSE},
		{TAG_EMV_TRANSACTION_SEQUENCE_COUNTER,				"\x9F\x41", 2, 4, FALSE},
		{TAG_EMV_APPLI_EXPIRATION_DATE,						"\x5F\x24", 2, 3, FALSE},
		{TAG_EMV_TRACK_2_EQU_DATA,							"\x57",     1,37, FALSE},
		{TAG_EMV_SERVICE_CODE,								"\x5F\x30", 2, 2, FALSE},
		{TAG_EMV_CARDHOLDER_NAME,							"\x5F\x20", 2,26, FALSE},
		{TAG_EMV_ICC_DYNAMIC_NUMBER,						"\x9F\x4C", 2, 0, FALSE},
	 	{TAG_EXPRESSPAY_TERMINAL_TRANSACTION_CAPABILITIES,	"\x9F\x6E", 2, 0, FALSE}};

    if (kernalStatusCode == EXPRESSPAY_STATUS_EMV_PARTIAL_ONLINE_AUTHORISATION ||
    	kernalStatusCode == EXPRESSPAY_STATUS_EMV_FULL_ONLINE_AUTHORISATION) {
    	if(kernalStatusCode == EXPRESSPAY_STATUS_EMV_FULL_ONLINE_AUTHORISATION)
    		CLESS_GUI_DisplayScreen (APCLESS_SCREEN_REMOVE_CARD);
		setCardInputMode (EMVCONTACTLESS);
    	unsigned char dataEMV[256] = {0};
    	int i, j = 0;
    	int tagCount = sizeof(ExpressPayRequestTags) / sizeof(ExpressPayRequestTags[0]);
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		unsigned char poscode[1] = {0};
		char  posencode[2]="07";
		Aschex(poscode,posencode, sizeof(posencode));
		GTL_SharedExchange_AddTag(dataStruct, TAG_EMV_POS_ENTRY_MODE, sizeof(poscode), poscode);
    	for (i = 0; i < tagCount; i++){
    		length = 0;
    		position = SHARED_EXCHANGE_POSITION_NULL;
    		if (dataStruct->ulDataLength)
    			GTL_SharedExchange_FindNext(dataStruct, &position, ExpressPayRequestTags[i].tagNum, &length, &ptValue);

    		if (length != 0){
    			memcpy (&dataEMV[j], ExpressPayRequestTags[i].tagName, ExpressPayRequestTags[i].tagNameLength);
    			memcpy (&dataEMV[j + ExpressPayRequestTags[i].tagNameLength], &length, 1);
    			memcpy (&dataEMV[j + ExpressPayRequestTags[i].tagNameLength + 1], ptValue, length);
    			j = j + ExpressPayRequestTags[i].tagNameLength + 1 + length;
    		}
    		else {
    			if (ExpressPayRequestTags[i].mandatoryFlag == TRUE) {
    				memcpy (&dataEMV[j], ExpressPayRequestTags[i].tagName, ExpressPayRequestTags[i].tagNameLength);
    				memcpy (&dataEMV[j + ExpressPayRequestTags[i].tagNameLength], &ExpressPayRequestTags[i].tagDataMinLen, 1);
    				memset (&dataEMV[j + ExpressPayRequestTags[i].tagNameLength + 1], 0, ExpressPayRequestTags[i].tagDataMinLen);
    				j = j + ExpressPayRequestTags[i].tagNameLength + 1 + ExpressPayRequestTags[i].tagDataMinLen;
    			}
    		}
    	}
    	setRequestEMVData(dataEMV, j);

    	// Set EMV Application Label
    	length = 0;
    	position = SHARED_EXCHANGE_POSITION_NULL;
    	if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_APPLICATION_LABEL, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
    		char app[17] = {0};
    		memcpy(app,ptValue,length);
    		setEMVApplicationLabel(app);
    	}
    	// set EMV Application Identifier (AID)
    	length = 0;
    	position = SHARED_EXCHANGE_POSITION_NULL;
    	if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_DF_NAME, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
    		char aid[33] = {0};
    		memcpy (aid, hexToASCII(ptValue,length), length*2);
    		setEMVApplicationIdentifier (aid);
    	}
    	// Set Transaction Status Information(TSI)
    	length = 0;
    	position = SHARED_EXCHANGE_POSITION_NULL;
    	if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_TSI, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
    		char tsi[5] = {0};
    		memcpy(tsi,ptValue,length);
    		setEMVTransactionStatusInformation(tsi);
    	}
    	// Get Card Number (Tag 5A)
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_APPLI_PAN, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char cardNo [20] = {0};
			Hexasc (cardNo, ptValue, length*2);
			int n;
			for (n = 0; n < length*2; n++) {
				if ((int)cardNo[n] < 48 || (int)cardNo[n] > 57)
					cardNo[n] = '\x00';
			}
			setCardNumber(cardNo, strlen(cardNo));
		}
		// Get Card Holder Name
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_CARDHOLDER_NAME, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			setCardHolderName (ptValue, length);
		}
		// Set Expiration Date
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_APPLI_EXPIRATION_DATE, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char cardAppExp[5] = {0};
			Hexasc(cardAppExp, ptValue, 4);
			setCardExpiryDate(cardAppExp);
		}
		// Get Track Data (Tag 57)
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_TRACK_2_EQU_DATA, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char tag57 [40] = {0};
			memcpy (tag57, unsignedCharToASCII(ptValue,length), length*2);
			int trackLength = 0;
			if (tag57 [0] != 'B'){
				char temp [40] = {0};
				temp [0] = 'B';
				memcpy (temp+1, tag57, length*2);
				trackLength = length*2 + 1;
				memcpy (tag57, temp, trackLength);
				if (tag57 [strlen(tag57) - 1] != 'F') {
					tag57 [strlen(tag57)] = 'F';
					trackLength = trackLength + 1;
				}
			}
			else
				trackLength = length*2;

			char *pcSrc = NULL, *pcDst = NULL;
			char tcTrk2[40] = {'\0'};
			pcSrc = tag57;
			pcDst = tcTrk2;
			while(*pcSrc) {                                  // Find start sentinel
				if(*pcSrc++ == 'B'){
					*pcDst++ = ';';
					break;
				}
			}
			while(*pcSrc) {                                  // Copy all data between start and end sentinels
				if(*pcSrc == 'F'){
					*pcDst = '?';
					break;
				}
				if(*pcSrc == 'D')
					*pcSrc = '=';
				*pcDst++ = *pcSrc++;
			}
			setTrack2Data(tcTrk2, trackLength);
		}
		// Get Cardholder Verification Method (Tag 9F34)
		/*length = 0;
		unsigned char cvr;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EXPRESSPAY_TRANSACTION_CVM, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			if (length != 0){
				memcpy (cvr, ptValue, sizeof (cvr));
				setCHVerificationMethod((((int) cvr[0] & 31) == 31 ? NO_AUTHENTICATION 	:		// 0x1F
										(((int) cvr[0] & 30) == 30 ? PAPER_SIGNATURE 	:		// 0x1E
										(((int) cvr[0] & 5)  == 5  ? SIGN_OFF_ENC_PIN 	:		// 0x05
										(((int) cvr[0] & 4)  == 4  ? OFF_ENCIPHER_PIN :		    // 0x04
										(((int) cvr[0] & 3)  == 3  ? SIGN_OFF_CLR_PIN 	:		// 0x03
										(((int) cvr[0] & 2)  == 2  ? ONLINE_PIN 		:		// 0x02
										(((int) cvr[0] & 1)  == 1  ? OFF_ENCIPHER_PIN 	:		// 0x01
																	 NO_AUTHENTICATION ))))))));
			}
		} */
    }
    else if (kernalStatusCode == EXPRESSPAY_STATUS_MAGSTRIPE_ONLINE_AUTHORISATION) {
    	setCardInputMode (MSRCONTACTLESS);

    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EXPRESSPAY_PSEUDO_MS_TRACK2, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char track2Raw [40] = {0};
			char * track2;
			memcpy (track2Raw, ptValue, length);
			setTrack2Data(track2Raw, strlen(track2Raw));
			if (track2Raw[0] == ';')
				track2 = strtok(track2Raw + 1,"?");
			else
				track2 = strtok(track2Raw,"?");
			int trackLen = strlen(track2);
			char * token = strtok(track2, "=");
			setCardNumber (token, strlen(token));
			token = strtok(NULL,"'\0'");
			char cardExpiryDate[4] = {0};
			memcpy (cardExpiryDate, token, 2);    // YY
			memcpy (cardExpiryDate+2, token+2, 2);    // MM
			setCardExpiryDate (cardExpiryDate);
			char svc[3] = {0};
			memcpy (svc, token + sizeof(cardExpiryDate), sizeof(svc));

    		setCHVerificationMethod (getCardType() == CREDIT	? PAPER_SIGNATURE 	:
    								(getCardType() == DEBIT  	? ONLINE_PIN 		:
    										 	 	 	 	 	  NO_AUTHENTICATION));
		}
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EXPRESSPAY_PSEUDO_MS_TRACK1, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			if (strtok(ptValue,"^")) {
				   char * token = strtok(NULL,"/^");
				   setCardHolderName(token, sizeof(token));
			 }
		}
    }
   	else {
   		result = FALSE;
   		goto End;
    }
End:
	return result;
}
