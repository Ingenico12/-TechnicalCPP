/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   06/30/2018   This module implements main the EMV Engine services.          *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "TlvTree.h"
#include "GTL_Assert.h"
#include "_emvdctag_.h"
#include "def_tag.h"
#include "EngineInterface.h"
#include "EngineInterfaceLib.h"

#include "Utils.h"
#include "EPSTOOL_TlvTree.h"

#include "EMV.h"
#include "emvparameter.h"

static int  __APEMV_ServicesEmv_StartTransaction(NO_SEGMENT appliId, int doEmvAppliSelection, TLV_TREE_NODE outputTlvTree);

static TLV_TREE_NODE __APEMV_ServicesEmv_TransacInfoTlvTree = NULL;										//!< Store the EMV transaction data (amount, date and time, ...).
static APEMV_ServicesEmv_TransactionStatus_e __APEMV_ServicesEmv_TransacStatus = APEMV_TR_STATUS_UNKNOWN;	//!< Store the EMV transaction status (transaction approved, ...).

/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Start an EMV transaction by calling EMV ENGINE.                                       *
 * 			                                                                                      *
 * [in] :   appliId The application ID.                        	                                  *
 * [in] :   doEmvAppliSelection 																  *
 * 			TRUE - 	if the application selection must be done (transaction not started by the     *
 * 					Telium Manager).                                                              *
 * 			FALSE -	if the application selection has already been done (transaction is started 	  *
 * 					by the Telium Manager, usually called from GIVE_AID).		                  *
 * [out]:   outputTlvTree Output TlvTree. Usually empty.                                          *
 * [return]: EMV ENGINE status code. -  ERR_ENG_OK if successful.                                 *
 * ---------------------------------------------------------------------------------------------- */
static int __APEMV_ServicesEmv_StartTransaction(NO_SEGMENT appliId, int doEmvAppliSelection, TLV_TREE_NODE outputTlvTree) {
	TLV_TREE_NODE inputTlvTree;
	int result;
	unsigned char buffer[2];
	object_info_t info;

	ASSERT(outputTlvTree != NULL);

	inputTlvTree = TlvTree_New(0);
	if (inputTlvTree == NULL) {
		ASSERT(FALSE);
		return ERR_ENG_NOT_ENOUGH_MEMORY;
	}

	// Store the application type to call callbacks
	ObjectGetInfo(OBJECT_TYPE_APPLI, appliId,&info);

	EPSTOOL_Convert_UShortToEmvBin(info.application_type, buffer);
	if (TlvTree_AddChild(inputTlvTree, TAG_ENG_CUSTOM_APPLI_TYPE, buffer, 2) == NULL) {
		EPSTOOL_TlvTree_Release(&inputTlvTree);
		ASSERT(FALSE);
		return ERR_ENG_NOT_ENOUGH_MEMORY;
	}

	// Indicate if Application Selection has already been done (usually by the Telium Manager)
	buffer[0] = !doEmvAppliSelection;
	if (TlvTree_AddChild(inputTlvTree, TAG_ENG_APPLI_SEL_ALREADY_DONE, buffer, 1) == NULL) {
		EPSTOOL_TlvTree_Release(&inputTlvTree);
		ASSERT(FALSE);
		return ERR_ENG_NOT_ENOUGH_MEMORY;
	}

	// Launch the transaction
	result = Engine_DoTransaction(inputTlvTree, &outputTlvTree);
	EPSTOOL_TlvTree_Release(&inputTlvTree);
	return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Perform an EMV transaction by calling EMV ENGINE.                                     *
 * 			                                                                                      *
 * [in] :   appliId The application ID.                        	                                  *
 * [in] :   doEmvAppliSelection 																  *
 * 			TRUE - 	if the application selection must be done (transaction not started by the     *
 * 					Telium Manager).                                                              *
 * 			FALSE -	if the application selection has already been done (transaction is started 	  *
 * 					by the Telium Manager, usually called from GIVE_AID).		                  *
 * [out]:   outputTlvTree Output TlvTree. Usually empty.                                          *
 * [return]: EMV ENGINE status code. -  ERR_ENG_OK if successful.                                 *
 * [Note]:	If date and time is not set in 'inputTlvTree', the current date and time is			  *
 * 			automatically used.                                                                   *
 * ---------------------------------------------------------------------------------------------- */
int emvDoTransaction (NO_SEGMENT appliId, int doEmvAppliSelection, TLV_TREE_NODE inputTlvTree) {
	int result;
	TLV_TREE_NODE outputTlvTree;
	Telium_Date_t currentDate;
	int dateMissing;
	int timeMissing;
	unsigned char buffer[3];

	ASSERT(inputTlvTree != NULL);

	__APEMV_ServicesEmv_TransacStatus = APEMV_TR_STATUS_UNKNOWN;

	outputTlvTree = TlvTree_New(0);
	if (outputTlvTree) {
		// Add date and time if they are missing
		dateMissing = (EPSTOOL_TlvTree_FindFirstData(inputTlvTree, TAG_TRANSACTION_DATE, NULL) == NULL);
		timeMissing = (EPSTOOL_TlvTree_FindFirstData(inputTlvTree, TAG_TRANSACTION_TIME, NULL) == NULL);
		if ((dateMissing) || (timeMissing)) {
			// The date and/or time is missing

			// Get the current date and time
			if (Telium_Read_date(&currentDate) == 0) {
				// Add the date if it is missing
				if (dateMissing) {
					buffer[0] = ((currentDate.year[0] - '0') << 4) | (currentDate.year[1] - '0');
					buffer[1] = ((currentDate.month[0] - '0') << 4) | (currentDate.month[1] - '0');
					buffer[2] = ((currentDate.day[0] - '0') << 4) | (currentDate.day[1] - '0');
					if (TlvTree_AddChild(outputTlvTree, TAG_TRANSACTION_DATE, buffer, 3) == NULL)
					{
						ASSERT(FALSE);
						return ERR_ENG_NOT_ENOUGH_MEMORY;
					}
				}

				// Add the time if it is missing
				if (timeMissing) {
					buffer[0] = ((currentDate.hour[0] - '0') << 4) | (currentDate.hour[1] - '0');
					buffer[1] = ((currentDate.minute[0] - '0') << 4) | (currentDate.minute[1] - '0');
					buffer[2] = ((currentDate.second[0] - '0') << 4) | (currentDate.second[1] - '0');
					if (TlvTree_AddChild(outputTlvTree, TAG_TRANSACTION_TIME, buffer, 3) == NULL) {
						ASSERT(FALSE);
						return ERR_ENG_NOT_ENOUGH_MEMORY;
					}
				}
			}
		}

		// Store the transaction input data
		EPSTOOL_TlvTree_Release(&__APEMV_ServicesEmv_TransacInfoTlvTree);
		__APEMV_ServicesEmv_TransacInfoTlvTree = TlvTree_New(0);
		if (__APEMV_ServicesEmv_TransacInfoTlvTree == NULL) {
			ASSERT(FALSE);
			return ERR_ENG_NOT_ENOUGH_MEMORY;
		}
		if (!EPSTOOL_TlvTree_CopyChildren(__APEMV_ServicesEmv_TransacInfoTlvTree, inputTlvTree)) {
			EPSTOOL_TlvTree_Release(&__APEMV_ServicesEmv_TransacInfoTlvTree);
			ASSERT(FALSE);
			return ERR_ENG_NOT_ENOUGH_MEMORY;
		}

		// TODO: Reset globals required for the transaction

		// Start the transaction
		result = __APEMV_ServicesEmv_StartTransaction(appliId, doEmvAppliSelection, outputTlvTree);

		// Resume the transaction until the end of the transaction
		while(result == ERR_ENG_SUSPEND) {
			EPSTOOL_TlvTree_ReleaseChildren(outputTlvTree);
			result = Engine_ResumeTransaction(NULL, &outputTlvTree);
		}

		// Force an error if transaction is not approved
		if ((result == ERR_ENG_OK) && (__APEMV_ServicesEmv_TransacStatus != APEMV_TR_STATUS_APPROVED)) {
			result = ERR_ENG_UNKNOWN;
		}
        if (result== ERR_ENG_UNKNOWN_SERVICE || result == ERR_ENG_ENGINE_ERROR ){
        	setErrorCode ("ERROR:043");
        }
		// Release memory
		EPSTOOL_TlvTree_Release(&outputTlvTree);
	}
	else {
		ASSERT(FALSE);
		result = ERR_ENG_NOT_ENOUGH_MEMORY;
	}

	// Reset globals
	EPSTOOL_TlvTree_Release(&__APEMV_ServicesEmv_TransacInfoTlvTree);
	__APEMV_ServicesEmv_TransacStatus = APEMV_TR_STATUS_UNKNOWN;

	return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Retrieve the transaction data (amount, date and time, ...)                            *
 * 			                                                                                      *
 * [out]:   outputTlvTree TlvTree that will be filled with the transaction data.                  *
 * [return]: TRUE if successful.                                                                  *
 * 			 FALSE if an error occurs (usually because not enough memory).                        *
 * ---------------------------------------------------------------------------------------------- */
int emvGetTransactionData (TLV_TREE_NODE outputTlvTree) {
	ASSERT(outputTlvTree != NULL);
	ASSERT(__APEMV_ServicesEmv_TransacInfoTlvTree != NULL);

	// Get the transaction data
	return EPSTOOL_TlvTree_CopyChildren(outputTlvTree, __APEMV_ServicesEmv_TransacInfoTlvTree);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Determine if the amount is known or not.                                              *
 * 			                                                                                      *
 * [return]: TRUE if the amount is known                                                          *
 * 			 FALSE if not                                                                         *
 * ---------------------------------------------------------------------------------------------- */
int emvAmountIsSet (void) {
	TLV_TREE_NODE nodeAmountBin;
	TLV_TREE_NODE nodeAmountNum;
	EPSTOOL_Data_t dataAmountBin;
	EPSTOOL_Data_t dataAmountNum;

	ASSERT(__APEMV_ServicesEmv_TransacInfoTlvTree != NULL);

	nodeAmountBin = EPSTOOL_TlvTree_FindFirstData(__APEMV_ServicesEmv_TransacInfoTlvTree, TAG_AMOUNT_AUTH_BIN, &dataAmountBin);
	nodeAmountNum = EPSTOOL_TlvTree_FindFirstData(__APEMV_ServicesEmv_TransacInfoTlvTree, TAG_AMOUNT_AUTH_NUM, &dataAmountNum);
	if (((nodeAmountBin != NULL) && (dataAmountBin.length > 0))
		|| ((nodeAmountNum != NULL) && (dataAmountNum.length > 0))) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Set the transaction amount.                                                         NU*
 *                                                                                                *
 * [in] :   amount The amount of the transaction.              	                                  *
 * [out]:   outputTlvTree A TlvTree that will contain the amounts tags (binary and numeric).      *
 * 			                                                                                      *
 * [return]: TRUE if the amount is set                                                            *
 * 			 FALSE if an error occurs.                                                            *
 * ---------------------------------------------------------------------------------------------- */
int emvAmountSet (unsigned long long amount, TLV_TREE_NODE outputTlvTree) {
	unsigned char amountBinary[4];
	unsigned char amountNumeric[6];

	ASSERT(__APEMV_ServicesEmv_TransacInfoTlvTree != NULL);

	if (amount <= 0xffffffff) {
		// Convert the amount into a 'EMV binary' number
		EPSTOOL_Convert_ULongToEmvBin((unsigned long)amount, amountBinary);
		if (TlvTree_AddChild(__APEMV_ServicesEmv_TransacInfoTlvTree, TAG_AMOUNT_AUTH_BIN, amountBinary, sizeof(amountBinary)) == NULL)
			return FALSE;
		if (outputTlvTree != NULL)
		{
			if (TlvTree_AddChild(outputTlvTree, TAG_AMOUNT_AUTH_BIN, amountBinary, sizeof(amountBinary)) == NULL)
				return FALSE;
		}
	}

	if (amount <= 999999999999ULL) {
		// Convert the amount into a 'EMV numeric' number
		EPSTOOL_Convert_UllToDcbNumber(amount, amountNumeric, 6);
		if (TlvTree_AddChild(__APEMV_ServicesEmv_TransacInfoTlvTree, TAG_AMOUNT_AUTH_NUM, amountNumeric, sizeof(amountNumeric)) == NULL)
			return FALSE;
		if (outputTlvTree != NULL) {
			if (TlvTree_AddChild(outputTlvTree, TAG_AMOUNT_AUTH_NUM, amountNumeric, sizeof(amountNumeric)) == NULL)
				return FALSE;
		}
	}
	else {
		// Amount is too big
		return FALSE;
	}
	return TRUE;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Retrieve the transaction status.                                                      *
 * 			                                                                                      *
 * [return]: The transaction status (from the global variable __APEMV_ServicesEmv_TransacStatus)  *
 * ---------------------------------------------------------------------------------------------- */
APEMV_ServicesEmv_TransactionStatus_e emvTransacStatusGet (void) {
	ASSERT((__APEMV_ServicesEmv_TransacStatus >= 0) && (__APEMV_ServicesEmv_TransacStatus < APEMV_TR_STATUS_END));
	return __APEMV_ServicesEmv_TransacStatus;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose:  Change the transaction status with a new value.                                      *
 * 			                                                                                      *
 * [in] :    status The new transaction status.              	                                  *
 * [return]: This function sets the global variable __APEMV_ServicesEmv_TransacStatus             *
 * ---------------------------------------------------------------------------------------------- */
void emvTransacStatusChange (APEMV_ServicesEmv_TransactionStatus_e status) {
	ASSERT((status >= 0) && (status < APEMV_TR_STATUS_END));
	__APEMV_ServicesEmv_TransacStatus = status;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose:  Set the transaction status (if needed) depending on the status code from ENGINE.     *
 * 			                                                                                      *
 * [in] :    statusCode The status code from ENGINE.           	                                  *
 * [return]: This function sets the global variable __APEMV_ServicesEmv_TransacStatus             *
 * ---------------------------------------------------------------------------------------------- */
void emvTransacStatusSet (unsigned short statusCode) {
	switch(statusCode)
	{
	case TAG_CUST_PROCESS_COMPLETED:
		// Do not change the status code!
		break;

	// Normal processing
	case TAG_CUST_TRANSACTION_ACCEPTED:
		__APEMV_ServicesEmv_TransacStatus = APEMV_TR_STATUS_APPROVED;
		break;
	case TAG_CUST_TRANSACTION_DECLINED:
		__APEMV_ServicesEmv_TransacStatus = APEMV_TR_STATUS_DECLINED;
		break;

	// Normal status that stops the transaction
	case TAG_CUST_SERVICE_NOT_ALLOWED:
		__APEMV_ServicesEmv_TransacStatus = APEMV_TR_STATUS_SERVICE_NOT_ALLOWED;
		break;
	case TAG_CUST_TRANSACTION_CANCELLED:
		__APEMV_ServicesEmv_TransacStatus = APEMV_TR_STATUS_CANCELLED;
		break;
	case TAG_CUST_CARD_BLOCKED:
		__APEMV_ServicesEmv_TransacStatus = APEMV_TR_STATUS_CARD_BLOCKED;
		break;
	case TAG_CUST_REMOVED_CARD:
		__APEMV_ServicesEmv_TransacStatus = APEMV_TR_STATUS_CARD_REMOVED;
		break;

	// Terminal errors
	case TAG_CUST_NOT_ENOUGH_MEMORY:
	case TAG_CUST_MISSING_MANDATORY_TERM_DATA:
	case TAG_CUST_INTERNAL_ERROR:
		__APEMV_ServicesEmv_TransacStatus = APEMV_TR_STATUS_TERMINAL_ERROR;
		break;

	//card is not supported EMV
	case TAG_CUST_CARD_ERROR:
		__APEMV_ServicesEmv_TransacStatus = APEMV_TR_STATUS_CARD_NOT_SUPPORTED_EMV;
		break;
	// Card errors
	case TAG_CUST_PROCESSING_ERROR:
	case TAG_CUST_NOT_ACCEPTED:
	case TAG_CUST_ICC_DATA_FORMAT_ERROR:
	case TAG_CUST_MISSING_MANDATORY_ICC_DATA:
	case TAG_CUST_ICC_REDUNDANT_DATA:
	case TAG_CUST_COND_OF_USE_NOT_SATISFIED:
		__APEMV_ServicesEmv_TransacStatus = APEMV_TR_STATUS_CARD_ERROR;
		break;

	default:
		if (statusCode >= 0x0010)
			// Error
			__APEMV_ServicesEmv_TransacStatus = APEMV_TR_STATUS_UNKNOWN;
		// Else do not change the transaction status (the status code is a warning, not an error)
		break;
	}
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose: Retrieves POS terminal configuration and preferences from emvParameter.h and 	NU*
 * 			pass those to EMV Engine.                                                         *
 * 			                                                                                  *
 * [in] :   inputTlvTree Input TlvTree.                                                       *
 * [out]:   outputTlvTree Output TlvTree that must be filled with the terminal parameters.    *
 * ------------------------------------------------------------------------------------------ */
void emvGetGlobalParam (TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;

    ASSERT(inputTlvTree != NULL);
    ASSERT(outputTlvTree != NULL);

    // Set the TAG_IFD_SERIAL_NUMBER
    NO_SERIE serial={0};
	PSQ_Give_Serial_Number(serial);
	ASSERT((serial[0] >= '0') && (serial[0] <= '9')
			&& (serial[1] >= '0') && (serial[1] <= '9')
			&& (serial[2] >= '0') && (serial[2] <= '9')
			&& (serial[3] >= '0') && (serial[3] <= '9')
			&& (serial[4] >= '0') && (serial[4] <= '9')
			&& (serial[5] >= '0') && (serial[5] <= '9')
			&& (serial[6] >= '0') && (serial[6] <= '9')
			&& (serial[7] >= '0') && (serial[7] <= '9'));
	VERIFY(TlvTree_AddChild(outputTlvTree, TAG_IFD_SERIAL_NUMBER, serial, 8) != NULL);

	VERIFY(TlvTree_AddChild(outputTlvTree, TAG_POS_ENTRY_MODE_CODE, "\x05", 1) != NULL);
}
