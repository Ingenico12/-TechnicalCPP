/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   07/31/2018   Manages the interface with the Discover DPAS functionality.   *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "CLESS.h"
#include "transaction.h"
#include "emvParameter.h"
#include "sec_interface.h"
#include "EPSTOOL_PinEntry.h"

#define SAMPLE_DISCOVER_DPAS_ONLINE_BUFFER_SIZE				2048	// Default size for shared buffer used for online authorisation
#define CPR_SWITCH_INTERFACE_ONLINE_UNABLE					0x80
#define C_CPT_TIME_20S						20

static T_SHARED_DATA_STRUCT * gs_pTransactionDataLog;			// Structure used to log the transaction data

static int 		CLESS_DiscoverDPAS_RetreiveCvmToApply (T_SHARED_DATA_STRUCT * pResultDataStruct, unsigned char * pCvm);
static int 		CLESS_DiscoverDPAS_RetreiveCardType (T_SHARED_DATA_STRUCT * pResultDataStruct, unsigned short * pCardType);
static int 		CLESS_DiscoverDPAS_AddDiscoverSpecificData (T_SHARED_DATA_STRUCT * pDataStruct);
static T_Bool 	CLESS_DiscoverDPAS_OnlinePinManagement (T_SHARED_DATA_STRUCT * pStructureForOnlineData, int nCardHolderLang);
static void 	CLESS_DiscoverDPAS_AddRecordToBatch (T_SHARED_DATA_STRUCT * pSharedData, unsigned short usCardType);
static void 	CLESS_DiscoverDPAS_GetSelectedPreferedLanguage (int * pCardholderLanguage, int nMerchantLanguage);
static int 		CLESS_DiscoverDPAS_FillBufferForOnlineAuthorisation (T_SHARED_DATA_STRUCT * pTransactionData, T_SHARED_DATA_STRUCT * pOnlineAuthorisationData);
//static void __ClessSample_DiscoverDPAS_FormatAmount (unsigned char ucFormat, unsigned char *ucCurrencyLabel, unsigned char ucPosition, const unsigned char * pAmount, unsigned int nAmountLength, unsigned char *pFormattedAmountMessage);
static void 	CLESS_DiscoverDPAS_DumpSpecificStructure (T_SHARED_DATA_STRUCT * pExchangeStruct, unsigned long ulTag, int bRequestToKernelIfNotPresent);
int 			CLESS_DiscoverDPAS_AddIssuerScripts (T_SHARED_DATA_STRUCT *pTransactionData, T_SHARED_DATA_STRUCT * pDataStruct);
int 			CLESS_DiscoverDPAS_SitchInterfaceOnOnlineFailure();
static int 		CLESS_DiscoverDPAS_WaitClessCard(void);
static int 		CLESS_DiscoverDPAS_StopClessCard(void);
int 			DiscoverDPAS_OnlineRequestData (T_SHARED_DATA_STRUCT* dataStruct, unsigned short cardType);

/*
//! \brief Dump the Data Record.
//!	\param[in] pDataRecordValue Data Record value.
//! \param[in] ulDataRecordLength Data Record length.

static void __ClessSample_DiscoverDPAS_DumpDataRecord (unsigned char * pDataRecordValue, unsigned long ulDataRecordLength)
{
	T_SHARED_DATA_STRUCT tDataRecord;

	if (GTL_SharedExchange_InitEx (&tDataRecord, ulDataRecordLength+1, ulDataRecordLength, pDataRecordValue) == STATUS_SHARED_EXCHANGE_OK)
	{
		// Dump the data record
		if (ClessSample_DumpData_DumpOpenOutputDriver())
		{
			ClessSample_DumpData ("DATA RECORD");
			ClessSample_DumpData_DumpNewLine();

			ClessSample_DumpData_DumpCloseOutputDriver();
		}

		// Dump the shared buffer
		ClessSample_DumpData_DumpSharedBuffer (&tDataRecord, 0);
	}
	else
	{
		// An error occurred when initialising the structure
		GTL_Traces_TraceDebug ("__ClessSample_DiscoverDPAS_DumpDataRecord : Data record structure initialisation failed");
	}
}



//! \brief Dump the Discretionary Data.
//!	\param[in] pDiscretionaryDataValue Discretionary Data value.
//! \param[in] ulDiscretionaryDataLength Discretionary Data length.

static void __ClessSample_DiscoverDPAS_DumpDiscretionaryData (unsigned char * pDiscretionaryDataValue, unsigned long ulDiscretionaryDataLength)
{
	T_SHARED_DATA_STRUCT tDiscretionaryData;

	if (GTL_SharedExchange_InitEx (&tDiscretionaryData, ulDiscretionaryDataLength+1, ulDiscretionaryDataLength, pDiscretionaryDataValue) == STATUS_SHARED_EXCHANGE_OK)
	{
		// Dump the data record
		if (ClessSample_DumpData_DumpOpenOutputDriver())
		{
			ClessSample_DumpData ("DISCRETIONARY DATA");
			ClessSample_DumpData_DumpNewLine();

			ClessSample_DumpData_DumpCloseOutputDriver();
		}

		// Dump the shared buffer
		ClessSample_DumpData_DumpSharedBuffer (&tDiscretionaryData, 0);
	}
	else
	{
		// An error occurred when initialising the structure
		GTL_Traces_TraceDebug ("__ClessSample_DiscoverDPAS_DumpDiscretionaryData : Discretionary data structure initialisation failed");
	}
}
*/

//! \brief Request a tag to the Discover kernel.
//! \param[in,out] pDataRequest Structure already initialised and allocated.
//! \param[in] ulTag tag to be requested.
//! \return
//!	- \a TRUE if correctly required.
//!	- \a FALSE if an error occurred.

static int __ClessSample_DiscoverDPAS_RequestDataToKernel (T_SHARED_DATA_STRUCT * pDataRequest, unsigned long ulTag)
{
	int nResult = TRUE;
	int cr;

	if (pDataRequest != NULL)
	{
		// Clear shared buffer
		GTL_SharedExchange_ClearEx (pDataRequest, FALSE);

		// Indicate tag to be requested
		GTL_SharedExchange_AddTag (pDataRequest, ulTag, 0, NULL);

		// Request the data to the kernel
		cr = DiscoverDPAS_GetData (pDataRequest);

		if (cr != KERNEL_STATUS_OK)
		{
			// An error occurred
			GTL_Traces_TraceDebug("__ClessSample_DiscoverDPAS_RequestDataToKernel : An error occured when getting tag to the Discover kernel (cr=%02x)", cr);
			nResult = FALSE;
		}
	}
	else
	{
		// An error occurred
		GTL_Traces_TraceDebug("__ClessSample_DiscoverDPAS_RequestDataToKernel : Provided structure is not initialised");
		nResult = FALSE;
	}

	return (nResult);
}



//! \brief Dump a specific Discover tag.
//! \param[in] ulTag Specific tag to be dumped.
//! \param[in] bRequestToKernelIfNotPresent Boolean that indicates if the tag must requested or not to the kernel if it is not present in pExchangeStruct.
//!	- \ref TAG_DISCOVER_DPAS_OUTCOME_PARAMETER_SET
//!	- \ref TAG_DISCOVER_DPAS_USER_INTERFACE_REQUEST_DATA
//!	- \ref TAG_DISCOVER_DPAS_DATA_RECORD
//!	- \ref TAG_DISCOVER_DPAS_DISCRETIONARY_DATA

void CLESS_DiscoverDPAS_DumpSpecificStructure (T_SHARED_DATA_STRUCT * pExchangeStruct, unsigned long ulTag, int bRequestToKernelIfNotPresent)
{
	unsigned long ulReadLength;
	unsigned char * pReadValue;
	T_SHARED_DATA_STRUCT * pRequestData = NULL;
	int nPosition;
	int bTagFound = FALSE;

	if (gs_pTransactionDataLog == NULL)
		gs_pTransactionDataLog = GTL_SharedExchange_InitLocal (10240);

	if (gs_pTransactionDataLog != NULL)
	{
		if (ulTag == TAG_DISCOVER_DPAS_DATA_RECORD)
		{
			// Check if the tag is present in pExchangeStruct
			nPosition = SHARED_EXCHANGE_POSITION_NULL;

			if (GTL_SharedExchange_FindNext (pExchangeStruct, &nPosition, ulTag, &ulReadLength, (const unsigned char **)&pReadValue) != STATUS_SHARED_EXCHANGE_OK)
			{
				if (bRequestToKernelIfNotPresent)
				{
					// Allocate the sharde buffer
					pRequestData = GTL_SharedExchange_InitShared (1024);

					if (pRequestData != NULL)
					{
						// Tag not found, request it to the kernel
						if (__ClessSample_DiscoverDPAS_RequestDataToKernel (pRequestData, ulTag))
						{
							// Check if the tag is present in pExchangeStruct
							nPosition = SHARED_EXCHANGE_POSITION_NULL;

							if (GTL_SharedExchange_FindNext (pRequestData, &nPosition, ulTag, &ulReadLength, (const unsigned char **)&pReadValue) == STATUS_SHARED_EXCHANGE_OK)
							{
								bTagFound = TRUE;
							}
						}
					}
				}
			}
			else
			{
				bTagFound = TRUE;
			}

			if (bTagFound)
			{
				GTL_SharedExchange_AddTag (gs_pTransactionDataLog, ulTag, ulReadLength, pReadValue);
			}
		}
	}

	// Destroy allocated structure (if allocated)
	if (pRequestData != NULL)
		GTL_SharedExchange_DestroyShare (pRequestData);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Get the CVM to apply (read from the Outcome Parameter Set).                      *
 * 			                                                                                  *
 * [in] :    pResultDataStruct Structure containing the C2 kernel output.                     *
 * [out]:    pCvm Retrieved transaction outcome :                                             *
 *             DISCOVER_DPAS_CVM_NO_CVM No CVM to be performed.                               *
 *             DISCOVER_DPAS_CVM_SIGNATURE if signature shall be performed.                   *
 *             DISCOVER_DPAS_CVM_ONLINE_PIN if online PIN shall be performed.                 *
 *             DISCOVER_DPAS_CVM_CONFIRMATION_CODE_VERIFIED - confirmation code has verified. *
 *             DISCOVER_DPAS_CVM_NA if CVM is not applicable to the case.                     *
 * [return]: TRUE if correctly retrieved.                                                     *
 *           FALSE if an error occurred.                                                      *
 * ------------------------------------------------------------------------------------------ */
static int CLESS_DiscoverDPAS_RetreiveCvmToApply (T_SHARED_DATA_STRUCT * pResultDataStruct, unsigned char * pCvm) {
	int nResult = TRUE;
	int nPosition, cr;
	unsigned long ulReadLength;
	const unsigned char * pReadValue;

	if (pCvm != NULL)
		*pCvm = DISCOVER_DPAS_CVM_NA;

	nPosition = SHARED_EXCHANGE_POSITION_NULL;
	if(GTL_SharedExchange_FindNext(pResultDataStruct, &nPosition, TAG_DISCOVER_DPAS_TRANSACTION_CVM, &ulReadLength, &pReadValue) != STATUS_SHARED_EXCHANGE_OK) {
		nResult = FALSE;
		goto End;
	}
	// Get the CVM to apply
	if (pCvm != NULL)
		*pCvm = *pReadValue;

End:
	return (nResult);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Get the card type.                                                               *
 * 			                                                                                  *
 * [in] :    pResultDataStruct Structure containing the C2 kernel output.                     *
 * [out]:    pCardType Retreived card type :                                                  *
 *             0 If card type not found.                                                      *
 *             0x8501 for MStripe card.                                                       *
 *             0x8502 for DPAS card.                                                          *
 * [return]: TRUE if correctly retrieved.                                                     *
 *           FALSE if an error occurred.                                                      *
 * ------------------------------------------------------------------------------------------ */
static int CLESS_DiscoverDPAS_RetreiveCardType (T_SHARED_DATA_STRUCT * pResultDataStruct, unsigned short * pCardType) {
	int nResult = TRUE;
	int nPosition, cr;
	unsigned long ulReadLength;
	const unsigned char * pReadValue;

	if (pCardType != NULL)
		*pCardType = 0; // Default result

	nPosition = SHARED_EXCHANGE_POSITION_NULL;
	if(GTL_SharedExchange_FindNext(pResultDataStruct, &nPosition, TAG_KERNEL_CARD_TYPE, &ulReadLength, &pReadValue) != STATUS_SHARED_EXCHANGE_OK) {
		nResult = FALSE;
		goto End;
	}
	// Get the transaction outcome
	if (pCardType != NULL)
		*pCardType = (pReadValue[0] << 8) + pReadValue[1];

End:
	return (nResult);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Fill buffer with specific Discover for transaction.                              *
 * 			                                                                                  *
 * [out] :   pDataStruct Shared exchange structure filled with the specific Discover data.    *
 * [return]: TRUE if correctly performed.                                                     *
 *           FALSE if an error occurred.                                                      *
 * ------------------------------------------------------------------------------------------ */
static int CLESS_DiscoverDPAS_AddDiscoverSpecificData (T_SHARED_DATA_STRUCT * pDataStruct) {
	int cr, nResult;
	object_info_t ObjectInfo;
	T_KERNEL_TRANSACTION_FLOW_CUSTOM sTransactionFlowCustom;
	unsigned char StepInterruption[KERNEL_PAYMENT_FLOW_STOP_LENGTH];// Bit field to stop payment flow,
																	// if all bit set to 0 => no stop during payment process
									                                // if right bit set to 1 : stop after payment step number 1
	unsigned char StepCustom[KERNEL_PAYMENT_FLOW_CUSTOM_LENGTH]; 	// Bit field to custom payment flow,
																	// if all bit set to 0 => no stop during payment process
									                                // if right bit set to 1 : stop after payment step number 1

	// Check the input data are correctly provided
	if (pDataStruct == NULL) {
		nResult = FALSE;
		goto End;
	}
	// Init parameteters
	memset(StepInterruption, 0, sizeof(StepInterruption)); 			// Default Value : not stop on process
	memset(StepCustom, 0, sizeof(StepCustom)); 						// Default Value : not stop on process
	ObjectGetInfo(OBJECT_TYPE_APPLI, ApplicationGetCurrent(), &ObjectInfo);
	nResult = TRUE;

	// Add a tag indicating where the transaction has to be stopped (default value, i.e. all bytes set to 0, is strongly recommanded)
	if(GTL_SharedExchange_AddTag(pDataStruct, TAG_KERNEL_PAYMENT_FLOW_STOP, KERNEL_PAYMENT_FLOW_STOP_LENGTH, (const unsigned char *)StepInterruption) != STATUS_SHARED_EXCHANGE_OK) {
		nResult = FALSE;
		goto End;
	}
	// Customize steps
	ADD_STEP_CUSTOM(STEP_DISCOVER_DPAS_MSTRIPE_REMOVE_CARD,StepCustom); 				// To do GUI when MStripe card has been read
	ADD_STEP_CUSTOM(STEP_DISCOVER_DPAS_REMOVE_CARD,StepCustom); 						// To do GUI when DPAS card has been read
	ADD_STEP_CUSTOM(STEP_DISCOVER_DPAS_ISSUER_SCRIPT_REMOVE_CARD,StepCustom); 			// To do GUI when Issuer Scripts have been performed.
	ADD_STEP_CUSTOM(STEP_DISCOVER_DPAS_GET_CERTIFICATE, StepCustom); 					// To provide the CA key data for ODA

	//if (ClessSample_IsBlackListPresent())
		//ADD_STEP_CUSTOM(STEP_DISCOVER_DPAS_EXCEPTION_FILE_GET_DATA, StepCustom); // To check if PAN is in the blacklist

	memcpy ((void*)&sTransactionFlowCustom, (void*)StepCustom, KERNEL_PAYMENT_FLOW_CUSTOM_LENGTH);
	sTransactionFlowCustom.usApplicationType = ObjectInfo.application_type; 			// Kernel will call this application for customisation
	sTransactionFlowCustom.usServiceId = SERVICE_CUSTOM_KERNEL; 						// Kernel will call SERVICE_CUSTOM_KERNEL service id for customisation

	if(GTL_SharedExchange_AddTag(pDataStruct, TAG_KERNEL_PAYMENT_FLOW_CUSTOM, sizeof(T_KERNEL_TRANSACTION_FLOW_CUSTOM), (const unsigned char *)&sTransactionFlowCustom) != STATUS_SHARED_EXCHANGE_OK) {
		nResult = FALSE;
		goto End;
	}
End:
	return (nResult);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Perform the Online PIN input and encipher PIN.                                   *
 * 			                                                                                  *
 * [out] :   pStructureForOnlineData Data returned by the kernel in which the enciphered      *
 *           online PIN would be added.                                                       *
 * [return]: TRUE if correctly performed.                                                     *
 *           FALSE if an error occurred.                                                      *
 * ------------------------------------------------------------------------------------------ */
static T_Bool CLESS_DiscoverDPAS_OnlinePinManagement (T_SHARED_DATA_STRUCT * pStructureForOnlineData, int nCardHolderLang) {
	//T_SHARED_DATA_STRUCT * pDataRequest;
	T_Bool nResult = B_TRUE;
	int nPosition, cr;
	const unsigned char * pPan;
	unsigned long ulPanLength;
	const unsigned char * pTrack2Data;
	unsigned long ulTrack2DataLength;
	BUFFER_SAISIE buffer_saisie;
	unsigned long ulReadDataRecordLength;
	unsigned char * pReadDataRecordValue;
	T_SHARED_DATA_STRUCT tDataRecord;

	// Get the DATA RECORD and copy all the data in the structure to be sent to the HOST
	nPosition = SHARED_EXCHANGE_POSITION_NULL;
	if(GTL_SharedExchange_FindNext (pStructureForOnlineData, &nPosition, TAG_DISCOVER_DPAS_DATA_RECORD, &ulReadDataRecordLength, (const unsigned char **)&pReadDataRecordValue) == STATUS_SHARED_EXCHANGE_OK) {
		if (GTL_SharedExchange_InitEx (&tDataRecord, ulReadDataRecordLength, ulReadDataRecordLength, pReadDataRecordValue) != STATUS_SHARED_EXCHANGE_OK) {
			nResult = B_FALSE;
			goto End;
		}
	}
	// Tags have been got (if present), get the PAN
	nPosition = SHARED_EXCHANGE_POSITION_NULL;
	if (GTL_SharedExchange_FindNext (&tDataRecord, &nPosition, TAG_EMV_APPLI_PAN, &ulPanLength, &pPan) != STATUS_SHARED_EXCHANGE_OK) {
		nPosition = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext (&tDataRecord, &nPosition, TAG_EMV_TRACK_2_EQU_DATA, &ulTrack2DataLength, &pTrack2Data) != STATUS_SHARED_EXCHANGE_OK) {
			nResult = B_FALSE;
			goto End;
		}
		else {
			// Continue with the PAN extracted from the track2 data
			pPan = pTrack2Data;
		}
	}

	// Warning, erase display must be made only if Pin input will be made on customer screen
	/*if (ClessSample_IsPinpadPresent())
	{
		// Display dummy message to erase display
		tMsg.message = aucDymmyMsg;
		tMsg.coding = _ISO8859_;
		tMsg.file = GetCurrentFont();

	}*/

	//cr = ClessSample_PinManagement_OnLinePinManagement ((unsigned char*)pPan, 1, 0, 30000, 10000, nCardHolderLang, &buffer_saisie);

	if (cr == INPUT_PIN_ON) {
		if(GTL_SharedExchange_AddTag(pStructureForOnlineData, TAG_SAMPLE_ENCIPHERED_PIN_CODE, buffer_saisie.nombre , (const unsigned char *)buffer_saisie.donnees) != STATUS_SHARED_EXCHANGE_OK) {
			nResult = B_FALSE;
			goto End;
		}
	}
	else if (cr == CANCEL_INPUT) {
		nResult = B_NON_INIT;
		goto End;
	}

End:
	return (nResult);
}



//! \brief Manage the debug mode for Discover kernel
//! \param[in] bActivate \a TRUE to activate the debug features. \a FALSE to deactivate features.

void CLESS_DiscoverDPAS_DebugActivation (int bActivate)
{
	T_SHARED_DATA_STRUCT * pSharedStructure;
	int nResult;
	unsigned char ucDebugMode = 0x00;

	if (bActivate)
		ucDebugMode = 0x01;

	// Init the shared buffer
	pSharedStructure = GTL_SharedExchange_InitShared(256);

	// Check the structure correctly created
	if (pSharedStructure != NULL)
	{
		// Add the debug information into the structure
		nResult = GTL_SharedExchange_AddTag(pSharedStructure, TAG_KERNEL_DEBUG_ACTIVATION, 1, &ucDebugMode);

		// Check if data correctly added
		if (nResult != STATUS_SHARED_EXCHANGE_OK)
		{
			// An error occurred when adding the tag in the structure
			GTL_Traces_TraceDebug("ClessSample_DiscoverDPAS_DebugActivation : Unable to add TAG_KERNEL_DEBUG_ACTIVATION (nResult = %02x)", nResult);
		}
		else
		{
			// Data correctly added, call the kernel to activate the debug feature
			nResult = DiscoverDPAS_DebugManagement(pSharedStructure);

			// Check if debug activation correctly performed
			if (nResult != KERNEL_STATUS_OK)
			{
				// An error occurred when enabling the debug feature in the kernel
				GTL_Traces_TraceDebug("ClessSample_DiscoverDPAS_DebugActivation : Error occured during Discover Debug activation (nResult = %02x)", nResult);
			}
		}

		// Destroy the shared buffer
		GTL_SharedExchange_DestroyShare(pSharedStructure);
	}
}

//! \brief Perform the C2 kernel customisation.
//! \param[in,out] pSharedData Shared buffer used for customisation.
//! \param[in] ucCustomisationStep Step to be customised.
//! \return
//!		- \a KERNEL_STATUS_CONTINUE always.

int CLESS_DiscoverDPAS_CustomiseStep (T_SHARED_DATA_STRUCT * pSharedData, const unsigned char ucCustomisationStep)
{
	int nResult = KERNEL_STATUS_CONTINUE;
	unsigned char ucCapkIndex;
	unsigned char ucRid[5];
	unsigned long ulReadLength;
	unsigned char Modulus [255] = {0};
	   unsigned int ModulusLength = 0;
	   unsigned char Exponent [3] = {0};
	   unsigned int ExponentLength = 0;
	   unsigned short found;
	int nPosition;
	const unsigned char * pReadValue;
	const unsigned char * pPan;
	unsigned long ulPanLength;
	const unsigned char * pPanSeqNumber;
	//unsigned char ucVoidPanSeqNumber = C_CLESS_VOID_PAN_SEQ_NUMBER; // Unused value for PanSeqNumber
	unsigned long ulPanSeqNbLength;
	unsigned char bPanInExceptionFile = FALSE;


    switch (ucCustomisationStep) // Steps to customise
    {
    case (STEP_DISCOVER_DPAS_MSTRIPE_REMOVE_CARD):
   	case (STEP_DISCOVER_DPAS_REMOVE_CARD):
   	case (STEP_DISCOVER_DPAS_ISSUER_SCRIPT_REMOVE_CARD):
		//HelperRemoveCardSequence(pSharedData);
	CLESS_GUI_DisplayScreen (APCLESS_SCREEN_REMOVE_CARD);
		GTL_SharedExchange_ClearEx (pSharedData, FALSE);
		nResult = KERNEL_STATUS_CONTINUE;
		break;


	case (STEP_DISCOVER_DPAS_GET_CERTIFICATE):
		//perflog("MG\tpW_CUST\tSTEP_DISCOVER_DPAS_GET_CERTIFICATE");
		// Init RID value
		memset (ucRid, 0, sizeof(ucRid));

		// Get the CA public key index (card)
		nPosition = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext (pSharedData, &nPosition, TAG_EMV_CA_PUBLIC_KEY_INDEX_CARD, &ulReadLength, (const unsigned char **)&pReadValue) == STATUS_SHARED_EXCHANGE_OK)
			ucCapkIndex = pReadValue[0];
		else
			ucCapkIndex = 0;

		// Get the DF Name returned by the card
		nPosition = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext (pSharedData, &nPosition, TAG_DISCOVER_DPAS_INT_RID, &ulReadLength, (const unsigned char **)&pReadValue) == STATUS_SHARED_EXCHANGE_OK)
			memcpy (ucRid, pReadValue, 5);

		// Clear the output structure
		GTL_SharedExchange_ClearEx (pSharedData, FALSE);
	       if (strlen(ucRid) && ucCapkIndex != 0) {
	             found = getCertificationAuthorityPublicKey (ucRid,
	            		 	 	 	 	 	 	 	 	 	 ucCapkIndex,
	     													Modulus,
	     													&ModulusLength,
	     													Exponent,
	     													&ExponentLength);
	             if (found) {
	            	 if (GTL_SharedExchange_AddTag(pSharedData, TAG_EMV_INT_CAPK_MODULUS, ModulusLength, Modulus) != STATUS_SHARED_EXCHANGE_OK) {
	            		 GTL_SharedExchange_ClearEx(pSharedData, FALSE);
	            		 return FALSE;
	            	 }
	            	 if (GTL_SharedExchange_AddTag(pSharedData, TAG_EMV_INT_CAPK_EXPONENT, ExponentLength, Exponent) != STATUS_SHARED_EXCHANGE_OK) {
	            		 GTL_SharedExchange_ClearEx(pSharedData, FALSE);
	            		 return FALSE;
	            	 }
	             }
	         }
		// Get the CA public key data (Modulus, exponent, etc) in the parameters
		/*if (!ClessSample_Parameters_GetCaKeyData (pTreeCurrentParam, ucCapkIndex, ucRid, pSharedData))
		{
			// An error occurred when retreiving the CA Public Key data in the parameters
			GTL_Traces_TraceDebug ("ClessSample_DiscoverDPAS_CustomiseStep : ClessSample_Parameters_GetCaKeyData failed");
		}*/

		nResult = KERNEL_STATUS_CONTINUE;
		break;


	case (STEP_DISCOVER_DPAS_EXCEPTION_FILE_GET_DATA):
		//perflog("MG\tpW_CUST\tSTEP_DISCOVER_DPAS_EXCEPTION_FILE_GET_DATA");
		// Get the PAN
		nPosition = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext (pSharedData, &nPosition, TAG_EMV_APPLI_PAN, &ulPanLength, &pPan) != STATUS_SHARED_EXCHANGE_OK) {
			// Pan parameters is missing, we cannot check BlackList
			GTL_Traces_TraceDebug ("ClessSample_DiscoverDPAS_CustomiseStep : PAN is missing for excpetion file checking");
			break;
		}

		// Get the PAN Sequence Number
		nPosition = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext (pSharedData, &nPosition, TAG_EMV_APPLI_PAN_SEQUENCE_NUMBER, &ulPanSeqNbLength, &pPanSeqNumber) != STATUS_SHARED_EXCHANGE_OK) {
			// Pan Sequence Number is missing, we will check BlackList without PanSeqNumber
			//pPanSeqNumber = &ucVoidPanSeqNumber;
		}

		// Check if PAN is in the exception file
		//bPanInExceptionFile = ClessSample_BlackListIsPan((int)ulPanLength, pPan, (int)(pPanSeqNumber[0]));

		GTL_SharedExchange_ClearEx (pSharedData, FALSE);

		if (bPanInExceptionFile)
		{
			// Add TAG_KERNEL_PAN_IN_BLACK_LIST tag in the exchange buffer to indicate Discover kernel the PAN is in the black list
			if (GTL_SharedExchange_AddTag (pSharedData, TAG_KERNEL_PAN_IN_BLACK_LIST, 1, &bPanInExceptionFile) != STATUS_SHARED_EXCHANGE_OK)
			{
				GTL_SharedExchange_ClearEx (pSharedData, FALSE);
				GTL_Traces_TraceDebug ("ClessSample_DiscoverDPAS_CustomiseStep : Unable to add TAG_KERNEL_PAN_IN_BLACK_LIST in the shared buffer");
			}
		}

		nResult = KERNEL_STATUS_CONTINUE;
		break;

	default:
		GTL_Traces_TraceDebug ("ClessSample_Discover_CustomiseStep : Step to customise (unknown) = %02x\n", ucCustomisationStep);
		break;
	}

	return (nResult);
}

/*
//! \brief Format a string with the transaction amount.
//! \param[in] ucFormat : the display format
//! \param[in] ucCurrency : transaction currency
//! \param[in] ucPosition : the position of the currency
//! \param[in] ulAmount : the transaction amount
//! \param[out] pFormattedAmountMessage : the formatted message to display

static void __ClessSample_DiscoverDPAS_FormatAmount (unsigned char ucFormat, unsigned char *ucCurrencyLabel, unsigned char ucPosition, const unsigned char * pAmount, unsigned int nAmountLength, unsigned char *pFormattedAmountMessage)
{
    unsigned char str[64];
    unsigned char * ptr;
    int index;
    int nLgStr;

	(void)ucFormat;
	(void)ucPosition;

	if (pFormattedAmountMessage == NULL)
		return;

	if ((pAmount == NULL) || (nAmountLength == 0))
	{
		*pFormattedAmountMessage = 0; // String end...
		return;
	}

    ptr = str;
    GTL_Convert_DcbNumberToAscii((const unsigned char*)pAmount, (char *)ptr, nAmountLength, nAmountLength*2);

    index = 0;
    while ((ptr[index] == '0') && (index < 10))
    	index++;
    ptr+=index;

    nLgStr = strlen((const char *)ptr);
    strcpy ((char *)pFormattedAmountMessage, (const char *)ucCurrencyLabel);
    if (nLgStr > 2)
    {
	    strcat ((char*)pFormattedAmountMessage, " ");
	    strncat ((char*)pFormattedAmountMessage, (char *)ptr, nLgStr - 2);
	    pFormattedAmountMessage[strlen((char *)ucCurrencyLabel) + nLgStr-1] = 0;
	    strcat ((char*)pFormattedAmountMessage, ",");
	    strncat ((char*)pFormattedAmountMessage, (char *)&ptr[nLgStr-2], 2);
	}
	else
	{
	    strcat ((char*)pFormattedAmountMessage, " 0,");
	    strcat ((char*)pFormattedAmountMessage, (char *)ptr);
    }
}

//! \brief Display Balance amount (if available from UIRD).
//! \param[in] pResultDataStruct Structure containing the C2 kernel output.
//! \return
//!		- \ref TRUE if no problem occured.
//!		- \ref FALSE if an error occured.

static int __ClessSample_DiscoverDPAS_DisplayBalanceAmount(T_SHARED_DATA_STRUCT * pResultDataStruct)
{
	int nResult = TRUE;
	int nPosition, cr;
	unsigned long ulReadLength;
	const unsigned char * pReadValue;
	static unsigned char ucBalanceAmountMessage[64];
	unsigned char ucCurrencyLabel[4];
	unsigned char ucFormat, ucPosition;
	unsigned char * pCurrencyCode = NULL;
	unsigned char * pCurrencyLabel = NULL;
	MSGinfos tDisplayMsgL1, tDisplayMsgL2;

	// Init position
	nPosition = SHARED_EXCHANGE_POSITION_NULL;

	// Get the Outcome Parameter Set
	cr = GTL_SharedExchange_FindNext(pResultDataStruct, &nPosition, TAG_DISCOVER_DPAS_USER_INTERFACE_REQUEST_DATA, &ulReadLength, &pReadValue);

	if (cr != STATUS_SHARED_EXCHANGE_OK)
	{
		GTL_Traces_TraceDebug("__ClessSample_DiscoverDPAS_DisplayBalanceAmount : Unable to get the UIRD from the C2 kernel response (cr = %02x)", cr);
		nResult = FALSE;
		goto End;
	}

	// Get the Balance value and format the message  to display
	if(pReadValue[DISCOVER_DPAS_UIRD_VALUE_QUALIFIER_BYTE] == DISCOVER_DPAS_UIRD_VALUE_QUALIFIER_BALANCE)
	{
		pCurrencyCode = (unsigned char *) (&pReadValue[DISCOVER_DPAS_UIRD_CURRENCY_CODE_OFFSET]);

		// Get the currency label and exponent from the parameters. If not found, indicate an invalid parameter as the currency code provided is unknown from the application.
// TODO

//		if(!ClessSample_Parameters_GetCurrencyFromParameters(pCurrencyCode, &pCurrencyLabel, &pCurrencyExponent))
//		{
//			GTL_Traces_TraceDebug ("__ClessSample_DiscoverDPAS_DisplayBalanceAmount, Currency code provided is unknown from the application (%02x %02x)", pCurrencyCode[0], pCurrencyCode[1]);
//			nResult = FALSE;
//			goto End;
//		}
//
//		// Retrieve the format of the money (currency position, separator, ...)
//		ClessSample_Parameters_GetCurrencyFormatFromParameters(pCurrencyLabel,&ucFormat,&ucPosition);

		memset(ucCurrencyLabel,0,sizeof(ucCurrencyLabel));
		memcpy(ucCurrencyLabel, pCurrencyLabel, 3);

		// Create a message that contains the balance amount, the currency ...
		memset (ucBalanceAmountMessage, 0, sizeof(ucBalanceAmountMessage));
		__ClessSample_DiscoverDPAS_FormatAmount (ucFormat, ucCurrencyLabel, ucPosition, &(pReadValue[DISCOVER_DPAS_UIRD_VALUE_OFFSET]), DISCOVER_DPAS_UIRD_VALUE_LENGTH, ucBalanceAmountMessage);

		GetMessageInfos(STD_MESS_AVAILABLE, &tDisplayMsgL1);

		tDisplayMsgL2.coding  = tDisplayMsgL1.coding;
		tDisplayMsgL2.file    = tDisplayMsgL1.file;
		tDisplayMsgL2.message = (char *) ucBalanceAmountMessage;

		// Display messages
		Helper_DisplayTextCustomer(NO_ERASE, HELPERS_CUSTOMER_LINE_2, &tDisplayMsgL1, CLESSSAMPLE_ALIGN_CENTER, NOLEDSOFF);
		Helper_DisplayTextCustomer(NO_ERASE, HELPERS_CUSTOMER_LINE_3, &tDisplayMsgL2, CLESSSAMPLE_ALIGN_CENTER, NOLEDSOFF);
}

End:
	return (nResult);
}

*/
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Prepare the data to be sent in the online authorization message.                 *
 * 			                                                                                  *
 * [in] :    pTransactionData Kernel transaction data (including the Data Record as well as   *
 *           the Discretionary Data. It could also contain the Ciphered Online PIN.           *
 * [out]:    pOnlineAuthorisationData Filled with the data to be sent in the online           *
 *           authorisation message.                                                           *
 * [return]: TRUE if correctly performed.                                                     *
 *           FALSE if an error occurred.                                                      *
 * ------------------------------------------------------------------------------------------ */
static int CLESS_DiscoverDPAS_FillBufferForOnlineAuthorisation (T_SHARED_DATA_STRUCT * pTransactionData, T_SHARED_DATA_STRUCT * pOnlineAuthorisationData) {
	int nPosition;
	unsigned long ulReadLength;
	unsigned char * pReadValue;
	T_SHARED_DATA_STRUCT tTempStruct;
	int bErrorDetected = FALSE;

	// Check input data consistence
	if ((pTransactionData != NULL) && (pOnlineAuthorisationData != NULL)) {
		nPosition = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext (pTransactionData, &nPosition, TAG_DISCOVER_DPAS_DATA_RECORD, &ulReadLength, (const unsigned char **)&pReadValue) == STATUS_SHARED_EXCHANGE_OK) {
			if (GTL_SharedExchange_InitEx (&tTempStruct, ulReadLength, ulReadLength, pReadValue) == STATUS_SHARED_EXCHANGE_OK) { // Copy data record data in the local buffer
				if (GTL_SharedExchange_AddSharedBufferContent (pOnlineAuthorisationData, &tTempStruct) != STATUS_SHARED_EXCHANGE_OK) {
					bErrorDetected = TRUE;
				}
			}
			else {
				bErrorDetected = TRUE;
			}
		}
		else {
			bErrorDetected = TRUE;
		}
		// Get the ciphered PIN if present
		if (!bErrorDetected) {
			// Get the Discretionary Data
			nPosition = SHARED_EXCHANGE_POSITION_NULL;
			if (GTL_SharedExchange_FindNext (pTransactionData, &nPosition, TAG_SAMPLE_ENCIPHERED_PIN_CODE, &ulReadLength, (const unsigned char **)&pReadValue) == STATUS_SHARED_EXCHANGE_OK) {
				if (GTL_SharedExchange_AddTag (pOnlineAuthorisationData, TAG_SAMPLE_ENCIPHERED_PIN_CODE, ulReadLength, pReadValue) != STATUS_SHARED_EXCHANGE_OK) {
					bErrorDetected = TRUE;
				}
			}
		}
	}
	else {
		bErrorDetected = TRUE;
	}
	return (!bErrorDetected);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Wait Cless Card.                                                                 *
 * 			                                                                                  *
 * [in,out]: pSharedData Shared buffer used for customization.                                *
 * [return]: TRUE if appropriate card has been inputed on field.                              *
 *           FALSE else.                                                                      *
 * ------------------------------------------------------------------------------------------ */
static int CLESS_DiscoverDPAS_WaitClessCard(void) {
	unsigned int bIsOpened, nTimeout, nEvent;
	unsigned int nKey, nNumOfCards;
	int nCpt;
	int nAppropriateCardFound;
	int nResult = KERNEL_STATUS_OK; // Default result

	// Local variables initialization
	nCpt = 0;							// Time counter initialisation (step = 1s)
	nAppropriateCardFound = FALSE;		// Default result : card hasn't been found

	// Cless Field Close allows to restart it later ...
	// ClessEmv_CloseDriver();

	// Card Power-On
	bIsOpened = CL_OK;//ClessEmv_OpenDriver ();  Open contactless field

	if (bIsOpened == CL_OK) {
		do{ // Infinite loop to wait a Contacless Card detection
			// Synchrone Detection (bloquante)
				nTimeout = 1; // 1s
				nNumOfCards = 1;
				nResult = ClessEmv_DetectCards(CL_TYPE_AB, &nNumOfCards, nTimeout);

				if (nResult != CL_OK) {
					nTimeout = 100;  // 1s
					nEvent = Telium_Ttestall (KEYBOARD, nTimeout);
					if (nEvent == KEYBOARD) {
						nKey = Telium_Getchar();
						if (nKey == T_ANN) // If Detection canceled
							nCpt = C_CPT_TIME_20S; // End loop
					}
				}
				nCpt ++;
		} while ((nResult != CL_OK) && (nCpt < C_CPT_TIME_20S)); // For 20s max

		if (nResult == CL_OK) {		// End if no card detected
			if (ClessEmv_ActiveCard(0, CL_ISO14443_4) == CL_OK) {
				nAppropriateCardFound = TRUE;
			}
		}
	}
	return(nAppropriateCardFound);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Stop Cless field.                                                                *
 * 			                                                                                  *
 * [return]: TRUE if appropriate card has been inputed on field.                              *
 *           FALSE else.                                                                      *
 * ------------------------------------------------------------------------------------------ */
static int CLESS_DiscoverDPAS_StopClessCard(void) {
	int nFctResult;
	nFctResult = ClessEmv_DeselectCard(0, TRUE, FALSE);
	if (nFctResult != CL_OK) {
		return FALSE;
	}
	return TRUE;
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Calls the Discover DPAS kernel to perform the transaction.                       *
 * 			                                                                                  *
 * [in] :    pDataStruct Data buffer to be filled and used for Discover DPAS transaction.     *
 * [return]: Discover kernel result.                                                          *
 * ------------------------------------------------------------------------------------------ */
int CLESS_DiscoverDPAS_PerformTransaction (T_SHARED_DATA_STRUCT * pDataStruct) {
	unsigned char bLoopMode;
	int nResult = CLESS_CR_MANAGER_END;
	int nPosition, nTransactionOutcome;
	int bReceiptRequired = TRUE;
	unsigned long ulReadLength;
	const unsigned char * pReadValue;
	unsigned char ucCvm;
	unsigned char auCustomerDisplayAvailable;
	unsigned char bSaveInBatch = FALSE;
	unsigned short usCardType = 0;
	int merchLang, nCardHolderLang;
	T_Bool bContinueWithOnlineAuthorisation = B_TRUE;
	MSGinfos tMsg;
	T_SHARED_DATA_STRUCT * pOnlineAuthorisationData;
	T_Bool bOnlineUnable = B_FALSE;
	char qUICS_Credit[16] = "A000000333010102";
	char qUICS_Debit[16]  = "A000000333010103";
	CLESS_Txn_SetCurrentPaymentScheme (APCLESS_SCHEME_DISCOVER_DPAS);

    if (CLESS_DiscoverDPAS_AddDiscoverSpecificData(pDataStruct)) {
    	nPosition = SHARED_EXCHANGE_POSITION_NULL;
    	if (GTL_SharedExchange_FindNext(pDataStruct, &nPosition, TAG_EMV_AID_TERMINAL, &ulReadLength, &pReadValue) == STATUS_SHARED_EXCHANGE_OK) {
    		char tempAID[16]={0};
    		memcpy (tempAID, hexToASCII (pReadValue, ulReadLength), ulReadLength*2);
    		//for China Union Pay byPass the exact transaction outcome
    		if(!memcmp(qUICS_Debit,  tempAID, ulReadLength*2) ||
    		   !memcmp(qUICS_Credit, tempAID, ulReadLength*2)){
    			nTransactionOutcome = DiscoverDPAS_DoTransaction(pDataStruct);
    			nTransactionOutcome = 276;
    		}
    		else
    		    nTransactionOutcome = DiscoverDPAS_DoTransaction(pDataStruct);
    	}
		// Get the transaction outcome
		//	- DISCOVER_DPAS_OPS_STATUS_APPROVED if transaction is approved.
		//	- DISCOVER_DPAS_OPS_STATUS_ONLINE_REQUEST if an online authorisation is requested.
		//	- DISCOVER_DPAS_OPS_STATUS_DECLINED if the transaction is declined.
		//	- DISCOVER_DPAS_OPS_STATUS_SELECT_NEXT if next AID shall be selected.
		//	- DISCOVER_DPAS_OPS_STATUS_TRY_AGAIN transaction shall be restarted from the begining..
		//	- DISCOVER_DPAS_OPS_STATUS_END_APPLICATION if the transaction is terminated.

		// Get prefered card language (a request shall be done to the Discover DPAS kernel as the TAG_KERNEL_SELECTED_PREFERED_LANGUAGE tag is not returned by the DPAS kernel).
		nCardHolderLang=0x00;		// default to English
		CLESS_DiscoverDPAS_GetSelectedPreferedLanguage (&nCardHolderLang, merchLang);

		// Get the TAG_DISCOVER_DPAS_OUTCOME_PARAMETER_SET to identify the CVM to be performed
		// 	- DISCOVER_DPAS_CVM_NO_CVM : "No CVM" method has been applied.
		// 	- DISCOVER_DPAS_CVM_SIGNATURE : "Signature" method has been applied.
		// 	- DISCOVER_DPAS_CVM_ONLINE_PIN : "Online PIN" method has been applied.
		//	- DISCOVER_DPAS_CVM_CONFIRMATION_CODE_VERIFIED : confirmation code has been verified.
		//	- DISCOVER_DPAS_CVM_NA : if CVM is not applicable.
		if (!CLESS_DiscoverDPAS_RetreiveCvmToApply (pDataStruct, &ucCvm))
			ucCvm = DISCOVER_DPAS_CVM_NA;

		// Get Card holder Verification Method
		if(ucCvm == DISCOVER_DPAS_CVM_ONLINE_PIN)
			setCHVerificationMethod(ONLINE_PIN);
		else if(ucCvm == DISCOVER_DPAS_CVM_SIGNATURE)
			setCHVerificationMethod(PAPER_SIGNATURE);
		else
			setCHVerificationMethod(NO_AUTHENTICATION);

		// Retrieve the card type
		if (!CLESS_DiscoverDPAS_RetreiveCardType (pDataStruct, &usCardType))
			usCardType = 0;

		// Additional possible processing :
		//	- Perform an online authorisation if necessary
		//	- Save the transaction in the batch if transaction is accepted
		//	- Perform CVM processing if necessary
		if ((ucCvm == DISCOVER_DPAS_CVM_ONLINE_PIN) && (nTransactionOutcome == KERNEL_STATUS_OFFLINE_APPROVED))
			nTransactionOutcome = KERNEL_STATUS_ONLINE_AUTHORISATION;

		switch (nTransactionOutcome) {
			case KERNEL_STATUS_OFFLINE_APPROVED:
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_OFFLINE_APPROVED);
				bSaveInBatch = TRUE;
				DiscoverDPAS_GetAllData(pDataStruct); // Get all the kernel data to print the receipt
				break;

			case KERNEL_STATUS_OFFLINE_DECLINED:
				CLESS_GUI_DisplayScreen (KERNEL_STATUS_OFFLINE_DECLINED);
				break;

			case KERNEL_STATUS_ONLINE_AUTHORISATION:
				DiscoverDPAS_GetAllData(pDataStruct);
				DiscoverDPAS_OnlineRequestData(pDataStruct, usCardType);
				//if PIN online is required and managed it.
			 	if (getCHVerificationMethod() == ONLINE_PIN ){
					int pinLength;
					switch (APEMV_UI_PinEntry (INPUT_PIN_ON, 3, &pinLength)) {
						case EPSTOOL_PINENTRY_SUCCESS:
							if (encryptPIN() == FALSE)
								setErrorCode("ERROR:033");
							break;
						case EPSTOOL_PINENTRY_TIMEOUT:
							setErrorCode("ERROR:013");
							break;
						case EPSTOOL_PINENTRY_ERROR:
						case EPSTOOL_PINENTRY_CANCEL:
							setErrorCode("ERROR:044");
							break;
						case EPSTOOL_PINENTRY_EVENT:
						case EPSTOOL_PINENTRY_BYPASS:
						default:
							break;
						}
				}
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ONLINE_PROCESSING);
				break;

			case KERNEL_STATUS_COMMUNICATION_ERROR:
				nResult = CLESS_CR_MANAGER_RESTART_NO_MESSAGE_BEFORE_RETRY;
				break;

			case KERNEL_STATUS_REMOVE_AID:
				nResult = CLESS_CR_MANAGER_REMOVE_AID;
				break;

			case KERNEL_STATUS_USE_CONTACT_INTERFACE:
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_USE_CONTACT);
				nResult = CLESS_CR_MANAGER_RESTART_WO_CLESS;
				break;

			case DISCOVER_DPAS_STATUS_USE_ANOTHER_CARD:
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_TRY_ANOTHER_CARD);
				DiscoverDPAS_GetAllData(pDataStruct); // Get all the kernel data to print the receipt
				nResult = CLESS_CR_MANAGER_RESTART_NO_MESSAGE_BEFORE_RETRY;
				break;

			case DISCOVER_DPAS_STATUS_CONSUMER_DEVICE_CVM_FAIL:
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_PHONE_INSTRUCTIONS_RETRY);
				nResult = CLESS_CR_MANAGER_RESTART_NO_MESSAGE_BEFORE_RETRY;
				break;

			default: // Error case
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ERROR);
				// Deselect the card in the standard error case
				if ((nResult != CLESS_CR_MANAGER_REMOVE_AID) && (nResult != CLESS_CR_MANAGER_RESTART_WO_CLESS)) {
					if(ClessEmv_IsDriverOpened())
						ClessEmv_DeselectCard(0, TRUE, FALSE);
				}
				break;
		}
		// If transaction shall be save in the batch, save it
		if (bSaveInBatch)
			CLESS_DiscoverDPAS_AddRecordToBatch (pDataStruct, usCardType);

		if ((nResult != CLESS_CR_MANAGER_RESTART) && (nResult != CLESS_CR_MANAGER_RESTART_NO_MESSAGE_BEFORE_RETRY) && (nResult != CLESS_CR_MANAGER_REMOVE_AID) && (nResult != CLESS_CR_MANAGER_RESTART_WO_CLESS))
		{
			ClessEmv_DeselectCard  (0, TRUE, FALSE);

		}

		// If the transaction does not restart from the begining, set the LEDs into the idle state
		if ((nResult != CLESS_CR_MANAGER_RESTART) && (nResult != CLESS_CR_MANAGER_RESTART_NO_MESSAGE_BEFORE_RETRY) && (nResult != CLESS_CR_MANAGER_REMOVE_AID)) {
			// Increment the transaction sequence counter
			DiscoverDPAS_GetAllData(pDataStruct); // Get all the kernel data to print the receipt
		}
	}

	// Transaction is completed, clear Discover kernel transaction data
	DiscoverDPAS_Clear();

	// Return result
	return (nResult);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Add the transaction data record to the batch.                                    *
 * 			                                                                                  *
 * [in] :    pSharedData Shared buffer to be used to retrieve the data record.                *
 * [in] :    usCardType Card type.                                                            *
 * ------------------------------------------------------------------------------------------ */
void CLESS_DiscoverDPAS_AddRecordToBatch (T_SHARED_DATA_STRUCT * pSharedData, unsigned short usCardType) {
	// Tags required for Offline and Online approved transactions
	T_TI_TAG tRequestedTags[] = {TAG_DISCOVER_DPAS_DATA_RECORD};

	unsigned int nIndex;
	int nPosition;
	int nResult, bErrorDetected;
	T_SHARED_DATA_STRUCT * pBatchData;
	T_SHARED_DATA_STRUCT tTempStruct;
	unsigned long ulReadLength;
	unsigned char * pReadValue;

	(void) usCardType;

	// Clear the shared exchange buffer
	GTL_SharedExchange_ClearEx (pSharedData, FALSE);
	nIndex = 0;
	bErrorDetected = FALSE;


	// Allocate the sharde buffer
	pBatchData = GTL_SharedExchange_InitLocal (2048);

	if (pBatchData != NULL)
	{
		// Request Data Record and Discretionary Data to the kernel
		while (nIndex < NUMBER_OF_ITEMS(tRequestedTags))
		{
			GTL_SharedExchange_AddTag (pSharedData, tRequestedTags[nIndex], 0, NULL);
			nIndex ++;
		}

		// Get the tags from the kernel
		nResult = DiscoverDPAS_GetData (pSharedData);

		if (nResult == KERNEL_STATUS_OK)
		{
			// Get the Data Record
			nPosition = SHARED_EXCHANGE_POSITION_NULL;
			if (GTL_SharedExchange_FindNext (pSharedData, &nPosition, TAG_DISCOVER_DPAS_DATA_RECORD, &ulReadLength, (const unsigned char **)&pReadValue) == STATUS_SHARED_EXCHANGE_OK)
			{
				// Copy data record data in the local buffer
				if (GTL_SharedExchange_InitEx (&tTempStruct, ulReadLength, ulReadLength, pReadValue) == STATUS_SHARED_EXCHANGE_OK)
				{
					if (GTL_SharedExchange_AddSharedBufferContent (pBatchData, &tTempStruct) != STATUS_SHARED_EXCHANGE_OK)
					{
						bErrorDetected = TRUE;
					}
				}
				else
				{
					bErrorDetected = TRUE;
				}
			}
			else
			{
				bErrorDetected = TRUE;
			}

			if (!bErrorDetected)
			{
				//if (!ClessSample_Batch_AddTransactionToBatch (pBatchData))
				//{
					bErrorDetected = TRUE;
				//}
			}
		}
		else
		{
			bErrorDetected = TRUE;
		}

		// Destroy allocated buffer
		GTL_SharedExchange_DestroyLocal (pBatchData);
	}
	else
	{
		// An error occurred when initialising the local data exchange
		bErrorDetected = TRUE;
	}

	if (bErrorDetected)
	{
        //merchLang = PSQ_Give_Language();
		//ClessSample_Term_Read_Message(STD_MESS_BATCH_ERROR, merchLang, &tMsg);
		//Helper_DisplayTextMerchant(ERASE, HELPERS_MERCHANT_LINE_3, &tMsg, LEDSOFF);
		//Helper_RefreshScreen (WAIT, HELPERS_MERCHANT_SCREEN);
	}
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Create a shared buffer, and requests the selected language to the Discover       *
 *           DPAS kernel.                                                                     *
 * 			                                                                                  *
 * [in] :    nMerchantLanguage Merchant language as configured by the manager.                *
 * [out]:    pCardholderLanguage Selected language (equal to nMerchantLanguage if selected    *
 *           language is not found).                                                          *
 * ------------------------------------------------------------------------------------------ */
void CLESS_DiscoverDPAS_GetSelectedPreferedLanguage (int * pCardholderLanguage, int nMerchantLanguage) {
	int ret;
	T_SHARED_DATA_STRUCT * pStruct;

	// By default, cardholder language is the same as the merchant language
	*pCardholderLanguage = nMerchantLanguage;

	// Init a shared buffer to get the prefered selected language
	pStruct = GTL_SharedExchange_InitShared (128);

	if (pStruct == NULL) {
		goto End;
	}

	// Add tag in the shared buffer to request it
	if(GTL_SharedExchange_AddTag (pStruct, TAG_KERNEL_SELECTED_PREFERED_LANGUAGE, 0, NULL) != STATUS_SHARED_EXCHANGE_OK) {
		goto End;
	}

	// Request data to DiscoverDPAS kernel
	ret = DiscoverDPAS_GetData (pStruct);
	if (ret != KERNEL_STATUS_OK) {
		goto End;
	}
End:
	// Destroy the shared buffer if created
	if (pStruct != NULL)
		GTL_SharedExchange_DestroyShare (pStruct);
}
int CLESS_DiscoverDPAS_SitchInterfaceOnOnlineFailure() {
	int ret;
	T_SHARED_DATA_STRUCT * pStruct;
	// Init a shared buffer to get the card processing requirements
	pStruct = GTL_SharedExchange_InitShared (128);

	if (pStruct == NULL) {
		// An error occurred when creating the shared buffer
		goto End;
	}

	// Add tag in the shared buffer to request it
	ret = GTL_SharedExchange_AddTag (pStruct, TAG_DISCOVER_DPAS_CARD_PROCESSING_REQUIREMENTS, 0, NULL);
	if (ret != STATUS_SHARED_EXCHANGE_OK) {
		// An error occurred when adding the TAG_KERNEL_SELECTED_PREFERED_LANGUAGE tag in the structure
		goto End;
	}

	// Request data to DiscoverDPAS kernel
	ret = DiscoverDPAS_GetData (pStruct);
	if (ret != KERNEL_STATUS_OK) {
		// An error occurred when getting data from the DPAS kernel
		goto End;
	}

End:
	// Destroy the shared buffer if created
	if (pStruct != NULL)
		GTL_SharedExchange_DestroyShare (pStruct);
	return ret;
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Add Issuer Scripts received from the authorization in the transaction data sent  *
 *           to the DiscoverDpas kernel.                                                      *
 * 			                                                                                  *
 * [in,out]: pTransactionData Transaction data.                                               *
 * ------------------------------------------------------------------------------------------ */
int CLESS_DiscoverDPAS_AddIssuerScripts (T_SHARED_DATA_STRUCT *pTransactionData, T_SHARED_DATA_STRUCT * pDataStruct) {
	T_SHARED_DATA_STRUCT * pTmpScripts71, * pTmpScripts72;
	T_BER_TLV_DECODE_STRUCT BerTlvStruct;
	int nResult, cr;
	int BytesRead;
	BER_TLV_TAG ReadTag;
	T_TI_LENGTH ReadLength;
	T_TI_VALUE  ReadValue;
	int nScitpsPresent = FALSE;


	pTmpScripts71 = GTL_SharedExchange_InitLocal(512);
	pTmpScripts72 = GTL_SharedExchange_InitLocal(512);

	if ((pTmpScripts71 != NULL) && (pTmpScripts72 != NULL)) {
		GTL_BerTlvDecode_Init (&BerTlvStruct, pTransactionData->nPtrData, pTransactionData->ulDataLength);
		// Parse Script  T1:71 or 72 L1 V1 ... Tn:71 or 72 Ln Vn
		for (;;) {
			//! \brief Parse the next tag in the BER-TLV structure.
			cr = GTL_BerTlvDecode_ParseTlv (&BerTlvStruct, &ReadTag, &ReadLength, (BER_TLV_VALUE*)&ReadValue, (unsigned char)FALSE, &BytesRead);
			if (cr == STATUS_BER_TLV_END)
				break;
			if (cr == STATUS_BER_TLV_OK) {
				if (ReadTag == TAG_EMV_ISSUER_SCRIPT_TEMPLATE_1) {
					nResult = GTL_SharedExchange_AddTag(pTmpScripts71, ReadTag, ReadLength, ReadValue);
					if (nResult != STATUS_SHARED_EXCHANGE_OK){
					}
				}
				if(ReadTag == TAG_EMV_ISSUER_SCRIPT_TEMPLATE_2) {
					nResult = GTL_SharedExchange_AddTag(pTmpScripts72, ReadTag, ReadLength, ReadValue);
					if (nResult != STATUS_SHARED_EXCHANGE_OK){
					}
				}
			}
			else
				break; // An error occurs
		} // end of loop about Script parsing
		// Add TAG_DISCOVER_DPAS_ISSUER_SCRIPT_71_LIST and TAG_DISCOVER_DPAS_ISSUER_SCRIPT_72_LIST tags in the data sent to the kernel
		if (pTmpScripts71->ulDataLength) {
			nScitpsPresent = TRUE;
			nResult = GTL_SharedExchange_AddTag(pDataStruct, TAG_DISCOVER_DPAS_ISSUER_SCRIPT_71_LIST, pTmpScripts71->ulDataLength, pTmpScripts71->nPtrData);
			if (nResult != STATUS_SHARED_EXCHANGE_OK) {
			}
		}
		if (pTmpScripts72->ulDataLength) {
			nScitpsPresent = TRUE;
			nResult = GTL_SharedExchange_AddTag(pDataStruct, TAG_DISCOVER_DPAS_ISSUER_SCRIPT_72_LIST, pTmpScripts72->ulDataLength, pTmpScripts72->nPtrData);
			if (nResult != STATUS_SHARED_EXCHANGE_OK) {
			}
		}
	}
	// Destroy the local buffers
	if (pTmpScripts71)
		GTL_SharedExchange_DestroyLocal(pTmpScripts71);
	if (pTmpScripts72)
		GTL_SharedExchange_DestroyLocal(pTmpScripts72);

	return (nScitpsPresent);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Prepare the Online authorization request data for Discover DPAS transactions     *
 * 			                                                                                  *
 * [in] :    dataStruct Data buffer to be filled and used for Discover DPAS transaction.      *
 *           cardType used in the Discover DPAS transaction.                                  *
 * [out]:    Fill the userInput data                                                          *
 * ------------------------------------------------------------------------------------------ */
int DiscoverDPAS_OnlineRequestData(T_SHARED_DATA_STRUCT* dataStruct, unsigned short cardType) {
	int result = TRUE;
	unsigned long length;
	const unsigned char* ptValue;
	int position;

	typedef struct{
		unsigned long tagNum;
		unsigned char tagName[2];
		int tagNameLength;
		int tagDataMinLen;
		int mandatoryFlag;
	}EMVTags;

	EMVTags DiscoverDPASRequestTags  [] =
	   {{TAG_EMV_AIP,                        			"\x82",     1, 2, TRUE},
		{TAG_EMV_DF_NAME,                    			"\x84",     1, 5, TRUE},
		{TAG_EMV_TVR,                        			"\x95",     1, 5, TRUE},
		{TAG_EMV_TRANSACTION_DATE,           			"\x9A",     1, 3, TRUE},
		{TAG_EMV_TRANSACTION_TYPE,           			"\x9C",     1, 1, TRUE},
		{TAG_EMV_TRANSACTION_CURRENCY_CODE,  			"\x5F\x2A", 2, 2, TRUE},
		{TAG_EMV_AMOUNT_AUTH_NUM,            			"\x9F\x02", 2, 6, TRUE},
		{TAG_EMV_AMOUNT_OTHER_NUM,           			"\x9F\x03", 2, 6, TRUE},
		{TAG_EMV_ISSUER_APPLI_DATA,    					"\x9F\x10", 2, 0, TRUE},
		{TAG_EMV_TERMINAL_COUNTRY_CODE,      			"\x9F\x1A", 2, 2, TRUE},
		{TAG_EMV_APPLICATION_CRYPTOGRAM,      			"\x9F\x26", 2, 8, TRUE},
		{TAG_EMV_CRYPTOGRAM_INFO_DATA,					"\x9F\x27", 2, 1, TRUE},
		{TAG_EMV_ATC,                        			"\x9F\x36", 2, 2, TRUE},
		{TAG_EMV_UNPREDICTABLE_NUMBER,       			"\x9F\x37", 2, 4, TRUE},
		{TAG_EMV_POS_ENTRY_MODE, 		 				"\x9F\x39", 2, 1, TRUE},
		{TAG_EMV_TERMINAL_CAPABILITIES,      			"\x9F\x33", 2, 3, FALSE},
		{TAG_EMV_CVM_RESULTS,                 			"\x9F\x34", 2, 3, FALSE},
		{TAG_EMV_TERMINAL_TYPE,              			"\x9F\x35", 2, 1, FALSE},
		{TAG_EMV_ADD_TERMINAL_CAPABILITIES,  			"\x9F\x40", 2, 5, FALSE},
		{TAG_EMV_AID_CARD, 				 				"\x4F",     1,16, FALSE},
		{TAG_EMV_AID_TERMINAL, 		         			"\x9F\x06", 2,16, FALSE},
		{TAG_EMV_TSI, 						 			"\x9B",     1, 2, FALSE},
		{TAG_EMV_TRANSACTION_TIME, 		     			"\x9F\x21", 2, 3, FALSE},
		{TAG_EMV_APPLI_PAN_SEQUENCE_NUMBER,				"\x5F\x34", 2, 1, FALSE},
		{TAG_EMV_IFD_SERIAL_NUMBER,						"\x9F\x1E", 2, 8, FALSE},
		{TAG_EMV_TRANSACTION_CURRENCY_EXPONENT,			"\x5F\x36", 2, 1, FALSE},
		{TAG_EMV_APPLI_VERSION_NUMBER_TERM,				"\x9F\x09", 2, 2, FALSE},
		{TAG_EMV_APPLI_PAN,								"\x5A", 	1,10, FALSE},
		{TAG_EMV_TRANSACTION_SEQUENCE_COUNTER,			"\x9F\x41", 2, 4, FALSE},
		{TAG_EMV_APPLI_EXPIRATION_DATE,					"\x5F\x24", 2, 3, FALSE},
		{TAG_EMV_TRACK_2_EQU_DATA,						"\x57",     1,37, FALSE},
		{TAG_EMV_SERVICE_CODE,							"\x5F\x30", 2, 2, FALSE},
		{TAG_EMV_CARDHOLDER_NAME,						"\x5F\x20", 2,26, FALSE},
		{TAG_EMV_ICC_DYNAMIC_NUMBER,					"\x9F\x4C", 2, 0, FALSE},
		{TAG_DISCOVER_DPAS_CARD_VERIFICATION_RESULTS, 	"\x9F\x53", 2, 0, FALSE}};

    if (cardType == 0x8502 || cardType == 0x8582) {
    	setCardInputMode (EMVCONTACTLESS);
    	unsigned char dataEMV[256] = {0};
    	int i, j = 0;
    	int tagCount = sizeof(DiscoverDPASRequestTags) / sizeof(DiscoverDPASRequestTags[0]);
			length = 0;
			position = SHARED_EXCHANGE_POSITION_NULL;
			unsigned char poscode[1] = {0};
			char  posencode[2]="07";
			Aschex(poscode,posencode, sizeof(posencode));
			GTL_SharedExchange_AddTag(dataStruct, TAG_EMV_POS_ENTRY_MODE, sizeof(poscode), poscode);
    	for (i = 0; i < tagCount; i++){
    		length = 0;
    		position = SHARED_EXCHANGE_POSITION_NULL;
    		if (dataStruct->ulDataLength)
    			GTL_SharedExchange_FindNext(dataStruct, &position, DiscoverDPASRequestTags[i].tagNum, &length, &ptValue);

    		if (length != 0){
    			memcpy (&dataEMV[j], DiscoverDPASRequestTags[i].tagName, DiscoverDPASRequestTags[i].tagNameLength);
    			memcpy (&dataEMV[j + DiscoverDPASRequestTags[i].tagNameLength], &length, 1);
    			memcpy (&dataEMV[j + DiscoverDPASRequestTags[i].tagNameLength + 1], ptValue, length);
    			j = j + DiscoverDPASRequestTags[i].tagNameLength + 1 + length;
    		}
    		else {
    			if (DiscoverDPASRequestTags[i].mandatoryFlag == TRUE) {
    				memcpy (&dataEMV[j], DiscoverDPASRequestTags[i].tagName, DiscoverDPASRequestTags[i].tagNameLength);
    				memcpy (&dataEMV[j + DiscoverDPASRequestTags[i].tagNameLength], &DiscoverDPASRequestTags[i].tagDataMinLen, 1);
    				memset (&dataEMV[j + DiscoverDPASRequestTags[i].tagNameLength + 1], 0, DiscoverDPASRequestTags[i].tagDataMinLen);
    				j = j + DiscoverDPASRequestTags[i].tagNameLength + 1 + DiscoverDPASRequestTags[i].tagDataMinLen;
    			}
    		}
    	}
    	setRequestEMVData(dataEMV, j);
    	// Set EMV Application Label
    	length = 0;
    	position = SHARED_EXCHANGE_POSITION_NULL;
    	if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_APPLICATION_LABEL, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
    		char app[17] = {0};
    		memcpy(app,ptValue,length);
    		setEMVApplicationLabel(app);
    	}
    	// set EMV Application Identifier (AID)
    	length = 0;
    	position = SHARED_EXCHANGE_POSITION_NULL;
    	if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_DF_NAME, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
    		char aid[33] = {0};
    		/*if(length==16)	//special case
    			memcpy (aid, hexToASCII(ptValue,length), length*2);
    		else if(length>9){
    			length=7;
    			memcpy (aid, hexToASCII(ptValue,length), length*2);
    		}*/
    		memcpy (aid, hexToASCII(ptValue,length), length*2);
    		setEMVApplicationIdentifier (aid);
    	}

    	// Get Card Number (Tag 5A)
    	length = 0;
    	position = SHARED_EXCHANGE_POSITION_NULL;
    	if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_APPLI_PAN, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char cardNo [20] = {0};
			Hexasc (cardNo, ptValue, length*2);
			int n;
			for (n = 0; n < length*2; n++) {
				if ((int)cardNo[n] < 48 || (int)cardNo[n] > 57)
					cardNo[n] = '\x00';
			}
			setCardNumber(cardNo, strlen(cardNo));
		}
    	// Get Card Holder Name
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_CARDHOLDER_NAME, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			setCardHolderName (ptValue, length);
		}
		// Set Expiration Date.
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_APPLI_EXPIRATION_DATE, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char cardAppExp[5] = {0};
			Hexasc(cardAppExp, ptValue, 4);
			setCardExpiryDate(cardAppExp);
		}
		// Get Track Data (Tag 57)
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_TRACK_2_EQU_DATA, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char tag57 [40] = {0};
			memcpy (tag57, unsignedCharToASCII(ptValue,length), length*2);
			int trackLength = 0;
			if (tag57 [0] != 'B'){
				char temp [40] = {0};
				temp [0] = 'B';
				memcpy (temp+1, tag57, length*2);
				trackLength = length*2 + 1;
				memcpy (tag57, temp, trackLength);
				if (tag57 [strlen(tag57) - 1] != 'F'){
					tag57 [strlen(tag57)] = 'F';
					trackLength = trackLength + 1;
				}
			}
			else
				trackLength = length*2;

			char *pcSrc = NULL, *pcDst = NULL;
			char tcTrk2[40] = {'\0'};
			pcSrc = tag57;
			pcDst = tcTrk2;
			while(*pcSrc) {                                  // Find start sentinel
				if(*pcSrc++ == 'B'){
					*pcDst++ = ';';
					break;
				}
			}
			while(*pcSrc) {                                  // Copy all data between start and end sentinels
				if(*pcSrc == 'F'){
					*pcDst = '?';
					break;
				}
				if(*pcSrc == 'D')
					*pcSrc = '=';
				*pcDst++ = *pcSrc++;
			}
			setTrack2Data(tcTrk2, trackLength);
		}

		//if PAN Number not found
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_APPLI_PAN, &length, &ptValue) != STATUS_SHARED_EXCHANGE_OK) {
			int trk2Length;
			char rawTrack2[40];
			memset(rawTrack2,0,sizeof(rawTrack2));
			getTrack2Data (rawTrack2, &trk2Length);
			char * tempTrack2 = strtok(rawTrack2,";");
			char * track2 = strtok(tempTrack2,"?");
			char * token = strtok(track2,"=");
			setCardNumber(token, strlen(token));
		}

	}
    else if (cardType == 0x8501 || cardType == 0x8581) {
    	setCardInputMode (MSRCONTACTLESS);
    	setCHVerificationMethod (getCardType() == CREDIT	? PAPER_SIGNATURE 	:
								(getCardType() == DEBIT  	? ONLINE_PIN 		:
															 NO_AUTHENTICATION));

    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_TRACK_2_EQU_DATA, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char track2Raw [40] = {0};
			Hexasc(track2Raw, ptValue, length*2);
			if (track2Raw[0] != ';') {
				track2Raw[0] = ';';
				Hexasc(track2Raw + 1, ptValue, length*2);
			}
			setTrack2Data(track2Raw, strlen(track2Raw));
			char * track2 = strtok(track2Raw,"?");
			int trackLen = strlen(track2);
			char * token = strtok(track2,"=");
			setCardNumber (token, strlen(token));
			token = strtok(NULL,"'\0'");
			char cardExpiryDate[4] = {0};
			memcpy (cardExpiryDate, token, 2);    // YY
			memcpy (cardExpiryDate+2, token+2, 2);    // MM
			setCardExpiryDate (cardExpiryDate);
			char svc[3] = {0};
			memcpy (svc, token + sizeof(cardExpiryDate), sizeof(svc));
		}
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_DISCOVER_DPAS_TRACK1_DATA, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			if (strtok(ptValue,"^")) {
				   char * token = strtok(NULL,"/^");
				   setCardHolderName(token, sizeof(token));
			 }
		}
    }
   	else {
   		result = FALSE;
   		goto End;
    }
End:
	return result;
}
