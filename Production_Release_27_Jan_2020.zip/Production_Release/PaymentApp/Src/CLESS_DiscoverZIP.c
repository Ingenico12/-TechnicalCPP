/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   12/31/2018   Manages the interface with the Discover contactless kernel.   *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "CLESS.h"
#include "sec_interface.h"
#include "EPSTOOL_PinEntry.h"
#include "transaction.h"
#include "emvParameter.h"

static int  CLESS_Discover_AddDiscoverSpecificData (T_SHARED_DATA_STRUCT * pDataStruct);
static void CLESS_Discover_AddRecordToBatch (T_SHARED_DATA_STRUCT * pSharedData);
int 		DiscoverZIP_OnlineRequestData (T_SHARED_DATA_STRUCT * dataStruct);

/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Fill buffer with specific Discover for transaction.                                   *
 * 			                                                                                      *
 * [out]: 	pDataStruct Shared exchange structure filled with the specific Discover data.         *
 * [return]: TRUE if correctly performed.                                                         *
 * 			 FALSE if an error occurred.                                                          *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_Discover_AddDiscoverSpecificData (T_SHARED_DATA_STRUCT * pDataStruct) {
	int nResult = FALSE;
	object_info_t ObjectInfo;
	T_KERNEL_TRANSACTION_FLOW_CUSTOM sTransactionFlowCustom;
	unsigned char StepInterruption[KERNEL_PAYMENT_FLOW_STOP_LENGTH];// Bit field to stop payment flow,
																	// if all bit set to 0 => no stop during payment process
									                                // if right bit set to 1 : stop after payment step number 1
	unsigned char StepCustom[KERNEL_PAYMENT_FLOW_CUSTOM_LENGTH]; 	// Bit field to custom payment flow,
																	// if all bit set to 0 => no stop during payment process
									                                // if right bit set to 1 : stop after payment step number 1

	if (pDataStruct != NULL) {
		memset(StepInterruption, 0, sizeof(StepInterruption)); // Default Value : not stop on process
		memset(StepCustom, 0, sizeof(StepCustom)); // Default Value : not stop on process
		ObjectGetInfo(OBJECT_TYPE_APPLI, ApplicationGetCurrent(), &ObjectInfo);

		// Add a tag for Do_Txn management
		if(GTL_SharedExchange_AddTag(pDataStruct, TAG_KERNEL_PAYMENT_FLOW_STOP, KERNEL_PAYMENT_FLOW_STOP_LENGTH, (const unsigned char *)StepInterruption) == STATUS_SHARED_EXCHANGE_OK) {
			ADD_STEP_CUSTOM(STEP_DISCOVER_REMOVE_CARD,StepCustom); // To do GUI when Discover card has been read

			memcpy ((void*)&sTransactionFlowCustom, (void*)StepCustom, KERNEL_PAYMENT_FLOW_CUSTOM_LENGTH);
			sTransactionFlowCustom.usApplicationType = ObjectInfo.application_type; // Kernel will call this application for customisation
			sTransactionFlowCustom.usServiceId = SERVICE_CUSTOM_KERNEL; // Kernel will call SERVICE_CUSTOM_KERNEL service id for customisation

			if(GTL_SharedExchange_AddTag(pDataStruct, TAG_KERNEL_PAYMENT_FLOW_CUSTOM, sizeof(T_KERNEL_TRANSACTION_FLOW_CUSTOM), (const unsigned char *)&sTransactionFlowCustom) == STATUS_SHARED_EXCHANGE_OK) {
				nResult = TRUE;
			}
		}
	}
	return (nResult);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Perform the Discover kernel customization.                                            *
 * 			                                                                                      *
 * [in] :    ucCustomisationStep Step to be customized.                                           *
 * [in,out]: pSharedData Shared buffer used for customization.                                    *
 * ---------------------------------------------------------------------------------------------- */
int CLESS_Discover_CustomiseStep (T_SHARED_DATA_STRUCT * pSharedData, const unsigned char ucCustomisationStep) {
	int nResult = KERNEL_STATUS_CONTINUE;

	switch (ucCustomisationStep) {
		case STEP_DISCOVER_REMOVE_CARD:
			CLESS_GUI_DisplayScreen (APCLESS_SCREEN_REMOVE_CARD);
			GTL_SharedExchange_ClearEx (pSharedData, FALSE);
			nResult = KERNEL_STATUS_CONTINUE;
			break;

		default:
			break;
	}
	return (nResult);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Calls the Discover kernel to perform the transaction.                            *
 * 			                                                                                  *
 * [in] :    pDataStruct Data buffer to be filled and used for Discover transaction.          *
 * [return]: Discover kernel result.                                                          *
 * ------------------------------------------------------------------------------------------ */
int CLESS_Discover_PerformTransaction (T_SHARED_DATA_STRUCT * pDataStruct) {
	int nResult = CLESS_CR_MANAGER_END;
	int cr;
	unsigned char bSaveInBatch = FALSE;

	CLESS_Txn_SetCurrentPaymentScheme (APCLESS_SCHEME_DISCOVER);
	if (CLESS_Discover_AddDiscoverSpecificData(pDataStruct)) {
		cr = Discover_DoTransaction(pDataStruct);

		switch (cr) {
			case KERNEL_STATUS_OFFLINE_APPROVED:
				ClessEmv_CloseDriver();
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_OFFLINE_APPROVED);
				Discover_GetAllData(pDataStruct); // Get all the kernel data to print the receipt
				break;

			case KERNEL_STATUS_OFFLINE_DECLINED:
				ClessEmv_CloseDriver();
				CLESS_GUI_DisplayScreen (KERNEL_STATUS_OFFLINE_DECLINED);
				break;

			case KERNEL_STATUS_ONLINE_AUTHORISATION:
				ClessEmv_CloseDriver();
				Discover_GetAllData (pDataStruct);
	        	DiscoverZIP_OnlineRequestData (pDataStruct);
	        	// TODO: Check if PIN online is required and manage it.
	        	if (getCHVerificationMethod() == ONLINE_PIN ){
					int pinLength;
					switch (APEMV_UI_PinEntry (INPUT_PIN_ON, 3, &pinLength)) {
						case EPSTOOL_PINENTRY_SUCCESS:
							if (encryptPIN() == FALSE)
								setErrorCode("ERROR:033");
							break;
						case EPSTOOL_PINENTRY_TIMEOUT:
							setErrorCode("ERROR:013");
							break;
						case EPSTOOL_PINENTRY_ERROR:
						case EPSTOOL_PINENTRY_CANCEL:
							setErrorCode("ERROR:044");
							break;
						case EPSTOOL_PINENTRY_EVENT:
						case EPSTOOL_PINENTRY_BYPASS:
						default:
							break;
						}


	        	}
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ONLINE_PROCESSING);
				break;

			case KERNEL_STATUS_USE_CONTACT_INTERFACE:
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_USE_CONTACT);
				nResult = CLESS_CR_MANAGER_RESTART_WO_CLESS;
				break;

			case KERNEL_STATUS_COMMUNICATION_ERROR:
				nResult = CLESS_CR_MANAGER_RESTART;
				break;

			case KERNEL_STATUS_REMOVE_AID:
				nResult = CLESS_CR_MANAGER_REMOVE_AID;
				break;

			case KERNEL_STATUS_CARD_BLOCKED:
				CLESS_GUI_DisplayScreen (KERNEL_STATUS_CARD_BLOCKED);
				break;

			case KERNEL_STATUS_APPLICATION_BLOCKED:
				break;

			default: // Error case
				CLESS_GUI_DisplayScreen (APCLESS_SCREEN_ERROR);
				break;
		}

		// Cless field must be stopped only if we don't try to work with an another AID
		if (nResult != CLESS_CR_MANAGER_REMOVE_AID)
			ClessEmv_DeselectCard(0, TRUE, FALSE);

		// If the transaction does not restart from the begining, set the LEDs into the idle state
		if ((nResult != CLESS_CR_MANAGER_RESTART) && (nResult != CLESS_CR_MANAGER_REMOVE_AID)) {
			if (bSaveInBatch)
				CLESS_Discover_AddRecordToBatch (pDataStruct);
		}
	}
	Discover_Clear ();
	return (nResult);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Add the tranasction record in the batch file.                                    *
 * 			                                                                                  *
 * [in] :    pSharedData Shared buffer to be used to get all the record data.                 *
 * ------------------------------------------------------------------------------------------ */
static void CLESS_Discover_AddRecordToBatch (T_SHARED_DATA_STRUCT * pSharedData) {
	// Tags required for Online approved transactions
	T_TI_TAG tRequestedTagsDiscover[] = {TAG_EMV_TRACK_2_EQU_DATA, TAG_DISCOVER_TRACK1_DATA, TAG_EMV_DF_NAME,
								TAG_EMV_APPLICATION_LABEL, TAG_EMV_APPLI_PREFERED_NAME, TAG_EMV_UNPREDICTABLE_NUMBER,
								TAG_DISCOVER_APPLI_VERSION_NUMBER_ICC, TAG_DISCOVER_DCVV,
								TAG_EMV_AMOUNT_AUTH_NUM, TAG_EMV_AIP, TAG_DISCOVER_TRANSACTION_OUTCOME};
	unsigned int nIndex;
	int nResult;

	// Clear the shared exchange buffer
	GTL_SharedExchange_ClearEx (pSharedData, FALSE);
	nIndex = 0;

	while (nIndex < NUMBER_OF_ITEMS(tRequestedTagsDiscover)) {
		GTL_SharedExchange_AddTag (pSharedData, tRequestedTagsDiscover[nIndex], 0, NULL);
		nIndex ++;
	}
	// Get the common tags
	nResult = Discover_GetData (pSharedData);
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  Prepare the Online authorization request data for ExpressPay3 transactions       *
 * 			                                                                                  *
 * [in] :    dataStruct Data buffer to be filled and used for ExpressPay3 transaction.        *
 *           kernalStatusCode used in the ExpressPay3 MSR and EMV Mode transaction.           *
 * [out]:    Fill the userInput data                                                          *
 * ------------------------------------------------------------------------------------------ */
int DiscoverZIP_OnlineRequestData (T_SHARED_DATA_STRUCT * dataStruct) {
	int result = TRUE;
	unsigned long length;
	const unsigned char* ptValue;
	int position;

	setCardInputMode (MSRCONTACTLESS);
	char cardType = 0;
	if (getCardType (&cardType)) {
		setCHVerificationMethod ((cardType == CREDIT ? PAPER_SIGNATURE 	:
								 (cardType == DEBIT  ? ONLINE_PIN 		:
										 	 	 	   NO_AUTHENTICATION)));
	}
    length = 0;
	position = SHARED_EXCHANGE_POSITION_NULL;
	if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_TRACK_2_EQU_DATA, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
		char track2Raw [40] = {0};
		Hexasc(track2Raw, ptValue, length*2);
		char * track2 = strtok(track2Raw,"?");
		int trackLen = strlen(track2);
		setTrack2Data(track2, trackLen);
		char * token = strtok(track2,"=");
		setCardNumber (token, strlen(token));
		token = strtok(NULL,"'\0'");
		char cardExpiryDate[4] = {0};
		memcpy (cardExpiryDate, token, 2);    // YY
		memcpy (cardExpiryDate+2, token+2, 2);    // MM
		setCardExpiryDate (cardExpiryDate);
		char svc[3] = {0};
		memcpy (svc, token + sizeof(cardExpiryDate), sizeof(svc));
	}
   	length = 0;
	position = SHARED_EXCHANGE_POSITION_NULL;
	if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_DISCOVER_TRACK1_DATA, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
		if (strtok(ptValue,"^")) {
		   char * token = strtok(NULL,"/^");
		   setCardHolderName(token, sizeof(token));
		}
	}
End:
	return result;
}
