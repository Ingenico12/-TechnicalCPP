/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   08/30/2018   This module implements the EMV Engine services related to the *
 * 									Application Selection.                                        *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "SEC_interface.h"
#include "GL_GraphicLib.h"
#include "TlvTree.h"
#include "GTL_Assert.h"
#include "_emvdctag_.h"
#include "def_tag.h"

#include "EPSTOOL_TlvTree.h"
#include "EPSTOOL_PinEntry.h"

#include "EMV.h"
#include "emvparameter.h"

// Structure that contain all information concerning an AID of the candidate list.
typedef struct {
	int aidLength;							//!< The length of the AID.
	unsigned char aid[16];					//!< The AID.
	char applicationLabel[16 + 1];			//!< The Application Label.
	unsigned char issuerCodeTableIndex;		//!< The Issuer Code Table Index.
	char preferredName[16 + 1];				//!< The Application Preferred Name.
	char languagePreference[8 + 1];			//!< The Language Preference.
	unsigned char priority;					//!< The Application Priority.
	unsigned char cardholderConfirmation;	//!< The cardholder confirmation flag. If TRUE, a confirmation is mandatory to use this AID.
} __APEMV_ServicesEmv_AidInfo_t;

static int emvGetCandidateList(TLV_TREE_NODE inputTlvTree, __APEMV_ServicesEmv_AidInfo_t **aids, int *numOfAids);

/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the list of supported AIDs managed by the terminal Application and pass	supported *
 * 			AIDs to EMV Engine.                                                                   *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree.                                                           *
 * [out]:   outputTlvTree Output TlvTree that must be filled with the list of terminal supported  *
 * 			AIDs..                                                                                *
 * ---------------------------------------------------------------------------------------------- */
void emvGetAidList (TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;

	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	unsigned char aids[128] = {0};
	int aidsLength = 0;
	int aidCount = 0;
	if (getTerminalSupportedAIDList(aids, &aidsLength, &aidCount)) {
		VERIFY(TlvTree_AddChild(outputTlvTree, TAG_AID_LIST_TERMINAL, aids, aidsLength) != NULL);
		VERIFY(TlvTree_AddChild(outputTlvTree, TAG_NB_AID_TERMINAL, &aidCount, sizeof(unsigned char)) != NULL);
	}
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Reformat the candidate list from inputTlvTree into an array of structures	          *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree that contains the candidate list.                          *
 * [out]:   aids - The candidate list in an array of structures (__APEMV_ServicesEmv_AidInfo_t)   *
 * 			numOfAids - The number of AIDs in the candidate list.                                 *
 *																							      *
 * Note:	in case of an empty list, the function returns TRUE, but aids is set to NULL.	      *
 * ---------------------------------------------------------------------------------------------- */
static int emvGetCandidateList(TLV_TREE_NODE inputTlvTree, __APEMV_ServicesEmv_AidInfo_t **aids, int *numOfAids) {
	int result;
	int maxNumberOfAids;
	TLV_TREE_NODE aidNode;
	TLV_TREE_NODE node;
	EPSTOOL_Data_t data;
	__APEMV_ServicesEmv_AidInfo_t *currentAid;

	ASSERT(inputTlvTree != NULL);
	ASSERT(aids != NULL);
	ASSERT(numOfAids != NULL);

	*aids = NULL;
	*numOfAids = 0;

	// Count the number of AIDs in the candidate list
	maxNumberOfAids = 0;
	aidNode = EPSTOOL_TlvTree_FindFirstData(inputTlvTree, TAG_AID_ICC, NULL);
	while(aidNode != NULL){
		maxNumberOfAids++;
		aidNode = EPSTOOL_TlvTree_FindNextData(aidNode, TAG_AID_ICC, NULL);
	}

	if (maxNumberOfAids <= 0){
		result = TRUE;   		// No AID within the candidate list!
	}
	else{
		// Allocate memory to store the candidate list
		*aids = umalloc(maxNumberOfAids * sizeof(__APEMV_ServicesEmv_AidInfo_t));
		if (*aids != NULL) {
			memclr(*aids, maxNumberOfAids * sizeof(__APEMV_ServicesEmv_AidInfo_t));

			// Parse input TlvTree to fill the candidate list array
			*numOfAids = 0;
			currentAid = *aids;
			aidNode = EPSTOOL_TlvTree_FindFirstData(inputTlvTree, TAG_AID_ICC, &data);
			while((aidNode != NULL) && (*numOfAids < maxNumberOfAids)) {
				// Store the AID
				memcpy(currentAid->aid, data.value, data.length);
				currentAid->aidLength = data.length;

				// Parse all tags within this AID
				node = EPSTOOL_TlvTree_GetFirstChildData(aidNode, &data);
				while((node != NULL) && (*numOfAids < maxNumberOfAids)) {
					if ((data.length > 0) && (data.value != NULL)) {
						switch(data.tag) {
						case TAG_APPLICATION_LABEL:       			// Tag 50
							// Store the Application Label (and carefully manage length to avoid buffer overflow)
							if (data.length <= sizeof(currentAid->applicationLabel) - 1) {
								memcpy(currentAid->applicationLabel, data.value, data.length);
								currentAid->applicationLabel[data.length] = '\0';
							}
							else {
								memcpy(currentAid->applicationLabel, data.value, sizeof(currentAid->applicationLabel) - 1);
								currentAid->applicationLabel[sizeof(currentAid->applicationLabel) - 1] = '\0';
							}
							break;

						case TAG_APPLICATION_PREFFERRED_NAME:		// Tag 9F12
							// Store the Application Preferred Name (and carefully manage length to avoid buffer overflow)
							if (data.length <= sizeof(currentAid->preferredName) - 1) {
								memcpy(currentAid->preferredName, data.value, data.length);
								currentAid->preferredName[data.length] = '\0';
							}
							else {
								memcpy(currentAid->preferredName, data.value, sizeof(currentAid->preferredName) - 1);
								currentAid->preferredName[sizeof(currentAid->preferredName) - 1] = '\0';
							}
							break;

						case TAG_LANGUAGE_PREFERENCE:				// Tag 5F2D
							// Store the Cardholder Languages (and carefully manage length to avoid buffer overflow)
							if (data.length <= sizeof(currentAid->languagePreference) - 1) {
								memcpy(currentAid->languagePreference, data.value, data.length);
								currentAid->languagePreference[data.length] = '\0';
							}
							else {
								memcpy(currentAid->languagePreference, data.value, sizeof(currentAid->languagePreference) - 1);
								currentAid->languagePreference[sizeof(currentAid->languagePreference) - 1] = '\0';
							}
							break;

						case TAG_ISSUER_CODE_TABLE_INDEX:    		// Tag 9F11
							// Store the Issuer Code Table Index
							currentAid->issuerCodeTableIndex = *(data.value);
							break;

						case TAG_APPLI_PRIOR_IND:					// Tag 87
							// Store the Application Priority with the Cardholder Confirmation Indicator
							currentAid->priority = (*(data.value) & 0x0f);
							currentAid->cardholderConfirmation = ((*(data.value) & 0x80) != 0);
							break;

						default:
							break;
						}
					}
					node = EPSTOOL_TlvTree_GetNextData(node, &data);
				}

				// Next AID
				(*numOfAids)++;
				currentAid++;
				aidNode = EPSTOOL_TlvTree_FindNextData(aidNode, TAG_AID_ICC, &data);
			}

			result = TRUE;
		}
		else{
			// Not enough memory
			result = FALSE;
		}
	}

	// TODO: (Optional) Sort the candidate list 'aids' in a proprietary way

	if (!result) {
		// In case of error
		// Free memory and return an empty candidate list
		if (*aids != NULL){
			ufree(*aids);
			*aids = NULL;
		}
		*numOfAids = 0;
	}
	return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called when the cardholder must select the AID to use.  							  *
 * 			Cardholder Selection, Cardholder confirmation supported by application.			      *
 * 			Service: I_EMVCUST_Menu_Select_TlvTree                                                *
 * 																							      *
 * 			Steps to manually select AIDs:													      *
 * 			1. Convert the candidate list from inputTlvTree into an array of structures		      *
 * 			2. Display a screen to select an AID if multiple AIDs match or Confirmation needed    *
 * 			3. Add the selected (by cardholder or application) AID into the output TlvTree        *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree that contains the candidate list.             		      *
 * [out]:   outputTlvTree Output TlvTree that must contain the selected AID in TAG_AID_ICC.       *
 * ---------------------------------------------------------------------------------------------- */
void emvMenuSelect (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	int numOfAids;
	__APEMV_ServicesEmv_AidInfo_t *aids;
	APEMV_UI_SelectAidItem_t *menuItems;
	int index;

	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	menuItems = NULL;

	// Convert the candidate list from TlvTree into an array of structures
	if (emvGetCandidateList(inputTlvTree, &aids, &numOfAids)) {
		if (numOfAids > 0) {
			if ((numOfAids == 1) && (!aids[0].cardholderConfirmation)) {
				// There is only one AID and no confirmation is required
				//  => select it
				VERIFY(TlvTree_AddChild(outputTlvTree, TAG_AID_ICC, aids[0].aid, aids[0].aidLength) !=  NULL);
				*statusCode = TAG_CUST_PROCESS_COMPLETED;
			}
			else {
				// Otherwise, display a screen with the list of AIDs
				menuItems = umalloc(numOfAids * sizeof(APEMV_UI_SelectAidItem_t));
				int aidFlag=FALSE;
				int index_value=0,length=7;
				char aidValue[16+1]={0};
				if (menuItems != NULL) {
					// Prepare the list of AIDs to select
					for(index = 0; index < numOfAids; index++) {
						menuItems[index].aidLength = aids[index].aidLength;
						memcpy(menuItems[index].aid, aids[index].aid, sizeof(menuItems[index].aid));
						menuItems[index].issuerCodeTableIndex = aids[index].issuerCodeTableIndex;
						memcpy(menuItems[index].preferredName, aids[index].preferredName, sizeof(menuItems[index].preferredName));
						memcpy(menuItems[index].applicationLabel, aids[index].applicationLabel, sizeof(menuItems[index].applicationLabel));
						memcpy (aidValue, hexToASCII(aids[index].aid,length), length*2);
						if (!strcmp(aidValue,"A0000000980840") ||
							!strcmp(aidValue,"A0000000042203")){
							aidFlag=TRUE;
							index_value=index;
						}
					}
					// Select the AID from Screen
					if (aidFlag==FALSE) {
						index = APEMV_UI_MenuSelectAid(numOfAids, menuItems);
						if (index >= 0) {
							// Add the selected AID into the output TlvTree
							VERIFY(TlvTree_AddChild(outputTlvTree, TAG_AID_ICC, aids[index].aid, aids[index].aidLength) !=  NULL);
							*statusCode = TAG_CUST_PROCESS_COMPLETED;
						}
						else if (index == -1) {
							*statusCode = TAG_CUST_TRANSACTION_CANCELLED;	// Cancelled
						}
						else {
							*statusCode = TAG_CUST_NOT_ENOUGH_MEMORY;    	// Not enough memory
						}
					}
					//Select the US DEBIT or US Maestro AID AUTOMATICALLY
					else {
						// Add the selected AID into the output TlvTree
						VERIFY(TlvTree_AddChild(outputTlvTree, TAG_AID_ICC, aids[index_value].aid, aids[index_value].aidLength) !=  NULL);
						*statusCode = TAG_CUST_PROCESS_COMPLETED;
					}
					ufree(menuItems);
				}
				else{
					*statusCode = TAG_CUST_NOT_ENOUGH_MEMORY;           // Not enough memory
				}
			}
		}
		else {
			*statusCode = TAG_CUST_PROCESS_COMPLETED;                   // Empty candidate list
		}
	}
	else {
		// Error (not enough memory to convert TlvTree into an array of structures)
		*statusCode = TAG_CUST_NOT_ENOUGH_MEMORY;
	}

	// Free the memory
	if (aids != NULL) {
		ufree(aids);
		aids = NULL;
	}
	emvTransacStatusSet (*statusCode);
}
