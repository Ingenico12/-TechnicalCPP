/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   06/30/2018   This module implements the EMV Engine services related to     *
 * 									online processing (Authorisation, Referral, Online Processing,*
 * 									Issuer Scripts and the 2nd Generate AC).                      *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "SEC_interface.h"
#include "GL_GraphicLib.h"
#include "TlvTree.h"
#include "GTL_Assert.h"
#include "_emvdctag_.h"
#include "def_tag.h"
#include "EngineInterface.h"
#include "EngineInterfaceLib.h"
#include "servcomm.h"

#include "EPSTOOL_TlvTree.h"
#include "EPSTOOL_PinEntry.h"

#include "EMV.h"
#include "Transaction.h"

void populateEMVData (TLV_TREE_NODE *inputTlvTree);

#define DEBUG
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called when the application must request an authorisation from the acquirer.          *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree.                                                           *
 * [out]:   outputTlvTree Output TlvTree.                                                    	  *
 * ---------------------------------------------------------------------------------------------- */
void emvAuthorisation (TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

/*
	if(Is_Offline_Only()==FCT_OK){
		// Build an output TLV tree
		code = 0;
		TlvTree_AddChild(*phOutputTLVTree, TAG_CUST_STATUS_CODE, (unsigned char *) &code, 2);
		code = 0;
		TlvTree_AddChild(*phOutputTLVTree, TAG_COMM_STATUS_CODE, (unsigned char *) &code, 2);
		code_result[0] = 1;
		TlvTree_AddChild(*phOutputTLVTree, TAG_AUTHORISATION_RESULT, (unsigned char *) &code_result, 1);
	}
	else
	{
*/
	TLV_TREE_NODE hRequiredEMVTLVTree;
	static const unsigned long RequiredTags[] = {
				/*9F34*/    TAG_CVR_RESULT,
				/*9F26*/    TAG_APPLI_CRYPTOGRAMME_AC,
				/*9F27*/    TAG_CRYPTOGRAM_INFORMATION_DATA,
				/*9F10*/    TAG_ISSUER_APPLICATION_DATA,
				/*9F37*/    TAG_UNPREDICTABLE_NUMBER,
				/*9F36*/    TAG_ATC,
				/*95*/    	TAG_TVR,
				/*82*/    	TAG_AIP,
				/*9B*/		TAG_TSI,
				/*9F33*/    TAG_TERMINAL_CAPABILITIES,
				/*9F1A*/    TAG_TERMINAL_COUNTRY_CODE,
				/*9F35*/    TAG_TERMINAL_TYPE,
				/*9F1E*/    TAG_IFD_SERIAL_NUMBER,
				/*9F03*/    TAG_AMOUNT_OTHER_NUM,
				/*9A*/    	TAG_TRANSACTION_DATE,
				/*9C*/    	TAG_TRANSACTION_TYPE,
				/*9F02*/    TAG_AMOUNT_AUTH_NUM,
				/*5F2A*/    TAG_TRANSACTION_CURRENCY_CODE,
				/*5F36*/    TAG_TRANSACTION_CURRENCY_EXP,
				/*84*/    	TAG_DF_NAME,
				/*4F*/    	TAG_AID_ICC,
				/*9F09*/    TAG_VERSION_NUMBER_TERMINAL,
				/*5A*/    	TAG_APPLI_PRIM_ACCOUNT_NB,
				/*5F34*/    TAG_APPLI_PRIM_ACCOUNT_NB_SEQ_NB,
				/*9F41*/    TAG_TRANSACTION_SEQ_COUNTER,
				/*9F8132*/  TAG_AUTOMATE,
				/*9F8134*/  TAG_PIN_CODE,
				/*5F24*/    TAG_APPLI_EXPIRATION_DATE,
				/*57*/    	TAG_TRACK2_EQU_DATA,
				/*5F30*/    TAG_SERVICE_CODE,
				/*9F24*/    TAG_PAYMENT_ACCOUNT_REFERENCE,
				/*5F20*/    TAG_CARDHOLDER_NAME,
				/*9F40*/    TAG_ADD_TERMINAL_CAPABILITIES,
				/*9F06*/	TAG_AID_TERMINAL,
				/*9F39*/	TAG_POS_ENTRY_MODE_CODE,
				/*9F21*/	TAG_TRANSACTION_TIME
	};
	// Retrieve all RequiredTags from EMVDC Data base
	hRequiredEMVTLVTree = Engine_GetDataElements(sizeof(RequiredTags) / sizeof(RequiredTags[0]), RequiredTags);

	// Remove tags with no value
	unsigned int length;
	char *ptData;
	TLV_TREE_NODE hNode;
	TLV_TREE_NODE hNode2;

	if (hRequiredEMVTLVTree != NULL) {
		hNode = TlvTree_GetFirstChild(hRequiredEMVTLVTree);
		while(hNode != NULL){
			length = TlvTree_GetLength(hNode);
			ptData = TlvTree_GetData(hNode);
			if ((length == 0) || (ptData == NULL)) {
				hNode2 = TlvTree_GetNext(hNode);
				TlvTree_Release(hNode);
				hNode = hNode2;
			}
			else {
				hNode = TlvTree_GetNext(hNode);
			}
		}
	}
	// Populate EMV Data
	populateEMVData (&hRequiredEMVTLVTree);


	unsigned char code_result[2];
	if (emvTransacStatusGet() == APEMV_TR_STATUS_APPROVED || emvTransacStatusGet() == APEMV_TR_STATUS_UNKNOWN){
		// Quick Chip Processing
		const unsigned char commStatus[2] = { 0x00, 0x00 };
		VERIFY(TlvTree_AddChild(outputTlvTree, TAG_COMM_STATUS_CODE, commStatus, sizeof(commStatus)) != NULL);
		code_result[0] = 1;
		TlvTree_AddChild(*outputTlvTree, TAG_AUTHORISATION_RESULT, (unsigned char *) &code_result, 1);
		TlvTree_AddChild(*outputTlvTree, TAG_AUTHORISATION_RESPONSE_CODE, "\x5A\x33", 2);
	}
	else {
		code_result[0] = 0;
		TlvTree_AddChild(*outputTlvTree, TAG_AUTHORISATION_RESULT, (unsigned char *) &code_result, 1);
	}
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called when the application must request a voice referral from the acquirer.        NU*
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree.                                                           *
 * [out]:   outputTlvTree Output TlvTree.                                                    	  *
 * ---------------------------------------------------------------------------------------------- */
void emvVoiceReferral (TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);
	// TODO: Perform the voice referral
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called just after the EXTERNAL AUTHENTICATE command.                                  *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree.                                                           *
 * [out]:   outputTlvTree Output TlvTree.                                                    	  *
 * ---------------------------------------------------------------------------------------------- */
void emvStepOnLineProcessing (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	// TODO: Customise if required
	/*if (*statusCode == TAG_CUST_PROCESS_COMPLETED)
	{
		// TODO: Check for retry
	}*/

	// Set the transaction status
#ifdef DEBUG
	unsigned short found;
	DataElement Data_Elt;
	TLV_TREE_NODE hTree;

	hTree = Engine_GetDataElement(TAG_LAST_APDU_CMD_RESPONSE);
	TLV_TREE_NODE hFoundNode=NULL;
	found = FALSE;

	if(&hTree != NULL){
		hFoundNode = TlvTree_Find(hTree, TAG_LAST_APDU_CMD_RESPONSE, 0);
		if(hFoundNode != NULL){
			Data_Elt.tag = TlvTree_GetTag(hFoundNode);
			Data_Elt.length = TlvTree_GetLength(hFoundNode);
			Data_Elt.ptValue = TlvTree_GetData(hFoundNode);
			found = TRUE;
		}
	}
#endif
	emvTransacStatusSet (*statusCode);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called just after the execution of a critical Issuer Script (executed before the      *
 *          second GENERATE AC).                                                                  *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree. statusCode = TAG_CUST_PROCESS_COMPLETED if success.       *
 * [out]:   outputTlvTree Output TlvTree.                                                    	  *
 * ---------------------------------------------------------------------------------------------- */
void emvStepIssuerToCardScriptProcessing1 (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree)
{
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	// TODO: Customise if required
	/*if (*statusCode == TAG_CUST_PROCESS_COMPLETED)
	{
	}*/
#ifdef DEBUG
	unsigned short found;
	DataElement Data_Elt;
	TLV_TREE_NODE hTree;

	hTree = Engine_GetDataElement(TAG_LAST_APDU_CMD_RESPONSE);
	TLV_TREE_NODE hFoundNode=NULL;
	found = FALSE;

	if(&hTree != NULL){
		hFoundNode = TlvTree_Find(hTree, TAG_LAST_APDU_CMD_RESPONSE, 0);
		if(hFoundNode != NULL){
			Data_Elt.tag = TlvTree_GetTag(hFoundNode);
			Data_Elt.length = TlvTree_GetLength(hFoundNode);
			Data_Elt.ptValue = TlvTree_GetData(hFoundNode);
			found = TRUE;
		}
	}
#endif

	// Set the transaction status
	emvTransacStatusSet (*statusCode);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called just after the second GENERATE AC.                                             *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree.                                                           *
 * [out]:   outputTlvTree Output TlvTree.                                                         *
 * ---------------------------------------------------------------------------------------------- */
void emvStepCompletion (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	// TODO: Customise if required
	unsigned short found;
	DataElement Data_Elt;
	TLV_TREE_NODE hTree;

	hTree = Engine_GetDataElement(TAG_LAST_APDU_CMD_RESPONSE);
	TLV_TREE_NODE hFoundNode=NULL;
	found = FALSE;

	if(&hTree != NULL){
		hFoundNode = TlvTree_Find(hTree, TAG_LAST_APDU_CMD_RESPONSE, 0);
		if(hFoundNode != NULL){
			Data_Elt.tag = TlvTree_GetTag(hFoundNode);
			Data_Elt.length = TlvTree_GetLength(hFoundNode);
			Data_Elt.ptValue = TlvTree_GetData(hFoundNode);
			found = TRUE;
		}
	}
	DataElement Data_Elt1;
	if (found){
		// Check if it was a 2nd Generate AC
		if ((Data_Elt.ptValue [0] == 0x80)  &&     // CLA command
			(Data_Elt.ptValue [1] == 0xAE))        // INS command
		{
/*
			unsigned char cmd_ok;
			// Check Response bytes SW1 SW2 for Exception handling
			cmd_ok =((Data_Elt.ptValue [4] == 0x90) && (Data_Elt.ptValue [5] == 0x00))  ||
					((Data_Elt.ptValue [4] == 0x62) && (Data_Elt.ptValue [5] == 0x83))  ||
					((Data_Elt.ptValue [4] == 0x63) && (Data_Elt.ptValue [5] == 0x00))  ||
					((Data_Elt.ptValue [4] == 0x63) && ((Data_Elt.ptValue [5] & 0xF0) == 0xC0));
*/
			TLV_TREE_NODE hTree1 = Engine_GetDataElement(TAG_APPLI_CRYPTOGRAMME_AC);
			TLV_TREE_NODE hFoundNode1 = NULL;

			if(&hTree1 != NULL){
				hFoundNode1 = TlvTree_Find(hTree, TAG_APPLI_CRYPTOGRAMME_AC, 0);
				if(hFoundNode1 != NULL){
					Data_Elt1.tag = TlvTree_GetTag(hFoundNode);
					Data_Elt1.length = TlvTree_GetLength(hFoundNode);
					Data_Elt1.ptValue = TlvTree_GetData(hFoundNode);
					// setRespTag9F26AuthnCert(Data_Elt1.ptValue);
				}
			}
		}
	}
	emvTransacStatusSet (*statusCode);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called just after the execution of a non-critical Issuer Script (executed after the   *
 *          second GENERATE AC).                                                                  *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree. statusCode = TAG_CUST_PROCESS_COMPLETED if success.       *
 * [out]:   outputTlvTree Output TlvTree.                                                         *
 * ---------------------------------------------------------------------------------------------- */
void emvStepIssuerToCardScriptProcessing2 (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	// TODO: Customise if required
	/*if (*statusCode == TAG_CUST_PROCESS_COMPLETED)
	{
	}*/

#ifdef DEBUG
	unsigned short found;
	DataElement Data_Elt;
	TLV_TREE_NODE hTree;

	hTree = Engine_GetDataElement(TAG_LAST_APDU_CMD_RESPONSE);
	TLV_TREE_NODE hFoundNode=NULL;
	found = FALSE;

	if(&hTree != NULL){
		hFoundNode = TlvTree_Find(hTree, TAG_LAST_APDU_CMD_RESPONSE, 0);
		if(hFoundNode != NULL){
			Data_Elt.tag = TlvTree_GetTag(hFoundNode);
			Data_Elt.length = TlvTree_GetLength(hFoundNode);
			Data_Elt.ptValue = TlvTree_GetData(hFoundNode);
			found = TRUE;
		}
	}
#endif
	emvTransacStatusSet (*statusCode);
}
/* --------------------------------------------------------------------------------------------- *
* Purpose: Prepare EMV Data block. The following EMV tag may be sent in EMV request block.   	 *
* ---------------------------------------------------------------------------------------------- */
void populateEMVData (TLV_TREE_NODE *inputTlvTree){
	typedef struct{
		unsigned long tagNum;
		unsigned char tagName[2];
		int tagNameLength;
		int tagDataMinLen;
		int mandatoryFlag;
	}EMVTags;

	EMVTags emvRequestTags [] =
		   {{TAG_AIP,                        	"\x82",     1, 2, TRUE},
			{TAG_DF_NAME,                    	"\x84",     1, 5, TRUE},
			{TAG_TVR,                        	"\x95",     1, 5, TRUE},
			{TAG_TRANSACTION_DATE,           	"\x9A",     1, 3, TRUE},
			{TAG_TRANSACTION_TYPE,           	"\x9C",     1, 1, TRUE},
			{TAG_TRANSACTION_CURRENCY_CODE,  	"\x5F\x2A", 2, 2, TRUE},
			{TAG_AMOUNT_AUTH_NUM,            	"\x9F\x02", 2, 6, TRUE},
			{TAG_AMOUNT_OTHER_NUM,           	"\x9F\x03", 2, 6, TRUE},
			{TAG_ISSUER_APPLICATION_DATA,    	"\x9F\x10", 2, 0, TRUE},
			{TAG_TERMINAL_COUNTRY_CODE,      	"\x9F\x1A", 2, 2, TRUE},
			{TAG_APPLI_CRYPTOGRAMME_AC,      	"\x9F\x26", 2, 8, TRUE},
			{TAG_CRYPTOGRAM_INFORMATION_DATA,	"\x9F\x27", 2, 1, TRUE},
			{TAG_ATC,                        	"\x9F\x36", 2, 2, TRUE},
			{TAG_UNPREDICTABLE_NUMBER,       	"\x9F\x37", 2, 4, TRUE},
			{TAG_POS_ENTRY_MODE_CODE, 		 	"\x9F\x39", 2, 1, TRUE},
			{TAG_TERMINAL_CAPABILITIES,      	"\x9F\x33", 2, 3, FALSE},
			{TAG_CVR_RESULT,                 	"\x9F\x34", 2, 3, FALSE},
			{TAG_TERMINAL_TYPE,              	"\x9F\x35", 2, 1, FALSE},
			{TAG_ADD_TERMINAL_CAPABILITIES,  	"\x9F\x40", 2, 5, FALSE},
			{TAG_AID_ICC, 					 	"\x4F",     1,16, FALSE},
			{TAG_AID_TERMINAL, 		         	"\x9F\x06", 2,16, FALSE},
			{TAG_TSI, 						 	"\x9B",     1, 2, FALSE},
			{TAG_TRANSACTION_TIME, 		     	"\x9F\x21", 2, 3, FALSE},
			{TAG_APPLI_PRIM_ACCOUNT_NB_SEQ_NB,	"\x5F\x34", 2, 1, FALSE},
			{TAG_IFD_SERIAL_NUMBER,				"\x9F\x1E", 2, 8, FALSE},
			{TAG_TRANSACTION_CURRENCY_EXP,		"\x5F\x36", 2, 1, FALSE},
			{TAG_VERSION_NUMBER_TERMINAL,		"\x9F\x09", 2, 2, FALSE},
			{TAG_APPLI_PRIM_ACCOUNT_NB,			"\x5A", 	1,10, FALSE},
			{TAG_TRANSACTION_SEQ_COUNTER,		"\x9F\x41", 2, 4, FALSE},
			{TAG_APPLI_EXPIRATION_DATE,			"\x5F\x24", 2, 3, FALSE},
			{TAG_TRACK2_EQU_DATA,				"\x57",     1,37, FALSE},
			{TAG_SERVICE_CODE,					"\x5F\x30", 2, 2, FALSE},
			{TAG_PAYMENT_ACCOUNT_REFERENCE,		"\x9F\x24", 2,29, FALSE},
			{TAG_CARDHOLDER_NAME,				"\x5F\x20", 2,26, FALSE}};

	TLV_TREE_NODE hFoundNode;
	unsigned char dataEMV[512] = {0};
	int i, j = 0;
	unsigned int  length;
	unsigned char *ptValue;
	int tagCount = sizeof(emvRequestTags) / sizeof(emvRequestTags[0]);

	for (i = 0; i < tagCount; i++){
		length = 0;
		if (*inputTlvTree != 0){
			hFoundNode = TlvTree_Find(*inputTlvTree,emvRequestTags[i].tagNum, 0);
			if(hFoundNode != 0){
				length = TlvTree_GetLength(hFoundNode);
				ptValue = TlvTree_GetData(hFoundNode);
			}
		}
		if (length != 0){
			memcpy (&dataEMV[j], emvRequestTags[i].tagName, emvRequestTags[i].tagNameLength);
			memcpy (&dataEMV[j + emvRequestTags[i].tagNameLength], &length, 1);
			memcpy (&dataEMV[j + emvRequestTags[i].tagNameLength + 1], ptValue, length);
			j = j + emvRequestTags[i].tagNameLength + 1 + length;
		}
		else {
			if (emvRequestTags[i].mandatoryFlag == TRUE) {
				memcpy (&dataEMV[j], emvRequestTags[i].tagName, emvRequestTags[i].tagNameLength);
				memcpy (&dataEMV[j + emvRequestTags[i].tagNameLength], &emvRequestTags[i].tagDataMinLen, 1);
				memset (&dataEMV[j + emvRequestTags[i].tagNameLength + 1], 0, emvRequestTags[i].tagDataMinLen);
				j = j + emvRequestTags[i].tagNameLength + 1 + emvRequestTags[i].tagDataMinLen;
			}
		}
	}
	setRequestEMVData(dataEMV, j);

	// Get Cardholder Verification Method (Tag 9F34).
    hFoundNode = 0;
    length = 0;
    unsigned char cvr [3] = {0};
    if (*inputTlvTree != 0) {
		hFoundNode = TlvTree_Find(*inputTlvTree, TAG_CVR_RESULT, 0);
		if(hFoundNode != 0){
			length = TlvTree_GetLength(hFoundNode);
			ptValue = TlvTree_GetData(hFoundNode);
		}
	}
	if (length != 0){
		memcpy (cvr, ptValue, sizeof (cvr));
		int cvm = 	(((int) cvr[0] & 31) == 31 ? NO_AUTHENTICATION 	:		// 0x1F
					(((int) cvr[0] & 30) == 30 ? PAPER_SIGNATURE 	:		// 0x1E
					(((int) cvr[0] & 5)  == 5  ? SIGN_OFF_ENC_PIN 	:		// 0x05
					(((int) cvr[0] & 4)  == 4  ? OFF_ENCIPHER_PIN   :		// 0x04
					(((int) cvr[0] & 3)  == 3  ? SIGN_OFF_CLR_PIN 	:		// 0x03
					(((int) cvr[0] & 2)  == 2  ? ONLINE_PIN 	    :		// 0x02
					(((int) cvr[0] & 1)  == 1  ? OFF_ENCIPHER_PIN 	:		// 0x01
												 NO_AUTHENTICATION )))))));
		setCHVerificationMethod(cvm);
	}
}
