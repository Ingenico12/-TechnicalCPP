/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   07/01/2018   This module implements the services provided by application   *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "SEC_interface.h"
#include "GL_GraphicLib.h"
#include "TlvTree.h"
#include "GTL_Assert.h"
#include "TagOS.h"
#include "_emvdctag_.h"
#include "def_tag.h"

#include "EngineInterface.h"
#include "EngineInterfaceLib.h"
#include "servcomm.h"

#include "EPSTOOL_TlvTree.h"
#include "EPSTOOL_PinEntry.h"
#include "Utils.h"
#include "EMV.h"
#include "CLESS.h"
#include "Transaction.h"

#define SERVICES_PRIORITY_DEFAULT				30		//!< Default priority for services.
#define IDLE_HIGH_PRIORITY          			150 + 30


//// Static function definitions ////////////////////////////////
static int 	main 	  (unsigned int size, StructPt *data);
static int 	mainEMV   (unsigned int size, I_CUST_TLVTREE_SERVICE_HEADER *data);
static int 	mainCLESS (unsigned int size, StructPt *data);
static void services_GiveInterface (unsigned short appliId);

// User Data
static struct sUserData mUserData = {0};
struct sUserData * pUserData = &mUserData;
// Host Data
static struct sHostData mHostData = {0};
struct sHostData * pHostData = &mHostData;

static struct sPinPadData mPinPadData;
struct sPinPadData * pPinPadData = &mPinPadData;


void entry(void);

//! \brief Array used to declare all the supported services to the system.
static Telium_service_desc_t Services[] = {
	{ 0, AFTER_RESET, 				 	(Telium_callback)main, 	 	SERVICES_PRIORITY_DEFAULT },
	{ 0, IS_NAME, 					 	(Telium_callback)main, 	 	SERVICES_PRIORITY_DEFAULT },
	{ 0, GIVE_YOUR_DOMAIN, 			 	(Telium_callback)main, 	 	SERVICES_PRIORITY_DEFAULT },
	{ 0, GIVE_YOUR_SPECIFIC_CONTEXT, 	(Telium_callback)main, 	 	SERVICES_PRIORITY_DEFAULT },
	{ 0, GIVE_MONEY_EXTENDED, 		 	(Telium_callback)main, 	 	SERVICES_PRIORITY_DEFAULT },
	{ 0, IS_STATE, 				     	(Telium_callback)main, 	 	SERVICES_PRIORITY_DEFAULT },
	{ 0, IS_DELETE, 				 	(Telium_callback)main, 	 	SERVICES_PRIORITY_DEFAULT },
	{ 0, GIVE_AID, 					 	(Telium_callback)main, 	 	SERVICES_PRIORITY_DEFAULT },
	//{ 0, IS_CARD_EMV_FOR_YOU, 		 	(Telium_callback)main, 	 	SERVICES_PRIORITY_DEFAULT },
	//{ 0, DEBIT_EMV, 				 	(Telium_callback)main, 	 	SERVICES_PRIORITY_DEFAULT },
	{ 0, MORE_FUNCTION, 			 	(Telium_callback)main, 	 	SERVICES_PRIORITY_DEFAULT },
	{ 0, IDLE_MESSAGE, 				 	(Telium_callback)main, 	 	IDLE_HIGH_PRIORITY		  },
	{ 0, GET_IDLE_STATE_PARAMETER, 	 	(Telium_callback)main, 	 	SERVICES_PRIORITY_DEFAULT },
	{ 0, KEYBOARD_EVENT, 			 	(Telium_callback)main, 	 	SERVICES_PRIORITY_DEFAULT },

	{ 0, CLESS_GIVE_INFO, 			 	(Telium_callback)mainCLESS, SERVICES_PRIORITY_DEFAULT },
	{ 0, CLESS_DEBIT_AID, 			 	(Telium_callback)mainCLESS, SERVICES_PRIORITY_DEFAULT },
	{ 0, CLESS_END, 				 	(Telium_callback)mainCLESS, SERVICES_PRIORITY_DEFAULT },
    { 0, CLESS_SERVICE_CUST_IMPSEL_GUI,	(Telium_callback)mainCLESS, SERVICES_PRIORITY_DEFAULT },
    { 0, SERVICE_CUSTOM_KERNEL, 		(Telium_callback)mainCLESS, SERVICES_PRIORITY_DEFAULT },

	{ 0, I_EMVCUST_Get_Global_Param_TlvTree, 		(Telium_callback)mainEMV, SERVICES_PRIORITY_DEFAULT },
	{ 0, I_EMVCUST_Get_AID_List_TlvTree, 			(Telium_callback)mainEMV, SERVICES_PRIORITY_DEFAULT },
	{ 0, I_EMVCUST_Get_AID_DATA_TlvTree, 			(Telium_callback)mainEMV, SERVICES_PRIORITY_DEFAULT },
	{ 0, I_EMVCUST_Get_AID_Param_TlvTree, 			(Telium_callback)mainEMV, SERVICES_PRIORITY_DEFAULT },
	{ 0, I_EMVCUST_Get_AID_ICS_TlvTree, 			(Telium_callback)mainEMV, SERVICES_PRIORITY_DEFAULT },
	{ 0, I_EMVCUST_Display_Message_TlvTree, 		(Telium_callback)mainEMV, SERVICES_PRIORITY_DEFAULT },
	{ 0, I_EMVCUST_Menu_Select_TlvTree, 			(Telium_callback)mainEMV, SERVICES_PRIORITY_DEFAULT },
	{ 0, I_EMVCUST_Choose_Language_Menu_TlvTree, 	(Telium_callback)mainEMV, SERVICES_PRIORITY_DEFAULT },
	{ 0, I_EMVCUST_Choose_Account_Type_Menu_TlvTree,(Telium_callback)mainEMV, SERVICES_PRIORITY_DEFAULT },
	{ 0, I_EMVCUST_Get_Last_Transaction_TlvTree, 	(Telium_callback)mainEMV, SERVICES_PRIORITY_DEFAULT },
	{ 0, I_EMVCUST_Authorization_TlvTree, 			(Telium_callback)mainEMV, SERVICES_PRIORITY_DEFAULT },
	{ 0, I_EMVCUST_Voice_Referral_TlvTree, 			(Telium_callback)mainEMV, SERVICES_PRIORITY_DEFAULT },
	{ 0, I_EMVCUST_Process_Step_TlvTree, 			(Telium_callback)mainEMV, SERVICES_PRIORITY_DEFAULT },
};


//! \brief The entry point for all the Telium Manager services.
//! \param[in] size Size of the data \a data.
//! \param[in,out] data Data related to the called service.
//! \return See Telium Manager documentation.
int main(unsigned int size, StructPt *data) {
	NO_SEGMENT appliId;
	int result;
	(void)size;

	// Get the application number
	appliId = (NO_SEGMENT)ApplicationGetCurrent();

	// Execute the requested service
	switch(data->service) {
	case AFTER_RESET:
		result = after_reset (appliId, NULL, &data->Param.AfterReset.param_out);
		break;

	case IS_NAME:
		result = ServicesManager_IsName(appliId, &data->Param.IsName.param_out);
		break;

	case GIVE_YOUR_DOMAIN:
		result = ServicesManager_GiveYourDomain(appliId, &data->Param.GiveYourType.param_out);
		break;

	case GIVE_YOUR_SPECIFIC_CONTEXT:
		result = ServicesManager_GiveYourSpecificContext(appliId, &data->Param.GiveYourSpecificContext.param_out);
		break;

	case GIVE_MONEY_EXTENDED:
		result = ServicesManager_GiveMoneyExtended(appliId, &data->Param.GiveMoneyExtended.param_out);
		break;

	case IS_STATE:
		result = ServicesManager_IsState(appliId, &data->Param.IsState.param_out);
		break;

	case IS_DELETE:
	    result = ServiceManager_IsDelete(appliId, &data->Param.IsDelete.param_out);
	    break;

	case GIVE_AID:
		result = APEMV_ServicesManager_GiveAid(appliId, &data->Param.GiveAid.param_in, &data->Param.GiveAid.param_out);
		break;

	case IS_CARD_EMV_FOR_YOU:
		result = APEMV_ServicesManager_IsCardEmvForYou(appliId, &data->Param.IsCardEmvForYou.param_in, &data->Param.IsCardEmvForYou.param_out);
		break;

	case DEBIT_EMV:
		result = APEMV_ServicesManager_DebitEmv(appliId, &data->Param.DebitEmv.param_in, &data->Param.DebitEmv.param_out);
		break;

	case MORE_FUNCTION:
		result = APEMV_ServicesManager_MoreFunction (appliId);
		break;

	case IDLE_MESSAGE:
		result = idle_message (0, NULL, NULL);
		break;

	case GET_IDLE_STATE_PARAMETER:
		result = get_idle_state_parameter (0, NULL, &data->Param.GetIdleStateParameter.param_out);

	case KEYBOARD_EVENT: // Activated when key is pressed
		result = keyboard_event(appliId, &data->Param.KeyboardEvent.param_in,
	        &data->Param.KeyboardEvent.param_out);
	    break;

	default:
		// Unknown service
		result = FCT_OK;
		ASSERT(FALSE);
		break;
	}
	return result;
}
static int mainCLESS(unsigned int size, StructPt *data) {
   NO_SEGMENT appliId;
   int result;

   (void)size;
   appliId = (NO_SEGMENT)ApplicationGetCurrent();
   switch(data->service) {
      // Implicit Selection Services
      case CLESS_GIVE_INFO:
         result = APCLESS_ServicesImplicit_ClessGiveInfo(appliId, &data->Param.ClessGiveInfo.param_in, &data->Param.ClessGiveInfo.param_out);
         break;

      case CLESS_DEBIT_AID:
         result = CLESS_Implicit_ClessDebitAid(appliId, size, data);
         break;

      case CLESS_END:
         result = CLESS_Implicit_ClessEnd(appliId);
         break;

      case CLESS_SERVICE_CUST_IMPSEL_GUI:
         result = CLESS_Implicit_CustomSelectionGui(size, data);
         break;

      // Kernel services   APCLESS_ServicesKernel_Custom
      case SERVICE_CUSTOM_KERNEL:
         result = CLESS_ServicesKernel_Custom(size, data);
         break;

      default:
         result = FCT_OK;
         ASSERT(FALSE);
         break;
   }
   return result;
}
//! \brief The entry point for all the EMV ENGINE services.
//! \param[in] size Size of the data \a data.
//! \param[in,out] data Data related to the called service.
//! \return Any \a ERR_ENG_xxx status code.
static int mainEMV (unsigned int size, I_CUST_TLVTREE_SERVICE_HEADER *data) {
	int result;
	TLV_TREE_NODE inputTlvTree;
	TLV_TREE_NODE outputTlvTree;
	unsigned short statusCode;
	TLV_TREE_NODE nodeStatusCode;
	unsigned char buffer[2];

	// Check that the input buffer contains at least the header
	if ((size <= sizeof(I_CUST_TLVTREE_SERVICE_HEADER)) || (data == NULL)) {
		ASSERT(FALSE);
		return ERR_ENG_INVALID_PARAMETERS;
	}
	// Build the input TlvTree
	if (TlvTree_Unserialize(&inputTlvTree, TLV_TREE_SERIALIZER_DEFAULT,
		(void*)(data + 1), size - sizeof(I_CUST_TLVTREE_SERVICE_HEADER)) != TLV_TREE_OK) {
		// Cannot de-serialise the input TlvTree => clear the output memory
		memclr((void*)(data + 1), size - sizeof(I_CUST_TLVTREE_SERVICE_HEADER));
		ASSERT(FALSE);
		return ERR_ENG_INVALID_PARAMETERS;
	}
	// Create the output TlvTree
	outputTlvTree = TlvTree_New(0);
	if (outputTlvTree != NULL) {
		// Get the status code from ENGINE
		statusCode = TAG_CUST_PROCESS_COMPLETED;
		nodeStatusCode = TlvTree_Find(inputTlvTree, TAG_SERVICE_STATUS_CODE, 0);
		if (nodeStatusCode != NULL) {
			if (TlvTree_GetLength(nodeStatusCode) == 2) {
				statusCode = EPSTOOL_Convert_EmvBinToUShort(TlvTree_GetData(nodeStatusCode));
				// Remove the 'suspend' flag
				statusCode &= 0x7fff;
			}
		}
		// Execute the requested service
		result = ERR_ENG_OK;
		switch(data->m_usService) {
		case I_EMVCUST_Get_Global_Param_TlvTree:
			emvGetGlobalParam (inputTlvTree, outputTlvTree);
			break;
		case I_EMVCUST_Get_AID_List_TlvTree:
			emvGetAidList (inputTlvTree, outputTlvTree);
			break;
		case I_EMVCUST_Get_AID_DATA_TlvTree:
			emvGetAidData (inputTlvTree, outputTlvTree);
			break;
		case I_EMVCUST_Get_AID_Param_TlvTree:
			emvGetAidParam (inputTlvTree, outputTlvTree);
			break;
		case I_EMVCUST_Get_AID_ICS_TlvTree:
			emvGetAidIcs (inputTlvTree, outputTlvTree);
			break;
		case I_EMVCUST_Display_Message_TlvTree:
			emvDisplayMessage (inputTlvTree, outputTlvTree);
			break;
		case I_EMVCUST_Menu_Select_TlvTree:
			emvMenuSelect (&statusCode, inputTlvTree, outputTlvTree);
			break;
		case I_EMVCUST_Choose_Language_Menu_TlvTree:
			emvMenuChooseLanguage (inputTlvTree, outputTlvTree);
			break;
		case I_EMVCUST_Choose_Account_Type_Menu_TlvTree:
			emvMenuAccountType (inputTlvTree, outputTlvTree);
			break;
		case I_EMVCUST_Get_Last_Transaction_TlvTree:
			emvGetLastTransaction (inputTlvTree, outputTlvTree);
			break;
		case I_EMVCUST_Authorization_TlvTree:
			emvAuthorisation (inputTlvTree, outputTlvTree);
			break;
		case I_EMVCUST_Voice_Referral_TlvTree:
			emvVoiceReferral (inputTlvTree, outputTlvTree);
			break;
		case I_EMVCUST_Process_Step_TlvTree:
			// Execute the transaction step
			switch(data->m_nFunction) {
			case EMVDC_START:
				emvStepStart (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_FINAL_SELECTION:
				emvStepFinalSelection (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_APPLICATION_SELECTION:
				emvStepApplicationSelection (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_INITIATE_APPLICATION_PROCESSING:
				emvStepInitiateApplicationProcessing (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_READ_APPLICATION_DATA:
				emvStepReadApplicationData (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_OFFLINE_DATA_AUTHENTICATION:
				emvStepOfflineDataAuthentication (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_PROCESSING_RESTRICTIONS:
				emvStepProcessingRestrictions (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_CARDHOLDER_VERIFICATION_FIRST:
				emvStepCardholderVerificationFirst (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_CARDHOLDER_VERIFICATION_OTHER:
				emvStepCardholderVerificationOther (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_TERMINAL_RISK_MANAGEMENT:
				emvStepTerminalRiskManagement (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_TERMINAL_ACTION_ANALYSIS:
				emvStepTerminalActionAnalysis (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_CARD_ACTION_ANALYSIS:
				emvStepCardActionAnalysis (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_ON_LINE_PROCESSING:
				emvStepOnLineProcessing (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_ISSUER_TO_CARD_SCRIPT_PROCESSING1:
				emvStepIssuerToCardScriptProcessing1 (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_COMPLETION:
				emvStepCompletion (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_ISSUER_TO_CARD_SCRIPT_PROCESSING2:
				emvStepIssuerToCardScriptProcessing2 (&statusCode, inputTlvTree, outputTlvTree);
				break;
			case EMVDC_STOP:
				emvStepStop (&statusCode, inputTlvTree, outputTlvTree);
				break;
			default:
				// Unknown step => do nothing
				break;
			}
			break;
		default:
			// Unknown service
			result = ERR_ENG_UNKNOWN;
			ASSERT(FALSE);
			break;
		}

		// Add the status code to the output TlvTree
		EPSTOOL_Convert_UShortToEmvBin(statusCode, buffer);
		TlvTree_AddChild(outputTlvTree, TAG_CUST_STATUS_CODE, buffer, 2);

		// Serialise the output TlvTree
		if (TlvTree_Serialize(outputTlvTree, TLV_TREE_SERIALIZER_DEFAULT, (void*)(data + 1), size - sizeof(I_CUST_TLVTREE_SERVICE_HEADER)) < 0) {
			// Cannot serialise the output TlvTree => clear the memory
			memclr((void*)(data + 1), size - sizeof(I_CUST_TLVTREE_SERVICE_HEADER));
			result = ERR_ENG_NOT_ENOUGH_MEMORY;
			ASSERT(FALSE);
		}
	}
	else {
		// Cannot create the output TlvTree => clear the memory
		memclr((void*)(data + 1), size - sizeof(I_CUST_TLVTREE_SERVICE_HEADER));
		result = ERR_ENG_NOT_ENOUGH_MEMORY;
		ASSERT(FALSE);
	}

	// Delete the input TlvTree
	if (inputTlvTree != NULL) {
		TlvTree_Release(inputTlvTree);
		inputTlvTree = NULL;
	}
	// Delete the output TlvTree
	if (outputTlvTree != NULL) {
		TlvTree_Release(outputTlvTree);
		outputTlvTree = NULL;
	}

	return result;
}
//! \brief This function registers all the services of the application to the system.
//! \param[in] appliId Application system identifier.
static void services_GiveInterface(unsigned short appliId) {
	int index;

	// Initialise the application type in the table of supported services
	for(index = 0; index < (int)(sizeof(Services) / sizeof(Services[0])); index++)
		Services[index].appli_id = appliId;

	// Register services
	Telium_ServiceRegister((sizeof(Services) / sizeof(Services[0])), Services);
}
//! \brief This function is the main function of the application.
//! The objective of this function is to declare the supported services.
void entry(void) {
	object_info_t info;

	// TODO: Initialise the global variables
	// Do It here to ensure that global variables are initialised before any service call
	// Be careful to only INITIALISE the global variables and not doing treatments (loading files, use display, ...)

	ObjectGetInfo(OBJECT_TYPE_APPLI, ApplicationGetCurrent(), &info);
	services_GiveInterface(info.application_type);
	 //ObjectGetInfo(OBJECT_TYPE_APPLI, ApplicationGetCurrent(), &info);
	//__APCLESS_GiveInterface(info.application_type);
}
