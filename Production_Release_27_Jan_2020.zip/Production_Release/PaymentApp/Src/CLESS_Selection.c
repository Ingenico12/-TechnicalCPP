/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   04/01/2018   This module manages the detection and selection process.      *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "CLESS.h"
#include "_emvdctag_.h"
#include "emvparameter.h"

#define __APCLESS_SELECTION_ADD_CUST_STEP(step, buffer)      buffer[(step-1)/8] += (1<<((step-1)%8))

static int __APCLESS_Selection_selectionMethod = APCLESS_SELECTION_UNKNOWN;
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Fill output TlvTree with data for CLESS_GIVE_INFO service or                          *
 * 			Cless_ExplicitSelection_LoadData().                                                   *
 * 			                                                                                      *
 * [out]:   tlvTree output TlvTree filled with all the necessary data for card detection and      *
 * 			application selection.                         										  *
 * ---------------------------------------------------------------------------------------------- */
int CLESS_Selection_GiveInfo (TLV_TREE_NODE * tlvTree, const int explicitSelection) {
   int result;
   TLV_TREE_NODE tmpAidInfo; // Temporary Node for AID methods
   TLV_TREE_NODE pTlvTmp;

   // Detection parameters
   unsigned char detectionType[] = {DETECTION_MASK_ISO_A | DETECTION_MASK_ISO_B ,0x00,0x00,0x00}; // ISO Type A and Type B cards
   unsigned char explicitDetectionTimeout[] = {0x00,0x00,0x17,0x70}; // 1 minute
   unsigned char numberOfCardsToDetect = 1;
   unsigned char terminalFloorLimit[] = {0x00, 0x00, 0x00, 0x00};    // Terminal Floor limit = 0

   result = FALSE;
   if (tlvTree != NULL) {
	   VERIFY(TlvTree_AddChild(*tlvTree, TAG_GENERIC_DETECTION_TYPE, detectionType, sizeof(detectionType))!= NULL);
	   VERIFY(TlvTree_AddChild(*tlvTree, TAG_GENERIC_DETECTION_NB_CARDS_TO_DETECT, &numberOfCardsToDetect, sizeof(numberOfCardsToDetect))!= NULL);
	   if (explicitSelection) {
		   VERIFY(TlvTree_AddChild (*tlvTree, TAG_GENERIC_DETECTION_GLOBAL_TIMEOUT, explicitDetectionTimeout, sizeof(explicitDetectionTimeout))!= NULL);
		   VERIFY(TlvTree_AddChild (*tlvTree, TAG_EMV_AMOUNT_AUTH_BIN, CLESS_Txn_GetAmountBin(), 4)!= NULL);

		   const unsigned long cless_tag_list[] = {TAG_EMV_TRANSACTION_CURRENCY_EXPONENT};
		   EMVDataElement termParam[] = {CLESSParameter};
		   int emvTagCount =  sizeof (cless_tag_list) / sizeof(unsigned long);
		   int emvParam = sizeof (termParam) / sizeof (EMVDataElement);
		   int x, y;
		   for (x = 0; x < emvTagCount; x++) {
			   for (y = 0; y < emvParam; y++) {
				   if (!memcmp(&cless_tag_list[x],&termParam[y].tag, sizeof(unsigned long)))
					   VERIFY(TlvTree_AddChild (*tlvTree, cless_tag_list[x], termParam[y].ptValue, termParam[y].length)!= NULL);
			   }
		   }
	   }
	  /* ---------------------------------------------------------------------------- *
	   * Add MasterCard PayPass ...                                                   *
	   * ---------------------------------------------------------------------------- */
	   unsigned char aidPaypass[] = 			{0xA0, 0x00, 0x00, 0x00, 0x04, 0x10, 0x10};
	   unsigned char aidPaypassId[] = 			{0x00, 0x00, 0x00, 0x00};       // SEPC PayPass AID internal identifier = 0
	   unsigned char aidPaypassKernelToUse[] = 	{0x00, 0x02};             		// PayPass kernel number = 2
	   unsigned char aidPaypassOptions[] = 		{0x01, 0x01, 0x00, 0x00};     	// Partial AID, PPSE method

		   struct sContactlessTable clessPayPass = {0};
		   if (getCLESSAIDSpecificData (aidPaypass, sizeof(aidPaypass), &clessPayPass)) {
			   tmpAidInfo = TlvTree_AddChild(*tlvTree, TAG_EP_AID_INFORMATION, NULL, 0);
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EMV_AID_TERMINAL, aidPaypass, sizeof(aidPaypass)) != NULL);
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_KERNEL_TO_USE, aidPaypassKernelToUse, sizeof(aidPaypassKernelToUse)));
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_OPTIONS, aidPaypassOptions, sizeof(aidPaypassOptions)));
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, aidPaypassId, sizeof(aidPaypassId)) != NULL);
		   }
		   /* ---------------------------------------------------------------------------- *
		    * Add MaestroCard PayPass ...                                                  *
		    * ---------------------------------------------------------------------------- */
		   unsigned char aidMaestro[] 				= 	{0xA0, 0x00, 0x00, 0x00, 0x04, 0x30, 0x60};
		   unsigned char aidMaestroId[] 			= 	{0x00, 0x00, 0x00, 0x00};       // SEPC PayPass AID internal identifier = 0
		   unsigned char aidMaestroKernelToUse[] 	= 	{0x00, 0x02};             		// PayPass kernel number = 2
		   unsigned char aidMaestroOptions[] 		=	{0x01, 0x01, 0x00, 0x00};     	// Partial AID, PPSE method

		   struct sContactlessTable clessMaestro = {0};
		   if (getCLESSAIDSpecificData (aidMaestro, sizeof(aidMaestro), &clessMaestro)) {
			   tmpAidInfo = TlvTree_AddChild(*tlvTree, TAG_EP_AID_INFORMATION, NULL, 0);
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EMV_AID_TERMINAL, aidMaestro, sizeof(aidMaestro)) != NULL);
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_KERNEL_TO_USE, aidMaestroKernelToUse, sizeof(aidMaestroKernelToUse)));
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_OPTIONS, aidMaestroOptions, sizeof(aidMaestroOptions)));
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, aidMaestroId, sizeof(aidMaestroId)) != NULL);
		   }
		   /* ---------------------------------------------------------------------------- *
		    * Add US MaestroCard PayPass ...                                                  *
		    * ---------------------------------------------------------------------------- */
		   unsigned char aidUSMaestro[] 			= 	{0xA0, 0x00, 0x00, 0x00, 0x04, 0x22, 0x03};
		   unsigned char aidUSMaestroId[] 			= 	{0x00, 0x00, 0x00, 0x00};       // SEPC PayPass AID internal identifier = 0
		   unsigned char aidUSMaestroKernelToUse[] 	= 	{0x00, 0x02};             		// PayPass kernel number = 2
		   unsigned char aidUSMaestroOptions[] 		= 	{0x01, 0x01, 0x00, 0x00};     	// Partial AID, PPSE method

		   struct sContactlessTable clessUSMaestro = {0};
		   if (getCLESSAIDSpecificData (aidUSMaestro, sizeof(aidUSMaestro), &clessUSMaestro)) {
			   tmpAidInfo = TlvTree_AddChild(*tlvTree, TAG_EP_AID_INFORMATION, NULL, 0);
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EMV_AID_TERMINAL, aidUSMaestro, sizeof(aidUSMaestro)) != NULL);
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_KERNEL_TO_USE, aidUSMaestroKernelToUse, sizeof(aidUSMaestroKernelToUse)));
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_OPTIONS, aidUSMaestroOptions, sizeof(aidUSMaestroOptions)));
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, aidUSMaestroId, sizeof(aidUSMaestroId)) != NULL);
		   }
	  /* ---------------------------------------------------------------------------- *
	   * Add VISA Credit or Debit or Easy Entry                                                         *
	   * ---------------------------------------------------------------------------- */
	   unsigned char aidpayWave[] = 			{0xA0, 0x00, 0x00, 0x00, 0x03, 0x10, 0x10};
	   unsigned char aidpayWaveId[] = 			{0x00, 0x00, 0x00, 0x01};		// SEPC payWave AID internal identifier = 1
	   unsigned char aidpayWaveKernelToUse[] = 	{0x00, 0x03};             		// Visa payWave kernel number = 3
	   unsigned char aidpayWaveOptions[] = 		{0x01, 0x01, 0x00, 0x00};     	// Partial AID, PPSE method
	   unsigned char aidpayWaveTTQ[] =			{0xB6, 0xC0, 0xC0, 0x00};
	   unsigned char aidpayWaveTerminalPriorityId[]        =   {0x01};

	   struct sContactlessTable clessPayWave = {0};
	   if (getCLESSAIDSpecificData (aidpayWave, sizeof(aidpayWave), &clessPayWave)) {
		   tmpAidInfo = TlvTree_AddChild(*tlvTree, TAG_EP_AID_INFORMATION, NULL, 0);
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EMV_AID_TERMINAL, aidpayWave, sizeof(aidpayWave)) != NULL);
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_KERNEL_TO_USE, aidpayWaveKernelToUse, sizeof(aidpayWaveKernelToUse)) != NULL);
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_OPTIONS, aidpayWaveOptions, sizeof(aidpayWaveOptions)) != NULL);
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_PAYWAVE_TERMINAL_TRANSACTION_QUALIFIERS, aidpayWaveTTQ, sizeof(aidpayWaveTTQ)) != NULL);
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, aidpayWaveId, sizeof(aidpayWaveId)) != NULL);
           VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_TERMINAL_PRIORITY, aidpayWaveTerminalPriorityId, sizeof(aidpayWaveTerminalPriorityId)) != NULL);
	   }

	   /* ---------------------------------------------------------------------------- *
	   	   * Add VISA: Visa Electron                                                         *
	   	   * ---------------------------------------------------------------------------- */
	   	   unsigned char aidpayWaveE[] = 			{0xA0, 0x00, 0x00, 0x00, 0x03, 0x20, 0x10};
	   	   unsigned char aidpayWaveIdE[] = 			{0x00, 0x00, 0x00, 0x01};		// SEPC payWave AID internal identifier = 1
	   	   unsigned char aidpayWaveKernelToUseE[] = 	{0x00, 0x03};             		// Visa payWave kernel number = 3
	   	   unsigned char aidpayWaveOptionsE[] = 		{0x01, 0x01, 0x00, 0x00};     	// Partial AID, PPSE method
	   	   unsigned char aidpayWaveTTQE[] =			{0xB6, 0xC0, 0xC0, 0x00};

	   	   struct sContactlessTable clessPayWaveE = {0};
	   	   if (getCLESSAIDSpecificData (aidpayWaveE, sizeof(aidpayWaveE), &clessPayWaveE)) {
	   		   tmpAidInfo = TlvTree_AddChild(*tlvTree, TAG_EP_AID_INFORMATION, NULL, 0);
	   		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EMV_AID_TERMINAL, aidpayWaveE, sizeof(aidpayWaveE)) != NULL);
	   		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_KERNEL_TO_USE, aidpayWaveKernelToUseE, sizeof(aidpayWaveKernelToUseE)) != NULL);
	   		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_OPTIONS, aidpayWaveOptionsE, sizeof(aidpayWaveOptionsE)) != NULL);
	   		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_PAYWAVE_TERMINAL_TRANSACTION_QUALIFIERS, aidpayWaveTTQE, sizeof(aidpayWaveTTQE)) != NULL);
	   		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, aidpayWaveIdE, sizeof(aidpayWaveIdE)) != NULL);
	   	   }

	   	/* ---------------------------------------------------------------------------- *
	   	           * Add only VISA Debit                                                          *
		   * ---------------------------------------------------------------------------- */
		  unsigned char aidpayWaveDebit[]            = {0xA0, 0x00, 0x00, 0x00, 0x98, 0x08, 0x40};
		  unsigned char aidpayWaveIdDebit[]          = {0x00, 0x00, 0x00, 0x01};         // SEPC payWave AID internal identifier = 1
		  unsigned char aidpayWaveKernelToUseDebit[]                 = {0x00, 0x03};                          // Visa payWave kernel number = 3
		  unsigned char aidpayWaveOptionsDebit[]                     =      {0x01, 0x01, 0x00, 0x00};            // Partial AID, PPSE method
		  unsigned char aidpayWaveTerminalPriorityIdDebit[]   =   {0x00};                       // Vi
		  unsigned char aidpayWaveTTQDebit[]                         =      {0xB6, 0xC0, 0xC0, 0x00};
		  struct sContactlessTable clessPayWaveDebit = {0};
		  if (getCLESSAIDSpecificData (aidpayWaveDebit, sizeof(aidpayWaveDebit), &clessPayWaveDebit)) {
				 tmpAidInfo = TlvTree_AddChild(*tlvTree, TAG_EP_AID_INFORMATION, NULL, 0);
				 VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EMV_AID_TERMINAL, aidpayWaveDebit, sizeof(aidpayWaveDebit)) != NULL);
				 VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_KERNEL_TO_USE, aidpayWaveKernelToUseDebit, sizeof(aidpayWaveKernelToUseDebit)) != NULL);
				 VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_OPTIONS, aidpayWaveOptionsDebit, sizeof(aidpayWaveOptionsDebit)) != NULL);
				 VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_PAYWAVE_TERMINAL_TRANSACTION_QUALIFIERS, aidpayWaveTTQDebit, sizeof(aidpayWaveTTQDebit)) != NULL);
				 VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_TERMINAL_PRIORITY, aidpayWaveTerminalPriorityIdDebit, sizeof(aidpayWaveTerminalPriorityIdDebit)) != NULL);
				 VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, aidpayWaveIdDebit, sizeof(aidpayWaveIdDebit)) != NULL);
		  }

	   	 /* ---------------------------------------------------------------------------- *
		   * Add VISA: Visa Interlink                                                         *
		   * ---------------------------------------------------------------------------- */
	   		   	   unsigned char aidpayWaveI[] = 			{0xA0, 0x00, 0x00, 0x00, 0x03, 0x30, 0x10};
	   		   	   unsigned char aidpayWaveIdI[] = 			{0x00, 0x00, 0x00, 0x01};		// SEPC payWave AID internal identifier = 1
	   		   	   unsigned char aidpayWaveKernelToUseI[] = 	{0x00, 0x03};             		// Visa payWave kernel number = 3
	   		   	   unsigned char aidpayWaveOptionsI[] = 		{0x01, 0x01, 0x00, 0x00};     	// Partial AID, PPSE method
	   		   	   unsigned char aidpayWaveTTQI[] =			{0xB6, 0xC0, 0xC0, 0x00};

	   		   	   struct sContactlessTable clessPayWaveI = {0};
	   		   	   if (getCLESSAIDSpecificData (aidpayWaveI, sizeof(aidpayWaveI), &clessPayWaveI)) {
	   		   		   tmpAidInfo = TlvTree_AddChild(*tlvTree, TAG_EP_AID_INFORMATION, NULL, 0);
	   		   		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EMV_AID_TERMINAL, aidpayWaveI, sizeof(aidpayWaveI)) != NULL);
	   		   		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_KERNEL_TO_USE, aidpayWaveKernelToUseI, sizeof(aidpayWaveKernelToUseI)) != NULL);
	   		   		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_OPTIONS, aidpayWaveOptionsI, sizeof(aidpayWaveOptionsI)) != NULL);
	   		   		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_PAYWAVE_TERMINAL_TRANSACTION_QUALIFIERS, aidpayWaveTTQI, sizeof(aidpayWaveTTQI)) != NULL);
	   		   		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, aidpayWaveIdI, sizeof(aidpayWaveIdI)) != NULL);
	   		   	   }
	  /* ---------------------------------------------------------------------------- *
	   * Add American Express ExpressPay ...                                          *
	   * ---------------------------------------------------------------------------- */
	   unsigned char aidExpressPay[] = 				{0xA0, 0x00, 0x00, 0x00, 0x25, 0x01};
	   unsigned char aidExpressPayId[] = 			{0x00, 0x00, 0x00, 0x07}; 	// SEPC ExpressPay AID internal identifier = 7
	   unsigned char aidExpressPayKernelToUse[] =	{0x00, 0x04};             	// AMEX ExpressPay kernel number = 4
	   unsigned char aidExpressPayOptions[] = 		{0x25, 0x03, 0x00, 0x00}; 	// Partial AID & Zero amount & PPSE

	   struct sContactlessTable clessExpressPay = {0};
	   if (getCLESSAIDSpecificData (aidExpressPay, sizeof(aidExpressPay), &clessExpressPay)) {
		   tmpAidInfo = TlvTree_AddChild(*tlvTree, TAG_EP_AID_INFORMATION, NULL, 0);
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EMV_AID_TERMINAL, aidExpressPay, sizeof(aidExpressPay)) != NULL);
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_KERNEL_TO_USE, aidExpressPayKernelToUse, sizeof(aidExpressPayKernelToUse)));
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_OPTIONS, aidExpressPayOptions, sizeof(aidExpressPayOptions)));
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, aidExpressPayId, sizeof(aidExpressPayId)) != NULL);
	   }
	  /* ---------------------------------------------------------------------------- *
	   * Add Discovery DPAS ...                                                       *
	   * ---------------------------------------------------------------------------- */
	   unsigned char aidDiscoverDPAS[] = 			{0xA0, 0x00, 0x00, 0x01, 0x52, 0x30, 0x10};
	   unsigned char aidDiscoverDPASId[] = 			{0x00, 0x00, 0x00, 0x04};	// SEPC Discover DPAS AID internal identifier = 4
	   unsigned char aidDiscoverDPASKernelToUse[] =	{0x00, 0x06};             	// Discover DPAS kernel number = 6
	   unsigned char aidDiscoverDPASOptions[] = 	{0x07, 0x01, 0x00, 0x00};   // Partial AID, PPSE Method
	   unsigned char aidDiscoverTTQ[]         =     {0xB6,0x00,0xC0,0x00};

	   struct sContactlessTable clessDiscoverDPAS = {0};
	   if (getCLESSAIDSpecificData (aidDiscoverDPAS, sizeof(aidDiscoverDPAS), &clessDiscoverDPAS)) {
		   tmpAidInfo = TlvTree_AddChild(*tlvTree, TAG_EP_AID_INFORMATION, NULL, 0);
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EMV_AID_TERMINAL, aidDiscoverDPAS, sizeof(aidDiscoverDPAS)) != NULL);
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_KERNEL_TO_USE, aidDiscoverDPASKernelToUse, sizeof(aidDiscoverDPASKernelToUse)));
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_OPTIONS, aidDiscoverDPASOptions, sizeof(aidDiscoverDPASOptions)));
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, aidDiscoverDPASId, sizeof(aidDiscoverDPASId)) != NULL);
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_DISCOVER_DPAS_TERMINAL_TRANSACTION_QUALIFIERS, aidDiscoverTTQ, sizeof(aidDiscoverTTQ)) != NULL);
	   }
	  /* ---------------------------------------------------------------------------- *
	   * Add Discovery ZIP ...            	                                          *
	   * ---------------------------------------------------------------------------- */
	   unsigned char aidDiscover[] = 				{0xA0, 0x00, 0x00, 0x03, 0x24, 0x10, 0x10};
	   unsigned char aidDiscoverId[] = 				{0x00, 0x00, 0x00, 0x05};	// SEPC Discover ZIP AID internal identifier = 5
	   unsigned char aidDiscoverKernelToUse[] =		{0x01, 0x02};             	// Discover ZIP kernel number = 102
	   unsigned char aidDiscoverOptions[] = 		{0x01, 0x01, 0x00, 0x00};   // Partial AID, PPSE Method
	   unsigned char aidDiscoverZTTQ[]         =     {0xB6,0x00,0xC0,0x00};

	   struct sContactlessTable clessDiscover = {0};
	   if (getCLESSAIDSpecificData (aidDiscover, sizeof(aidDiscover), &clessDiscover)) {
		   tmpAidInfo = TlvTree_AddChild(*tlvTree, TAG_EP_AID_INFORMATION, NULL, 0);
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EMV_AID_TERMINAL, aidDiscover, sizeof(aidDiscover)) != NULL);
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_KERNEL_TO_USE, aidDiscoverKernelToUse, sizeof(aidDiscoverKernelToUse)));
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_OPTIONS, aidDiscoverOptions, sizeof(aidDiscoverOptions)));
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, aidDiscoverId, sizeof(aidDiscoverId)) != NULL);
		   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_DISCOVER_DPAS_TERMINAL_TRANSACTION_QUALIFIERS, aidDiscoverZTTQ, sizeof(aidDiscoverZTTQ)) != NULL);
	   }
	   /* ---------------------------------------------------------------------------- *
	    * Add JCB  ...            	                                           *
	    * ---------------------------------------------------------------------------- */
	   /*<node tag=\"0x9F06\"> A0 00 00 00 65 10 10 </node>                  <!-- TAG_AID_TERMINAL : JCB AID -->"*/

	   unsigned char aidJCB[]  			 =	{0xA0, 0x00, 0x00, 0x00, 0x65, 0x10, 0x10};
	   unsigned char aidJCBId[]			 =	{0x00, 0x00, 0x00, 0x06};		// SEPC JCB AID internal identifier = 6;
	   unsigned char aidJCBKernelToUse[] = 	{0x00, 0x05};					// JCB  kernel number = 5
	   unsigned char aidJCBOptions[]	 =	{0x05, 0x01, 0x00, 0x00};     	// Partial AID, PPSE method; 	05 01 00 00

		   struct sContactlessTable clessJCB = {0};
		   if (getCLESSAIDSpecificData(aidJCB, sizeof(aidJCB), &clessJCB)) {
			   tmpAidInfo = TlvTree_AddChild(*tlvTree, TAG_EP_AID_INFORMATION, NULL, 0);
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EMV_AID_TERMINAL, aidJCB, sizeof(aidJCB)) != NULL);
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_KERNEL_TO_USE, aidJCBKernelToUse, sizeof(aidJCBKernelToUse)));
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_OPTIONS, aidJCBOptions, sizeof(aidJCBOptions)));
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, aidJCBId, sizeof(aidJCBId)) != NULL);
		   }
		   /* ---------------------------------------------------------------------------- *
		    * Add China Union Pay Credit...                                                      *
		    * ---------------------------------------------------------------------------- */
		   unsigned char aidqUICSCredit[] 			 = 	{0xA0, 0x00, 0x00, 0x03, 0x33, 0x01, 0x01, 0x02};
		   unsigned char aidqUICSCreditId[] 		 = 	{0x00, 0x00, 0x00, 0x04};	// SEPC Discover DPAS AID internal identifier for qUICS = 4
		   unsigned char aidqUICSCreditKernelToUse[] =	{0x00, 0x06};             	// Discover DPAS kernel number for qUICS = 6
		   unsigned char aidqUICSCreditOptions[] 	 = 	{0x07, 0x01, 0x00, 0x00};   // Partial AID, PPSE Method

		   struct sContactlessTable clessqUICSCredit = {0};
		   if (getCLESSAIDSpecificData (aidqUICSCredit, sizeof(aidqUICSCredit), &clessqUICSCredit)) {
			   tmpAidInfo = TlvTree_AddChild(*tlvTree, TAG_EP_AID_INFORMATION, NULL, 0);
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EMV_AID_TERMINAL, aidqUICSCredit, sizeof(aidqUICSCredit)) != NULL);
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_KERNEL_TO_USE, aidqUICSCreditKernelToUse, sizeof(aidqUICSCreditKernelToUse)));
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_OPTIONS, aidqUICSCreditOptions, sizeof(aidqUICSCreditOptions)));
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, aidqUICSCreditId, sizeof(aidqUICSCreditId)) != NULL);
		   }
		   /* ---------------------------------------------------------------------------- *
		    * Add China Union Pay Debit...                                                      *
		    * ---------------------------------------------------------------------------- */
		   unsigned char aidqUICSDebit[] 			= 	{0xA0, 0x00, 0x00, 0x03, 0x33, 0x01, 0x01, 0x03};
		   unsigned char aidqUICSDebitId[] 			= 	{0x00, 0x00, 0x00, 0x04};	// SEPC Discover DPAS AID internal identifier for qUICS = 4
		   unsigned char aidqUICSDebitKernelToUse[] =	{0x00, 0x06};             	// Discover DPAS kernel number for qUICS = 6
		   unsigned char aidqUICSDebitOptions[] 	= 	{0x07, 0x01, 0x00, 0x00};   // Partial AID, PPSE Method

		   struct sContactlessTable clessqUICSDebit = {0};
		   if (getCLESSAIDSpecificData (aidqUICSDebit, sizeof(aidqUICSDebit), &clessqUICSDebit)) {
			   tmpAidInfo = TlvTree_AddChild(*tlvTree, TAG_EP_AID_INFORMATION, NULL, 0);
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EMV_AID_TERMINAL, aidqUICSDebit, sizeof(aidqUICSDebit)) != NULL);
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_KERNEL_TO_USE, aidqUICSDebitKernelToUse, sizeof(aidqUICSDebitKernelToUse)));
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_EP_AID_OPTIONS, aidqUICSDebitOptions, sizeof(aidqUICSDebitOptions)));
			   VERIFY(TlvTree_AddChild(tmpAidInfo, TAG_GENERIC_AID_PROPRIETARY_IDENTIFIER, aidqUICSDebitId, sizeof(aidqUICSDebitId)) != NULL);
		   }
		   result = TRUE;
	   }
	   return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Set the current selection method                                                      *
 * 			-  APCLESS_SELECTION_EXPLICIT                                                         *
 * 			-  APCLESS_SELECTION_IMPLICIT                                                         *
 * 			-  APCLESS_SELECTION_UNKNOWN                                                          *
 * ---------------------------------------------------------------------------------------------- */
void CLESS_Selection_SetMethod(int mode) {
   __APCLESS_Selection_selectionMethod = mode;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the current selection method                                                      *
 * 			-  APCLESS_SELECTION_EXPLICIT                                                         *
 * 			-  APCLESS_SELECTION_IMPLICIT                                                         *
 * 			-  APCLESS_SELECTION_UNKNOWN                                                          *
 * ---------------------------------------------------------------------------------------------- */
int CLESS_Selection_GetMethod(void) {
   return __APCLESS_Selection_selectionMethod;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: This function is called by the Entry Point to customize the Graphical User Interface  *
 *          during Selection.                                                                     *
 * 			                                                                                      *
 * [in,out]:  dataStruct shared buffer with the entry point application.                          *
 * [return]:  CLESS_CUST_DEFAULT, CLESS_CUST_CONTINUE                                             *
 * ---------------------------------------------------------------------------------------------- */
int CLESS_Selection_GuiCustomisation(T_SHARED_DATA_STRUCT* dataStruct) {
   int result = CLESS_CUST_DEFAULT;
   int ret;
   int position;
   unsigned long readLength;
   unsigned char* readValue = NULL;
   unsigned short customStep;
   unsigned char stepsToCustomise[8];

   position = SHARED_EXCHANGE_POSITION_NULL;
   memset(stepsToCustomise, 0, sizeof(stepsToCustomise));

   // Get the GUI step identifier
   ret = GTL_SharedExchange_FindNext(dataStruct, &position, TAG_GENERIC_CUST_STEP_ID, &readLength, (const unsigned char **) &readValue);
   if (ret == STATUS_SHARED_EXCHANGE_OK) {
      // Save the step Identifier
      customStep = readValue[0];

      switch (customStep) {
         case CLESS_CUST_GUI_REGISTRATION_STEP_ID: // Registration step
            GTL_SharedExchange_ClearEx(dataStruct, FALSE);
            __APCLESS_SELECTION_ADD_CUST_STEP(CLESS_CUST_GUI_PRESENT_CARD_AMOUNT_STEP_ID, stepsToCustomise);
            __APCLESS_SELECTION_ADD_CUST_STEP(CLESS_CUST_GUI_PRESENT_CARD_NO_AMOUNT_STEP_ID, stepsToCustomise);
            __APCLESS_SELECTION_ADD_CUST_STEP(CLESS_CUST_GUI_DOUBLE_TAP_STEP_ID, stepsToCustomise);
            __APCLESS_SELECTION_ADD_CUST_STEP(CLESS_CUST_GUI_RETRY_AMOUNT_STEP_ID, stepsToCustomise);
            __APCLESS_SELECTION_ADD_CUST_STEP(CLESS_CUST_GUI_RETRY_NO_AMOUNT_STEP_ID, stepsToCustomise);
            __APCLESS_SELECTION_ADD_CUST_STEP(CLESS_CUST_GUI_COLLISION_STEP_ID, stepsToCustomise);
            __APCLESS_SELECTION_ADD_CUST_STEP(CLESS_CUST_GUI_CARD_NOT_SUPPORTED_STEP_ID, stepsToCustomise);
            __APCLESS_SELECTION_ADD_CUST_STEP(CLESS_CUST_GUI_USE_CONTACT_STEP_ID, stepsToCustomise);
            GTL_SharedExchange_AddTag(dataStruct, TAG_GENERIC_CUST_STEPS_TO_CUSTOMISE, 8, stepsToCustomise);
            result = CLESS_CUST_CONTINUE;
            break;

         case CLESS_CUST_GUI_PRESENT_CARD_AMOUNT_STEP_ID:
         case CLESS_CUST_GUI_PRESENT_CARD_NO_AMOUNT_STEP_ID:
            // Check if a double tap is in progress ("see phone for instructions" is displayed)
            if (CLESS_Txn_GetDoubleTapInProgress()) {
            	CLESS_GUI_DisplayScreen(APCLESS_SCREEN_PHONE_INSTRUCTIONS);

               // Turn on the first LED only
               CLESS_GUI_IndicatorWait();

               result = CLESS_CUST_CONTINUE;
            }
            else {
               if (CLESS_Selection_GetMethod() == APCLESS_SELECTION_EXPLICIT) {
            	   CLESS_GUI_PresentCard("USD", 2, CLESS_Txn_GetAmountBcd(), 6);
                  //continue to default processing to manage the leds
               }
               result = CLESS_CUST_DEFAULT;
            }
            break;

         case CLESS_CUST_GUI_DOUBLE_TAP_STEP_ID:
        	CLESS_GUI_DisplayScreen(APCLESS_SCREEN_PHONE_INSTRUCTIONS);
            CLESS_GUI_IndicatorWait();
            result = CLESS_CUST_CONTINUE;
            break;

         case CLESS_CUST_GUI_RETRY_AMOUNT_STEP_ID:
         case CLESS_CUST_GUI_RETRY_NO_AMOUNT_STEP_ID:

            if (CLESS_Selection_GetMethod() == APCLESS_SELECTION_EXPLICIT) {
               // Turn on the first LED only
            	CLESS_GUI_IndicatorWait();

               // Customized to avoid that the TPass DLL performs a beep
               result = CLESS_CUST_CONTINUE;
            }
            else {
               result = CLESS_CUST_DEFAULT;
            }
            break;

         case CLESS_CUST_GUI_COLLISION_STEP_ID:
            // Display the message
            if (CLESS_Selection_GetMethod() == APCLESS_SELECTION_EXPLICIT) {
            	CLESS_GUI_DisplayScreen(APCLESS_SCREEN_COLLISION);
            	result = CLESS_CUST_CONTINUE;
            }
            break;

         case CLESS_CUST_GUI_CARD_NOT_SUPPORTED_STEP_ID:
            if (CLESS_Selection_GetMethod() == APCLESS_SELECTION_EXPLICIT) {
            	CLESS_GUI_DisplayScreen(APCLESS_SCREEN_ERROR);
               result = CLESS_CUST_CONTINUE;
            }
            break;

         case CLESS_CUST_GUI_USE_CONTACT_STEP_ID:
            if (CLESS_Selection_GetMethod() == APCLESS_SELECTION_EXPLICIT) {
            	CLESS_GUI_DisplayScreen(APCLESS_SCREEN_USE_CONTACT);
               result = CLESS_CUST_CONTINUE;
            }
            break;

         default:
            result = CLESS_CUST_DEFAULT;
            break;
      }
   }
   else {
      // Custom step tag not found
      result = CLESS_CUST_DEFAULT;
   }
   return result;
}
