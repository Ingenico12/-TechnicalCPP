/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   04/01/2018   This module manages Mastercard PayPass 3 transactions.        *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "CLESS.h"
#include "sec_interface.h"
#include "EPSTOOL_PinEntry.h"
#include "transaction.h"

/*---------- Static functions definition -----------*/
static int  CLESS_PayPass_AddPayPassSpecificData(T_SHARED_DATA_STRUCT* dataStruct);
static int  CLESS_PayPass_RetrieveTransactionOutcome(T_SHARED_DATA_STRUCT* resultDataStruct, int* pTransactionOutcome);
static int  CLESS_PayPass_RetrieveStart(T_SHARED_DATA_STRUCT* resultDataStruct, int* pStart);
static int  CLESS_PayPass_RetrieveErrorIndicationByte(T_SHARED_DATA_STRUCT* resultDataStruct, const unsigned int nByteNumber, unsigned char* pErrorIndicationByte);
static int  CLESS_PayPass_RetrieveUirdMessage(T_SHARED_DATA_STRUCT* resultDataStruct, int* pUirdMessage);
static int  CLESS_PayPass_RetrieveCvmToApply(T_SHARED_DATA_STRUCT* resultDataStruct, unsigned char* pCvm);
static int  CLESS_PayPass_RetrieveFieldOffValue(T_SHARED_DATA_STRUCT* resultDataStruct, unsigned char* pFieldOff);
static int  CLESS_PayPass_RetrieveCardType(T_SHARED_DATA_STRUCT* resultDataStruct, unsigned short* cardType);
static int  CLESS_PayPass_IsReceiptRequired(T_SHARED_DATA_STRUCT* resultDataStruct, int* isReceiptRequired);
static int  CLESS_PayPass_DisplayApprovedWithBalance(T_SHARED_DATA_STRUCT* resultDataStruct);
static void CLESS_PayPass_DisplayUirdMsg(T_SHARED_DATA_STRUCT* dataStruct, const int isPhoneMessage);
static void CLESS_PayPass_DebugActivation(int activate);
static void CLESS_PayPass_AddRecordToBatch(T_SHARED_DATA_STRUCT * sharedData);
static int  PayPass_OnlineRequestData(T_SHARED_DATA_STRUCT* dataStruct, unsigned short cardType);

/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Fill buffer with specific PayPass for transaction (custom steps, stop steps ...).     *
 * 			                                                                                      *
 * [out]:   dataStruct Shared exchange structure filled with the specific PayPass data.           *
 * [return]: TRUE if correctly retrieved.                                                         *
 *           FALSE if an error occurred.                                                          *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_PayPass_AddPayPassSpecificData(T_SHARED_DATA_STRUCT* dataStruct) {
   int cr;
   int result = FALSE;
   object_info_t ObjectInfo;
   T_KERNEL_TRANSACTION_FLOW_CUSTOM sTransactionFlowCustom;
   unsigned char StepInterruption[KERNEL_PAYMENT_FLOW_STOP_LENGTH];// Bit field to stop payment flow,
                                                   // if all bit set to 0 => no stop during payment process
                                                           // if right bit set to 1 : stop after payment step number 1
   unsigned char StepCustom[KERNEL_PAYMENT_FLOW_CUSTOM_LENGTH];   // Bit field to custom payment flow,
                                                   // if all bit set to 0 => no stop during payment process
                                                           // if right bit set to 1 : stop after payment step number 1
#ifdef PAYPASS_TORN
   unsigned char ucTornRecordNumber;
   unsigned char ucTornMaxRecordNumber;
#endif


   // Check the input data are correctly provided
   if (dataStruct == NULL) {
      goto End;
   }

   // Init parameteters
   memset(StepInterruption, 0, sizeof(StepInterruption)); // Default Value : not stop on process
   memset(StepCustom, 0, sizeof(StepCustom)); // Default Value : not stop on process
   ObjectGetInfo(OBJECT_TYPE_APPLI, ApplicationGetCurrent(), &ObjectInfo);

   // Add a tag indicating where the transaction has to be stopped (default value, i.e. all bytes set to 0, is strongly recommended)
   cr = GTL_SharedExchange_AddTag(dataStruct, TAG_KERNEL_PAYMENT_FLOW_STOP, KERNEL_PAYMENT_FLOW_STOP_LENGTH, (const unsigned char *)StepInterruption);
   if (cr != STATUS_SHARED_EXCHANGE_OK)
   {
      goto End;
   }


   // Customize steps
   ADD_STEP_CUSTOM(STEP_PAYPASS_MSTRIPE_REMOVE_CARD, StepCustom); // To do GUI when MStripe card has been read
   ADD_STEP_CUSTOM(STEP_PAYPASS_MCHIP_REMOVE_CARD, StepCustom); // To do GUI when MChip card has been read
   ADD_STEP_CUSTOM(STEP_PAYPASS_MCHIP_GET_CERTIFICATE, StepCustom); // To provide the CA key data for ODA
   ADD_STEP_CUSTOM(STEP_PAYPASS_MCHIP_SEND_PHONE_MSG, StepCustom);      // To do GUI when MChip phone has been read
   ADD_STEP_CUSTOM(STEP_PAYPASS_MSTRIPE_SEND_PHONE_MSG, StepCustom); // To do GUI when MStripe phone has been read
   ADD_STEP_CUSTOM(STEP_PAYPASS_CANCEL_DE_PROCESSING, StepCustom); // To allow the application to cancel outstanding DE processing

   // TODO: If BlackList Present  ADD_STEP_CUSTOM(STEP_PAYPASS_MCHIP_EXCEPTION_FILE_GET_DATA, StepCustom);

#ifdef PAYPASS_TORN
   {
      ADD_STEP_CUSTOM(STEP_PAYPASS_MCHIP_IS_TORN_RECORD, StepCustom);      // To check if transaction is in the torn transaction log
      ADD_STEP_CUSTOM(STEP_PAYPASS_MCHIP_ADD_TORN_RECORD, StepCustom);  // To add a transaction in the torn transaction log
      ADD_STEP_CUSTOM(STEP_PAYPASS_MCHIP_REMOVE_TORN_RECORD, StepCustom);  // To remove a transaction from the torn transaction log

      // Add TAG_PAYPASS_MAX_NUMBER_OF_TORN_TXN_LOG_RECORDS
      ucTornMaxRecordNumber = APCLESS_PAYPASS_MAX_NUMBER_OF_TORN_TXN_LOG_RECORDS;
      cr = GTL_SharedExchange_AddTag(dataStruct, TAG_PAYPASS_MAX_NUMBER_OF_TORN_TXN_LOG_RECORDS, 1, &ucTornMaxRecordNumber);
      if (cr != STATUS_SHARED_EXCHANGE_OK)
      {
         goto End;
      }

      // Add data indicating the number of records in the torn transaction log.
      ucTornRecordNumber = CLESS_PayPassTorn_GetNumberOfTornTxnLogRecords();
      if (ucTornRecordNumber > 0)
      {
         cr = GTL_SharedExchange_AddTag(dataStruct, TAG_PAYPASS_NUMBER_OF_TORN_TXN_LOG_RECORDS, 1, &ucTornRecordNumber);
         if (cr != STATUS_SHARED_EXCHANGE_OK)
         {
            goto End;
         }
      }
   }
#endif

   memcpy(sTransactionFlowCustom.pucStepCustom, (void*)StepCustom, KERNEL_PAYMENT_FLOW_CUSTOM_LENGTH);
   sTransactionFlowCustom.usApplicationType = ObjectInfo.application_type; // Kernel will call this application for customisation
   sTransactionFlowCustom.usServiceId = SERVICE_CUSTOM_KERNEL; // Kernel will call SERVICE_CUSTOM_KERNEL service id for customisation

   cr = GTL_SharedExchange_AddTag(dataStruct, TAG_KERNEL_PAYMENT_FLOW_CUSTOM, sizeof(T_KERNEL_TRANSACTION_FLOW_CUSTOM), (const unsigned char *)&sTransactionFlowCustom);
   if (cr != STATUS_SHARED_EXCHANGE_OK)
   {
      goto End;
   }
   result = TRUE;

End:
   return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Activate or not the PayPass kernel debug features..                                   *
 * 			                                                                                      *
 * [in]:    activate                                                                              *
 *           TRUE : activate the PayPass kernel traces                                            *
 *           FALSE : deactivate the PayPass kernel traces                                         *
 * ---------------------------------------------------------------------------------------------- */
static void CLESS_PayPass_DebugActivation(int activate) {
   T_SHARED_DATA_STRUCT* sharedStructure;
   int result;
   unsigned char debugMode = 0x00;

   if (activate)
      debugMode = KERNEL_DEBUG_MASK_TRACES;   // Provide debug information in the Trace.exe tool

   sharedStructure = GTL_SharedExchange_InitShared(256);

   if (sharedStructure != NULL)
   {
      result = GTL_SharedExchange_AddTag(sharedStructure, TAG_KERNEL_DEBUG_ACTIVATION, 1, &debugMode);

      if (result == STATUS_SHARED_EXCHANGE_OK)
      {
         result = PayPass3_DebugManagement(sharedStructure);
      }

      // Destroy the shared buffer
      GTL_SharedExchange_DestroyShare(sharedStructure);
   }
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the PayPass transaction outcome from the Outcome Parameter Set.                   *
 * 			                                                                                      *
 * [in] :   resultDataStruct Structure containing the PayPass 3 kernel output.                    *
 * [out]:   pTransactionOutcome Retrieved transaction outcome :                                   *
 *          - PAYPASS_OPS_STATUS_APPROVED if transaction is approved.                             *
 *          - PAYPASS_OPS_STATUS_ONLINE_REQUEST if an online authorisation is requested.          *
 *          - PAYPASS_OPS_STATUS_DECLINED if the transaction is declined.                         *
 *          - PAYPASS_OPS_STATUS_SELECT_NEXT if next AID shall be selected.                       *
 *          - PAYPASS_OPS_STATUS_TRY_AGAIN transaction shall be restarted from the beginning..    *
 *          - PAYPASS_OPS_STATUS_END_APPLICATION if the transaction is terminated.                *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_PayPass_RetrieveTransactionOutcome(T_SHARED_DATA_STRUCT* resultDataStruct, int* pTransactionOutcome) {
   int result = TRUE;
   int position;
   unsigned long readLength;
   const unsigned char* readValue;

   position = SHARED_EXCHANGE_POSITION_NULL;

   if (pTransactionOutcome != NULL)
      *pTransactionOutcome = PAYPASS_OPS_STATUS_END_APPLICATION;
   if (GTL_SharedExchange_FindNext(resultDataStruct, &position, TAG_PAYPASS_OUTCOME_PARAMETER_SET, &readLength, &readValue) != STATUS_SHARED_EXCHANGE_OK){
      result = FALSE;
      goto End;
   }
   if (pTransactionOutcome != NULL)
      *pTransactionOutcome = readValue[PAYPASS_OPS_STATUS_BYTE];

End:
   return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the start byte from the Outcome Parameter Set.                                    *
 * 			                                                                                      *
 * [in] :   resultDataStruct Structure containing the PayPass 3 kernel output.                    *
 * [out]:   pStart Retrieved start value :                                                        *
 *          - PAYPASS_OPS_START_A if transaction needs to start at A.                             *
 *          - PAYPASS_OPS_START_B if transaction needs to start at B.                             *
 *          - PAYPASS_OPS_START_C if transaction needs to start at C.                             *
 *          - PAYPASS_OPS_START_D if transaction needs to start at D.                             *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_PayPass_RetrieveStart(T_SHARED_DATA_STRUCT* resultDataStruct, int* pStart) {
   int result = TRUE;
   int position;
   unsigned long readLength;
   const unsigned char* readValue;

   position = SHARED_EXCHANGE_POSITION_NULL;

   if (pStart != NULL)
      *pStart = PAYPASS_OPS_START_NA;

   if (GTL_SharedExchange_FindNext(resultDataStruct, &position, TAG_PAYPASS_OUTCOME_PARAMETER_SET, &readLength, &readValue) != STATUS_SHARED_EXCHANGE_OK) {
      result = FALSE;
      goto End;
   }
   if (pStart != NULL)
      *pStart = readValue[PAYPASS_OPS_START_BYTE];

End:
   return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the PayPass Error Indication required byte(extracted from the Discretionary Data) *
 * 			                                                                                      *
 * [in] :   resultDataStruct Structure containing the PayPass 3 kernel output.                    *
 * [in] :   nByteNumber byte number to be returned (shall be in [0;5]).                           *
 * [out]:   pErrorIndicationByte Retrieved byte.Retrieved transaction outcome :                   *
 *          - Value if correctly retrieved.                                                       *
 *          - 0xFF if not.                                                                        *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_PayPass_RetrieveErrorIndicationByte(T_SHARED_DATA_STRUCT* resultDataStruct, const unsigned int nByteNumber, unsigned char* pErrorIndicationByte) {
   int result = FALSE;
   int position;
   unsigned long readLength;
   unsigned char* readValue;

   unsigned long ulEiReadLength;
   const unsigned char* pEiReadValue;
   T_SHARED_DATA_STRUCT tDiscretionaryData;

   // Init output data
   if (pErrorIndicationByte != NULL)
      *pErrorIndicationByte = 0xFF;

   if (nByteNumber > PAYPASS_EI_MSG_ON_ERROR_BYTE)
   {
      goto End;
   }
   // Get the Outcome Parameter Set
   position = SHARED_EXCHANGE_POSITION_NULL;
   if (GTL_SharedExchange_FindNext(resultDataStruct, &position, TAG_PAYPASS_DISCRETIONARY_DATA, &readLength, (const unsigned char **)&readValue) != STATUS_SHARED_EXCHANGE_OK) {
      goto End;
   }
   // Init the shared buffer with the discretionary data buffer
   if (GTL_SharedExchange_InitEx (&tDiscretionaryData, readLength, readLength, readValue) != STATUS_SHARED_EXCHANGE_OK) {
      goto End;
   }
   // Get the Error array
   position = SHARED_EXCHANGE_POSITION_NULL;
   if (GTL_SharedExchange_FindNext (&tDiscretionaryData, &position, TAG_PAYPASS_ERROR_INDICATION, &ulEiReadLength, &pEiReadValue) != STATUS_SHARED_EXCHANGE_OK) {
      goto End;
   }
   // Get the byte number from the EI
   if (pErrorIndicationByte != NULL)
      *pErrorIndicationByte = pEiReadValue[nByteNumber];

   result = TRUE;

End:
   return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the PayPass message to be displayed from the UIRD.                                *
 * 			                                                                                      *
 * [in] :   resultDataStruct Structure containing the PayPass 3 kernel output.                    *
 * [out]:   pUirdMessage Retrieved transaction outcome :                                          *
 *    		- PAYPASS_UIRD_MESSAGE_ID_CARD_READ_OK Indicates the card has been read.              *
 *    		- PAYPASS_UIRD_MESSAGE_ID_TRY_AGAIN Indicates the card has to be presented again.     *
 *    		- PAYPASS_UIRD_MESSAGE_ID_APPROVED Indicates the transaction is approved.             *
 *    		- PAYPASS_UIRD_MESSAGE_ID_APPROVED_SIGN Indicates the transaction is approved but     *
 *    												signature required.                           *
 *    		- PAYPASS_UIRD_MESSAGE_ID_DECLINED Indicates the transaction is declined.             *
 *    		- PAYPASS_UIRD_MESSAGE_ID_ERROR_OTHER_CARD Indicates the an error occurred and the    *
 *    												   cardholder shall use another card.         *
 *    		- PAYPASS_UIRD_MESSAGE_ID_SEE_PHONE Indicates the cardholder shall see his phone for  *
 *    		                                    instructions.                                     *
 *    		- PAYPASS_UIRD_MESSAGE_ID_CLEAR_DISPLAY Indicates the display shall be cleared.       *
 *    		- PAYPASS_UIRD_MESSAGE_ID_NA Message identifier is not applicable.                    *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_PayPass_RetrieveUirdMessage(T_SHARED_DATA_STRUCT* resultDataStruct, int* pUirdMessage) {
   int result = TRUE;
   int position;
   unsigned long readLength;
   const unsigned char* readValue;

   position = SHARED_EXCHANGE_POSITION_NULL;

   if (pUirdMessage != NULL)
      *pUirdMessage = PAYPASS_UIRD_MESSAGE_ID_NA;

   if (GTL_SharedExchange_FindNext(resultDataStruct, &position, TAG_PAYPASS_USER_INTERFACE_REQUEST_DATA, &readLength, &readValue) != STATUS_SHARED_EXCHANGE_OK) {
      result = FALSE;
      goto End;
   }
   if (pUirdMessage != NULL)
      *pUirdMessage = readValue[PAYPASS_UIRD_MESSAGE_ID_BYTE];

End:
   return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the CVM to apply (read from the Outcome Parameter Set                             *
 * 			                                                                                      *
 * [in] :   resultDataStruct Structure containing the PayPass 3 kernel output.                    *
 * [out]:   pCvm Retrieved transaction outcome :                                                  *
 *          - PAYPASS_OPS_CVM_NO_CVM : "No CVM" method has been applied.                          *
 *          - PAYPASS_OPS_CVM_SIGNATURE : "Signature" method has been applied.                    *
 *          - PAYPASS_OPS_CVM_ONLINE_PIN : "Online PIN" method has been applied.                  *
 *          - PAYPASS_OPS_CVM_CONFIRMATION_CODE_VERIFIED : confirmation code has been verified.   *
 *          - PAYPASS_OPS_CVM_NA : if CVM is not applicable.                                      *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_PayPass_RetrieveCvmToApply(T_SHARED_DATA_STRUCT* resultDataStruct, unsigned char* pCvm) {
   int result = TRUE;
   int position;
   unsigned long readLength;
   const unsigned char* readValue;

   position = SHARED_EXCHANGE_POSITION_NULL;

   if (pCvm != NULL)
      *pCvm = PAYPASS_OPS_CVM_NA;
   if (GTL_SharedExchange_FindNext(resultDataStruct, &position, TAG_PAYPASS_OUTCOME_PARAMETER_SET, &readLength, &readValue)!= STATUS_SHARED_EXCHANGE_OK) {
      result = FALSE;
      goto End;
   }
   if (pCvm != NULL)
      *pCvm = readValue[PAYPASS_OPS_CVM_BYTE];

End:
   return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the Field Off value (read from the Outcome Parameter Set).                        *
 * 			                                                                                      *
 * [in] :   resultDataStruct Structure containing the PayPass 3 kernel output.                    *
 * [out]:   pFieldOff Retrieved field off value (in units of 100 ms).                             *
 *          - PAYPASS_OPS_FIELD_OFF_REQUEST_NA if Field Off is not applicable to the case..       *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_PayPass_RetrieveFieldOffValue(T_SHARED_DATA_STRUCT* resultDataStruct, unsigned char* pFieldOff) {
   int result = TRUE;
   int position;
   unsigned long readLength;
   const unsigned char* readValue;

   position = SHARED_EXCHANGE_POSITION_NULL;
   if (pFieldOff != NULL)
      *pFieldOff = PAYPASS_OPS_FIELD_OFF_REQUEST_NA;
   if (GTL_SharedExchange_FindNext(resultDataStruct, &position, TAG_PAYPASS_OUTCOME_PARAMETER_SET, &readLength, &readValue) != STATUS_SHARED_EXCHANGE_OK) {
      result = FALSE;
      goto End;
   }
   if (pFieldOff != NULL)
      *pFieldOff = readValue[PAYPASS_OPS_FIELD_OFF_REQUEST_BYTE];

End:
   return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Get the card type.                                                                    *
 * 			                                                                                      *
 * [in] :   resultDataStruct Structure containing the PayPass 3 kernel output.                    *
 * [out]:   cardType Retrieved card type                                                          *
 *          - 0 If card type not found.                                                           *
 *          - 0x8501 for MStripe card.                                                            *
 *          - 0x8502 for MChip card.                                                              *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_PayPass_RetrieveCardType(T_SHARED_DATA_STRUCT* resultDataStruct, unsigned short* cardType) {
   int result = TRUE;
   int position;
   unsigned long readLength;
   const unsigned char* readValue;

   position = SHARED_EXCHANGE_POSITION_NULL;

   if (cardType != NULL)
      *cardType = 0; // Default result

   if (GTL_SharedExchange_FindNext(resultDataStruct, &position, TAG_KERNEL_CARD_TYPE, &readLength, &readValue) != STATUS_SHARED_EXCHANGE_OK) {
      result = FALSE;
      goto End;
   }
   if (cardType != NULL)
      *cardType = (readValue[0] << 8) + readValue[1];

End:
   return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Check if a receipt is required or not (read from the Outcome Parameter Set).          *
 * 			                                                                                      *
 * [in] :   resultDataStruct Structure containing the PayPass 3 kernel output.                    *
 * [out]:   isReceiptRequired TRUE if the receipt is required, FALSE else.                        *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_PayPass_IsReceiptRequired(T_SHARED_DATA_STRUCT* resultDataStruct, int* isReceiptRequired) {
   int result = TRUE;
   int position;
   unsigned long readLength;
   const unsigned char* readValue;

   position = SHARED_EXCHANGE_POSITION_NULL;
   if (isReceiptRequired != NULL)
      *isReceiptRequired = FALSE;

   if (GTL_SharedExchange_FindNext(resultDataStruct, &position, TAG_PAYPASS_OUTCOME_PARAMETER_SET, &readLength, &readValue) != STATUS_SHARED_EXCHANGE_OK) {
      result = FALSE;
      goto End;
   }
   if (isReceiptRequired != NULL)
      *isReceiptRequired = ((readValue[PAYPASS_OPS_DATA_PRESENCE_BYTE] & PAYPASS_OPS_DATA_PRESENCE_MASK_RECEIPT) == PAYPASS_OPS_DATA_PRESENCE_MASK_RECEIPT);

End:
   return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display the Approved message with the Balance amount (if available from UIRD).        *
 * 			                                                                                      *
 * [in] :   resultDataStruct Structure containing the PayPass 3 kernel output.                    *
 * [return]:   TRUE if no problem occurred.                                                       *
 *             FALSE if not displayed (balance not available, an error occurred).                 *
 * ---------------------------------------------------------------------------------------------- */
static int CLESS_PayPass_DisplayApprovedWithBalance(T_SHARED_DATA_STRUCT* resultDataStruct) {
   int result = FALSE;
   int position, cr;
   unsigned long readLength;
   const unsigned char* readValue;
   //unsigned char* pCurrencyCode;

   // Get the Outcome Parameter Set
   position = SHARED_EXCHANGE_POSITION_NULL;
   cr = GTL_SharedExchange_FindNext(resultDataStruct, &position, TAG_PAYPASS_USER_INTERFACE_REQUEST_DATA, &readLength, &readValue);
   if (cr != STATUS_SHARED_EXCHANGE_OK)
   {
      goto End;
   }

   // Get the Balance value and format the message to display
   if(readValue[PAYPASS_UIRD_VALUE_QUALIFIER_BYTE] == PAYPASS_UIRD_VALUE_QUALIFIER_BALANCE) {
	  // TODO: Uncomment to get the currency code
      //pCurrencyCode = (unsigned char *) (&readValue[PAYPASS_UIRD_CURRENCY_CODE_OFFSET]);

      // TODO: Get the currency label and exponent from the parameters. If not found, indicate an invalid parameter as the currency code provided is unknown from the application.

      // TODO: Retrieve the format of the money (currency position, separator, ...)

      // Display the message with the balance amount
	   CLESS_GUI_DisplayScreenWithBalance(APCLESS_PAYPASS_SCREEN_APPROVED, "USD", 2, &(readValue[PAYPASS_UIRD_VALUE_OFFSET]), PAYPASS_UIRD_VALUE_LENGTH);

      result = TRUE;
   }

End:
   return result;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Add the transaction data record to the batch.                                         *
 * 			                                                                                      *
 * [in,out]: sharedData Shared buffer to be used to retrieve the data record.                     *
 * ---------------------------------------------------------------------------------------------- */
static void CLESS_PayPass_AddRecordToBatch(T_SHARED_DATA_STRUCT * sharedData) {
   int result;

   // TODO: Get transaction data and add them to the batch

   // Note : here we are using PayPass3_GetData() but it is also possible to use PayPass3_GetAllData()

   // Clear the shared exchange buffer
   GTL_SharedExchange_ClearEx (sharedData, FALSE);

   // Add the needed tags : Data Record and Discretionary Data
   result = GTL_SharedExchange_AddTag(sharedData, TAG_PAYPASS_DATA_RECORD, 0, NULL);
   if (result != STATUS_SHARED_EXCHANGE_OK)
   {
      goto End;
   }
   result = GTL_SharedExchange_AddTag(sharedData, TAG_PAYPASS_DISCRETIONARY_DATA, 0, NULL);
   if (result != STATUS_SHARED_EXCHANGE_OK)
   {
      goto End;
   }

   // Get the tags from the kernel
   result = PayPass3_GetData(sharedData);
   if (result == KERNEL_STATUS_OK)
   {
      // TODO: Now we have the needed transaction data, add them in the batch
      // ...

   }

End:

   if (result != KERNEL_STATUS_OK) {
      // TODO: Manage error case
   }
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Display a specific message according to the UIRD.                                     *
 * 			                                                                                      *
 * [in] :   dataStruct Shared buffer containing the UIRD, containing itself the message to be     *
 *          displayed.                                                                            *
 * [in]:    isPhoneMessage TRUE if function called when displaying phone message FALSE else.      *
 * ---------------------------------------------------------------------------------------------- */
static void CLESS_PayPass_DisplayUirdMsg(T_SHARED_DATA_STRUCT* dataStruct, const int isPhoneMessage) {
   int uirdMessage;

   // Get the UIRD message to be displayed
   if (!CLESS_PayPass_RetrieveUirdMessage (dataStruct, &uirdMessage))
      uirdMessage = PAYPASS_UIRD_MESSAGE_ID_NA;

   switch (uirdMessage) {
      case PAYPASS_UIRD_MESSAGE_ID_CARD_READ_OK:
    	 CLESS_GUI_DisplayScreen(APCLESS_SCREEN_REMOVE_CARD);
         break;
      case PAYPASS_UIRD_MESSAGE_ID_TRY_AGAIN:
    	 CLESS_GUI_DisplayScreen(APCLESS_SCREEN_RETRY);
         break;
      case PAYPASS_UIRD_MESSAGE_ID_APPROVED:
    	 CLESS_GUI_DisplayScreen(APCLESS_PAYPASS_SCREEN_APPROVED);
         break;
      case PAYPASS_UIRD_MESSAGE_ID_APPROVED_SIGN:
    	 CLESS_GUI_DisplayScreen(APCLESS_PAYPASS_SCREEN_SIGNATURE_OK);
         break;
      case PAYPASS_UIRD_MESSAGE_ID_DECLINED:
    	 CLESS_GUI_DisplayScreen(APCLESS_PAYPASS_SCREEN_DECLINED);
         break;
      case PAYPASS_UIRD_MESSAGE_ID_ERROR_OTHER_CARD:
    	 CLESS_GUI_DisplayScreen(APCLESS_SCREEN_ERROR);
         break;
      case PAYPASS_UIRD_MESSAGE_ID_SEE_PHONE:
         // Request cardholder to follow his phone for instructions
    	 CLESS_GUI_DisplayScreen(APCLESS_PAYPASS_SCREEN_PHONE_INSTRUCTIONS);

         if (isPhoneMessage) {
            // Indicate double tap is in progress
        	 CLESS_Txn_SetDoubleTapInProgress(TRUE);
         }
         break;
      case PAYPASS_UIRD_MESSAGE_ID_AUTHORISING_PLEASE_WAIT:
    	  CLESS_GUI_DisplayScreen(APCLESS_PAYPASS_SCREEN_AUTHORISING);
         break;
      case PAYPASS_UIRD_MESSAGE_ID_INSERT_CARD:
    	  CLESS_GUI_DisplayScreen(APCLESS_SCREEN_USE_CONTACT);
         break;
      case PAYPASS_UIRD_MESSAGE_ID_CLEAR_DISPLAY:
    	  CLESS_GUI_DisplayScreen(APCLESS_SCREEN_EMPTY);
         break;
      default:
         break;
   }
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Calls the PayPass kernel to perform the transaction.                                  *
 * 			                                                                                      *
 * [in] :   dataStruct Data buffer to be filled and used for PayPass transaction.                 *
 * [out]:   return - status of the PayPass kernel execution (CLESS_CR_MANAGER_xxx status)         *
 * ---------------------------------------------------------------------------------------------- */
int CLESS_PayPass_PerformTransaction(T_SHARED_DATA_STRUCT* dataStruct) {
   int result = CLESS_CR_MANAGER_END;
   int cr;
   int transactionOutcome;
   int transactionStart;
   int receiptRequired;
   unsigned char cvm, fieldOff;
   unsigned char saveInBatch = FALSE;
   unsigned short cardType = 0;
   int mobileTransaction;
   int uirdMessage;
   unsigned char errorIndicationByte;
   int performDeselect = TRUE;
   unsigned int nNumOfCards;


   // Indicate PayPass kernel is going to be used (for customisation purposes)
   CLESS_Txn_SetCurrentPaymentScheme (APCLESS_SCHEME_PAYPASS);

   // Init PayPass kernel debug traces
   CLESS_PayPass_DebugActivation(CLESS_Txn_GetDebugTrace());

   // Get the PayPass
   if(CLESS_PayPass_AddPayPassSpecificData(dataStruct)) {
      cr = PayPass3_DoTransaction(dataStruct);

      if (!CLESS_PayPass_RetrieveTransactionOutcome(dataStruct, &transactionOutcome))
         transactionOutcome = PAYPASS_OPS_STATUS_END_APPLICATION;
      if (CLESS_PayPass_RetrieveCvmToApply (dataStruct, &cvm)){
        	 if(cvm == PAYPASS_OPS_CVM_ONLINE_PIN)
				setCHVerificationMethod(ONLINE_PIN);
			else if(cvm == PAYPASS_OPS_CVM_SIGNATURE)
				setCHVerificationMethod(PAPER_SIGNATURE);
			else if(cvm == PAYPASS_OPS_CVM_CONFIRMATION_CODE_VERIFIED)
				setCHVerificationMethod(OFF_ENCIPHER_PIN);
			else{
				setCHVerificationMethod(NO_AUTHENTICATION);
                cvm = PAYPASS_OPS_CVM_NA;
			}
      }
      if (!CLESS_PayPass_RetrieveFieldOffValue(dataStruct, &fieldOff))
         fieldOff = PAYPASS_OPS_FIELD_OFF_REQUEST_NA;
      if (!CLESS_PayPass_RetrieveCardType(dataStruct, &cardType))
         cardType = 0;
      if (!CLESS_PayPass_IsReceiptRequired(dataStruct, &receiptRequired))
         receiptRequired = FALSE;
      if (!CLESS_PayPass_RetrieveUirdMessage(dataStruct, &uirdMessage))
         uirdMessage = PAYPASS_UIRD_MESSAGE_ID_NA;
      if (!CLESS_PayPass_RetrieveStart(dataStruct, &transactionStart))
         transactionStart = PAYPASS_OPS_START_NA;

      //For Refund Txn
      if (!strcmp (getTransactionType(), "REFUND"))
    	  transactionOutcome = PAYPASS_OPS_STATUS_ONLINE_REQUEST;

      // Additional possible processing :
      // - Perform an online authorisation if necessary
      // - Save the transaction in the batch if transaction is accepted
      // - Perform CVM processing if necessary

      // Check if a mobile transaction has been performed
      mobileTransaction = ((cardType & PAYPASS_B2_MASK_ON_DEVICE_CVM_SUPPORTED) == PAYPASS_B2_MASK_ON_DEVICE_CVM_SUPPORTED);
      if((mobileTransaction == 1) && (transactionOutcome == PAYPASS_OPS_STATUS_DECLINED))
    	  transactionOutcome = PAYPASS_OPS_STATUS_ONLINE_REQUEST;


      switch (transactionOutcome) {
         case PAYPASS_OPS_STATUS_APPROVED:
         case PAYPASS_OPS_STATUS_DECLINED:
         case PAYPASS_OPS_STATUS_TRY_ANOTHER_INTERFACE:
         case PAYPASS_OPS_STATUS_ONLINE_REQUEST:
        	 // Messages display and processing will be performed after the field is closed
            break;

         case PAYPASS_OPS_STATUS_TRY_AGAIN:
            // Transaction shall be silently restarted from the beginning
            result = CLESS_CR_MANAGER_RESTART_NO_MESSAGE_BEFORE_RETRY;

            // Do not perform deselect when a silent restart needs to be performed
            performDeselect = FALSE;
            break;

         case PAYPASS_OPS_STATUS_SELECT_NEXT:
            // The next AID shall be selected in the candidate list
            result = CLESS_CR_MANAGER_REMOVE_AID;
            break;

         default: // Error case
            // Check if the transaction must be restarted
            if ((transactionOutcome == PAYPASS_OPS_STATUS_END_APPLICATION) && (transactionStart == PAYPASS_OPS_START_B)) {
               performDeselect = FALSE;

               CLESS_PayPass_RetrieveErrorIndicationByte(dataStruct, PAYPASS_EI_L1_BYTE, &errorIndicationByte);

               // Check if the restart is due to a communication error with the card
               if((uirdMessage == PAYPASS_UIRD_MESSAGE_ID_TRY_AGAIN) && (errorIndicationByte != PAYPASS_EI_L1_OK)) {
                  // Display a message and wait card removal
                  if(fieldOff == PAYPASS_OPS_FIELD_OFF_REQUEST_NA) {
                	  CLESS_GUI_DisplayScreen(APCLESS_PAYPASS_SCREEN_WAIT_CARD_REMOVAL);
                     ClessEmv_DeselectCard(0, TRUE, TRUE);
                  }

                  if (CLESS_Txn_GetDoubleTapInProgress())
                	  CLESS_GUI_DisplayScreen(APCLESS_SCREEN_PHONE_INSTRUCTIONS_RETRY);
                  else {
                     if (CLESS_Selection_GetMethod() == APCLESS_SELECTION_EXPLICIT)
                    	 CLESS_GUI_DisplayScreen(APCLESS_SCREEN_RETRY);
                  }

                  // Transaction shall be restarted from the beginning
                  result = CLESS_CR_MANAGER_RESTART;
               }
               else {
                  // Message has already been displayed in the customisation of steps STEP_PAYPASS_MCHIP_SEND_PHONE_MSG and STEP_PAYPASS_MSTRIPE_SEND_PHONE_MSG

                  // Wait card removal
                  if(fieldOff == PAYPASS_OPS_FIELD_OFF_REQUEST_NA)
                     ClessEmv_DeselectCard(0, TRUE, TRUE);

                  if (CLESS_Txn_GetDoubleTapInProgress())
                     result = CLESS_CR_MANAGER_RESTART_DOUBLE_TAP;
                  else
                     result = CLESS_CR_MANAGER_RESTART;
               }
            }
            else // Standard error case
            {
               CLESS_PayPass_RetrieveErrorIndicationByte(dataStruct, PAYPASS_EI_L3_BYTE, &errorIndicationByte);

               if (!((transactionOutcome == PAYPASS_OPS_STATUS_END_APPLICATION) && ((errorIndicationByte == PAYPASS_EI_L3_STOP) ||
            		   (uirdMessage == PAYPASS_UIRD_MESSAGE_ID_CLEAR_DISPLAY)))) {
                  // Indicate an error occurred (transaction is terminated)
            	   CLESS_GUI_DisplayScreen(APCLESS_SCREEN_ERROR);
               }

               // Indicate double tap is not in progress
               CLESS_Txn_SetDoubleTapInProgress(FALSE);
            }
            break;
      }
      if(result != CLESS_CR_MANAGER_REMOVE_AID) {
         // After the transaction, turn off the field during the time requested in the OPS
         if(fieldOff != PAYPASS_OPS_FIELD_OFF_REQUEST_NA) {
            ClessEmv_CloseDriver();
            if(fieldOff != 0)
            	Telium_Ttestall(0, fieldOff * 10);
         }
         else {
            if (transactionStart == PAYPASS_OPS_START_NA) {
               // Card presence in the field will be checked after all the end of transaction processing is performed (receipt, online authorisation, etc.).
               ClessEmv_CloseDriver();
            }
         }
      }


      /* ------------------------------------------------------------------------------- *
       * Processing to perform after the field has been turned off                       *
       * ------------------------------------------------------------------------------- */
      switch (transactionOutcome) {
         case PAYPASS_OPS_STATUS_APPROVED:
        	if (cvm == PAYPASS_OPS_CVM_SIGNATURE) {
        		CLESS_GUI_DisplayScreen(APCLESS_PAYPASS_SCREEN_SIGNATURE_REQUIRED);
			}
			else {
			   // Display Approved message and, if available, the balance amount
			   if(FALSE == CLESS_PayPass_DisplayApprovedWithBalance(dataStruct))
				   CLESS_GUI_DisplayScreen(APCLESS_PAYPASS_SCREEN_APPROVED);
			}
            PayPass3_GetAllData(dataStruct); // Get all the kernel data to print the receipt

            // TODO: Print the receipt...

            // If the selected CVM is signature
            if (cvm == PAYPASS_OPS_CVM_SIGNATURE) {
                  // TODO: Ask merchant if signature is OK
                  // if yes  bSaveInBatch = TRUE;
            }
            break;

         case PAYPASS_OPS_STATUS_DECLINED:
            // Display the message located in the UIRD (DECLINED, INSERT CARD or CLEAR DISPLAY)
            CLESS_PayPass_DisplayUirdMsg (dataStruct, FALSE);
            break;

         case PAYPASS_OPS_STATUS_TRY_ANOTHER_INTERFACE:
            // Display the message located in the UIRD
            CLESS_PayPass_DisplayUirdMsg (dataStruct, FALSE);
            break;

         case PAYPASS_OPS_STATUS_ONLINE_REQUEST:
        	PayPass3_GetAllData(dataStruct);
        	PayPass_OnlineRequestData(dataStruct, cardType);
        	// TODO: Check if PIN online is required and manage it.
        	if (getCHVerificationMethod() == ONLINE_PIN ){
				int pinLength;
				switch (APEMV_UI_PinEntry (INPUT_PIN_ON, 3, &pinLength)) {
					case EPSTOOL_PINENTRY_SUCCESS:
						if (encryptPIN() == FALSE)
							setErrorCode("ERROR:033");
						break;
					case EPSTOOL_PINENTRY_TIMEOUT:
						setErrorCode("ERROR:013");
						break;
					case EPSTOOL_PINENTRY_ERROR:
					case EPSTOOL_PINENTRY_CANCEL:
						setErrorCode("ERROR:044");
						break;
					case EPSTOOL_PINENTRY_EVENT:
					case EPSTOOL_PINENTRY_BYPASS:
					default:
						break;
					}
        		}

        	CLESS_GUI_DisplayScreen(APCLESS_SCREEN_ONLINE_PROCESSING);
            break;

         case PAYPASS_OPS_STATUS_TRY_AGAIN:
         case PAYPASS_OPS_STATUS_SELECT_NEXT:
         default: // Error case
        	// All required processing has been done before
            break;
      }
      if(result != CLESS_CR_MANAGER_REMOVE_AID) {
         // After the transaction, turn off the field during the time requested in the OPS
         if ((fieldOff == PAYPASS_OPS_FIELD_OFF_REQUEST_NA) && (transactionStart == PAYPASS_OPS_START_NA)) {
        	 if (performDeselect) {
        		 if (TRUE != ClessEmv_IsDriverOpened()) {
        			 if (CL_OK == ClessEmv_OpenDriver()) {
        				 nNumOfCards = 1;
        				 if (CL_OK == ClessEmv_DetectCards(CL_TYPE_AB, &nNumOfCards, 0)) {
        					 if (CL_OK == ClessEmv_ActiveCard(0, CL_ISO14443_4)) {
        						 ClessEmv_DeselectCard(0, TRUE, TRUE);
        					 }
        				 }
        				 ClessEmv_CloseDriver();
        			 }
        		 }
        	 }
         }
         // Turn on the 1st LED only
         if ((result == CLESS_CR_MANAGER_RESTART) || (result == CLESS_CR_MANAGER_RESTART_DOUBLE_TAP)) {
        	 CLESS_GUI_IndicatorWait();
         }
      }
      // If transaction shall be save in the batch, save it
      if (saveInBatch) {
         CLESS_PayPass_AddRecordToBatch(dataStruct);
      }

      // If the transaction does not restart from the beginning, set the LEDs into the idle state
      if ((result != CLESS_CR_MANAGER_RESTART) && (result != CLESS_CR_MANAGER_RESTART_NO_MESSAGE_BEFORE_RETRY) && (result != CLESS_CR_MANAGER_REMOVE_AID) && (result != CLESS_CR_MANAGER_RESTART_DOUBLE_TAP)) {
    	  CLESS_Txn_IncrementTsc();
      }
   }
   PayPass3_Clear ();
   return result;
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose: Perform PayPass 3 kernel customization                                            *
 * 			                                                                                  *
 * [in] :   ucCustomisationStep Step to be customized.                                        *
 * [out]:   sharedData Shared buffer used for customization.                                  *
 * ------------------------------------------------------------------------------------------ */
int CLESS_PayPass_KernelCustomiseStep(T_SHARED_DATA_STRUCT* sharedData, const unsigned char ucCustomisationStep) {
   int result = KERNEL_STATUS_CONTINUE;
   unsigned char keyIndex;
   unsigned char rid[7] = {0};
   unsigned char Modulus [255] = {0};
   unsigned int ModulusLength = 0;
   unsigned char Exponent [3] = {0};
   unsigned int ExponentLength = 0;
   unsigned short found;
   unsigned long readLength;
   int position;
   const unsigned char* readValue;

   switch (ucCustomisationStep)  {
      case STEP_PAYPASS_MSTRIPE_REMOVE_CARD:
      case STEP_PAYPASS_MCHIP_REMOVE_CARD:
    	  CLESS_GUI_DisplayScreen(APCLESS_SCREEN_REMOVE_CARD);
         GTL_SharedExchange_ClearEx (sharedData, FALSE);
         result = KERNEL_STATUS_CONTINUE;
         break;

      case STEP_PAYPASS_MCHIP_GET_CERTIFICATE:
         position = SHARED_EXCHANGE_POSITION_NULL;
         if (GTL_SharedExchange_FindNext(sharedData, &position, TAG_EMV_CA_PUBLIC_KEY_INDEX_CARD, &readLength, (const unsigned char **)&readValue) == STATUS_SHARED_EXCHANGE_OK)
            keyIndex = readValue[0];

         position = SHARED_EXCHANGE_POSITION_NULL;
         if (GTL_SharedExchange_FindNext(sharedData, &position, TAG_PAYPASS_INT_RID, &readLength, (const unsigned char **)&readValue) == STATUS_SHARED_EXCHANGE_OK) {
        	 memcpy (rid +1, readValue, 5);
        	 memcpy (rid, "\x05", 1);
         }
         GTL_SharedExchange_ClearEx (sharedData, FALSE);
         if (strlen(rid) && keyIndex != 0) {
             found = getCertificationAuthorityPublicKey (rid,
     													keyIndex,
     													Modulus,
     													&ModulusLength,
     													Exponent,
     													&ExponentLength);
             if (found) {
            	 if (GTL_SharedExchange_AddTag(sharedData, TAG_EMV_INT_CAPK_MODULUS, ModulusLength, Modulus) != STATUS_SHARED_EXCHANGE_OK) {
            		 GTL_SharedExchange_ClearEx(sharedData, FALSE);
            		 return;
            	 }
            	 if (GTL_SharedExchange_AddTag(sharedData, TAG_EMV_INT_CAPK_EXPONENT, ExponentLength, Exponent) != STATUS_SHARED_EXCHANGE_OK) {
            		 GTL_SharedExchange_ClearEx(sharedData, FALSE);
            		 return;
            	 }
             }
         }
         result = KERNEL_STATUS_CONTINUE;
         break;

      case STEP_PAYPASS_MCHIP_EXCEPTION_FILE_GET_DATA:
         // TODO:  Check if PAN is in the exception file
         result = KERNEL_STATUS_CONTINUE;
         break;

      case STEP_PAYPASS_MCHIP_SEND_PHONE_MSG:
      case STEP_PAYPASS_MSTRIPE_SEND_PHONE_MSG:
         CLESS_PayPass_DisplayUirdMsg(sharedData, TRUE);
         GTL_SharedExchange_ClearEx(sharedData, FALSE);
         result = KERNEL_STATUS_CONTINUE;
         break;
      case (STEP_PAYPASS_CANCEL_DE_PROCESSING):
			CLESS_PayPass_DisplayUirdMsg(sharedData, TRUE);
		    GTL_SharedExchange_ClearEx(sharedData, FALSE);
			result = KERNEL_STATUS_CONTINUE;

#ifdef PAYPASS_TORN
      case STEP_PAYPASS_MCHIP_IS_TORN_RECORD:
         if(!CLESS_PayPassTorn_IsTornTxn(sharedData))
            GTL_SharedExchange_ClearEx (sharedData, FALSE);

         result = KERNEL_STATUS_CONTINUE;
         break;

      case STEP_PAYPASS_MCHIP_ADD_TORN_RECORD:
         if(!CLESS_PayPassTorn_AddRecord(sharedData))
            GTL_SharedExchange_ClearEx (sharedData, FALSE);

         result = KERNEL_STATUS_CONTINUE;
         break;

      case STEP_PAYPASS_MCHIP_REMOVE_TORN_RECORD:
    	  CLESS_PayPassTorn_RemoveRecord();

         GTL_SharedExchange_ClearEx (sharedData, FALSE);

         result = KERNEL_STATUS_CONTINUE;
         break;
#endif

      default:
         break;
    }
    return result;
}
/* --------------------------------------------------------------------------------------------- *
* Purpose: Prepare EMV Data block. The following EMV tag may be sent in EMV request block.   	 *
* ---------------------------------------------------------------------------------------------- */
int PayPass_OnlineRequestData(T_SHARED_DATA_STRUCT* dataStruct, unsigned short cardType) {
	int result = TRUE;
	unsigned long length;
	const unsigned char* ptValue;
	int position;

	typedef struct{
		unsigned long tagNum;
		unsigned char tagName[2];
		int tagNameLength;
		int tagDataMinLen;
		int mandatoryFlag;
	}EMVTags;

	EMVTags PayPassRequestTags [] =
	   {{TAG_EMV_AIP,                        	"\x82",     1, 2, TRUE},
		{TAG_EMV_DF_NAME,                    	"\x84",     1, 5, TRUE},
		{TAG_EMV_TVR,                        	"\x95",     1, 5, TRUE},
		{TAG_EMV_TRANSACTION_DATE,           	"\x9A",     1, 3, TRUE},
		{TAG_EMV_TRANSACTION_TYPE,           	"\x9C",     1, 1, TRUE},
		{TAG_EMV_TRANSACTION_CURRENCY_CODE,  	"\x5F\x2A", 2, 2, TRUE},
		{TAG_EMV_AMOUNT_AUTH_NUM,            	"\x9F\x02", 2, 6, TRUE},
		{TAG_EMV_AMOUNT_OTHER_NUM,           	"\x9F\x03", 2, 6, TRUE},
		{TAG_EMV_ISSUER_APPLI_DATA,    			"\x9F\x10", 2, 0, TRUE},
		{TAG_EMV_TERMINAL_COUNTRY_CODE,      	"\x9F\x1A", 2, 2, TRUE},
		{TAG_EMV_APPLICATION_CRYPTOGRAM,      	"\x9F\x26", 2, 8, TRUE},
		{TAG_EMV_CRYPTOGRAM_INFO_DATA,			"\x9F\x27", 2, 1, TRUE},
		{TAG_EMV_ATC,                        	"\x9F\x36", 2, 2, TRUE},
		{TAG_EMV_UNPREDICTABLE_NUMBER,       	"\x9F\x37", 2, 4, TRUE},
		{TAG_EMV_POS_ENTRY_MODE, 		 		"\x9F\x39", 2, 1, TRUE},
		{TAG_EMV_TERMINAL_CAPABILITIES,      	"\x9F\x33", 2, 3, FALSE},
		{TAG_EMV_CVM_RESULTS,                 	"\x9F\x34", 2, 3, FALSE},
		{TAG_EMV_TERMINAL_TYPE,              	"\x9F\x35", 2, 1, FALSE},
		{TAG_EMV_ADD_TERMINAL_CAPABILITIES,  	"\x9F\x40", 2, 5, FALSE},
		{TAG_EMV_AID_CARD, 				 		"\x4F",     1,16, FALSE},
		{TAG_EMV_AID_TERMINAL, 		         	"\x9F\x06", 2,16, FALSE},
		{TAG_EMV_TSI, 						 	"\x9B",     1, 2, FALSE},
		{TAG_EMV_TRANSACTION_TIME, 		     	"\x9F\x21", 2, 3, FALSE},
		{TAG_EMV_APPLI_PAN_SEQUENCE_NUMBER,		"\x5F\x34", 2, 1, FALSE},
		{TAG_EMV_IFD_SERIAL_NUMBER,				"\x9F\x1E", 2, 8, FALSE},
		{TAG_EMV_TRANSACTION_CURRENCY_EXPONENT,	"\x5F\x36", 2, 1, FALSE},
		{TAG_EMV_APPLI_VERSION_NUMBER_TERM,		"\x9F\x09", 2, 2, FALSE},
		{TAG_EMV_APPLI_PAN,						"\x5A", 	1,10, FALSE},
		{TAG_EMV_TRANSACTION_SEQUENCE_COUNTER,	"\x9F\x41", 2, 4, FALSE},
		{TAG_EMV_APPLI_EXPIRATION_DATE,			"\x5F\x24", 2, 3, FALSE},
		{TAG_EMV_TRACK_2_EQU_DATA,				"\x57",     1,37, FALSE},
		{TAG_EMV_SERVICE_CODE,					"\x5F\x30", 2, 2, FALSE},
		{TAG_EMV_CARDHOLDER_NAME,				"\x5F\x20", 2,26, FALSE},
		{TAG_EMV_ICC_DYNAMIC_NUMBER,			"\x9F\x4C", 2, 0, FALSE},
		{TAG_PAYPASS_TRACK2_DATA,				"\x9F\x6B", 2, 0, FALSE},
		{TAG_PAYPASS_MERCHANT_CUSTOM_DATA,		"\x9F\x7C", 2, 0, FALSE},
		{TAG_PAYPASS_TRANSACTION_CATEGORY_CODE, "\x9F\x53", 2, 0, FALSE},
	 	{TAG_PAYPASS_THIRD_PARTY_DATA,          "\x9F\x6E", 2, 0, FALSE}};

	 if (cardType == 0x8502 || cardType == 0x8582) {
		setCardInputMode (EMVCONTACTLESS);
    	unsigned char dataEMV[256] = {0};
    	int i, j = 0;
    	int tagCount = sizeof(PayPassRequestTags) / sizeof(PayPassRequestTags[0]);
    	length = 0;
    	position = SHARED_EXCHANGE_POSITION_NULL;
    	unsigned char poscode[1] = {0};
		char  posencode[2]="07";
		Aschex(poscode,posencode, sizeof(posencode));
		GTL_SharedExchange_AddTag(dataStruct, TAG_EMV_POS_ENTRY_MODE, sizeof(poscode), poscode);
    	for (i = 0; i < tagCount; i++){
    		length = 0;
    		position = SHARED_EXCHANGE_POSITION_NULL;
    		if (dataStruct->ulDataLength)
    			GTL_SharedExchange_FindNext(dataStruct, &position, PayPassRequestTags[i].tagNum, &length, &ptValue);

    		if (length != 0){
    			memcpy (&dataEMV[j], PayPassRequestTags[i].tagName, PayPassRequestTags[i].tagNameLength);
    			memcpy (&dataEMV[j + PayPassRequestTags[i].tagNameLength], &length, 1);
    			memcpy (&dataEMV[j + PayPassRequestTags[i].tagNameLength + 1], ptValue, length);
    			j = j + PayPassRequestTags[i].tagNameLength + 1 + length;
    		}
    		else {
    			if (PayPassRequestTags[i].mandatoryFlag == TRUE) {
    				memcpy (&dataEMV[j], PayPassRequestTags[i].tagName, PayPassRequestTags[i].tagNameLength);
    				memcpy (&dataEMV[j + PayPassRequestTags[i].tagNameLength], &PayPassRequestTags[i].tagDataMinLen, 1);
    				memset (&dataEMV[j + PayPassRequestTags[i].tagNameLength + 1], 0, PayPassRequestTags[i].tagDataMinLen);
    				j = j + PayPassRequestTags[i].tagNameLength + 1 + PayPassRequestTags[i].tagDataMinLen;
    			}
    		}
    	}
    	setRequestEMVData(dataEMV, j);

    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_TRANSACTION_CURRENCY_CODE, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
		}

		// Set EMV Application Label
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_APPLICATION_LABEL, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char app[17] = {0};
			memcpy(app,ptValue,length);
			setEMVApplicationLabel(app);
		}
		// set EMV Application Identifier (AID)
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_DF_NAME, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char aid[33] = {0};
			memcpy (aid, hexToASCII(ptValue,length), length*2);
			setEMVApplicationIdentifier (aid);
		}
		// Set Transaction Status Information(TSI)
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_TSI, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char tsi[5] = {0};
			memcpy(tsi,ptValue,length);
			setEMVTransactionStatusInformation(tsi);
		}
    	// Get Card Number (Tag 5A)
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_APPLI_PAN, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char cardNo [20] = {0};
			Hexasc (cardNo, ptValue, length*2);
			int n;
			for (n = 0; n < length*2; n++) {
				if ((int)cardNo[n] < 48 || (int)cardNo[n] > 57)
					cardNo[n] = '\x00';
			}
			setCardNumber(cardNo, strlen(cardNo));
		}
		// Get Card Holder Name
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_CARDHOLDER_NAME, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			setCardHolderName (ptValue, length);
		}
		// Set Expiration Date.
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_APPLI_EXPIRATION_DATE, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char cardAppExp[5] = {0};
			Hexasc(cardAppExp, ptValue, 4);
			setCardExpiryDate(cardAppExp);
		}
		// Get Track Data (Tag 57)
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_EMV_TRACK_2_EQU_DATA, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char tag57 [40] = {0};
			memcpy (tag57, unsignedCharToASCII(ptValue,length), length*2);
			int trackLength = 0;
			if (tag57 [0] != 'B'){
				char temp [40] = {0};
				temp [0] = 'B';
				memcpy (temp+1, tag57, length*2);
				trackLength = length*2 + 1;
				memcpy (tag57, temp, trackLength);
				if (tag57 [strlen(tag57) - 1] != 'F'){
					tag57 [strlen(tag57)] = 'F';
					trackLength = trackLength + 1;
				}
			}
			else
				trackLength = length*2;

			char *pcSrc = NULL, *pcDst = NULL;
			char tcTrk2[40] = {'\0'};
			pcSrc = tag57;
			pcDst = tcTrk2;
			while(*pcSrc) {                                  // Find start sentinel
				if(*pcSrc++ == 'B'){
					*pcDst++ = ';';
					break;
				}
			}
			while(*pcSrc) {                                  // Copy all data between start and end sentinels
				if(*pcSrc == 'F'){
					*pcDst = '?';
					break;
				}
				if(*pcSrc == 'D')
					*pcSrc = '=';
				*pcDst++ = *pcSrc++;
			}
			setTrack2Data(tcTrk2, trackLength);
		}

    }
    else if (cardType == 0x8501 || cardType == 0x8581) {
    	setCardInputMode (MSRCONTACTLESS);

    	/**************TLV Data for Mobile Device Type******************* */
		 unsigned char dataEMV[256] = {0};
		int i, j = 0;
		int tagCount = sizeof(PayPassRequestTags) / sizeof(PayPassRequestTags[0]);
		length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		unsigned char poscode[1] = {0};
		char  posencode[2]="07";
		Aschex(poscode,posencode, sizeof(posencode));
		GTL_SharedExchange_AddTag(dataStruct, TAG_EMV_POS_ENTRY_MODE, sizeof(poscode), poscode);
		for (i = 0; i < tagCount; i++){
			length = 0;
			position = SHARED_EXCHANGE_POSITION_NULL;
			if (dataStruct->ulDataLength)
				GTL_SharedExchange_FindNext(dataStruct, &position, PayPassRequestTags[i].tagNum, &length, &ptValue);

			if (length != 0){
				memcpy (&dataEMV[j], PayPassRequestTags[i].tagName, PayPassRequestTags[i].tagNameLength);
				memcpy (&dataEMV[j + PayPassRequestTags[i].tagNameLength], &length, 1);
				memcpy (&dataEMV[j + PayPassRequestTags[i].tagNameLength + 1], ptValue, length);
				j = j + PayPassRequestTags[i].tagNameLength + 1 + length;
			}
			else {
				if (PayPassRequestTags[i].mandatoryFlag == TRUE) {
					memcpy (&dataEMV[j], PayPassRequestTags[i].tagName, PayPassRequestTags[i].tagNameLength);
					memcpy (&dataEMV[j + PayPassRequestTags[i].tagNameLength], &PayPassRequestTags[i].tagDataMinLen, 1);
					memset (&dataEMV[j + PayPassRequestTags[i].tagNameLength + 1], 0, PayPassRequestTags[i].tagDataMinLen);
					j = j + PayPassRequestTags[i].tagNameLength + 1 + PayPassRequestTags[i].tagDataMinLen;
				}
			}
		}
		setRequestEMVData(dataEMV, j);

    	 /****************************TLV Data for Mobile Device Type End ******************/
		setCHVerificationMethod (getCardType() == CREDIT	? PAPER_SIGNATURE 	:
								(getCardType() == DEBIT  	? ONLINE_PIN 		:
														  	  NO_AUTHENTICATION));
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_PAYPASS_TRACK2_DATA, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			char tag57 [40] = {0};
			memcpy (tag57, unsignedCharToASCII(ptValue,length), length*2);
			int trackLength = 0;
			if (tag57 [0] != 'B'){
				char temp [40] = {0};
				temp [0] = 'B';
				memcpy (temp+1, tag57, length*2);
				trackLength = length*2 + 1;
				memcpy (tag57, temp, trackLength);
			}
			else
				trackLength = length*2;

			char *pcSrc = NULL, *pcDst = NULL;
			char tcTrk2[40] = {'\0'};
			pcSrc = tag57;
			pcDst = tcTrk2;
			while(*pcSrc) {                                  // Find start sentinel
				if(*pcSrc++ == 'B'){
					*pcDst++ = ';';
					break;
				}
			}
			while(*pcSrc) {                                  // Copy all data between start and end sentinels
				if(*pcSrc == 'F'){
					*pcDst = '?';
					break;
				}
				if(*pcSrc == 'D')
					*pcSrc = '=';
				*pcDst++ = *pcSrc++;
			}
			setTrack2Data(tcTrk2, trackLength);

	        char * token = strtok(&tcTrk2[1],"=");
	        setCardNumber (token, strlen(token));

	        token = strtok(NULL,"?");
	        char cardExpiryDate [4] = {0};
	        memcpy (cardExpiryDate, token, sizeof(cardExpiryDate));
	        setCardExpiryDate (cardExpiryDate);
		}
    	length = 0;
		position = SHARED_EXCHANGE_POSITION_NULL;
		if (GTL_SharedExchange_FindNext(dataStruct, &position, TAG_PAYPASS_TRACK1_DATA, &length, &ptValue) == STATUS_SHARED_EXCHANGE_OK) {
			if (strtok(ptValue,"^")) {
				   char * token = strtok(NULL,"/^");
				   setCardHolderName(token, strlen(token));
			 }
		}
    }
   	else {
   		result = FALSE;
   		goto End;
    }
End:
	return result;
}
