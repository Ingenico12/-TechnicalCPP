/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   06/30/2018   This module implements the EMV Engine services related to the *
 * 									end of transaction.                                           *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "SEC_interface.h"
#include "GL_GraphicLib.h"
#include "TlvTree.h"
#include "GTL_Assert.h"
#include "_emvdctag_.h"
#include "def_tag.h"
#include "EngineInterface.h"
#include "EngineInterfaceLib.h"
#include "servcomm.h"

#include "EPSTOOL_TlvTree.h"
#include "EPSTOOL_PinEntry.h"

#include "EMV.h"

#include "emvparameter.h"
#include "transaction.h"

#define  DEBUG
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Called when the transaction is terminated (so further call will be performed by EMV   *
 * 			ENGINE).	                                                                          *
 * 			                                                                                      *
 * [in] :   inputTlvTree Input TlvTree.                                                           *
 * [out]:   outputTlvTree Output TlvTree.                                                         *
 * ---------------------------------------------------------------------------------------------- */
void emvStepStop (unsigned short *statusCode, TLV_TREE_NODE inputTlvTree, TLV_TREE_NODE outputTlvTree) {
	(void)inputTlvTree;
	(void)outputTlvTree;

	ASSERT(statusCode != NULL);
	ASSERT(inputTlvTree != NULL);
	ASSERT(outputTlvTree != NULL);

	emvTransacStatusSet (*statusCode);

#ifdef DEBUG
	unsigned short found;
	DataElement Data_Elt;
	TLV_TREE_NODE hTree;
	char tag8A [2] = {0};

	hTree = Engine_GetDataElement(TAG_AUTHORISATION_RESPONSE_CODE);
	TLV_TREE_NODE hFoundNode=NULL;
	found = FALSE;

	if(&hTree != NULL){
		hFoundNode = TlvTree_Find(hTree, TAG_AUTHORISATION_RESPONSE_CODE, 0);
		if(hFoundNode != NULL){
			Data_Elt.tag = TlvTree_GetTag(hFoundNode);
			Data_Elt.length = TlvTree_GetLength(hFoundNode);
			Data_Elt.ptValue = TlvTree_GetData(hFoundNode);
			memcpy (tag8A, Data_Elt.ptValue, Data_Elt.length);
			found = TRUE;
		}
	}
#endif

	// Check whether support Force Acceptance.
    unsigned char forceAcceptanceFlag [2] = {0};
 	const unsigned long cst_tag_list[] = {
		TAG_CUST_IS_FORCED_ACCEPTANCE,
		TAG_CUST_FORCED_ACCEPTANCE_REQUEST
	};
	EMVDataElement termParam[] = {ContactEMVParameter};
	int emvTagCount =  sizeof (cst_tag_list) / sizeof(unsigned long);
	int emvParam = sizeof (termParam) / sizeof (EMVDataElement);
	int x, y;
	for (x = 0; x < emvTagCount; x++){
		for (y = 0; y < emvParam; y++){
			if (!memcmp(&cst_tag_list[x],&termParam[y].tag, sizeof(unsigned long))){
				memcpy (&forceAcceptanceFlag[x], termParam[y].ptValue, termParam[y].length);
			}
		}
	}
	if (emvTransacStatusGet() == APEMV_TR_STATUS_DECLINED) {
		if (forceAcceptanceFlag[1] != 0) {
			if (APEMV_UI_MenuForceAcceptance())
			{
				if (forceAcceptanceFlag[1] != 0) {
					*statusCode = TAG_CUST_TRANSACTION_ACCEPTED;
					emvTransacStatusChange (APEMV_TR_STATUS_APPROVED);
				}
			}
		}
	}

	// Display the transaction outcome
	switch(emvTransacStatusGet())
	{
	case APEMV_TR_STATUS_APPROVED:
		if (memcmp(tag8A, "Y3", 2))		// Bypass for QuickChip
			APEMV_UI_MessageApproved();
		break;
	case APEMV_TR_STATUS_DECLINED:
		if (memcmp(tag8A, "Z3", 2))
			setErrorCode("ERROR:040");// Bypass for QuickChip
			//APEMV_UI_MessageDeclined();
		break;

	case APEMV_TR_STATUS_SERVICE_NOT_ALLOWED:
		APEMV_UI_MessageServiceNotAllowed();
		break;

	case APEMV_TR_STATUS_CANCELLED:
		if (getPINEntryCancelbyCardholder() == PIN_ENTRY_CANCELLED_BY_CARDHOLDER)
			APEMV_UI_PINEntryCancelledbyCardholder();
		else
			APEMV_UI_MessageTransactionCancelled();
		break;

	case APEMV_TR_STATUS_CARD_BLOCKED:
		setFallBackCount(FALLBACK_COUNT_MAX);
		APEMV_UI_MessageCardBlocked();
		break;

	case APEMV_TR_STATUS_CARD_REMOVED:
		APEMV_UI_MessageCardRemoved();
		break;

	case APEMV_TR_STATUS_CARD_ERROR:
		setChipErrorFlag(TRUE);
		setFallBackCount(FALLBACK_COUNT_MAX);
		APEMV_UI_MessageCardError();
		break;
		
	case APEMV_TR_STATUS_CARD_NOT_SUPPORTED_EMV:
	case APEMV_TR_STATUS_TERMINAL_ERROR:
		setChipErrorFlag(TRUE);
		setFallBackCount(FALLBACK_COUNT_MAX);
		APEMV_UI_MessageCardNotSupportedEMV();
		break;

	case APEMV_TR_STATUS_UNKNOWN:
		setEmptyCandidateListFlag(TRUE);
		setFallBackCount(FALLBACK_COUNT_MAX);
		APEMV_UI_MessageCardError();
		break;
		

	default:
		//APEMV_UI_MessageTransactionError();
		break;
	}
}
