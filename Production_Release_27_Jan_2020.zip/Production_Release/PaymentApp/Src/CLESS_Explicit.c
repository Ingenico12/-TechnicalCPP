/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   04/01/2018   This module implements the Contactless/NFC explicit selection *
 *                                  transaction flow.                                             *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "CLESS.h"
#include "transaction.h"

#define __APCLESS_EXPLICIT_STEP_DETECTION                 1        ///< Explicit execution step to detect the card
#define __APCLESS_EXPLICIT_STEP_SELECTION                 2        ///< Explicit execution step to select a card application
#define __APCLESS_EXPLICIT_STEP_KERNEL_EXECUTION          3        ///< Explicit execution step to run a kernel
#define __APCLESS_EXPLICIT_STEP_KERNEL_EXECUTION_BIS      4        ///< Explicit execution step to run again the kernel (used by Visa card for payWave kernel)
#define __APCLESS_EXPLICIT_STEP_CHECK_RESULT              5        ///< Explicit execution step to check kernel result ( to manage restart)
#define __APCLESS_EXPLICIT_STEP_END                       99       ///< Explicit execution step to stop processing

/* ---------------------------------------------------------------------------------------------- *
 * Purpose:  Get Parameter for Explicit Selection                                                 *
 *  		 The main steps are:                                                                  *
 *  			- parameters initialization                                                       *
 *  			- card detection and application selection                                        *
 * ---------------------------------------------------------------------------------------------- */
int CLESS_Explicit_GetParam() {
	int previousUiState;
	TLV_TREE_NODE selectionTlvTree = NULL;
	int result;

	previousUiState = CLESS_GUI_TransactionBegin();

	// Set the transaction parameters
	char cAmount[12] = {0};
	unsigned char ucAmount[6] = {0};
	struct sFeesApplied fees [MAX_FEE_COUNT];
	int feeCount;
	getProprietaryData (fees,&feeCount);
	int n;
	for (n = 0; n < 3; n++) {
		if (!memcmp (fees[n].feeType, "CORE", sizeof("CORE"))){
			char temp[20] = {0};
			strcpy (temp, fees[n].feeAmount);
			float fAmount = atoff(temp);
			int iAmount = fAmount * 100;
			memset (temp, 0 , sizeof(temp));
			sprintf (temp, "%d", iAmount);
			memcpy (&cAmount[sizeof(cAmount) - strlen(temp)], temp, strlen(temp));
			memset (cAmount, '0', sizeof(cAmount) - strlen(temp));
			Aschex(ucAmount,cAmount,12);
		}
	}
	if (strcmp(getTransactionType(),REFUND))
		CLESS_Txn_SetTransactionType(APCLESS_TRANSACTION_TYPE_REFUND);
	else
		CLESS_Txn_SetTransactionType(APCLESS_TRANSACTION_TYPE_DEBIT);

	CLESS_Txn_SetAmountBcd ((unsigned char*)ucAmount);
	CLESS_Txn_SetCurrencyCode((unsigned char*) "\x08\x40"); // USA currency code
	CLESS_Txn_SetCurrencyExponent(2);
	CLESS_Txn_SetDateTime();  // use terminal current date

	CLESS_Selection_SetMethod(APCLESS_SELECTION_EXPLICIT);
	CLESS_Txn_SetCurrentPaymentScheme(APCLESS_SCHEME_UNKNOWN);
	CLESS_Txn_SetDoubleTapInProgress(FALSE);

	// create selection TLV tree (for selection input parameters)
	selectionTlvTree = TlvTree_New(0);
	result = CLESS_Selection_GiveInfo(&selectionTlvTree, TRUE);
	if (result == TRUE) {
		result = Cless_ExplicitSelection_LoadData(selectionTlvTree);
		if (result == CLESS_STATUS_OK) {
			Cless_ExplicitSelection_Custom_RegistrationForGui(&CLESS_Selection_GuiCustomisation);
			// Perform the selection pre-processing
			result = Cless_ExplicitSelection_EntryPoint_TransactionPreProcessing();
			if (result == CLESS_STATUS_OK) {
				result = Cless_ExplicitSelection_GlobalCardDetection();
			}
		}
	}
	return result;
}
/* ------------------------------------------------------------------------------------------ *
 * Purpose:  This function performs all a contactless transaction using the explicit selection*
 *           method. contactless kernel execution                                             *
 * ------------------------------------------------------------------------------------------ */
void CLESS_Explicit_DoTransaction (void) {
	int result;
	TLV_TREE_NODE selectionTlvTree = NULL;
	T_SHARED_DATA_STRUCT* selectionSharedData = NULL;
	T_SHARED_DATA_STRUCT* kernelSharedBuffer = NULL;
	int kernelToUse;
	int step;
	int previousUiState;

	// Create the selection shared buffer (for selection result)
	selectionSharedData = GTL_SharedExchange_InitShared(10240);
	if (selectionSharedData == NULL) {
		goto End;
	}

	// Create the kernel shared buffer
	kernelSharedBuffer = GTL_SharedExchange_InitShared(C_SHARED_KERNEL_BUFFER_SIZE);
	if (kernelSharedBuffer == NULL) {
		goto End;
	}

	step = __APCLESS_EXPLICIT_STEP_DETECTION;
	while(step < __APCLESS_EXPLICIT_STEP_END) {
		switch(step) {

			case __APCLESS_EXPLICIT_STEP_DETECTION:
				GTL_SharedExchange_ClearEx(selectionSharedData, FALSE);
				result = Cless_Generic_CardDetectionGetResults(selectionSharedData, TRUE);
				if (result != CLESS_STATUS_OK) {
					step = __APCLESS_EXPLICIT_STEP_END;
					break;
				}
				step = __APCLESS_EXPLICIT_STEP_SELECTION;
				break;

			case __APCLESS_EXPLICIT_STEP_SELECTION:
				result = Cless_ExplicitSelection_Selection_ApplicationSelectionProcess(selectionSharedData);
				if (result != CLESS_STATUS_OK) {
					if(result == CLESS_STATUS_COMMUNICATION_ERROR) {
						result = CLESS_CR_MANAGER_RESTART;
						step = __APCLESS_EXPLICIT_STEP_CHECK_RESULT;
					}
					else {
						step = __APCLESS_EXPLICIT_STEP_END;
					}
					break;
				}
				step = __APCLESS_EXPLICIT_STEP_KERNEL_EXECUTION;
				break;

			case __APCLESS_EXPLICIT_STEP_KERNEL_EXECUTION:
				GTL_SharedExchange_ClearEx (kernelSharedBuffer, FALSE);
				if (!CLESS_AddTransactionGenericData (kernelSharedBuffer)) {
					step = __APCLESS_EXPLICIT_STEP_END;
					break;
				}
				if (!CLESS_AddAIDRelatedData (selectionSharedData, kernelSharedBuffer, &kernelToUse)) {
					step = __APCLESS_EXPLICIT_STEP_END;
					break;
				}
				switch (kernelToUse) {
					case DEFAULT_EP_KERNEL_PAYPASS :
						result = CLESS_PayPass_PerformTransaction(kernelSharedBuffer);
						break;

					case DEFAULT_EP_KERNEL_VISA :
						result = CLESS_PayWave_PerformTransaction(kernelSharedBuffer);
						break;

					case DEFAULT_EP_KERNEL_AMEX :
						result = CLESS_ExpressPay_PerformTransaction(kernelSharedBuffer);
						break;

					case DEFAULT_EP_KERNEL_DISCOVER_DPAS :
						result = CLESS_DiscoverDPAS_PerformTransaction(kernelSharedBuffer);
						break;

					case DEFAULT_EP_KERNEL_DISCOVER :
						result = CLESS_Discover_PerformTransaction(kernelSharedBuffer);
						break;
					case DEFAULT_EP_KERNEL_JCB_C5:
						result = ClessSample_JCB_PerformTransaction(kernelSharedBuffer);
						break;
					case DEFAULT_EP_KERNEL_INTERAC :
						// result = APCLESS_Interac_PerformTransaction(kernelSharedBuffer);
						break;

					default:
						break;
				}
				step = __APCLESS_EXPLICIT_STEP_CHECK_RESULT;
				break;

			case __APCLESS_EXPLICIT_STEP_CHECK_RESULT:
				switch(result) {
					case CLESS_CR_MANAGER_REMOVE_AID:
						// Restart with application selection
						CLESS_Txn_SetCurrentPaymentScheme(APCLESS_SCHEME_UNKNOWN);
						step = __APCLESS_EXPLICIT_STEP_SELECTION;
						break;

					case CLESS_CR_MANAGER_RESTART_DOUBLE_TAP:
						// Restart with card detection
						Cless_ExplicitSelection_DetectionPrepareForRestart(TRUE);
						CLESS_Txn_SetCurrentPaymentScheme(APCLESS_SCHEME_UNKNOWN);
						setErrorCode("ERROR:012");
						step = __APCLESS_EXPLICIT_STEP_DETECTION;
						break;

					case CLESS_CR_MANAGER_RESTART:
					case CLESS_CR_MANAGER_RESTART_NO_MESSAGE_BEFORE_RETRY:
						// Restart with card detection
						Cless_ExplicitSelection_DetectionPrepareForRestart(FALSE);
						CLESS_Txn_SetCurrentPaymentScheme(APCLESS_SCHEME_UNKNOWN);
						step = __APCLESS_EXPLICIT_STEP_DETECTION;
						break;

					default:
						step = __APCLESS_EXPLICIT_STEP_END;
						break;
				}
				break;

			default:    // iStep value unknown -> end processing
				step = __APCLESS_EXPLICIT_STEP_END;
				break;
		}
   }

End :   // End processing (cleaning)

   // Wait end of message display
	CLESS_GUI_DisplayScreen(APCLESS_SCREEN_WAIT_END_DISPLAY);

   // Release the TLV Tree if allocated
   if (selectionTlvTree != NULL)
   {
      TlvTree_Release(selectionTlvTree);
      selectionTlvTree = NULL;
   }

   // Release shared buffer if allocated
   if (selectionSharedData != NULL)
      GTL_SharedExchange_DestroyShare(selectionSharedData);

   if (kernelSharedBuffer != NULL)
      GTL_SharedExchange_DestroyShare(kernelSharedBuffer);

   // Clear the detection/selection resources
   Cless_ExplicitSelection_ClearGlobalData();

   // Reset APCLESS transaction parameters
   CLESS_Selection_SetMethod(APCLESS_SELECTION_UNKNOWN);
   CLESS_Txn_SetCurrentPaymentScheme(APCLESS_SCHEME_UNKNOWN);
   CLESS_Txn_SetDoubleTapInProgress(FALSE);

   // Set the LEDs into the idle state
   CLESS_GUI_IndicatorIdle();

	// Restore the user interface environment
   CLESS_GUI_TransactionEnd(previousUiState);
}
