/* --------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                  *
 * --------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                *
 * ---   ---------     ----         -----------                                *
 * V01   RS Software   12/31/2017   Initial Creation                           *
 * --------------------------------------------------------------------------- */
#include <GL_GraphicLib.h>
#include "MessageError.h"


const ERRORTABLE errorTable [] = {
		{"ERROR:000","NO ERROR"},
		{"ERROR:001","Invalid Card"},
		{"ERROR:002","Card Expired"},
		{"ERROR:003","Invalid CVV2/CVC2/CID2"},
		{"ERROR:004","Invalid Amount"},
		{"ERROR:005","Separator Fault"},
		{"ERROR:006","Parity Fault"},
		{"ERROR:007","LRC Fault"},
		{"ERROR:008","Luhn Fault"},
		{"ERROR:009","Numerical Fault"},
		{"ERROR:010","No Readable data"},
		{"ERROR:011","Unknown error"},
		{"ERROR:012","Transaction Cancelled"},
		{"ERROR:013","Time Out"},
		{"ERROR:014","Outlet No \n update failed"},
		{"ERROR:015","Terminal No \n update failed"},
		{"ERROR:016","Merchant No \n update failed"},
		{"ERROR:017","HOST IP Address/PORT \n update failed"},
		{"ERROR:018","Processing Error \n Invalid Entry Mode"},
		{"ERROR:019","Transaction Data \n Not Found"},
		{"ERROR:020","Transaction already reversed"},
		{"ERROR:021","Financial Institute \n update failed"},
		{"ERROR:022","Settlement Failed "},
		{"ERROR:023","Exceed Merchant maximum limit"},
		{"ERROR:024","No Transaction receipt \n to reprint"},
		{"ERROR:025","Card holder disagree \n to proceed"},
		{"ERROR:026","Communication \n Error"},
		{"ERROR:027","Unable to Connect \n Server"},
		{"ERROR:028","Response \n Time Out"},
		{"ERROR:029","No Transaction to settle"},
		{"ERROR:030","Invalid\nTransaction No."},
		{"ERROR:031","Manual Key entry\nNOT allowed for DEBIT"},
		{"ERROR:032","Invalid Response"},
		{"ERROR:033","Key Not Found"},
		{"ERROR:034","Invalid Name"},
		{"ERROR:035","Exceed Merchant Max Limit"},
		{"ERROR:036","Address Can't be Empty"},
		{"ERROR:037","ZIP Can't be Empty"},
		{"ERROR:038","Encryption Error"},
		{"ERROR:039","Error Card Details"},
		{"ERROR:040","Transaction Declined"},
		{"ERROR:041","Configure Your Terminal"},
		{"ERROR:042","Not Selected Any\n Transaction"},
		{"ERROR:043","EMV Engine Not Installed"},
		{"ERROR:044","PIN Entry Cancelled by\n Card Holder"},
		{"ERROR:045","Fees Gateway Error"},
		{"ERROR:046","PIN Try Exceeded"},
		{"ERROR:047","SEE PHONE FOR\n INSTRUCTIONS"},
		{"ERROR:048","Server Down"},
		{"ERROR:049","PINPAD Connection Error"},

};
void displayError(char * errorCode){
	int errorCount = sizeof(errorTable)/sizeof(errorTable[0]);
	int n;
	for (n = 0; n < errorCount; n++){
		if (!strcmp(errorTable[n].errorCode,errorCode)){
			GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, errorTable[n].errorMsg, GL_ICON_ERROR, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
			n = errorCount;
		}
	}
}
