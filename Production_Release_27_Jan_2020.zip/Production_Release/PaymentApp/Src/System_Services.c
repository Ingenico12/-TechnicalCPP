/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   04/01/2018   This module implements all the Telium Manager services.       *
 * ---------------------------------------------------------------------------------------------- */
#include "sdk.h"
#include "SEC_Interface.h"
#include "GL_GraphicLib.h"
#include "TlvTree.h"
#include "GTL_Assert.h"
#include "GTL_Convert.h"
#include "del_lib.h"
#include "TagOS.h"
#include "_emvdctag_.h"
#include "EngineInterface.h"
#include "HTTP_.h"
#include "EPSTOOL_TlvTree.h"
#include "EPSTOOL_PinEntry.h"

#include "EMV.h"
#include "CLESS.h"
#include "Utils.h"
#include "MerchantData.h"

static void ServicesManager_GetAppName(NO_SEGMENT appliId, char *name, int nameBufferSize);

extern struct sUserData * pUserData;
extern struct sPinPadData * pPinPadData;

/* ---------------------------------------------------------------------------------------------- *
 * Purpose: The Telium Manager calls this service at startup.(EMV and CLESS)                      *
 * 			                                                                                      *
 * [in] :   appliId The application ID                                                            *
 * [out]:   paramOut Output parameters that contains the application ID.                          *
 * ---------------------------------------------------------------------------------------------- */
int after_reset (NO_SEGMENT appliId, void *in, S_TRANSOUT *paramOut) {
	unsigned char changeFlag;
	unsigned char changeType;
	int isAppliUpdated;
	int __APCLESS_ServicesManager_isDllTpassLoaded = FALSE;

	ASSERT(paramOut != NULL);

	// Clear the output parameter
	memclr(paramOut, sizeof(*paramOut));
	paramOut->noappli = appliId;

	// Check for first run
	isAppliUpdated = FALSE;
	if (first_init(appliId, &changeFlag, &changeType) != FSE_FAILED) {
		if (changeFlag == (unsigned char)-1) {
			isAppliUpdated = TRUE;
		}
	}
	//************************************************************************
	// Initialize the application
	//************************************************************************
	// Open the DLLs if any
	SEClib_Open();

	// Check if TPass DLL is present and can be used.
	__APCLESS_ServicesManager_isDllTpassLoaded = (TPass_IsLoaded() == ERR_TPASS_OK);

	// Initialize generic components of the application
	CLESS_GUI_Init();

	// Initialize the application (load files ...)
	if (__APCLESS_ServicesManager_isDllTpassLoaded) {
		CLESS_GUI_IndicatorIdle();
	}
	else {
		CLESS_GUI_Display_Error_No_TPass();
	}
	//************************************************************************
	// TODO: Print a ticket to inform the merchant that the application has been loaded / updated
	//************************************************************************
	if (isAppliUpdated) {
		// TODO: Print the application version
	}
	// Clear the first run flag
	if (isAppliUpdated) {
		raz_init(appliId);
	}
	return FCT_OK;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: Retrieves the name of the application.                                                *
 * 			                                                                                      *
 * [in] :   appliId The application ID                                                            *
 * [out]:   name, nameBufferSize which will contain the application name.                         *
 * ---------------------------------------------------------------------------------------------- */
static void ServicesManager_GetAppName(NO_SEGMENT appliId, char *name, int nameBufferSize) {
	(void)nameBufferSize;
	object_info_t info;

	ASSERT(name != NULL);
	ASSERT(nameBufferSize >= 0);

	// Build the application value
	// TODO: Set your application name
	ObjectGetInfo(OBJECT_TYPE_APPLI, appliId,&info);

	VERIFY(sprintf(name, "PayPlex", (unsigned char)info.application_type) < nameBufferSize);
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: The Telium Manager calls this service to get the name of the application.             *
 * 			                                                                                      *
 * [in] :   appliId The application ID                                                            *
 * [out]:   paramOut Output parameters that contains the application name amongst other things    *
 * ---------------------------------------------------------------------------------------------- */
int ServicesManager_IsName(NO_SEGMENT appliId, S_ETATOUT *paramOut) {
	ASSERT(paramOut != NULL);

	memclr(&paramOut->returned_state[paramOut->response_number],
		sizeof(paramOut->returned_state[paramOut->response_number]));

	// Get the name of the application
	ServicesManager_GetAppName(appliId, paramOut->returned_state[paramOut->response_number].appname,
		sizeof(paramOut->returned_state[paramOut->response_number].appname));
	paramOut->returned_state[paramOut->response_number].no_appli = appliId;
	paramOut->returned_state[paramOut->response_number].state.response = REP_OK;
	paramOut->response_number++;

	return FCT_OK;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: The Telium Manager calls this service to let the application to customise the         *
 * 			Telium Manager behaviour.														      *
 * 			                                                                                      *
 * [in] :   appliId The application ID                                                            *
 * [out]:   paramOut Output parameters.                                                           *
 * ---------------------------------------------------------------------------------------------- */
int ServicesManager_GiveYourDomain(NO_SEGMENT appliId, S_INITPARAMOUT *paramOut) {
	(void)appliId;

	ASSERT(paramOut != NULL);

	memclr(&paramOut->returned_state[paramOut->response_number],
		sizeof(paramOut->returned_state[paramOut->response_number]));

	// Allow Telium Manager to modify all the parameters
	// TODO: Set the value to your needs
	paramOut->returned_state[paramOut->response_number].mask = MSK_ALL_PARAM;

	// It is a standard application
	paramOut->returned_state[paramOut->response_number].application_type = TYP_EXPORT;
	paramOut->response_number++;

	return FCT_OK;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: The Telium Manager calls this service to get information about the application.       *
 * 			                                                                                      *
 * [in] :   appliId The application ID                                                            *
 * [out]:   paramOut Output parameters.                                                           *
 * ---------------------------------------------------------------------------------------------- */
int ServicesManager_GiveYourSpecificContext(NO_SEGMENT appliId, S_SPECIFIC_CONTEXT *paramOut) {
	(void)appliId;

	ASSERT(paramOut != NULL);

	// Initialise the output parameter
	memclr(&paramOut->returned_state[paramOut->response_number],
		sizeof(paramOut->returned_state[paramOut->response_number]));

	// TODO: Set the following values to your needs

	// Give the resource file name that contains the icon of the application
	strncpy(paramOut->returned_state[paramOut->response_number].appname,
			_ING_APPLI_DATA_FILE_BINARY_NAME, sizeof(paramOut->returned_state[paramOut->response_number].appname) - 1);
	paramOut->returned_state[paramOut->response_number].no_appli = appliId;
	paramOut->returned_state[paramOut->response_number].mask = 0;
	//paramOut->returned_state[paramOut->response_number].type = ;
	//paramOut->returned_state[paramOut->response_number].support = ;
	//paramOut->returned_state[paramOut->response_number].cam = ;
	// To allow Manager look into the resource to get the icon of the application
	paramOut->returned_state[paramOut->response_number].cgui = CGUI_MASK;
	paramOut->response_number++;

	return FCT_OK;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: The Telium Manager calls this service to get the list of supported currencies by      *
 *          the application.                                                                      *
 * 			                                                                                      *
 * [in] :   appliId The application ID                                                            *
 * [out]:   paramOut Output parameters.                                                           *
 * ---------------------------------------------------------------------------------------------- */
int ServicesManager_GiveMoneyExtended(NO_SEGMENT appliId, S_MONEYOUT_EXTENDED *paramOut) {
	int numberOfCurrencies;

	ASSERT(paramOut != NULL);

	memclr(&paramOut->etat_retour[paramOut->nb_reponse],
		sizeof(paramOut->etat_retour[paramOut->nb_reponse]));

	ServicesManager_GetAppName(appliId, paramOut->etat_retour[paramOut->nb_reponse].libelle,
		sizeof(paramOut->etat_retour[paramOut->nb_reponse].libelle));

	numberOfCurrencies = 0;

	// TODO: Retrieve the supported currencies from the parameters
	paramOut->etat_retour[paramOut->nb_reponse].money[numberOfCurrencies].currency.code[0] = '8';
	paramOut->etat_retour[paramOut->nb_reponse].money[numberOfCurrencies].currency.code[1] = '4';
	paramOut->etat_retour[paramOut->nb_reponse].money[numberOfCurrencies].currency.code[2] = '0';
	paramOut->etat_retour[paramOut->nb_reponse].money[numberOfCurrencies].currency.posdec = 2;
	// TODO: Set the following settings depending on the current language
	paramOut->etat_retour[paramOut->nb_reponse].money[numberOfCurrencies].currency.nom[0] = 'U';
	paramOut->etat_retour[paramOut->nb_reponse].money[numberOfCurrencies].currency.nom[1] = 'S';
	paramOut->etat_retour[paramOut->nb_reponse].money[numberOfCurrencies].currency.nom[2] = 'D';
	paramOut->etat_retour[paramOut->nb_reponse].money[numberOfCurrencies].infos.cents_separator = ',';
	paramOut->etat_retour[paramOut->nb_reponse].money[numberOfCurrencies].infos.thousands_separator = '.';
	paramOut->etat_retour[paramOut->nb_reponse].money[numberOfCurrencies].infos.currency_position = CURRENCY_AFTER_AMOUNT;
	numberOfCurrencies++;

	if (numberOfCurrencies > 0) {
		paramOut->etat_retour[paramOut->nb_reponse].nb_money = numberOfCurrencies;
		paramOut->nb_reponse++;
	}
	return FCT_OK;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: The Telium Manager calls this service to know the state of the application.           *
 * 			                                                                                      *
 * [in] :   appliId The application ID                                                            *
 * [out]:   paramOut Output parameters that contains the state of the application.                *
 * ---------------------------------------------------------------------------------------------- */
int ServicesManager_IsState(NO_SEGMENT appliId, S_ETATOUT *paramOut) {
	ASSERT(paramOut != NULL);

	memclr(&paramOut->returned_state[paramOut->response_number],
		sizeof(paramOut->returned_state[paramOut->response_number]));

	ServicesManager_GetAppName(appliId, paramOut->returned_state[paramOut->response_number].appname,
		sizeof(paramOut->returned_state[paramOut->response_number].appname));
	paramOut->returned_state[paramOut->response_number].no_appli = appliId;

	// TODO: Retrieve the state of the application
	paramOut->returned_state[paramOut->response_number].state.response = REP_OK;
	paramOut->response_number++;

#ifdef PAYPASS_TORN
   // Clean up the Torn Transaction log by removing torn records that were not recovered and that have been aged off the log.
	CLESS_PayPassTorn_CleanLog();
#endif

	return FCT_OK;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: The Telium Manager calls this service each time it wants to delete an application     *
 * 			                                                                                      *
 * [in] :   appliId The application ID                                                            *
 * [out]:   paramOut Output parameters that contains the application response:                    *
 * 		- DEL_YES : application authorises deletion process                                       *
 * 		- DEL_NO  : application refuses any deletion process (Manager will display a message      *
 * 					regarding the application which has refused the deletion)                     *
 * ---------------------------------------------------------------------------------------------- */
int ServiceManager_IsDelete(NO_SEGMENT appliId, S_DELETE *paramOut) {
   (void)appliId;

   memclr(paramOut, sizeof(*paramOut));

   // TODO: Check batch file status
   paramOut->deleting = DEL_YES;

   return FCT_OK;
}

//! \brief The Telium Manager calls this service when an EMV card is inserted to know the list of supported AIDs.
//! \param[in] appliId The application ID.
//! \param[in] paramIn Parameters of the transaction (amount, ...).
//! \param[in] paramOut The list of supported AIDs.
//! \return Always \a FCT_OK.
//! \sa Telium Manager reference documentation.
int APEMV_ServicesManager_GiveAid(NO_SEGMENT appliId, const S_TRANSIN *paramIn, _DEL_ *paramOut)
{
	static const unsigned char aidVisa[] = {0}; //{ 0xa0, 0x00, 0x00, 0x00, 0x03 };
	static const unsigned char aidMastercard[] = {0}; //{ 0xa0, 0x00, 0x00, 0x00, 0x04 };
	TLV_TREE_NODE outputTlvTree;
	unsigned char byte;
	int result;

	// To avoid warnings because 'paramIn' is not used
	(void)paramIn;

	ASSERT(paramIn != NULL);
	ASSERT(paramOut != NULL);

	// Initialise the output DEL
	_DEL_Init(paramOut);

	// TODO: Check input parameters 'paramIn'

	// Fill the output DEL
	outputTlvTree = TlvTree_New(0);
	if (outputTlvTree != NULL)
	{
		result = TRUE;

		// Add the application ID
		if (TlvTree_AddChild(outputTlvTree, TAG_TERM_APP_NUMBER, &appliId, 1) == NULL)
			result = FALSE;

		// Do not force manual selection
		byte = VALUE_GIVE_AID_MANUAL_SELECTION_FORCE_CONFIRMATION;	// Possible values are: VALUE_GIVE_AID_MANUAL_SELECTION_FORCE_CONFIRMATION | VALUE_GIVE_AID_MANUAL_SELECTION_FORCE_SELECTION
		if (TlvTree_AddChild(outputTlvTree, TAG_GIVE_AID_MANUAL_SELECTION, &byte, 1) == NULL)
			result = FALSE;

		// TODO: Add the supported AIDs

		// Add the VISA AID
		if (TlvTree_AddChild(outputTlvTree, TAG_GIVE_AID_AID_VALUE, &aidVisa, sizeof(aidVisa)) == NULL)
			result = FALSE;
		byte = 0;	// Allow partial matching. Set it to 0x80 to forbid partial matching.
		if (TlvTree_AddChild(outputTlvTree, TAG_GIVE_AID_ASI, &byte, 1) == NULL)
			result = FALSE;

		// Add the Mastercard AID
		if (TlvTree_AddChild(outputTlvTree, TAG_GIVE_AID_AID_VALUE, &aidMastercard, sizeof(aidMastercard)) == NULL)
			result = FALSE;
		byte = 0;	// Allow partial matching. Set it to 0x80 to forbid partial matching.
		if (TlvTree_AddChild(outputTlvTree, TAG_GIVE_AID_ASI, &byte, 1) == NULL)
			result = FALSE;


		if (result)
		{
			// TODO: Be careful if 'outputTlvTree' contains more than 50 tags.
			// TODO: In such case, a special treatment must be applied (see Telium Manager documentation).

			// Copy the TlvTree into the output DEL
			EPSTOOL_TlvTree_AddToDelValue(paramOut, outputTlvTree);
		}

		EPSTOOL_TlvTree_Release(&outputTlvTree);
	}

	return FCT_OK;
}

//! \brief The Telium Manager calls this service after the Application Selection. The application shall answer an interest level concerning the selected AID.
//! \param[in] appliId The application ID.
//! \param[in] paramIn The selected AID.
//! \param[in] paramOut Output parameters that contains the interest level (priority) amongst other things.
//! \return Always \a FCT_OK.
//! \sa Telium Manager reference documentation.
int APEMV_ServicesManager_IsCardEmvForYou(NO_SEGMENT appliId, const S_AID *paramIn, S_CARDOUT *paramOut)
{
	(void)paramIn;

	ASSERT(paramIn != NULL);
	ASSERT(paramOut != NULL);

	// Initialise the output parameter
	memclr(&paramOut->returned_state[paramOut->response_number],
		sizeof(paramOut->returned_state[paramOut->response_number]));

	ServicesManager_GetAppName(appliId, paramOut->returned_state[paramOut->response_number].appname,
		sizeof(paramOut->returned_state[paramOut->response_number].appname));
	paramOut->returned_state[paramOut->response_number].no_appli = appliId;

	// This function is only called when the AID is supported by the application
	// So we always what to manage the AID with a normal priority
	paramOut->returned_state[paramOut->response_number].cardappnumber = 1;
	paramOut->returned_state[paramOut->response_number].cardapp[0].priority = CARD_RECOGNIZED;
	ServicesManager_GetAppName(appliId, paramOut->returned_state[paramOut->response_number].cardapp[0].cardappname,
		sizeof(paramOut->returned_state[paramOut->response_number].cardapp[0].cardappname));
	paramOut->response_number++;

	return FCT_OK;
}

//! \brief The Telium Manager calls this service when the application shall manage the inserted EMV card.
//! \param[in] appliId The application ID.
//! \param[in] paramIn Parameters of the transaction (amount, ...).
//! \param[in] paramOut Output parameters that contains the payment result amongst other things.
//! \return Always \a FCT_OK.
//! \sa Telium Manager reference documentation.
int APEMV_ServicesManager_DebitEmv(NO_SEGMENT appliId, const S_TRANSIN *paramIn, S_TRANSOUT *paramOut)
{
	int doTransaction;
	TLV_TREE_NODE inputTlvTree;
	TLV_TREE_NODE node;
	TLV_TREE_NODE tmpNode;
	EPSTOOL_Data_t data;
	int deleteTag;
	unsigned char buffer[4];
	int previousUiState;

	ASSERT(paramIn != NULL);
	ASSERT(paramOut != NULL);

	// Initialise the output parameter
	memclr(paramOut, sizeof(*paramOut));
	paramOut->noappli = appliId;
	paramOut->rc_payment = PAY_KO;

	doTransaction = FALSE;
	if (EPSTOOL_TlvTree_NewFromDel(&inputTlvTree, 0, &paramIn->del))
	{
		node = EPSTOOL_TlvTree_GetFirstChildData(inputTlvTree, &data);
		while(node != NULL)
		{
			deleteTag = FALSE;
			switch(data.tag)
			{
			case TAG_GIVE_AID_AID_VALUE:
				TlvTree_SetTag(node, TAG_AID_ICC);
				// The AID is given by the Manager, so we can do the transaction
				doTransaction = TRUE;
				break;
			case TAG_GIVE_AID_APP_NAME:
				TlvTree_SetTag(node, TAG_APPLICATION_LABEL);
				break;
			case TAG_GIVE_AID_APP_PRIO:
				TlvTree_SetTag(node, TAG_APPLI_PRIOR_IND);
				break;
			case TAG_GIVE_AID_PREF_LANGUAGE:
				TlvTree_SetTag(node, TAG_LANGUAGE_PREFERENCE);
				break;
			default:
				// We don't know this tag => delete it
				deleteTag = TRUE;
				break;
			}

			if (deleteTag) {
				// Delete the tag and go to the next tag
				tmpNode = EPSTOOL_TlvTree_GetNextData(node, &data);
				TlvTree_Release(node);
				node = tmpNode;
			}
			else {
				// Next tag
				node = EPSTOOL_TlvTree_GetNextData(node, &data);
			}
		}

		// Add the amount
		if ((doTransaction) && (paramIn->entry != NO_ENTRY)) {
			// TODO: Check that the currency is allowed and coherent with parameters

			EPSTOOL_Convert_ULongToEmvBin(paramIn->amount, buffer);
			if (TlvTree_AddChild(inputTlvTree, TAG_AMOUNT_AUTH_BIN, buffer, 4) == NULL) {
				doTransaction = FALSE;
			}

			buffer[0] = (paramIn->currency.code[0] - '0');
			buffer[1] = ((paramIn->currency.code[1] - '0') << 4) | (paramIn->currency.code[2] - '0');
			if (TlvTree_AddChild(inputTlvTree, TAG_TRANSACTION_CURRENCY_CODE, buffer, 2) == NULL) {
				doTransaction = FALSE;
			}

			buffer[0] = (unsigned char)paramIn->currency.posdec;
			if (TlvTree_AddChild(inputTlvTree, TAG_TRANSACTION_CURRENCY_EXP, buffer, 1) == NULL) {
				doTransaction = FALSE;
			}

			//  - TAG_AMOUNT_OTHER_BIN (set to 0)

			// TODO: Check the amount if required (to forbid zero amount...)
		}

		// By default, we start a standard transaction.
		// Cash or cashback may be known later in the transaction
		buffer[0] = TYPE_GOODS_SERVICES;
		if (TlvTree_AddChild(inputTlvTree, TAG_INT_TRANSACTION_TYPE, buffer, 1) == NULL) {
			doTransaction = FALSE;
		}

		// Set the transaction type
		switch(paramIn->transaction)
		{
		case DEBIT_TR:
			// Purchase transaction
			buffer[0] = 0x00;	// Standard ISO8583:1983 transaction type for 'debit' is 00
			if (TlvTree_AddChild(inputTlvTree, TAG_TRANSACTION_TYPE, buffer, 1) == NULL) {
				doTransaction = FALSE;
			}
			break;

		case CANCEL_TR:
		case EXT_CANCEL_TR:
			// Void transaction
			buffer[0] = 0x02;	// Standard ISO8583:1983 transaction type for 'void' is 02
			if (TlvTree_AddChild(inputTlvTree, TAG_TRANSACTION_TYPE, buffer, 1) == NULL)
			{
				doTransaction = FALSE;
			}
			break;

		case CREDIT_TR:
			// Refund transaction
			buffer[0] = 0x20;	// Standard ISO8583:1983 transaction type for 'refund' is 20
			if (TlvTree_AddChild(inputTlvTree, TAG_TRANSACTION_TYPE, buffer, 1) == NULL)
			{
				doTransaction = FALSE;
			}
			break;

		default:
			// Unknown transaction type
			doTransaction = FALSE;
			break;
		}

		// Add the reader ID
		buffer[0] = paramIn->peri;
		if (TlvTree_AddChild(inputTlvTree, TAG_CHIP_READER_ID, buffer, 1) == NULL)
		{
			doTransaction = FALSE;
		}

		if (doTransaction)
		{
			// Setup the user interface environment
			previousUiState = APEMV_UI_TransactionBegin();

			// Perform the transaction !
			switch(emvDoTransaction (appliId, FALSE, inputTlvTree))
			{
			case ERR_ENG_OK:
				// Payment approved
				paramOut->rc_payment = PAY_OK;
				break;
			case ERR_ENG_TRY_ANOTHER_AID:
				// Another AID must be selected
				paramOut->rc_payment = PAY_OTHER_AID;
				break;
			default:
				// Payment not performed (declined ...)
				paramOut->rc_payment = PAY_KO;
				break;
			}

			// Restore the user interface environment
			APEMV_UI_TransactionEnd(previousUiState);
		}
	}
	// Release the memory
	EPSTOOL_TlvTree_Release(&inputTlvTree);

	return FCT_OK;
}
/* ---------------------------------------------------------------------------------------------- *
 * Purpose: The Telium Manager calls this service which allows applications to execute their      *
 *          own functions via menus.                                                              *
 * 			                                                                                      *
 * [in] :   appliId The application ID                                                            *
 * ---------------------------------------------------------------------------------------------- */
int APEMV_ServicesManager_MoreFunction(NO_SEGMENT appliId) {
	if(IsIPP3XX())
		return FCT_OK;
	else
		merchantTerminalUI (appliId);
	return FCT_OK;
}

int idle_message (NO_SEGMENT no, void *p1, void *p2) {
	int x = 0;   // time value, it can be customized by developer according to the use case
	int y = 10;  // time value, it can be customized by developer according to the use case

    Telium_File_t *hDsp;
    T_GL_HWIDGET GM_Tab_Gw;
    T_GL_HWIDGET label;
    LL_HANDLE hUSB=NULL;
    char dspMsg[25]={0};
    char softver[20 +1]={0};
    char currentsoftver[20 +1]={0};
    char *displayMessage;
    char externalPinpad[2]={0};
    char displayMsgFlag[2]={0};
    fetch_appconfig_data("IDLE_MESSAGE",dspMsg);
    displayMessage = strtok(dspMsg," ");
    fetch_appconfig_data("EXTERNAL_PINPAD",externalPinpad);
    fetch_appconfig_data("TMSFILE_VERSION",currentsoftver);
    fetch_appconfig_data("SOFTWARE_VERSION",softver);
    fetch_appconfig_data("DISPLAY_MSG_FLAG",displayMsgFlag);
    if(strcmp(currentsoftver,softver))
    	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Update Terminal Software",GL_ICON_WARNING, GL_BUTTON_ALL, 2*GL_TIME_SECOND);

if(atoi(externalPinpad)){
    if (IsIPP3XX()) {
    	int iRet=0;
    	char tcSnd [sizeof (struct sUserData) + 1]= {0};
    	char tcRsp [sizeof (struct sUserData) + 1]= {0};
    	char displayFee [200]={0};
    	memset(tcSnd, 0, sizeof(tcSnd));
    	memset(tcRsp, 0, sizeof(tcRsp));
		hDsp = Telium_Fopen("DISPLAY", "w*");
		GM_Tab_Gw = GL_Window_Create(APEMV_UI_GoalHandle());
		label     = GL_Label_Create(GM_Tab_Gw);

    	hUSB = OpenUSB();
		iRet = ConnectUSB(hUSB);
		iRet = LL_ClearSendBuffer(hUSB);
		iRet = LL_ClearReceiveBuffer(hUSB);
		if(strlen(pUserData->mUserText)>0){
			strcpy(pUserData->errorCode,"ERROR:013");
			iRet = SendUSB(hUSB, pUserData, (word) sizeof(struct sUserData));
			memset(pUserData,0,sizeof(struct sUserData));
		}

		do {
			// TODO: Merchant Service Provider LOGO / Welcome message would be add as per requirement.
			if (atoi(displayMsgFlag)){
				GL_Widget_SetText(label, "GovPay");
				GL_Widget_SetBackAlign(label, GL_ALIGN_CENTER);
				GL_Widget_SetFontScale(label, GL_SCALE_LARGE);
			}
			else
				GL_Widget_SetText(label, "Please Wait");
		    GL_Window_Dispatch(GM_Tab_Gw, x);
		    iRet = ReceiveUSB(hUSB, tcRsp,10*GL_TIME_SECOND);      // Received Data
			if(iRet > 0) {
				memcpy (pUserData, tcRsp, sizeof(struct sUserData));
				memset(tcRsp,0,sizeof(tcRsp));
				// Intimate Clerk Terminal
				if (!strcmp(pUserData->mTransactionType,"CARDTYPESELECTION")){
					strcpy(pUserData->mUserText, "Waiting for Card Type\nSelection");
				}
				else if(!strcmp(pUserData->mTransactionType,FULL_REVERSAL))
					strcpy (pUserData->mUserText, "Waiting for Customer\nConfirmation");
				else
					strcpy (pUserData->mUserText, "Waiting for Card Entry");
				iRet = SendUSB(hUSB, pUserData, (word) sizeof(struct sUserData)); // Send data Clerk Terminal
				if(iRet > 0 ) {
					if(!strcmp(pUserData->mTransactionType,REFUND))
						constructRefundData(displayFee);
					else if(!strcmp(pUserData->mTransactionType,PURCHASE))
						constructPayableData(displayFee);
					else if(!strcmp(pUserData->mTransactionType,FULL_REVERSAL))
						constructPayableData(displayFee);
					else if(!strcmp(pUserData->mTransactionType,PREAUTH))
						constructPayableData(displayFee);
					else if(!strcmp(pUserData->mTransactionType,COMPLETION))
						constructPayableData(displayFee);
					else if(!strcmp(pUserData->mTransactionType,"CARDTYPESELECTION")){
						strcpy(displayFee,"Press Green Button");
					}
					else
						break;
					if ( strlen (displayFee) != 0) {
						GL_Widget_SetText(label, displayFee);
						GL_Widget_SetBackAlign(label, GL_ALIGN_CENTER);
						GL_Widget_SetFontScale(label, GL_SCALE_SMALL);
						do {
							GL_Window_Dispatch(GM_Tab_Gw, x); // display the message
							y=30*1000;
							if (Telium_Ttestall(TIMER, y) == TIMER) {
								//strcpy(pUserData->errorCode,"ERROR:012");
								//iRet = SendUSB(hUSB, pUserData, (word) sizeof(struct sUserData)); // Send data Clerk Terminal
								//memset(pUserData,0,sizeof(struct sUserData));
				    		   break; // TIMER event has been received from the Telium Manager
							}
						} while(1);
						if(strcmp(pUserData->mTransactionType,"CARDTYPESELECTION"))
							saveAdminParameter("DISPLAY_MSG_FLAG","1");
					}
					break;
				}
			   // break;
			}
			else if (Telium_Ttestall(TIMER, y) == TIMER) {
	    		   break; // TIMER event has been received from the Telium Manager
			}
		} while(1);
		iRet = DisconnectUSB(hUSB);
		//iRet = CloseUSB(hUSB);
		GL_Widget_Destroy(GM_Tab_Gw);
	    Telium_Fclose(hDsp);
	}
	else {
       hDsp = Telium_Fopen("DISPLAY", "w*");
       GM_Tab_Gw = GL_Window_Create(APEMV_UI_GoalHandle());
       label     = GL_Label_Create(GM_Tab_Gw);
       GL_Widget_SetText(label, displayMessage);
       GL_Widget_SetBackAlign(label, GL_ALIGN_CENTER);
       GL_Widget_SetFontScale(label, GL_SCALE_MEDIUM);
       do {
    	   GL_Window_Dispatch(GM_Tab_Gw, x); // display the message
    	   if (Telium_Ttestall(TIMER, y) == TIMER) {
    		   break; // TIMER event has been received from the Telium Manager
		   }
       } while(1);
       GL_Widget_Destroy(GM_Tab_Gw);
       Telium_Fclose(hDsp);
	}
}

if(!atoi(externalPinpad)){ //INTERNAL PINPAD

	int iRet = GL_File_Exists("file://flash/HOST/PS_GOV.BMP");
	if(iRet==GL_SUCCESS){
		do{
			iRet= GL_Dialog_Picture(APEMV_UI_GoalHandle(),NULL,NULL,"file://flash/HOST/PS_GOV.BMP", 0, 1);                // Display BMP
			// Display BMP
			if (Telium_Ttestall(TIMER, 1) == TIMER) {
			break; // TIMER event has been received from the Telium Manager
			}
		}while(1);
	}
	else{
    hDsp = Telium_Fopen("DISPLAY", "w*");
    GM_Tab_Gw = GL_Window_Create(APEMV_UI_GoalHandle());
    label     = GL_Label_Create(GM_Tab_Gw);

    GL_Widget_SetText(label, displayMessage);
    GL_Widget_SetBackAlign(label, GL_ALIGN_CENTER);
    GL_Widget_SetFontScale(label, GL_SCALE_MEDIUM);
    do {

 	   GL_Window_Dispatch(GM_Tab_Gw, x); // display the message
 	   if (Telium_Ttestall(TIMER, y) == TIMER) {
 		   break; // TIMER event has been received from the Telium Manager
		   }
    } while(1);
    GL_Widget_Destroy(GM_Tab_Gw);
    Telium_Fclose(hDsp);
	}
}
    return FCT_OK;
}
int get_idle_state_parameter (NO_SEGMENT no, void *in, S_STATEOUT *out) {
	int ret = FCT_OK;
	MASQUE mask = 0;

	mask = SWIPE2 | SWIPE31 | CAM0 | CLESS;

	out->returned_state[out->response_number].no_appli = no;
	out->returned_state[out->response_number].mask = mask;
	out->response_number++;

	return ret;
}
int keyboard_event(NO_SEGMENT noappli, S_KEY *key_in, S_KEY *key_out) {
    // Keyboard management
    switch (key_in->keycode) {
    	case N0:                // KEYBOARD : '0'
        case N1:                // KEYBOARD : '1'
        case N2:                // KEYBOARD : '2'
        case N3:                // KEYBOARD : '3'
        case N4:                // KEYBOARD : '4'
        case N5:                // KEYBOARD : '5'
        case N6:                // KEYBOARD : '6'
        case N7:                // KEYBOARD : '7'
        case N8:                // KEYBOARD : '8'
        case N9:                // KEYBOARD : '9'
        case NAVI_CLEAR:        // KEYBOARD : 'C' // Not available for iWL
        case NAVI_OK:           // KEYBOARD : OK
        case UP:                // KEYBOARD : UP
        case DOWN:              // KEYBOARD : DOWN
        case F1:                // KEYBOARD : F1
        case F2:                // KEYBOARD : F2
        case F3:                // KEYBOARD : F3
        case F4:                // KEYBOARD : F4
        case T_CORR:            // KEYBOARD : YELLOW KEY
        case T_POINT:           // KEYBOARD : '.'
        	key_out->keycode = 0;
            break;
        case T_VAL:             // KEYBOARD : GREEN KEY
        	if (IsIPP3XX()){
        		if(strlen(pUserData->mTransactionType)>0){
        			if (!strcmp(pUserData->mTransactionType,"CARDTYPESELECTION")){
        				saveAdminParameter("DISPLAY_MSG_FLAG","0");
        				externalPINPadUIForCardTypeSelection(noappli);
        			}
        			else{
        				saveAdminParameter("DISPLAY_MSG_FLAG","1");
        				externalPINPadUI (noappli);
        			}
        		}
        		key_out->keycode = 0;
				break;
        	}
            else {
            	merchantTerminalUI (noappli);
				key_out->keycode = 0;
				break;
            }
        case T_ANN:             // KEYBOARD : RED KEY
        	if (IsIPP3XX())
        			saveAdminParameter("DISPLAY_MSG_FLAG","1");
        	if (IsIPP3XX()&&strlen(pUserData->mTransactionType)>0){
        		menuHolderDisagree(noappli);
        	}
            key_out->keycode = 0;
            break;
        case T_F:               // KEYBOARD : 'F' KEY
        	if (IsIPP3XX()){
        		appDownloadForIPP3XX(noappli);
        	}
        	key_out->keycode=key_in->keycode;
            break;
        default:
        	key_out->keycode=key_in->keycode;
            break;
    }
    return (FCT_OK);
}
