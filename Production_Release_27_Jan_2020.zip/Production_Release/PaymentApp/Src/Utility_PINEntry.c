/**
* \file
* \brief This module implements the PIN entry common treatments.
*
* \author Ingenico
* \author Copyright (c) 2012 Ingenico, 28-32, boulevard de Grenelle,\n
* 75015 Paris, France, All Rights Reserved.
*
* \author Ingenico has intellectual property rights relating to the technology embodied\n
* in this software. In particular, and without limitation, these intellectual property rights may\n
* include one or more patents.\n
* This software is distributed under licenses restricting its use, copying, distribution, and\n
* and decompilation. No part of this software may be reproduced in any form by any means\n
* without prior written authorisation of Ingenico.
**/

/////////////////////////////////////////////////////////////////
//// Includes ///////////////////////////////////////////////////

#include "sdk.h"
#include "SEC_interface.h"
#include "schVar_def.h"
#include "GL_GraphicLib.h"
#include "GTL_Assert.h"
#include "tlvVar_def.h"
#include "EPSTOOL_PinEntry.h"

//// Macros & preprocessor definitions //////////////////////////

//// Types //////////////////////////////////////////////////////

typedef byte  txPinBlock[ PIN_BLOC_SIZE ];
typedef byte  txPanBlock[ PAN_BLOC_SIZE ];
typedef byte  txPinDukptSMID[ DUKPT_SMID_SIZE ];

//! \brief Context of a PIN entry.
typedef struct
{
	EPSTOOL_PinEntry_Infos_t *infos;		//!< PIN entry parameters.

	int firstRefresh;						//!< First refresh flag.
	int pinLength;							//!< Current length of the entered PIN.
	EPSTOOL_PinEntry_Status_e status;		//!< Status of the PIN entry.
} __EPSTOOL_PinEntry_Context_t;

//// Static function definitions ////////////////////////////////

static unsigned long __EPSTOOL_PinEntry_Open(T_GL_HSCHEME_INTERFACE interface);
static void __EPSTOOL_PinEntry_Close(T_GL_HSCHEME_INTERFACE interface);
static unsigned long __EPSTOOL_PinEntry_Refresh(T_GL_HSCHEME_INTERFACE interface, T_GL_HWIDGET label);

//// Global variables ///////////////////////////////////////////
T_SEC_DATAKEY_ID  xKeyDukptPin;

//// Functions //////////////////////////////////////////////////

//! \brief Start a GOAL PIN entry.
//! \param[in] interface GOAL PIN entry context.
//! \return \a GL_RESULT_SUCCESS if PIN entry can be performed or \a GL_RESULT_FAILED to abort PIN entry.
static unsigned long __EPSTOOL_PinEntry_Open(T_GL_HSCHEME_INTERFACE interface)
{
	__EPSTOOL_PinEntry_Context_t *pinEntryContext;
	T_SEC_ENTRYCONF pinEntryConfig;
	int result;

	ASSERT(interface != NULL);
	pinEntryContext = (__EPSTOOL_PinEntry_Context_t*)interface->privateData;

	ASSERT(pinEntryContext != NULL);
	ASSERT(pinEntryContext->infos != NULL);

	if (pinEntryContext->infos->pinBypassAllowed)
	{
		// Force the scheme min PIN length to 0
		memcpy(&pinEntryConfig, &pinEntryContext->infos->pinEntryConfig, sizeof(pinEntryConfig));
		pinEntryConfig.ucMinDigits = 0;
		// Initialise the PIN entry
		result = SEC_PinEntryInit(&pinEntryConfig, pinEntryContext->infos->secureType);
	}
	else
	{
		// Initialise the PIN entry
		result = SEC_PinEntryInit(&pinEntryContext->infos->pinEntryConfig, pinEntryContext->infos->secureType);

	}

	if (result == OK)
	{
		return GL_RESULT_SUCCESS;
	}
	else
	{
		return GL_RESULT_FAILED;
	}
}

//! \brief End a GOAL PIN entry.
//! \param[in] interface GOAL PIN entry context.
static void __EPSTOOL_PinEntry_Close(T_GL_HSCHEME_INTERFACE interface)
{
	unsigned int eventsToWait;
	unsigned char key;
	int continuePinEntry;

	ASSERT(interface != NULL);

	// Stop the PIN entry
	eventsToWait = 0;
	key = 0;
	continuePinEntry = FALSE;
	SEC_PinEntry(&eventsToWait, &key, &continuePinEntry);
}

//! \brief Refresh the display of a GOAL PIN entry.
//! \param[in] interface GOAL PIN entry context.
//! \param[in] label Handle of the GOAL widget that displays the PIN entry.
//! \return \a GL_RESULT_SUCCESS if success or any other status code to abort PIN entry.
static unsigned long __EPSTOOL_PinEntry_Refresh(T_GL_HSCHEME_INTERFACE interface, T_GL_HWIDGET label)
{
	unsigned long result;
	__EPSTOOL_PinEntry_Context_t *pinEntryContext;
	unsigned int eventsToWait;
	unsigned char key;
	int continuePinEntry;
	int updateDisplay;
	unsigned long events;

	ASSERT(interface != NULL);
	pinEntryContext = (__EPSTOOL_PinEntry_Context_t*)interface->privateData;

	ASSERT(pinEntryContext != NULL);
	ASSERT(pinEntryContext->infos != NULL);
	ASSERT(pinEntryContext->infos->refresh != NULL);
	ASSERT(pinEntryContext->pinLength >= 0);
	ASSERT(pinEntryContext->pinLength <= pinEntryContext->infos->pinEntryConfig.ucMaxDigits);

	if (pinEntryContext->firstRefresh)
	{
		// First call of this function
		//  => Call the user 'refresh' function once before starting PIN entry
		ASSERT(pinEntryContext->pinLength == 0);
		pinEntryContext->infos->refresh(pinEntryContext->infos, label, pinEntryContext->pinLength);
		pinEntryContext->firstRefresh = FALSE;

		// Return to let GOAL update the display
		return GL_RESULT_SUCCESS;
	}

	result = GL_RESULT_SUCCESS;

	// Manage PIN entry
	eventsToWait = pinEntryContext->infos->eventsToWait;
	key = 0;
	continuePinEntry = TRUE;
	updateDisplay = FALSE;
	switch(SEC_PinEntry(&eventsToWait, &key, &continuePinEntry))
	{
	case OK:
		if (key == pinEntryContext->infos->pinEntryConfig.ucEchoChar)
		{
			// A numeric key has been pressed
			//  => Increase the PIN length (unless max digits has already been entered)
			if (pinEntryContext->pinLength < pinEntryContext->infos->pinEntryConfig.ucMaxDigits)
			{
				pinEntryContext->pinLength++;
				updateDisplay = TRUE;
			}
		}
		else if (key == T_CORR)
		{
			// The correction key has been pressed
			//  => Decrease the PIN length (unless no digits has already been entered)
			if (pinEntryContext->pinLength > 0)
			{
				pinEntryContext->pinLength--;
				updateDisplay = TRUE;
			}
		}
		else if (key == T_ANN)
		{
			// The cancel key has been pressed
			pinEntryContext->status = EPSTOOL_PINENTRY_CANCEL;
			result = GL_KEY_CANCEL;
		}
		else if (key == T_VAL)
		{
			// The cancel key has been pressed
			if ((pinEntryContext->pinLength == 0) && (pinEntryContext->infos->pinBypassAllowed))
			{
				// PIN bypass
				pinEntryContext->status = EPSTOOL_PINENTRY_BYPASS;
				// Stop the PIN entry
				result = GL_KEY_CANCEL;
			}
			else if (pinEntryContext->pinLength >= pinEntryContext->infos->pinEntryConfig.ucMinDigits)
			{
				// Terminate the PIN entry
				pinEntryContext->status = EPSTOOL_PINENTRY_SUCCESS;
				result = GL_KEY_VALID;
			}
			else
			{
				// Invalid PIN (too short)
				pinEntryContext->status = EPSTOOL_PINENTRY_INVALID;
				result = GL_KEY_CANCEL;
			}
		}
		else if (key == 0)
		{
			// No custom 'user event' function => Stop the PIN entry
			pinEntryContext->status = EPSTOOL_PINENTRY_TIMEOUT;
			result = GL_RESULT_INACTIVITY;
		}

		// Update the display
		if (updateDisplay)
		{
			ASSERT(pinEntryContext->infos->refresh != NULL);
			pinEntryContext->infos->refresh(pinEntryContext->infos, label, pinEntryContext->pinLength);
		}
		break;

	case ERR_TIMEOUT:
		events = (eventsToWait & pinEntryContext->infos->eventsToWait);
		if (events != 0)
		{
			// User event
			if (pinEntryContext->infos->userEvents != NULL)
			{
				if (pinEntryContext->infos->userEvents(pinEntryContext->infos, label, events, pinEntryContext->pinLength))
				{
					// Continue the PIN entry
					result = GL_RESULT_SUCCESS;
				}
				else
				{
					// Stop the PIN entry
					pinEntryContext->status = EPSTOOL_PINENTRY_EVENT;
					result = GL_KEY_CANCEL;
				}
			}
			else
			{
				// No custom 'user event' function => Stop the PIN entry
				pinEntryContext->status = EPSTOOL_PINENTRY_EVENT;
				result = GL_KEY_CANCEL;
			}
		}
		else
		{
			// Timeout from scheme => pinpad error
			pinEntryContext->status = EPSTOOL_PINENTRY_ERROR;
			result = GL_KEY_CANCEL;
		}
		break;

	case C_SEC_ERR_PINENTRY_CURRENT:
	default:
		// Error => stop the PIN entry
		pinEntryContext->status = EPSTOOL_PINENTRY_ERROR;
		result = GL_KEY_CANCEL;
		break;
	}

	return result;
}

//! \brief Ask for a PIN.
//! \param[in] goalHandle The GOAL handle.
//! \param[in] title Title of the message box (or null if no title).
//! \param[in] text Text displayed (null hides text).
//! \param[in] help Help displayed (null hides text).
//! \param[in] pinEntryInfo PIN entry parameters.
//! \param[out] pinLength Length of the entered PIN.
//! \return Any value of \ref EPSTOOL_PinEntry_Status_e.
EPSTOOL_PinEntry_Status_e EPSTOOL_PinEntry(T_GL_HGRAPHIC_LIB goalHandle, const char *title, const char *text, const char *help, EPSTOOL_PinEntry_Infos_t *pinEntryInfo, int *pinLength)
{
	T_GL_SCHEME_INTERFACE pinEntryInterface;
	__EPSTOOL_PinEntry_Context_t pinEntryContext;

	ASSERT(goalHandle != NULL);
	ASSERT(pinEntryInfo != NULL);
	ASSERT(pinEntryInfo->refresh != NULL);

	memclr(&pinEntryInterface, sizeof(pinEntryInterface));
	memclr(&pinEntryContext, sizeof(pinEntryContext));

	// Set PIN entry parameters
	pinEntryContext.infos = pinEntryInfo;
	pinEntryContext.firstRefresh = TRUE;
	pinEntryContext.pinLength = 0;
	pinEntryContext.status = EPSTOOL_PINENTRY_ERROR;

	// Ask for a PIN entry
	pinEntryInterface.open = &__EPSTOOL_PinEntry_Open;
	pinEntryInterface.close = &__EPSTOOL_PinEntry_Close;
	pinEntryInterface.refresh = &__EPSTOOL_PinEntry_Refresh;
	pinEntryInterface.privateData = &pinEntryContext;
	GL_Dialog_Scheme(goalHandle, title, text, help, &pinEntryInterface);

	// Return the PIN length and PIN entry status
	if (pinLength != NULL)
	{
		*pinLength = pinEntryContext.pinLength;
	}
	return pinEntryContext.status;
}

int encryptPIN(void){
    int              nStatus = -1;
    /*
     * SchGetPinGN scheme should be used in NAR US region for PIN entry. This
     * scheme allows to configure PIN entry process so just below are few notes
     * on how to do that.
     *
     * T_SEC_ENTRYCONF.ucEchoLine value is triggering specific meaning and it's
     * behavior is explained below:
     *
     * Input:
     *
     * - bit_7:
     *      0 : to return FCT keys (T_SK10, T_SKHAUT, T_SK2, T_SK3, T_SKBAS, ...)
     *      1 : not to return FCT keys
     *
     * - bits_6 to bit_1:
     *      RUF to 0
     *
     * - bit_0:
     *      0 : Standard T_VAL input mode
     *      1 : Automatic T_VAL input mode
     *
     *
     * Notes:
     *
     * By 'output' SEC_PinEntry() output parameters values are assumed. Just
     * below is SEC_PinEntry() function prototype parameters:
     *
     * int
     * SEC_PinEntry(
     *      unsigned int*  pt_uiEventToWait,
     *      unsigned char* pt_ucKey,
     *      int*           ptibToContinue
     *      );
     *
     * Output:
     *
     * - ucEchoChar:
     *      T_SEC_ENTRYCONF.ucEchoChar key means 0..9 input and, if bit_7 is 0,
     *      function also reports FCT keys (like '+', 'F', ...)
     *
     * - 02:
     *      numeric key input not saved for PIN (> T_SEC_ENTRYCONF.ucMaxDigits)
     *
     * - T_CORR:
     *      T_CORR key (if PIN length > 0 then the last char PIN input is not
     *      saved)
     *
     * - T_ANN:
     *      T_ANN key (output *ptibToContinue is FALSE)
     *
     * - 03:
     *      - bit_0:
     *          0 : PIN length < T_SEC_ENTRYCONF.ucMinDigits
     *          1 : PIN not saved
     *
     * - T_VAL:
     *      - bit_0
     *          0 : T_SEC_ENTRYCONF.ucMinDigits <= PIN length <= T_SEC_ENTRYCONF.ucMaxDigits
     *              Means PIN is saved, *ptibToContinue will be set to FALSE
     *          1 : PIN length = T_SEC_ENTRYCONF.ucMaxDigits;
     *              Means PIN is saved, *ptibToContinue will be set to FALSE
    */

    /*
     * we do not want to receive FCT keys and we would like to be in Standard
     * T_VAL input mode
     */

    /*
     * run 'PIN entry' procedure with given parameters
     */
	xKeyDukptPin.iSecretArea = (SEG_ID)0x00042131; //list
	xKeyDukptPin.cAlgoType = TLV_TYPE_TDESDUKPT;   // PIN key is a DES Key
	xKeyDukptPin.usNumber = 32;//slot
	xKeyDukptPin.uiBankId = 0x80000000;

	txPinBlock      xPinBlock;
	txPanBlock      xPanBlock;
	txPinDukptSMID  xSMID;

	memset( &xPinBlock, 0, sizeof( xPinBlock ) );
	memset( &xPanBlock, 0, sizeof( xPanBlock ) );
	memset( &xSMID, 0, sizeof( xSMID ) );

	char xPanNO[20]={0};
	int panLength;
	int OrginalPanLength;
	char pan[19 +1]={0};
	getCardNumber(xPanNO,&panLength);
	OrginalPanLength = strlen(xPanNO);
	if(panLength >16)
		strncpy(pan, xPanNO +6, panLength -6);
	else if(panLength == 16)
		strncpy(pan, xPanNO +3, panLength -3);
	else
		strncpy(pan, xPanNO +2, panLength -2);
	panLength=strlen(pan);
	memset(xPanNO, 0, sizeof(xPanNO));
	memcpy(xPanNO, pan, panLength -1);
	memset(pan, 0, sizeof(pan));
	strcpy(pan,"0000");
	strcat(pan,xPanNO);
	Aschex(xPanBlock,pan,strlen(pan));

	// DUKPT Pin Ciphering (ANSI X9.24)
	nStatus = SEC_DukptEncryptPin( C_SEC_PINCODE,
								&xKeyDukptPin,
								DUKPT_ENCRYPT_PIN,
								xPanBlock,
								xPinBlock,
								xSMID
								);
	if( OK != nStatus )
	{
		nStatus=FALSE;//Error
	}
	else{
		char pinData[16+1]={0};
		char pinKSN[20+1]={0};
		memcpy(pinData, hexToASCII(xPinBlock,PIN_BLOC_SIZE), 2*PIN_BLOC_SIZE);
		memcpy(pinKSN, hexToASCII(xSMID,DUKPT_SMID_SIZE), 2*DUKPT_SMID_SIZE);
		setDUKPTPINBlock (pinData);
		setDUKPTKSN (pinKSN);
		nStatus=TRUE;
	}
	return nStatus;
}

