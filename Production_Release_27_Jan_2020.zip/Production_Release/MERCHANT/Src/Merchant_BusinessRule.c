/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   07/01/2018   This module implements Merchant's business rules              *
 * ---------------------------------------------------------------------------------------------- */
#include <sdk_tplus.h>
#include <OSL_Logger.h>
#include <GL_GraphicLib.h>

#include "_emvdctag_.h"
#include "del_lib.h"
#include "def_tag.h"
#include "servcomm.h"
#include "LinkLayer.h"
#include "serveng.h"
#include "EngineInterfaceLib.h"
#include "EngineInterface.h"
#include "GL_GraphicLib.h"
#include "sec_interface.h"
#include "GTL_Assert.h"
#include "GTL_Convert.h"
#include "GL_Types.h"
#include "MerchantData.h"


int calculateFee (char *transactionType){
	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Please Wait ...", GL_ICON_INFORMATION, GL_BUTTON_ALL,0);
	setTransactionType("CALCULATE_FEE");
	return processOnlineTransaction (transactionType);
}
void constructPayableData (char *displayFee) {
	struct sFeesApplied feesApplied [MAX_FEE_COUNT]={0};//Total= %d.%02d Please Confirm?
	int feeCount;
	char displayMsg[100]={0};
	int i=0;
	int totalAmt=0;
	if (getProprietaryData (feesApplied,&feeCount)) {
		for(i=0;i<feeCount;i++){
			if(!strcmp(feesApplied[i].feeType,"CORE"))
				sprintf(displayMsg,"Amount = %s \n",feesApplied[i].feeAmount);
			else
				sprintf(displayMsg,"%s Amount = %s \n",feesApplied[i].feeType,feesApplied[i].feeAmount);
			strcat(displayFee,displayMsg);
			memset(displayMsg,0,sizeof(displayMsg));
			if (strcmp(feesApplied[i].feeType,"CHARG")){
				float temp_amount=0.00;
			   temp_amount=atof(feesApplied[i].feeAmount)*100;
			   totalAmt = totalAmt + temp_amount;

			}
		}
		memset(displayMsg,0,sizeof(displayMsg));
		sprintf(displayMsg,"Total= %d.%02d \n Please Confirm?",totalAmt/100, abs(totalAmt%100));
		strcat (displayFee,displayMsg);
		return;
	}
	return;
}
void constructListOfTxnDetails(char * displayTxnDetails,char * txnReferenceNo,int indexNo){
	struct refundTxnListBuffer listOfTxnDetails [MAXIMIUM_TXN_IN_A_LIST];
	memset(listOfTxnDetails,0,sizeof(listOfTxnDetails));
	int txnCount=0;
	char displayDetails[100]={0};
	getTxnListForRefund(listOfTxnDetails,&txnCount);
	sprintf(displayDetails,"Txn ID = %s\nAmount = %s \n[No]              [Yes]",listOfTxnDetails[indexNo].txn_ReferenceNo,listOfTxnDetails[indexNo].txnAmount);
	strcpy(txnReferenceNo,listOfTxnDetails[indexNo].txn_ReferenceNo);
	strcpy(displayTxnDetails,displayDetails);
}
void constructRefundData (char *displayFee) {
	struct sFeesApplied feesApplied [MAX_FEE_COUNT]={0};//Total= %d.%02d Please Confirm?
	int feeCount;
	char displayMsg[200]={0};
	int i=0;
	int totalAmt=0;
	if (getProprietaryData (feesApplied,&feeCount)) {
		for(i=0;i<feeCount;i++){
			sprintf(displayMsg,"%s Amount = %s \n",feesApplied[i].feeType,feesApplied[i].feeAmount);
			strcat(displayFee,displayMsg);
			memset(displayMsg,0,sizeof(displayMsg));
			if (strcmp(feesApplied[i].feeType,"CHARG")){
				float tempAmt=0.00;
				tempAmt=atof(feesApplied[i].feeAmount)*100;
				totalAmt = totalAmt +  tempAmt;
			}
		}
		memset(displayMsg,0,sizeof(displayMsg));
		if (IsIPP3XX()){
			sprintf(displayMsg,"Refund Max= %d.%02d",totalAmt/100, abs(totalAmt%100));
			strcat (displayFee,displayMsg);
		} else{
		sprintf(displayMsg,"Refund Max= %d.%02d \n[Edit]       [Continue]",totalAmt/100, abs(totalAmt%100));
		strcat (displayFee,displayMsg);
		}
		return;
	}
	return;
}
