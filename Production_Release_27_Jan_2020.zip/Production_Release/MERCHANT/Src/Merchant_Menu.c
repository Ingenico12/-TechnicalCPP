/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   04/01/2018   This module implements User Interface/ menu of POS application*
 * ---------------------------------------------------------------------------------------------- */
#include <sdk_tplus.h>
#include <OSL_Logger.h>
#include <GL_GraphicLib.h>
#include "_emvdctag_.h"
#include "del_lib.h"
#include "def_tag.h"
#include "servcomm.h"
#include "LinkLayer.h"
#include "serveng.h"
#include "EngineInterfaceLib.h"
#include "EngineInterface.h"
#include "GL_GraphicLib.h"
#include "sec_interface.h"
#include "GTL_Assert.h"
#include "GTL_Convert.h"
#include "GL_Types.h"
#include "MerchantData.h"

//T_GL_HGRAPHIC_LIB APEMV_UI_GoalHandle();
/* ========================================================================	*/
/* Global variables                                                         */
/* ========================================================================	*/
unsigned short Bypass_Required;
unsigned short TransactionForcedOnline;
unsigned char RetransmitIndicator;
TLV_TREE_NODE CUMORE_Tree;
unsigned short TransactionReactivateAsked;
extern int TransactionLoopMode;
extern unsigned long loop_amount;
static int flag_app;
static int temsCheck;
int batchall=0;
int tmsDownloadProcess(char *choice);
void displayCardTypeMenu();
static Telium_File_t *sKeyboard;
static Telium_File_t *sDisplay;

/*+************* VARIABLES *************************************************+*/
extern char appName[OBJECT_NAME_LEN + 1];

extern struct sUserData * pUserData;

// Disable header, footer, led in order to Maximize canvas size
int sSavedStatusHeader, sSavedStatusLeds, sSavedStatusFooter;

void appDownloadForIPP3XX(NO_SEGMENT appliId){
/*********************************************************************
		 *
		 * @param Application Download For PINPAD
		 * @return
**********************************************************************/
		char httpTMSFileHeader[]=
					"GET /payment-services/tms/file/pinpad HTTP/1.0\r\n"
					"Accept: application/xml\r\n"
					"terminalId: %s\r\n\n\r";
					//"fileType: %d\r\n\n\r";
					//"apiKey: %s\r\n\n\r";
		/*char httpTMSUpdateHeader[]=
					"POST /TMSWeb/rest/tms/update HTTP/1.0\r\n"
					"Content-Type: application/xml\r\n"
					"apiKey: %s\r\n"
					"Content-Length: %d\r\n\r\n";
		char tmsUpdatebody[]=
					"<TerminalManagementMBAModel>\r\n"
				    "<fileType>%d</fileType>\r\n"
				    "<fileVersion>%s</fileVersion>\r\n"
					"<terminalId>%s</terminalId>\r\n"
					"</TerminalManagementMBAModel>\r\n";*/
		ulong tmsmenue=0;
		char requestbuf[5000]={0};
		char responsebuf[5000]={0};
		char authHeader[1024]={0};
		char revreq[1024]={0};
		char tmsterminal_id[20 +1]={0};
		char tempterminal[20 +1]={0};
		char filetype[2]={0};
		char filever[20 +1]={0};
		char tempfilever[20 +1]={0};
		char apikey[48 +1]={0};
        ulong keyPressed=NULL;
		initUIContext(_OFF_);
		struct sUserMenu menutm={.menuTms={"Software update",0}};
		tmsmenue=GL_Dialog_Choice (APEMV_UI_GoalHandle(),"PRELOADER",(const)menutm.menuTms, tmsmenue, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
		if(tmsmenue != GL_KEY_CANCEL){
			restoreAdminParameters();
			switch(tmsmenue){
			case 0:
				keyPressed=GL_Dialog_Message(APEMV_UI_GoalHandle(), "SOFTWARE", "Software Installing",NULL, GL_BUTTON_ALL, 2*GL_TIME_SECOND);
				keyPressed=GL_Dialog_Text (APEMV_UI_GoalHandle(), "Terminal No.", "Enter Terminal ID:","/d/d/d/d/d/d/d/d/d/d/d/d/d/d/d/d/d/d/d/d",
										tmsterminal_id, sizeof(tmsterminal_id), 3*GL_TIME_MINUTE);
					if(keyPressed != GL_KEY_CANCEL && strlen(tmsterminal_id)){
					memset(requestbuf, 0, sizeof(requestbuf));
					memset(revreq, 0, sizeof(revreq));
					memset(responsebuf, 0, sizeof(responsebuf));
					sprintf(revreq,httpTMSFileHeader,tmsterminal_id);
					strcpy(requestbuf, revreq);
					//setErrorCode("ERROR:000");
					if(!hostcall(requestbuf,responsebuf,0))
						break;
					//if(!strcmp(getErrorCode(),"ERROR:000")){
					if(iFtp_download_Connect(FALSE))
					{
						GL_Dialog_Message(APEMV_UI_GoalHandle(), "SOFTWARE", "Restarting Terminal\n Please Wait...",NULL, GL_BUTTON_ALL, 2*GL_TIME_SECOND);
						Telium_Exit(1);
						}
					   //}
					}
				break;
			default:
				break;
			}
		}
		displayError(getErrorCode());
		releaseUIContext();
}

void externalPINPadUI (NO_SEGMENT appliId) {
	initUIContext(_OFF_);
	LL_HANDLE hUSB=NULL;
	int iRet=0;
	char retMsg[20] = {0};
	ulong choice=0,result=0;
	char clerkResponse [sizeof (struct sUserData)+1]= {0};
	if(!restoreAdminParameters()){
	  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"Configuration File \n Missing",
							NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
	  setErrorCode("ERROR:012");
	  goto lblEnd;
	}
	setErrorCode("ERROR:000");
	if(strcmp(getTransactionType(),FULL_REVERSAL)){
		if(sKeyboard){
			Telium_Fclose(sKeyboard);
			sKeyboard = NULL;
		}
		readCardData (appliId, retMsg);
		//if pin entry cancelled by card holder, transaction process or terminated
		if (getPINEntryCancelbyCardholder() == PIN_ENTRY_CANCELLED_BY_CARDHOLDER){
			setErrorCode("ERROR:044");
			acknowledgeClerk();
			releaseUIContext();
			return;
		}
		if (strcmp(getErrorCode(),"ERROR:000")) {
			displayError(getErrorCode());
			acknowledgeClerk();
			releaseUIContext();
			return;
		}
		if(sKeyboard == NULL){
			sKeyboard = Telium_Fopen("KEYBOARD", "r*");
		}
	}
lblEnd:
	hUSB = OpenUSB();
	if (hUSB != NULL) {
		iRet = ConnectUSB(hUSB);
		if (iRet == LL_ERROR_OK) {
			iRet = SendUSB(hUSB, pUserData, (word) sizeof (struct sUserData));   // Send data
			if (!strcmp(getErrorCode(),"ERROR:000")) {
				GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Please Wait...", GL_ICON_INFORMATION,
											GL_BUTTON_ALL, GL_TIME_SECOND);
				iRet = ReceiveUSB (hUSB, clerkResponse,240*GL_TIME_SECOND);
				memcpy(pUserData, clerkResponse,sizeof (struct sUserData));
				if (strcmp(getErrorCode(),"ERROR:000")) {
					displayError(getErrorCode());
				}
				else {
					GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, pUserData->mUserText, GL_ICON_INFORMATION,
							GL_BUTTON_ALL, 10*GL_TIME_SECOND);
				}
			}
			else{
				displayError(getErrorCode());
			}
			DisconnectUSB(hUSB);
		}
		//CloseUSB();
	}
	releaseUIContext();
	return;
}
void externalPINPadUIForCardTypeSelection(NO_SEGMENT appliId){
	initUIContext(_OFF_);
	LL_HANDLE hUSB=NULL;
	int iRet=0;
	setErrorCode("ERROR:000");
	if (!strcmp(getTransactionType(),"CARDTYPESELECTION")) {
		displayCardTypeMenu();
		if (strcmp(getErrorCode(),"ERROR:000")) {
			displayError(getErrorCode());
			acknowledgeClerk();
			releaseUIContext();
			return;
		}
	hUSB = OpenUSB();
	if (hUSB != NULL) {
		iRet = ConnectUSB(hUSB);
		if (iRet == LL_ERROR_OK) {
			iRet = SendUSB(hUSB, pUserData, (word) sizeof (struct sUserData));   // Send data
			DisconnectUSB(hUSB);
		}
	  }
	}
	releaseUIContext();
	return;
}
void menuHolderDisagree (NO_SEGMENT appliId) {
	LL_HANDLE hUSB=NULL;
	int iRet=0;
	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "CUSTOMER CANCEL PAYMENT", GL_ICON_INFORMATION, GL_BUTTON_ALL, 1*GL_TIME_SECOND);
	hUSB = OpenUSB();
	if (hUSB != NULL) {
		iRet = ConnectUSB(hUSB);
		if (iRet == LL_ERROR_OK){
			strcpy(pUserData->mUserText, "CUSTOMER DISAGREED");
			setErrorCode("ERROR:012");
			iRet = SendUSB(hUSB, pUserData, (word) sizeof (struct sUserData));   // Send data
			DisconnectUSB(hUSB);
		}
		//CloseUSB();
	}
	houseKeeping();
}
void merchantTerminalUI (NO_SEGMENT appliId) {
  ulong mainChoice = 0;
  ulong moreChoice = 0;
  ulong deptChoice = 0;
  ulong subChoice  = 0;
  ulong choice  = 0;
  ulong keyPressed = 0;
  ulong feeOption =0;
  ulong gatewayOption=0;
  ulong refundFlg =0;
  ulong voidFlg =0;
  ulong authOnlyFlg =0;
  ulong endOfDayFlg=0;
  ulong pinpadMode=0;
  ulong receiptMode=0;
  ulong referenceMode=0;
  ulong level_2_Mode=0;
  ulong level_3_Mode=0;
  ulong autoBatchMode=0;
  ulong posMode=0;
  ulong subRefundChoice  = 0;
  ulong refundChoice  = 0;
  ulong duplicateRecpChoice  = 0;
 // APEMV_UI_GoalHandle()ce = APEMV_UI_GoalHandle();
  ulong result;
  if(!restoreAdminParameters()){
	  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"Configuration File \n Missing",
							NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
	  goto lblEnd;
  }
  setUserDataParameters();
  char externalPinPad[2]={0};
  getPinPadMode(externalPinPad);
  initUIContext(_OFF_);
  char isLogoutDone[2]={0};
  isLogout(isLogoutDone);
  if(atoi(isLogoutDone))
	  temsCheck=temsUserMenu();
  /**********************************************LOAD MENU****************************************************************************/

  struct sUserMenu menu=  {.menuMore ={"Pre Loader","User Management","Transaction Params",/*"Settlement Params",*/
									"Terminal Params","Gateway Params","System","Merchant Management", 0} ,
  	  	  	  	  	  	  .menuTxnParam ={"Max Trans Amt","Fee",0},
						  .menuSettleParam ={"Auto Batch","Auto Batch Time",0},
						  .menuTerminalParam ={"Terminal ID",				//"Merchant ID",
								  "Merchant Param","Receipt Disclaimer","Home Screen Message",0},
								  /****** For Pre Loader Change */
						  //.menuMerchantParam={"Merchant Transactions","Name","Address","City","State","ZIP Code","Phone Number",0},
						  .menuMerchantParam={"Merchant Transactions","Name",0},
						  .menuReceipt={"Receipt Header","Receipt Footer",0},
						  .menuDownloadParam ={"Set IP","Set PORT","Set URL","Set CGI",0},
						  .menuSystem ={"Date/Time","App Version","PIN Pad","Reference-ID",
									  	  "Point-of-Sale Mode","Receipt","Level-2","Level-3",0},
						  .menuGateway={"TCP/IP","Web Service",0},
						  .menuAccept={"Yes","No",0},
						  .menuGatewayTcp={"Gateway API Key","Gateway IP","Gateway Port",0},
						  .menuGatewayWeb={"Gateway API Key","Gateway URL","Gateway CGI",0},
						  .menuPinPad={"External","Internal",0},
						  .menuTransactions={"Sale","Refund","Void","Auth-Only/Capture","End-of-Day",0},
						  .menuPOSMode={"Stand-Alone","Semi-Integrated",0},
  	  	  	  	  	  	  .menuRefundDetails={"Card Last4Digit","Txn ID",0},
	  					  .menuBatchDetails={"Department ","ALL",0},
  	  	  	  	  	  	  .menuDuplicateReceptChoice={"Card Last4Digit","Txn ID","Last Copy",0},};
  	  	  	  	  	  	  /*.menuDuplicateReceptChoice={"Card Last4Digit","Last Copy",0},};*/
  char txnFlag[2]={0};
  int idx = 0;
  menu.menuMain[idx]="Sale";					idx++;
  isAuthOnlySupported(txnFlag);
  if(atoi(txnFlag)){
	  menu.menuMain[idx]="Auth-Only";   		idx++;
	  menu.menuMain[idx]="Capture";				idx++;
  }
  isRefundSupported(txnFlag);
  if(atoi(txnFlag)){
	  menu.menuMain[idx]="Refund"; 				idx++;
  }
  isVoidSupported(txnFlag);
  if(atoi(txnFlag)){
  	  menu.menuMain[idx]="Reversal";  			idx++;
  }
  isManBatchSupported(txnFlag);
  if(atoi(txnFlag)){
	menu.menuMain[idx]="Batch Summary";  			idx++;
  }
  menu.menuMain[idx]="Transaction Summary";  		idx++;
  menu.menuMain[idx]="Duplicate Receipt";		idx++;

  // Clerk and admin login
  if(temsCheck !=2){
  menu.menuMain[idx]="More...";		idx++;
  }
  menu.menuMain[idx]="Logout";		idx++;
  menu.menuMain[idx] = 0;

  if(temsCheck == 3)
  	  goto lblEnd;
/****************************************************************************************************************************/

  do {
	  mainChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "TRANSACTION",(const) menu.menuMain,
			  mainChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);

	  if(mainChoice > 9) {mainChoice = GL_KEY_CANCEL;}
	  if(mainChoice!=GL_KEY_CANCEL) {
		  char morePassword [5]={0};
		  char amount [13] = "000";
		  char lastFourDigitCardNo[4+1]={0};
		  char userTxnNo[22]={0};
		  int amountEntryFlag;
		  int i=0;
		  char departmentList[DEPARTMENT_COUNT][DEPARTMENT_NAME_LEN+1]={0};
		  char deptMidList[DEPARTMENT_COUNT][MERCHANT_ID_LEN+1]={0};
		  char deptAPIKeyList[DEPARTMENT_COUNT][APIKEY_LEN+1]={0};
		  char *deptMenu[DEPARTMENT_NAME_LEN+1]={0};
		  memset(departmentList,0,sizeof(departmentList));
		  getDepartmentList(departmentList);
		  getMIDList(deptMidList);
		  getAPIKeyList(deptAPIKeyList);
		  char deptCount[2]={0};
		  getDepartmentCount(deptCount);
		  for(i=0;i<atoi(deptCount);i++){
			if(strlen(departmentList[i])<=0)
				continue;
			deptMenu[i]=departmentList[i];
		  }
		  deptMenu[i]=0;
		  char referenceNo[20 +1]={0};
		  char referenceFlag[2]={0};
		  getReferenceFlag(referenceFlag);
		  char clerkID[6+1]={0};
		  //getClerkId(clerkID);
		  fetch_appconfig_data("CLERK_ID",clerkID);
		  setErrorCode("ERROR:000");
		  if(!strcmp(menu.menuMain[mainChoice],"Sale")){
			  /* Department Screen */
			  if(atoi(deptCount)<=0){
				  setErrorCode("ERROR:041");
				  break;
			  }
			  deptChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "TRANSACTION",(const) deptMenu,
						deptChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
			  if(deptChoice > DEPARTMENT_COUNT) {deptChoice = GL_KEY_CANCEL;}
			  if(deptChoice!=GL_KEY_CANCEL) {
				  setDepartmentName(&departmentList[deptChoice][0]);
				  setDeptMID(&deptMidList[deptChoice][0]);
				  setDeptAPIKey(&deptAPIKeyList[deptChoice][0]);
				  setMerchantChoice(deptChoice);
				//memcpy (pUserInput->mDepartmentName,&departmentList[deptChoice][0], DEPARTMENT_NAME_LEN);
			  }
			  else{
				//mainChoice=GL_KEY_CANCEL;
				continue;
	   		  }
			  /*Reference ID Screen*/
			  if(atoi(referenceFlag)){
			  result= GL_Dialog_Text (APEMV_UI_GoalHandle(), "TRANSACTION", "Enter Reference No:",
											"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", referenceNo, sizeof(referenceNo), 3*GL_TIME_MINUTE);
			  if (result == GL_KEY_VALID){
				  setReferenceNo(referenceNo);
			   }
			  else
				  continue;
			  }
			  /*Clerk ID Screen*/
			  result= GL_Dialog_Text (APEMV_UI_GoalHandle(), "TRANSACTION", "Enter Clerk ID:",
											"/d/d/d/d/d/d", clerkID, sizeof(clerkID), 3*GL_TIME_MINUTE);
			  if (result == GL_KEY_VALID){
			  	int length=strlen(clerkID);
			  	char tempID[6]={0};
				memcpy (&tempID[sizeof(tempID) - length],clerkID, length);
				memset (tempID, '0', sizeof (tempID) - length);
				saveAdminParameter("CLERK_ID",tempID);
				setClerkID(tempID);
    		   }
			  else
				  continue;
			  /* Screen - Enter Amount */
			  do{
				  amountEntryFlag=TRUE;
				  memset(amount,0,sizeof(amount));
				  result = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "Amount", "Enter Amount:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", amount, sizeof(amount),"USD",
						  GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
				  char maxTxnAmt[13]={0};
				  getMaxTxnAmount(maxTxnAmt);
				  if (result==GL_KEY_VALID){
					  if(atoi(amount)==0)
						  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Invalid Amount",GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
					  else if(strtoull(amount,NULL,10)>strtoull(maxTxnAmt,NULL,10))
						  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Exceed Merchant Max Limit",GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
					  else
						  amountEntryFlag=FALSE;
				  }else{
					  result=GL_KEY_CANCEL;
					  mainChoice=GL_KEY_CANCEL;
					  break;
				  }
			  }while(amountEntryFlag);
			  //Amount Entry Done
			  if (result == GL_KEY_VALID){
				  int length = strlen(amount);
				  memcpy (&amount[sizeof(amount) - length-1], amount, length);
				  memset (amount, '0', sizeof (amount) - length-1);
				  setInputAmount (amount);
				  char creditSupport[2]={0},debitSupport[2]={0};
				  isCreditSupported(creditSupport);
				  isDebitSupported(debitSupport);
				  if (atoi(creditSupport)&&atoi(debitSupport)){
					  if (atoi(externalPinPad)){
						  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Connecting to PINPAD...", NULL, GL_BUTTON_ALL, 0);
						  setTransactionType("CARDTYPESELECTION");
						  if (!connectExternalPINPad()) {
							  //display msg unable to connect pinpad within time limit
							  setErrorCode("ERROR:049");
							  mainChoice = GL_KEY_CANCEL;
							  break;
						  }
					  }
					  else
						  displayCardTypeMenu();
				  }
				  if (strcmp(getErrorCode(),"ERROR:000")){
					  mainChoice = GL_KEY_CANCEL;
					  break;
				  }
				  if (calculateFee (PURCHASE)){
					 char displayFee [200] = {0};
					 constructPayableData(displayFee);
					 if ( strlen (displayFee) != 0) {
						 result = GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, displayFee, NULL, GL_BUTTON_ALL, 30*GL_TIME_SECOND);
					 	 if (result == GL_KEY_VALID) {
					 		setTransactionType (PURCHASE);
					 		char level2_DataDisplayFlag[2]={0};
					 		char level3_DataDisplayFlag[2]={0};
					 		getLevel_2_DataFlag(level2_DataDisplayFlag);
					 		getLevel_3_DataFlag(level3_DataDisplayFlag);
					 		if (!atoi(externalPinPad)){
								char retMsg[20]= {0};
								if(sKeyboard){
									Telium_Fclose(sKeyboard);
									sKeyboard = NULL;
								}
								readCardData (appliId, retMsg);
								if(sKeyboard == NULL){
									sKeyboard = Telium_Fopen("KEYBOARD", "r*");
								}
								//if pin entry cancelled by card holder, transaction process or terminated
								if (getPINEntryCancelbyCardholder() == PIN_ENTRY_CANCELLED_BY_CARDHOLDER){
										mainChoice = GL_KEY_CANCEL;
										break;
								}
								if (strcmp(getErrorCode(),"ERROR:000")) {
									 mainChoice = GL_KEY_CANCEL;
									 break;
								}
								setTransactionType(PURCHASE);
								char userCardNo[20]={0}; int cardLength=0;
								getCardNumber(userCardNo,&cardLength);
								/*if (!cardLength){
									setErrorCode("ERROR:039");
									goto lblEnd;
								}*/
								//Display Level2 Data Details
								if (atoi(level2_DataDisplayFlag)) {
									if(cardLength){
									if(userCardNo[0] == '4' || userCardNo[0] == '5'  ||userCardNo[0] == '2' ){
										if(GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"Do you want to add\nLevel 2 data?", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND)==GL_KEY_VALID){
											setLevel2Flg(TRUE);
											getLevel2Input(); //ENTER LEVEL 2 FIELDS
										}
										else
											setLevel2Flg(FALSE);
									}
									else if(!memcmp (userCardNo, "34", 2) || !memcmp (userCardNo, "37", 2)){
										if(GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"Do you want to add\nLevel 2 data?", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND)==GL_KEY_VALID){
											setLevel2Flg(TRUE);
											getLevel2Input(); //ENTER LEVEL 2 FIELDS
										}
										else
											setLevel2Flg(FALSE);
									}
								  }
								}
								// Display Level3 Details
								if (atoi(level3_DataDisplayFlag)) {
									if(cardLength){
									if(userCardNo[0] == '4' || userCardNo[0] == '5'  ||userCardNo[0] == '2' ){
										if(GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"Do you want to add\nLevel 3 data?", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND)==GL_KEY_VALID){
											setLevel3Flg(TRUE);
											getLevel3Input(); //ENTER LEVEL 3 FIELDS
										}
										else
											setLevel3Flg(FALSE);
									}
								}
								}
								processPaymentTransaction();
					 		}
					 		else if (atoi(externalPinPad)){
								GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Connecting to PINPAD...", NULL, GL_BUTTON_ALL, 0);
								 if (connectExternalPINPad ()) {
									 if (!strcmp(getErrorCode(),"ERROR:000")) {
										 char userCardNo[20]={0}; int cardLength=0;
									    	getCardNumber(userCardNo,&cardLength);
									    	/*if(!cardLength){
									    		setErrorCode("ERROR:039");
									    		goto lblEnd;
									    	}*/
										 //Display level-2 Details
										 if(atoi(level2_DataDisplayFlag)){
												if(cardLength){
												if(userCardNo[0] == '4' || userCardNo[0] == '5'  ||userCardNo[0] == '2' ){
													if(GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"Do you want to add\nLevel 2 data?", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND)==GL_KEY_VALID){
														setLevel2Flg(TRUE);
														getLevel2Input(); //ENTER LEVEL 2 FIELDS
													}
													else
														setLevel2Flg(FALSE);
												}
												else if(!memcmp (userCardNo, "34", 2) || !memcmp (userCardNo, "37", 2)){
													if(GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"Do you want to add\nLevel 2 data?", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND)==GL_KEY_VALID){
														setLevel2Flg(TRUE);
														getLevel2Input(); //ENTER LEVEL 2 FIELDS
													}
													else
														setLevel2Flg(FALSE);
												}
											  }
										 }
										 //Display level-3 details
										 if (atoi(level3_DataDisplayFlag)) {
												char userCardNo[20]={0}; int cardLength=0;
												getCardNumber(userCardNo,&cardLength);
												if(cardLength){
												if(userCardNo[0] == '4' || userCardNo[0] == '5'  ||userCardNo[0] == '2' ){
													if(GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"Do you want to add\nLevel 3 data?", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND)==GL_KEY_VALID){
														setLevel3Flg(TRUE);
														getLevel3Input(); //ENTER LEVEL 3 FIELDS
													}
													else
														setLevel3Flg(FALSE);
												}
											}
										 }
										 processPaymentTransaction ();
										 if (strcmp(getErrorCode(),"ERROR:000")) {
											 mainChoice=GL_KEY_CANCEL;
											 break;
										 }
									 }
									 else {
										 mainChoice=GL_KEY_CANCEL;
										 break;
									 }
								 }
								 else
									 GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"PINPAD Connection  Error", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
							}

					 		mainChoice=GL_KEY_CANCEL;
					 		break;
					 	 }
					 	 else {
					 		 mainChoice=GL_KEY_CANCEL;
					 		 break;
					 	 }
					 }
					 else {
						 mainChoice=GL_KEY_CANCEL;
						 setErrorCode("ERROR:045");
						 break;
					 }
				  }
				  else {
					  mainChoice=GL_KEY_CANCEL;
					  break;
				  }
			  }
			  /*else {
				  mainChoice=GL_KEY_CANCEL;
				  break;
			  }*/
		  }
		  else if(!strcmp(menu.menuMain[mainChoice],"Auth-Only")){//Auth-Only
			  /* Department Screen */
			  if(atoi(deptCount)<= 0){
				  setErrorCode("ERROR:041");
				  break;
			  }
			  deptChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "TRANSACTION",(const) deptMenu,
						deptChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
			  if(deptChoice > DEPARTMENT_COUNT) {deptChoice = GL_KEY_CANCEL;}
			  if(deptChoice!=GL_KEY_CANCEL) {
				  setDepartmentName(&departmentList[deptChoice][0]);
				  setDeptMID(&deptMidList[deptChoice][0]);
				  setDeptAPIKey(&deptAPIKeyList[deptChoice][0]);
				  setMerchantChoice(deptChoice);
				//memcpy (pUserInput->mDepartmentName,&departmentList[deptChoice][0], DEPARTMENT_NAME_LEN);
			  }
			  else{
				//mainChoice=GL_KEY_CANCEL;
				continue;
			  }
			  /*Reference ID Screen*/
			  if(atoi(referenceFlag)){
			  result= GL_Dialog_Text (APEMV_UI_GoalHandle(), "TRANSACTION", "Enter Reference No:",
											"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", referenceNo, sizeof(referenceNo), 3*GL_TIME_MINUTE);
			  if (result == GL_KEY_VALID){
				  setReferenceNo(referenceNo);
			   }
			  else
				  continue;
			  }
			  /*Clerk ID Screen*/
			  result= GL_Dialog_Text (APEMV_UI_GoalHandle(), "TRANSACTION", "Enter Clerk ID:",
											"/d/d/d/d/d/d", clerkID, sizeof(clerkID), 3*GL_TIME_MINUTE);
			  if (result == GL_KEY_VALID){
				int length=strlen(clerkID);
				char tempID[6]={0};
				memcpy (&tempID[sizeof(tempID) - length],clerkID, length);
				memset (tempID, '0', sizeof (tempID) - length);
				saveAdminParameter("CLERK_ID",tempID);
				setClerkID(tempID);
			   }
			  else
				  continue;
			  /* Screen - Enter Amount */
			  do{
				  amountEntryFlag=TRUE;
				  memset(amount,0,sizeof(amount));
				  result = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "Amount", "Enter Amount:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", amount, sizeof(amount),"USD",
						  GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
				  char maxTxnAmt[13]={0};
				  getMaxTxnAmount(maxTxnAmt);
				  if (result==GL_KEY_VALID){
					  if(atoi(amount)==0)
						  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Invalid Amount",GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
					  else if(strtoull(amount,NULL,10)>strtoull(maxTxnAmt,NULL,10))
						  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Exceed Merchant Max Limit",GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
					  else
						  amountEntryFlag=FALSE;
				  }else{
					  result=GL_KEY_CANCEL;
					  mainChoice=GL_KEY_CANCEL;
					  break;
				  }
			  }while(amountEntryFlag);
			  //Amount Entry Done
			  if (result == GL_KEY_VALID){
				  int length = strlen(amount);
				  memcpy (&amount[sizeof(amount) - length-1], amount, length);
				  memset (amount, '0', sizeof (amount) - length-1);
				  setInputAmount (amount);
				  char creditSupport[2]={0},debitSupport[2]={0};
				  isCreditSupported(creditSupport);
				  isDebitSupported(debitSupport);
				  if (atoi(creditSupport)&&atoi(debitSupport)){
					  if (atoi(externalPinPad)){
						  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Connecting to PINPAD...", NULL, GL_BUTTON_ALL, 0);
						  setTransactionType("CARDTYPESELECTION");
						  if (!connectExternalPINPad()) {
							  //display msg unable to connect pinpad within time limit
							  setErrorCode("ERROR:049");
							  mainChoice = GL_KEY_CANCEL;
							  break;
						  }
					  }
					  else
						  displayCardTypeMenu();
				  }
				  if (strcmp(getErrorCode(),"ERROR:000")){
					  mainChoice = GL_KEY_CANCEL;
					  break;
				  }
				  if (calculateFee (PURCHASE)){
					 char displayFee [200] = {0};
					 constructPayableData(displayFee);
					 if ( strlen (displayFee) != 0) {
						 result = GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, displayFee, NULL, GL_BUTTON_ALL, 30*GL_TIME_SECOND);
						 if (result == GL_KEY_VALID) {
							setTransactionType (PREAUTH);
							if (!atoi(externalPinPad)){ //INTERNAL PINPAD
								char retMsg[20]= {0};
								if(sKeyboard){
									Telium_Fclose(sKeyboard);
									sKeyboard = NULL;
								}
								readCardData (appliId, retMsg);
								if(sKeyboard == NULL){
									sKeyboard = Telium_Fopen("KEYBOARD", "r*");
								}
								//if pin entry cancelled by card holder, transaction process or terminated
								if (getPINEntryCancelbyCardholder() == PIN_ENTRY_CANCELLED_BY_CARDHOLDER){
									mainChoice = GL_KEY_CANCEL;
									break;
								}
								if (strcmp(getErrorCode(),"ERROR:000")) {
									 mainChoice = GL_KEY_CANCEL;
									 break;
								}
								processPaymentTransaction();
							}
							else if (atoi(externalPinPad)){ //EXTERNAL PINPAD
							 if (connectExternalPINPad ()) {
								 if (!strcmp(getErrorCode(),"ERROR:000")) {
									 processPaymentTransaction ();
									 if (strcmp(getErrorCode(),"ERROR:000")) {
										 mainChoice=GL_KEY_CANCEL;
										 break;
									 }
								 }
								 else {
									 mainChoice=GL_KEY_CANCEL;
									 break;
								 }
							 }
							 else
								 GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"PINPAD Connection  Error", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
							}

							mainChoice=GL_KEY_CANCEL;
							break;
						 }
						 else {
							 mainChoice=GL_KEY_CANCEL;
							 break;
						 }
					 }
					 else {
						 mainChoice=GL_KEY_CANCEL;
						 setErrorCode("ERROR:045");
						 break;
					 }
				  }
				  else {
					  mainChoice=GL_KEY_CANCEL;
					  break;
				  }
			  }
			  /*else {
				  mainChoice=GL_KEY_CANCEL;
				  break;
			  }*/
		  }
		  else if(!strcmp(menu.menuMain[mainChoice],"Refund")){//Refund

			  /* Department Screen */
			  if(atoi(deptCount)<=0){
				  setErrorCode("ERROR:041");
				  break;
			  }
			  deptChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "TRANSACTION",(const) deptMenu,
						deptChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
			  if(deptChoice > DEPARTMENT_COUNT) {deptChoice = GL_KEY_CANCEL;}
			  if(deptChoice!=GL_KEY_CANCEL) {
				  setDepartmentName(&departmentList[deptChoice][0]);
				  setDeptMID(&deptMidList[deptChoice][0]);
				  setDeptAPIKey(&deptAPIKeyList[deptChoice][0]);
				  setMerchantChoice(deptChoice);
				//memcpy (pUserInput->mDepartmentName,&departmentList[deptChoice][0], DEPARTMENT_NAME_LEN);
			  }
			  else{
				//mainChoice=GL_KEY_CANCEL;
				continue;
			  }
			  /*Reference ID Screen*/
			  if(atoi(referenceFlag)){
			  result= GL_Dialog_Text (APEMV_UI_GoalHandle(), "TRANSACTION", "Enter Reference No:",
											"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", referenceNo, sizeof(referenceNo), 3*GL_TIME_MINUTE);
			  if (result == GL_KEY_VALID){
				  setReferenceNo(referenceNo);
			   }
			  else
				  continue;
			  }
			  /*Clerk ID Screen*/
			  result= GL_Dialog_Text (APEMV_UI_GoalHandle(), "TRANSACTION", "Enter Clerk ID:",
											"/d/d/d/d/d/d", clerkID, sizeof(clerkID), 3*GL_TIME_MINUTE);
			  if (result == GL_KEY_VALID){
				int length=strlen(clerkID);
				char tempID[6]={0};
				memcpy (&tempID[sizeof(tempID) - length],clerkID, length);
				memset (tempID, '0', sizeof (tempID) - length);
				saveAdminParameter("CLERK_ID",tempID);
				setClerkID(tempID);
			   }
			  else
				  continue;
			  //2 sub menu regarding refund,"Enter last 4 digit card number"/"Enter Txn Id"
			  do{
			  refundChoice=GL_Dialog_Menu(APEMV_UI_GoalHandle(), "REFUND",(const) menu.menuRefundDetails,
					  refundChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
			  if(refundChoice>3) {refundChoice=GL_KEY_CANCEL;}
			  if (refundChoice!=GL_KEY_CANCEL) {
				  if(!strcmp(menu.menuRefundDetails[refundChoice],"Card Last4Digit")){	//menu for last 4 digit of card number
					  do{
						  memset(lastFourDigitCardNo,0,sizeof(lastFourDigitCardNo));
						  subRefundChoice= GL_Dialog_Text (APEMV_UI_GoalHandle(), "REFUND", "Enter Last Four Digit\nof Card Number:",
								  "/c/c/c/c", lastFourDigitCardNo, sizeof(lastFourDigitCardNo), 3*GL_TIME_MINUTE);
						  if(subRefundChoice==GL_KEY_CANCEL){
							  mainChoice=GL_KEY_CANCEL;
							  break;
						  }
					  }while(strlen(lastFourDigitCardNo)<4);
					  if(subRefundChoice==GL_KEY_VALID){
					  setLastFourDigitCardNo(lastFourDigitCardNo);
					  setTransactionType (REFUND);
					  processPaymentTransaction();
					  if (strcmp(getErrorCode(),"ERROR:000"))
						  result=GL_KEY_CANCEL;
					  //display the list of refund txn
					  else{
						  char displayTxnDetails [200] = {0};
						  int recordIndexNo=0,i=0;
						  int txnSelectedFlag=FALSE;
						  recordIndexNo=pUserData->mTransactionCount;
						  if(recordIndexNo>=1){
							  while((i<recordIndexNo)&&(txnSelectedFlag==FALSE)){
								  constructListOfTxnDetails(displayTxnDetails,userTxnNo,i);
								  setTransReferenceNo(userTxnNo);
								  result = GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, displayTxnDetails, NULL, GL_BUTTON_ALL, 30*GL_TIME_SECOND);
								  if (result == GL_KEY_VALID)
									  txnSelectedFlag=TRUE;
								  else{
									  i++;
									  if(i==recordIndexNo) //if not selected any txn by end user display the error msg
										  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Refund Transaction not selected",GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND); //setErrorCode("ERROR:042");
									  	  result=GL_KEY_CANCEL;
								  }
							  }
						  }
						  else
							  result=GL_KEY_CANCEL;
				   }
			  }
			}
		    else if(!strcmp(menu.menuRefundDetails[refundChoice],"Txn ID")){	//menu for txn id
				do{
				memset(userTxnNo,0,sizeof(userTxnNo));
				subRefundChoice= GL_Dialog_Text (APEMV_UI_GoalHandle(), "REFUND", "Enter Transaction No:",
					"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", userTxnNo, sizeof(userTxnNo), 3*GL_TIME_MINUTE);
				if(subRefundChoice==GL_KEY_CANCEL){
				refundChoice=GL_KEY_CANCEL;
				break;
				}
				}while(strlen(userTxnNo)==0);
			  }
		   }
		 else{
		  result=GL_KEY_CANCEL;
			break;
			  }
			  }while(refundChoice==GL_KEY_CANCEL);
			  if(result!=GL_KEY_CANCEL)
			  /* Screen - Enter Amount */
				  do{
					  amountEntryFlag=TRUE;
					  memset(amount,0,sizeof(amount));
					  result = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "Amount", "Enter Amount:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", amount, sizeof(amount),"USD",
							  GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
					  char maxTxnAmt[13]={0};
					  getMaxTxnAmount(maxTxnAmt);
					  if (result==GL_KEY_VALID){
						  if(atoi(amount)==0)
							  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Invalid Amount",GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
						  else if(strtoull(amount,NULL,10)>strtoull(maxTxnAmt,NULL,10))
							  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Exceed Merchant Max Limit",GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
						  else
							  amountEntryFlag=FALSE;
					  }else{
						  result=GL_KEY_CANCEL;
						  mainChoice=GL_KEY_CANCEL;
						  break;
					  }
				  }while(amountEntryFlag);
			  //Amount Entry Done
			  if (result == GL_KEY_VALID){
				  int length = strlen(amount);
				  memcpy (&amount[sizeof(amount) - length-1], amount, length);
				  memset (amount, '0', sizeof (amount) - length-1);
				  setInputAmount (amount);
				  char creditSupport[2]={0},debitSupport[2]={0};
				  isCreditSupported(creditSupport);
				  isDebitSupported(debitSupport);
				  if (atoi(creditSupport)&&atoi(debitSupport)){
					  if (atoi(externalPinPad)){
						  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Connecting to PINPAD...", NULL, GL_BUTTON_ALL, 0);
						  setTransactionType("CARDTYPESELECTION");
						  if (!connectExternalPINPad()) {
							  //display msg unable to connect pinpad within time limit
							  setErrorCode("ERROR:049");
							  mainChoice = GL_KEY_CANCEL;
							  break;
						  }
					  }
					  else
						  displayCardTypeMenu();
				  }
				  if (strcmp(getErrorCode(),"ERROR:000")){
					  mainChoice = GL_KEY_CANCEL;
					  break;
				  }
			  }
			  if(result!=GL_KEY_CANCEL){
				 // if (result == GL_KEY_VALID){
				  setTransReferenceNo(userTxnNo);
					  if (calculateFee (REFUND)){
						  char displayFee [200] = {0};
						  constructRefundData(displayFee);
						 if (strlen (displayFee) != 0) {
							 result = GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, displayFee, NULL, GL_BUTTON_ALL, 30*GL_TIME_SECOND);
						 	 if (result == GL_KEY_VALID) {
						 		setTransReferenceNo(userTxnNo);
						 		setTransactionType (REFUND);
						 		if (!atoi(externalPinPad)){ //INTERNAL PINPAD
									char retMsg[20]= {0};
									if(sKeyboard){
										Telium_Fclose(sKeyboard);
										sKeyboard = NULL;
									}
									readCardData (appliId, retMsg);
									if(sKeyboard == NULL){
										sKeyboard = Telium_Fopen("KEYBOARD", "r*");
									}
									//if pin entry cancelled by card holder, transaction process or terminated
									if (getPINEntryCancelbyCardholder() == PIN_ENTRY_CANCELLED_BY_CARDHOLDER){
										mainChoice = GL_KEY_CANCEL;
										break;
									}
									if (strcmp(getErrorCode(),"ERROR:000")) {
										 mainChoice = GL_KEY_CANCEL;
										 break;
									}
									processPaymentTransaction();
						 		}
						 		else if (atoi(externalPinPad)){ //EXTERNAL PINPAD
									 if (connectExternalPINPad ()) {
										 if (!strcmp(getErrorCode(),"ERROR:000")) {
											 processPaymentTransaction ();
											 if (strcmp(getErrorCode(),"ERROR:000")) {
												 mainChoice=GL_KEY_CANCEL;
												 break;
											 }
										 }
										 else {
											 mainChoice=GL_KEY_CANCEL;
											 break;
										 }
									 }
									 else
										 GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"PINPAD Connection  Error", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
						 		}
							 mainChoice=GL_KEY_CANCEL;
							 break;
						 	 }
						 	 else if(result == GL_KEY_CORRECTION){
						 		struct sFeesApplied feesApplied [MAX_FEE_COUNT];//Total= %d.%02d Please Confirm?
						 		int feeCount,i;
						 		if (getProprietaryData (feesApplied,&feeCount)) {
						 			if(feeCount == 1){
						 				GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "No Fee is Applicable", NULL, GL_BUTTON_ALL, 30*GL_TIME_SECOND);
						 			}
						 			else{
										for(i=0;i<feeCount;i++){
											char feeType[20]={0};
											char feeAmount[13]={0};
											if(!strcmp(feesApplied[i].feeType,"CORE") || !strcmp(feesApplied[i].feeType,"CHARG")){
												//i++;
												continue;
											}
											sprintf(feeAmount,"%d",(int)(atof(feesApplied[i].feeAmount)*100));
											sprintf(feeType,"Enter %s Amount:",feesApplied[i].feeType);
											do{
												result = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "EDIT FEE", feeType, "/d/d/d/d,/d/d/d,/d/d/D./D/D", feeAmount, sizeof(feeAmount),"USD",
																							GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
												//int temp = (int)((atof(feesApplied[i].feeAmount))*100);
												/*if(temp<(atoi(feeAmount))){
													GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Invalid Amount", NULL, GL_BUTTON_ALL, 30*GL_TIME_SECOND);
													 continue;
												}*/
												//else{
													memset(feesApplied[i].feeAmount,0,sizeof(feesApplied[i].feeAmount));
													sprintf(feesApplied[i].feeAmount,"%d.%02d",atoi(feeAmount)/100,atoi(feeAmount)%100);
													break;
												//}
											}while(1);

										}
										if(i==feeCount){
											setProprietaryData(feesApplied,feeCount);
											memset(displayFee,0,sizeof(displayFee));
											constructRefundData(displayFee);
											result = GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, displayFee, NULL, GL_BUTTON_ALL, 30*GL_TIME_SECOND);
											if(result == GL_KEY_CANCEL)
											//{
												//i=0;
												//continue;
											//}
											break;
										}

						 			}
						 		}
						 	setTransactionType (REFUND);
						 	setTransReferenceNo(userTxnNo);
						 	if (!atoi(externalPinPad)){ //INTERNAL PINPAD
								char retMsg[20]= {0};
								if(sKeyboard){
									Telium_Fclose(sKeyboard);
									sKeyboard = NULL;
								}
								readCardData (appliId, retMsg);
								if(sKeyboard == NULL){
									sKeyboard = Telium_Fopen("KEYBOARD", "r*");
								}
								//if pin entry cancelled by card holder, transaction process or terminated
								if (getPINEntryCancelbyCardholder() == PIN_ENTRY_CANCELLED_BY_CARDHOLDER){
									mainChoice = GL_KEY_CANCEL;
									break;
								}
								if (strcmp(getErrorCode(),"ERROR:000")) {
									 mainChoice = GL_KEY_CANCEL;
									 break;
								}
								processPaymentTransaction();
						 	}
						 	else if (atoi(externalPinPad)){ //EXTERNAL PINPAD
							 if (connectExternalPINPad ()) {
								 if (!strcmp(getErrorCode(),"ERROR:000")) {
									 processPaymentTransaction ();
									 if (strcmp(getErrorCode(),"ERROR:000")) {
										 mainChoice=GL_KEY_CANCEL;
										 break;
									 }
								 }
								 else {
									 mainChoice=GL_KEY_CANCEL;
									 break;
								 }
							 }
							 else
								 GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"PINPAD Connection  Error", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
						 	}
						 	 }
						 }

					  }
					  else {
						 mainChoice=GL_KEY_CANCEL;
						 break;
					 }

				 // }

			  }
			  mainChoice=GL_KEY_CANCEL;
			  break;
		  }
		  else if(!strcmp(menu.menuMain[mainChoice],"Reversal")){//Reversal

			  if(atoi(deptCount)<=0){
				  setErrorCode("ERROR:041");
				  break;
			  }
			  /* Department Screen */
			  deptChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "TRANSACTION",(const) deptMenu,
						deptChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
			  if(deptChoice > DEPARTMENT_COUNT) {deptChoice = GL_KEY_CANCEL;}
			  if(deptChoice!=GL_KEY_CANCEL) {
				  setDepartmentName(&departmentList[deptChoice][0]);
				  setDeptMID(&deptMidList[deptChoice][0]);
				  setDeptAPIKey(&deptAPIKeyList[deptChoice][0]);
				  setMerchantChoice(deptChoice);
				//memcpy (pUserInput->mDepartmentName,&departmentList[deptChoice][0], DEPARTMENT_NAME_LEN);
			  }
			  else{
				//mainChoice=GL_KEY_CANCEL;
				continue;
			  }
			  /*Reference ID Screen*/
			  if(atoi(referenceFlag)){
			  result= GL_Dialog_Text (APEMV_UI_GoalHandle(), "TRANSACTION", "Enter Reference No:",
											"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", referenceNo, sizeof(referenceNo), 3*GL_TIME_MINUTE);
			  if (result == GL_KEY_VALID){
				  setReferenceNo(referenceNo);
			   }
			  else
				  continue;
			  }
			  /*Clerk ID Screen*/
			  result= GL_Dialog_Text (APEMV_UI_GoalHandle(), "TRANSACTION", "Enter Clerk ID:",
											"/d/d/d/d/d/d", clerkID, sizeof(clerkID), 3*GL_TIME_MINUTE);
			  if (result == GL_KEY_VALID){
				int length=strlen(clerkID);
				char tempID[6]={0};
				memcpy (&tempID[sizeof(tempID) - length],clerkID, length);
				memset (tempID, '0', sizeof (tempID) - length);
				saveAdminParameter("CLERK_ID",tempID);
				setClerkID(tempID);
			   }
			  else
				  continue;

			  /* Screen - Enter Amount */
			  do{
				  amountEntryFlag=TRUE;
				  memset(amount,0,sizeof(amount));
				  result = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "Amount", "Enter Amount:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", amount, sizeof(amount),"USD",
						  GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
				  char maxTxnAmt[13]={0};
				  getMaxTxnAmount(maxTxnAmt);
				  if (result==GL_KEY_VALID){
					  if(atoi(amount)==0)
						  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Invalid Amount",GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
					  else if(strtoull(amount,NULL,10)>strtoull(maxTxnAmt,NULL,10))
						  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Exceed Merchant Max Limit",GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
					  else
						  amountEntryFlag=FALSE;
				  }else{
					  result=GL_KEY_CANCEL;
					  mainChoice=GL_KEY_CANCEL;
					  break;
				  }
			  }while(amountEntryFlag);
			  //Amount Entry Done
			  if (result == GL_KEY_VALID){
				  int length = strlen(amount);
				  memcpy (&amount[sizeof(amount) - length-1], amount, length);
				  memset (amount, '0', sizeof (amount) - length-1);
				  setInputAmount (amount);
				  char creditSupport[2]={0},debitSupport[2]={0};
				  isCreditSupported(creditSupport);
				  isDebitSupported(debitSupport);
				  if (atoi(creditSupport)&&atoi(debitSupport)){
					  if (atoi(externalPinPad)){
						  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Connecting to PINPAD...", NULL, GL_BUTTON_ALL, 0);
						  setTransactionType("CARDTYPESELECTION");
						  if (!connectExternalPINPad()) {
							  //display msg unable to connect pinpad within time limit
							  setErrorCode("ERROR:049");
							  mainChoice = GL_KEY_CANCEL;
							  break;
						  }
					  }
					  else
						  displayCardTypeMenu();
				  }
				  if (strcmp(getErrorCode(),"ERROR:000")){
					  mainChoice = GL_KEY_CANCEL;
					  break;
				  }
			  }
			  if(result!=GL_KEY_CANCEL){
				  result= GL_Dialog_Text (APEMV_UI_GoalHandle(), "REVERSAL", "Enter Transaction No:",
														"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", userTxnNo, sizeof(userTxnNo), 3*GL_TIME_MINUTE);
				  if (result == GL_KEY_VALID){
					  if(strlen(userTxnNo)<=0){
						  GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Invalid Transaction ID", NULL, GL_BUTTON_ALL, 30*GL_TIME_SECOND);
						  mainChoice=GL_KEY_CANCEL;
						  break;
					  }
					  setTransReferenceNo(userTxnNo);
					  if (calculateFee (FULL_REVERSAL)){
						  char displayFee [200] = {0};
						  constructPayableData(displayFee);
						 if ( strlen (displayFee) != 0) {
							 result = GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, displayFee, NULL, GL_BUTTON_ALL, 30*GL_TIME_SECOND);
						 	 if (result == GL_KEY_VALID) {
						 		 setTransReferenceNo(userTxnNo);
						 		 setTransactionType (FULL_REVERSAL);
						 if (!atoi(externalPinPad)){ //INTERNAL PINPAD
							 processPaymentTransaction();
						 }
						 else if (atoi(externalPinPad)){ //EXTERNAL PINPAD
							 if (connectExternalPINPad ()) {
								 if (!strcmp(getErrorCode(),"ERROR:000")) {
									 processPaymentTransaction ();
									 if (strcmp(getErrorCode(),"ERROR:000")) {
										 mainChoice=GL_KEY_CANCEL;
										 break;
									 }
								 }
								 else {
									 mainChoice=GL_KEY_CANCEL;
									 break;
								 }
							 }
							 else
								 GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"PINPAD Connection  Error", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
						 }

						mainChoice=GL_KEY_CANCEL;
						break;
						 	 }
						 	 else {
						 		mainChoice = GL_KEY_CANCEL;
						 		break;
						 	 }
						 }

					  }
					  else {
						 mainChoice=GL_KEY_CANCEL;
						 break;
					 }

				  }

			  }

		  }
		  else if(!strcmp(menu.menuMain[mainChoice],"Capture")){//Capture
			  /* Department Screen */
			  if(atoi(deptCount)<=0){
				  setErrorCode("ERROR:041");
				  break;
			  }
			  deptChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "TRANSACTION",(const) deptMenu,
						deptChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
			  if(deptChoice > DEPARTMENT_COUNT) {
				  deptChoice = GL_KEY_CANCEL;
			  }
			  if(deptChoice!=GL_KEY_CANCEL) {
				  setDepartmentName(&departmentList[deptChoice][0]);
				  setDeptMID(&deptMidList[deptChoice][0]);
				  setDeptAPIKey(&deptAPIKeyList[deptChoice][0]);
				  setMerchantChoice(deptChoice);
				//memcpy (pUserInput->mDepartmentName,&departmentList[deptChoice][0], DEPARTMENT_NAME_LEN);
			  }
			  else{
				//mainChoice=GL_KEY_CANCEL;
				continue;
			  }
			  /*Reference ID Screen*/
			  if(atoi(referenceFlag)){
			  result= GL_Dialog_Text (APEMV_UI_GoalHandle(), "TRANSACTION", "Enter Reference No:",
											"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", referenceNo, sizeof(referenceNo), 3*GL_TIME_MINUTE);
			  if (result == GL_KEY_VALID){
				  setReferenceNo(referenceNo);
			   }
			  else
				  continue;
			  }
			  /*Clerk ID Screen*/
			  result= GL_Dialog_Text (APEMV_UI_GoalHandle(), "TRANSACTION", "Enter Clerk ID:",
											"/d/d/d/d/d/d", clerkID, sizeof(clerkID), 3*GL_TIME_MINUTE);
			  if (result == GL_KEY_VALID){
				int length=strlen(clerkID);
				char tempID[6]={0};
				memcpy (&tempID[sizeof(tempID) - length],clerkID, length);
				memset (tempID, '0', sizeof (tempID) - length);
				saveAdminParameter("CLERK_ID",tempID);
				setClerkID(tempID);
			   }
			  else
				  continue;

			  result= GL_Dialog_Text (APEMV_UI_GoalHandle(), "CAPTURE", "Enter Transaction No:",
			  			  										"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", userTxnNo, sizeof(userTxnNo), 3*GL_TIME_MINUTE);
			  if(result!=GL_KEY_CANCEL){
				  setTransReferenceNo(userTxnNo);
				  setTransactionType(COMPLETION);
				  processPaymentTransaction();

			  }
			  mainChoice=GL_KEY_CANCEL;
			 break;

		  }

		  else if(!strcmp(menu.menuMain[mainChoice],"Batch Summary")){
			  /* Department Screen */
			  if(atoi(deptCount)<=0){
				  setErrorCode("ERROR:041");
				  break;
			  }
			  deptChoice=GL_Dialog_Menu (APEMV_UI_GoalHandle(),"Batch Summary",(const)menu.menuBatchDetails, deptChoice,
			  						  GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
			  if(deptChoice != GL_KEY_CANCEL){
			  switch(deptChoice){
			  case 0:
			  deptChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "TRANSACTION",(const) deptMenu,
						deptChoice, GL_BUTTON_VALID_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
			  if(deptChoice > DEPARTMENT_COUNT) {deptChoice = GL_KEY_CANCEL;}
			  if(deptChoice!=GL_KEY_CANCEL) {
				  setDepartmentName(&departmentList[deptChoice][0]);
				  setDeptMID(&deptMidList[deptChoice][0]);
				  setDeptAPIKey(&deptAPIKeyList[deptChoice][0]);
				  setMerchantChoice(deptChoice);
				//memcpy (pUserInput->mDepartmentName,&departmentList[deptChoice][0], DEPARTMENT_NAME_LEN);
				  setTransactionType(BATCH_SETTLE);
				  processPaymentTransaction(BATCH_SETTLE);
				  //mainChoice=GL_KEY_CANCEL;
				  break;
				  }else
					  break;
			  case 1:
				  batchall=1;
				  setTransactionType(BATCH_SETTLE);
				  processPaymentTransaction(BATCH_SETTLE);
				  batchall=0;
				  break;
			  }
			  }
			  break;
		  }
		  else if(!strcmp(menu.menuMain[mainChoice],"Transaction Summary")){
			  TransactionSummary();
			  setTransactionType(TRAN_SUM);
			  processPaymentTransaction();
		  }
		  else if(!strcmp(menu.menuMain[mainChoice],"Duplicate Receipt")){
			  do{
				  duplicateRecpChoice=GL_Dialog_Menu (APEMV_UI_GoalHandle(),"Duplicate Receipt",(const)menu.menuDuplicateReceptChoice, duplicateRecpChoice,
						  GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
			  if(duplicateRecpChoice>4) {duplicateRecpChoice=GL_KEY_CANCEL;}
			  if (duplicateRecpChoice!=GL_KEY_CANCEL) {
				  char last4digit[4+1]={0};
				  char txnNo[21+1]={0};
				  switch(duplicateRecpChoice){
					case 0://menu for last four digit
						//do{
							GL_Dialog_Text (APEMV_UI_GoalHandle(), "Duplicate Receipt", "Enter Card Last Four Digit:","/d/d/d/d",
									last4digit, sizeof(last4digit), 3*GL_TIME_MINUTE);
						//}while(!strlen(last4digit));
						 if(strlen(last4digit)){
							setLastFourDigitCardNo(last4digit);
							setTransactionType(DUPLICATE_RECEIPT);
							processPaymentTransaction();
							duplicateRecpChoice=GL_KEY_CANCEL;
							 }
							break;
					case 1://todo menu for Txn ID
						//do{
							GL_Dialog_Text (APEMV_UI_GoalHandle(), "Duplicate Receipt", "Enter Transaction ID:",
									"/d/d/d/d/d/d/d/d/d/d/d/d/d/d/d/d/d/d/d/d",txnNo, sizeof(txnNo), 3*GL_TIME_MINUTE);
						//}while(!strlen(txnNo));
						if(strlen(txnNo)){
							setTransReferenceNo(txnNo);
							setTransactionType(DUPLICATE_RECEIPT);
							processPaymentTransaction();
							duplicateRecpChoice=GL_KEY_CANCEL;
						}
						break;
					case 2://menu last copy
						printReceipt(APEMV_UI_GoalHandle(), MERCHANT_COPY, DUPLICATE_COPY);
						result = GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Do You Want To Print \n Customer Copy?",
								GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
						if (result == GL_KEY_VALID)
							printReceipt(APEMV_UI_GoalHandle(),CUSTOMER_COPY,DUPLICATE_COPY);
						duplicateRecpChoice=GL_KEY_CANCEL;
						break;
					default:
						break;
				}
			  }
			  }while(duplicateRecpChoice!=GL_KEY_CANCEL);
			mainChoice=GL_KEY_CANCEL;
			break;
		  }
		  else if(!strcmp(menu.menuMain[mainChoice],"More...")){ //More..
						char amtLimit[12+1]={0};
						getMaxTxnAmount(amtLimit);
						sprintf(amtLimit,"%d",atoi(amtLimit));
						char autoBatchTime[5]={0};
						getAutoBatchTime(autoBatchTime);
						char terminalID[20+1]={0};
						getTerminalID(terminalID);
						char merchantID[20+1]={0};
						getMerchantID(merchantID);
						char mercName[25]={0};
						getMerchantName(mercName);
						char mercAddress[25]={0};
						getMerchantAddress(mercAddress);
						char mercCity[25]={0};
						getMerchantCity(mercCity);
						char mercState[25]={0};
						getMerchantState(mercState);
						char mercZIP[11]={0};
						getMerchantZIP(mercZIP);
						char mercPhone[11]={0};
						getMerchantPhone(mercPhone);
						char receiptHeader[25]={0};
						getReceiptHeader(receiptHeader);
						char receiptFooter[25]={0};
						getReceiptFooter(receiptFooter);
						char idleMessage[25]={0};
						getIdleMsg(idleMessage);
						char gatewayAPI[48+1]={0};
						getGatewayAPIKey(gatewayAPI);
						char gatewayPort[4]={0};
						getGatewayPort(gatewayPort);
						char gatewayURL[50]={0};
						getGatewayURL(gatewayURL);
						char gatewayCGI[25]={0};
						getGatewayCGI(gatewayCGI);
						char downloadPort[5]={0};
						getTMSPort(downloadPort);
						char downloadURL[49]={0};
						getTMSURL(downloadURL);
						char feeChoice[2]={0};
						isFeeSupported(&feeChoice[0]);
						char comChoice[2]={0};
						getComType(&comChoice[0]);
						gatewayOption = atoi(comChoice);
						feeOption = !atoi(feeChoice);
						char refundChoice[2] = {0};
						isRefundSupported(refundChoice);
						refundFlg = !atoi(refundChoice);
						char voidChoice[2] = {0};
						isVoidSupported(voidChoice);
						voidFlg = !atoi(voidChoice);
						char authOnlyChoice[2] = {0};
						isAuthOnlySupported(authOnlyChoice);
						authOnlyFlg = !atoi(authOnlyChoice);
						char endOfDayChoice[2] = {0};
						isManBatchSupported(endOfDayChoice);
						endOfDayFlg = !atoi(endOfDayChoice);
						char autoBatchChoice[2]={0};
						isAutoBatchSupported(autoBatchChoice);
						autoBatchMode = !atoi(autoBatchChoice);
						char pinpadChoice[2]={0};
						getPinPadMode(&pinpadChoice[0]);
						pinpadMode = !atoi(pinpadChoice);
						char posModeChoice[2]={0};
						getPOSMode(&posModeChoice[0]);
						posMode = atoi(posModeChoice);
						char receiptChoice[2]={0};
						getReceiptFlag(&receiptChoice[0]);
						receiptMode = !atoi(receiptChoice);
						char referenceChoice[2]={0};
						getReferenceFlag(&referenceChoice[0]);
						referenceMode= !atoi(referenceChoice);
						char level2_Choice[2]={0};
						getLevel_2_DataFlag(&level2_Choice[0]);
						level_2_Mode = !atoi(level2_Choice);
						char level3_Choice[2]={0};
						getLevel_3_DataFlag(&level3_Choice[0]);
						level_3_Mode = !atoi(level3_Choice);
						char gatewayIP[16]={0};
						getGatewayIP(gatewayIP);
						char tmsIP[16]={0};
						getTMSIP(tmsIP);
						char departmentList[DEPARTMENT_COUNT][DEPARTMENT_NAME_LEN+1]={0};
						char deptMIDList[DEPARTMENT_COUNT][MERCHANT_ID_LEN+1]={0};
						char deptAPIKeyList[DEPARTMENT_COUNT][APIKEY_LEN+1]={0};
						getDepartmentList(departmentList);
						getMIDList(deptMIDList);
						getAPIKeyList(deptAPIKeyList);
						do{
							moreChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "MORE...",(const) menu.menuMore,
									  moreChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
							if(moreChoice > 8) {moreChoice = GL_KEY_CANCEL;}
							if(moreChoice!=GL_KEY_CANCEL){
								if(!strcmp(menu.menuMore[moreChoice],"Pre Loader")){
									if(!tmsDownloadProcess("Pre Loader"))
									break;
								}
								else if(!strcmp(menu.menuMore[moreChoice],"Transaction Params")){
									do{
										subChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "TRANSACTION PARAMS",(const) menu.menuTxnParam,
														subChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
										if(subChoice > 3) {subChoice = GL_KEY_CANCEL;}
										if(subChoice!=GL_KEY_CANCEL){
											if(!strcmp(menu.menuTxnParam[subChoice],"Max Trans Amt")){
												keyPressed= GL_Dialog_Amount (APEMV_UI_GoalHandle(), "MAX TRANS AMT", "Max Amt Limit:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", amtLimit, sizeof(amtLimit),"USD",
																					GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
												if(keyPressed == GL_KEY_VALID){
													char temp[12+1]={0};
													memcpy (&temp[sizeof (amtLimit) - 1 - strlen (amtLimit)],
															amtLimit, strlen (amtLimit));
													memset (temp, '0', sizeof (amtLimit) - 1 - strlen (amtLimit));
													if(saveAdminParameter("MAX_TXN_AMOUNT",temp)){
														GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Amount Limit Updated",
																			GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
													}
													else
														GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Amount Limit Update\nFailed",
															GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
													continue;
												}
												else
													continue;
											}
											else if(!strcmp(menu.menuTxnParam[subChoice],"Fee")){

												feeOption=GL_Dialog_Choice (APEMV_UI_GoalHandle(),"FEE",
																	 (const)menu.menuAccept, feeOption, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
												if(feeOption != GL_KEY_CANCEL){
													switch(feeOption){
													case 0:
														if (saveAdminParameter ("SPLIT_PAYMENT", "1")) {
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "FEE", "Updated to Yes",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														}
														else
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "FEE", "Not Able to Update \n Re-Try",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													case 1:
														if (saveAdminParameter ("SPLIT_PAYMENT", "0")) {
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "FEE", "Updated to No",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														}
														else
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "FEE", "Not Able to Update \n Re-Try",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													}
													continue;
												}
												else
													continue;
											}
										}
									}while(subChoice!=GL_KEY_CANCEL);

								}
								else if(!strcmp(menu.menuMore[moreChoice],"User Management")){
									if(!tmsDownloadProcess("USER"))
										break;
								}
								else if(!strcmp(menu.menuMore[moreChoice],"Settlement Params")){
									do{
										subChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "SETTLEMENT PARAMS",(const) menu.menuSettleParam,
														subChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
										if(subChoice > 3) {subChoice = GL_KEY_CANCEL;}
										if(subChoice!=GL_KEY_CANCEL){
											if(!strcmp(menu.menuSettleParam[subChoice],"Auto Batch Time")){/*

												keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "AUTO BATCH TIME", "Set Time:",
																						"/d/d:/d/d", autoBatchTime, sizeof(autoBatchTime), 3*GL_TIME_MINUTE);
												if(keyPressed == GL_KEY_VALID){
													if(atoi(autoBatchTime)<=0){
														GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Invalid Time",
																					GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														continue;
													}
													if(saveAdminParameter("AUTO_BATCH_TIME",autoBatchTime)){
														GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Auto Batch Time\n Updated",
																			GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
													}
													else
														GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Auto Batch Time\nUpdate Failed",
															GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
													continue;
												}
												else
													continue;
											*/}
											else if(!strcmp(menu.menuSettleParam[subChoice],"Auto Batch")){/*

												autoBatchMode=GL_Dialog_Choice (APEMV_UI_GoalHandle(),"AUTO BATCH",
																	 (const)menu.menuAccept, autoBatchMode, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
												if(autoBatchMode != GL_KEY_CANCEL){
													switch(autoBatchMode){
													case 0:
														if (saveAdminParameter ("AUTO_BATCH_SUPPORTED", "1")) {
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "AUTO BATCH", "Updated to Yes",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														}
														else
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "AUTO BATCH", "Not Able to Update \n Re-Try",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													case 1:
														if (saveAdminParameter ("AUTO_BATCH_SUPPORTED", "0")) {
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "AUTO BATCH", "Updated to No",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														}
														else
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "AUTO BATCH", "Not Able to Update \n Re-Try",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													}
													continue;
												}
												else
													continue;
											*/}
										}
									}while(subChoice!=GL_KEY_CANCEL);
								}
								else if(!strcmp(menu.menuMore[moreChoice],"Terminal Params")){
									do{
										subChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "TERMINAL PARAMS",(const) menu.menuTerminalParam,
														subChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
										if(subChoice > 6) {subChoice = GL_KEY_CANCEL;}
										if(subChoice!=GL_KEY_CANCEL){
											if(!strcmp(menu.menuTerminalParam[subChoice],"Terminal ID")){

												keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "TERMINAL PARAMS", "Enter Terminal ID:",
																						"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", terminalID, sizeof(terminalID), 3*GL_TIME_MINUTE);
												if(keyPressed == GL_KEY_VALID){
													memset (&terminalID[strlen(terminalID)], ' ', sizeof (terminalID) - 1 - strlen (terminalID));
													if(saveAdminParameter("TERMINAL_ID",terminalID)){
														GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Terminal ID Updated",
																			GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
													}
													else
														GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Terminal ID Update\nFailed",
															GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
													continue;
												}
												else
													continue;
											}
											else if(!strcmp(menu.menuTerminalParam[subChoice],"Merchant ID")){

												keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "TERMINAL PARAMS", "Enter Merchant ID:",
																						"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", merchantID, sizeof(merchantID), 3*GL_TIME_MINUTE);
												if(keyPressed == GL_KEY_VALID){
													memset (&merchantID[strlen(merchantID)], ' ', sizeof (merchantID) - 1 - strlen (merchantID));
													if(saveAdminParameter("MERCHANT_ID",merchantID)){
														GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant ID Updated",
																			GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
													}
													else
														GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant ID Update\nFailed",
															GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
													continue;
												}
												else
													continue;
											}
											else if(!strcmp(menu.menuTerminalParam[subChoice],"Merchant Param")){
												do{
													choice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "MERCHANT PARAM",(const) menu.menuMerchantParam,
															choice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
													if(choice > 7) {choice = GL_KEY_CANCEL;}
													if(choice!=GL_KEY_CANCEL){
														subChoice = 0;
														if(!strcmp(menu.menuMerchantParam[choice],"Merchant Transactions")){
															do{
																subChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "MERCHANT TRANSACTIONS",(const) menu.menuTransactions,
																		subChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
																if(subChoice == GL_KEY_CANCEL)
																	break;
																if(!strcmp(menu.menuTransactions[subChoice],"Sale")){
																	refundFlg = GL_Dialog_Choice (APEMV_UI_GoalHandle(),"ENABLE SALE",
																						 (const)menu.menuAccept, refundFlg, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
																	if(refundFlg != GL_KEY_CANCEL){
																		switch(refundFlg){
																		case 0:
																			if (saveAdminParameter ("SALE", "1")) {
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE SALE", "Updated to Yes",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			}
																			else
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE SALE", "Not Able to Update \n Re-Try",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			break;
																		case 1:
																			if (saveAdminParameter ("SALE", "0")) {
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE SALE", "Updated to No",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			}
																			else
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE SALE", "Not Able to Update \n Re-Try",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			break;
																		}
																		continue;
																	}
																	else
																		continue;
																}
																else if(!strcmp(menu.menuTransactions[subChoice],"Refund")){
																	refundFlg = GL_Dialog_Choice (APEMV_UI_GoalHandle(),"ENABLE REFUND",
																						 (const)menu.menuAccept, refundFlg, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
																	if(refundFlg != GL_KEY_CANCEL){
																		switch(refundFlg){
																		case 0:
																			if (saveAdminParameter ("REFUND", "1")) {
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE REFUND", "Updated to Yes",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			}
																			else
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE REFUND", "Not Able to Update \n Re-Try",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			break;
																		case 1:
																			if (saveAdminParameter ("REFUND", "0")) {
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE REFUND", "Updated to No",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			}
																			else
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE REFUND", "Not Able to Update \n Re-Try",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			break;
																		}
																		continue;
																	}
																	else
																		continue;
																}
																else if(!strcmp(menu.menuTransactions[subChoice],"Void")){
																	voidFlg = GL_Dialog_Choice (APEMV_UI_GoalHandle(),"ENABLE REVERSAL",
																						 (const)menu.menuAccept, voidFlg, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
																	if(voidFlg != GL_KEY_CANCEL){
																		switch(voidFlg){
																		case 0:
																			if (saveAdminParameter ("VOID", "1")) {
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE REVERSAL", "Updated to Yes",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			}
																			else
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE REVERSAL", "Not Able to Update \n Re-Try",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			break;
																		case 1:
																			if (saveAdminParameter ("VOID", "0")) {
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE REVERSAL", "Updated to No",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			}
																			else
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE REVERSAL", "Not Able to Update \n Re-Try",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			break;
																		}
																		continue;
																	}
																	else
																		continue;
																}
																else if(!strcmp(menu.menuTransactions[subChoice],"Auth-Only/Capture")){
																	authOnlyFlg = GL_Dialog_Choice (APEMV_UI_GoalHandle(),"ENABLE AUTH-ONLY",
																						 (const)menu.menuAccept, authOnlyFlg, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
																	if(authOnlyFlg != GL_KEY_CANCEL){
																		switch(authOnlyFlg){
																		case 0:
																			if (saveAdminParameter ("AUTH_ONLY", "1")) {
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE AUTH-ONLY", "Updated to Yes",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			}
																			else
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE AUTH-ONLY", "Not Able to Update \n Re-Try",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			break;
																		case 1:
																			if (saveAdminParameter ("AUTH_ONLY", "0")) {
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE AUTH-ONLY", "Updated to No",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			}
																			else
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE AUTH-ONLY", "Not Able to Update \n Re-Try",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			break;
																		}
																		continue;
																	}
																	else
																		continue;
																}
																else if(!strcmp(menu.menuTransactions[subChoice],"End-of-Day")){
																	endOfDayFlg = GL_Dialog_Choice (APEMV_UI_GoalHandle(),"ENABLE END-OF-DAY",
																						 (const)menu.menuAccept, endOfDayFlg, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
																	if(endOfDayFlg != GL_KEY_CANCEL){
																		switch(endOfDayFlg){
																		case 0:
																			if (saveAdminParameter ("MANUAL_BATCH", "1")) {
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE END-OF-DAY", "Updated to Yes",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			}
																			else
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE END-OF-DAY", "Not Able to Update \n Re-Try",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			break;
																		case 1:
																			if (saveAdminParameter ("MANUAL_BATCH", "0")) {
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE END-OF-DAY", "Updated to No",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			}
																			else
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), "ENABLE END-OF-DAY", "Not Able to Update \n Re-Try",
																									NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																			break;
																		}
																		continue;
																	}
																	else
																		continue;
																}
															}while(keyPressed!=GL_KEY_CANCEL);
														}
														else if(!strcmp(menu.menuMerchantParam[choice],"Name")){

															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "MERCHANT PARAM", "Merchant Name:",
																						"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", mercName, sizeof(mercName), 3*GL_TIME_MINUTE);
															if(keyPressed == GL_KEY_VALID){
																memset (&mercName[strlen (mercName)], ' ', sizeof (mercName) - 1 - strlen (mercName));
																if(saveAdminParameter("MERCHANT_NAME",mercName)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant Name Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant Name Update\nFailed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;
															}
															else
																continue;
														}
														else if(!strcmp(menu.menuMerchantParam[choice],"Address")){

															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "MERCHANT PARAM", "Merchant Address:",
																						"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", mercAddress, sizeof(mercAddress), 3*GL_TIME_MINUTE);
															if(keyPressed == GL_KEY_VALID){
																memset (&mercAddress[strlen (mercAddress)], ' ', sizeof (mercAddress) - 1 - strlen (mercAddress));
																if(saveAdminParameter("MERCHANT_ADDRESS",mercAddress)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant Address Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant Address Update\nFailed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;
															}
															else
																continue;
														}
														else if(!strcmp(menu.menuMerchantParam[choice],"City")){

															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "MERCHANT PARAM", "Merchant City:",
																						"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", mercCity, sizeof(mercCity), 3*GL_TIME_MINUTE);
															if(keyPressed == GL_KEY_VALID){
																memset (&mercCity[strlen (mercCity)], ' ', sizeof (mercCity) - 1 - strlen (mercCity));
																if(saveAdminParameter("MERCHANT_CITY",mercCity)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant City Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant City Update\nFailed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;
															}
															else
																continue;
														}

														else if(!strcmp(menu.menuMerchantParam[choice],"State")){

															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "MERCHANT PARAM", "Merchant State:",
																						"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", mercState, sizeof(mercState), 3*GL_TIME_MINUTE);
															if(keyPressed == GL_KEY_VALID){
																memset (&mercState[strlen (mercState)], ' ', sizeof (mercState) - 1 - strlen (mercState));
																if(saveAdminParameter("MERCHANT_STATE",mercState)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant State Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant State Update\nFailed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;
															}
															else
																continue;
														}
														else if(!strcmp(menu.menuMerchantParam[choice],"ZIP Code")){

															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "MERCHANT PARAM", "Merchant ZIP:",
																						"/c/c/c/c/c/c/c/c/c/c", mercZIP, sizeof(mercZIP), 3*GL_TIME_MINUTE);
															if(keyPressed == GL_KEY_VALID){
																memset (&mercZIP[strlen (mercZIP)], ' ', sizeof (mercZIP) - 1 - strlen (mercZIP));
																if(saveAdminParameter("MERCHANT_ZIP",mercZIP)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant ZIP Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant ZIP Update\nFailed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;
															}
															else
																continue;
														}
														else if(!strcmp(menu.menuMerchantParam[choice],"Phone Number")){

															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "MERCHANT PARAM", "Merchant Phone:",
																						"/d/d/d/d/d/d/d/d/d/d", mercPhone, sizeof(mercPhone), 3*GL_TIME_MINUTE);
															if(keyPressed == GL_KEY_VALID){
																if(strlen(mercPhone)<10){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Invalid Phone Number",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																	continue;
																}
																if(saveAdminParameter("MERCHANT_PHONE",mercPhone)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant Phone Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Merchant Phone Update\nFailed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;

															}
															else
																continue;
														}
													}
												}while(choice!=GL_KEY_CANCEL);
											}
											else if(!strcmp(menu.menuTerminalParam[subChoice],"Receipt Disclaimer")){
												do{
													choice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "MERCHANT PARAM",(const) menu.menuReceipt,
															choice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
													if(choice > 3) {choice = GL_KEY_CANCEL;}
													if(choice!=GL_KEY_CANCEL){
														if(!strcmp(menu.menuReceipt[choice],"Receipt Header")){

															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "RECEIPT DISCLAIMER", "Receipt Header Text:",
																						"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", receiptHeader, sizeof(receiptHeader), 3*GL_TIME_MINUTE);
															if(keyPressed == GL_KEY_VALID){
																memset (&receiptHeader[strlen (receiptHeader)], ' ', sizeof (receiptHeader) - 1 - strlen (receiptHeader));
																if(saveAdminParameter("RECEIPT_HEADER",receiptHeader)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Receipt Header Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Receipt Header Update\nFailed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;
															}
															else
																continue;
														}
														else if(!strcmp(menu.menuReceipt[choice],"Receipt Footer")){

															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "RECEIPT DISCLAIMER", "Receipt Footer Text:",
																						"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", receiptFooter, sizeof(receiptFooter), 3*GL_TIME_MINUTE);
															if(keyPressed == GL_KEY_VALID){
																memset (&receiptFooter[strlen (receiptFooter)], ' ', sizeof (receiptFooter) - 1 - strlen (receiptFooter));
																if(saveAdminParameter("RECEIPT_FOOTER",receiptFooter)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Receipt Footer Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Receipt Footer Update\nFailed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;
															}
															else
																continue;
														}
													}
												}while(choice!=GL_KEY_CANCEL);
											}
											else if(!strcmp(menu.menuTerminalParam[subChoice],"Home Screen Message")){

												keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "TERMINAL PARAMS", "Home Screen Message:",
																						"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", idleMessage, sizeof(idleMessage), 3*GL_TIME_MINUTE);
												if(keyPressed == GL_KEY_VALID){
													memset (&idleMessage[strlen (idleMessage)], ' ', sizeof (idleMessage) - 1 - strlen (idleMessage));
													if(saveAdminParameter("IDLE_MESSAGE",idleMessage)){
														GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Home Screen Message Updated",
																			GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
													}
													else
														GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Home Screen Message \nUpdate Failed",
															GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
													continue;
												}
												else
													continue;
											}
										}
									}while(subChoice!=GL_KEY_CANCEL);
								}
								else if(!strcmp(menu.menuMore[moreChoice],"Gateway Params")){

									gatewayOption=GL_Dialog_Choice (APEMV_UI_GoalHandle(),"GATEWAY PARAMS",
														 (const)menu.menuGateway, gatewayOption, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
									if(gatewayOption != GL_KEY_CANCEL){
										switch(gatewayOption){
										case 0:
											if (saveAdminParameter ("GATEWAY_COM_TYPE", "0")) { //TCP/IP
												do{
													subChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "GATEWAY PARAMS",(const) menu.menuGatewayTcp,
																	subChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
													if(subChoice > 4) {subChoice = GL_KEY_CANCEL;}
													if(subChoice!=GL_KEY_CANCEL){
														if(!strcmp(menu.menuGatewayTcp[subChoice],"Gateway API Key")){

															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "GATEWAY PARAMS", "Gateway API Key:",
																									"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", gatewayAPI, sizeof(gatewayAPI), 3*GL_TIME_MINUTE);
															if(keyPressed == GL_KEY_VALID){
																memset (&gatewayAPI[strlen (gatewayAPI)], ' ', sizeof (gatewayAPI) - 1 - strlen (gatewayAPI));
																if(saveAdminParameter("GATEWAY_API_KEY",gatewayAPI)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "GateWay API Key Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "GateWay API Key \nUpdate Failed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;


															}
															else
																continue;
														}
														else if(!strcmp(menu.menuGatewayTcp[subChoice],"Gateway IP")){
															doubleword hIp=0;
															char temp[16];
															memset(temp,0,sizeof(temp));
															memcpy(temp,gatewayIP,strlen(gatewayIP));
															hIp=IpToUint(temp);
															result=GL_Dialog_Ip (APEMV_UI_GoalHandle(), "GATEWAY PARAMS", "Gateway IP Address:", (T_GL_HIP)&hIp, 3*GL_TIME_MINUTE);
															memset (gatewayIP,0, sizeof (gatewayIP));
															UintToIp(hIp,gatewayIP);
															if (result==GL_KEY_VALID) {
																memset (&gatewayIP[strlen(gatewayIP)], ' ', sizeof (gatewayIP) - 1 - strlen (gatewayIP));
																if (saveAdminParameter ("GATEWAY_IP_ADDRESS", gatewayIP)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Gateway IP Address Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else {
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Gateway IP Address \n Updated Failed",
																											GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
															}
														}
														else if(!strcmp(menu.menuGatewayTcp[subChoice],"Gateway Port")){

															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "GATEWAY PARAMS", "Gateway Port:",
																									"/c/c/c", gatewayPort, sizeof(gatewayPort), 3*GL_TIME_MINUTE);

															memset (&gatewayPort[strlen(gatewayPort)], ' ', sizeof (gatewayPort) - 1 - strlen (gatewayPort));
															if(keyPressed == GL_KEY_VALID){
																if(saveAdminParameter("GATEWAY_PORT",gatewayPort)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Gateway Port Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Gateway Port Update \nFailed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;
															}
															else
																continue;
														}

													}
												}while(subChoice!=GL_KEY_CANCEL);
											}
											else
												GL_Dialog_Message(APEMV_UI_GoalHandle(), "GATEWAY PARAMS", "Not Able to Update \n Re-Try",
																	NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
											break;
										case 1:
											if (saveAdminParameter ("GATEWAY_COM_TYPE", "1")) { //WEB_SERVICE CALL
												do{
													subChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "GATEWAY PARAMS",(const) menu.menuGatewayWeb,
																	subChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
													if(subChoice > 4) {subChoice = GL_KEY_CANCEL;}
													if(subChoice!=GL_KEY_CANCEL){
														if(!strcmp(menu.menuGatewayWeb[subChoice],"Gateway API Key")){

															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "GATEWAY PARAMS", "Gateway API Key:",
																									"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", gatewayAPI, sizeof(gatewayAPI), 3*GL_TIME_MINUTE);
															if(keyPressed == GL_KEY_VALID){
																memset (&gatewayAPI[strlen (gatewayAPI)], ' ', sizeof (gatewayAPI) - 1 - strlen (gatewayAPI));
																if(saveAdminParameter("GATEWAY_API_KEY",gatewayAPI)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "GateWay API Key Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "GateWay API Key \nUpdate Failed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;


															}
															else
																continue;
														}
														else if(!strcmp(menu.menuGatewayWeb[subChoice],"Gateway URL")){
															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "GATEWAY PARAMS", "Gateway URL:",
																						"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", gatewayURL, sizeof(gatewayURL), 3*GL_TIME_MINUTE);
															if(keyPressed == GL_KEY_VALID){
																memset (&gatewayURL[strlen (gatewayURL)], ' ', sizeof (gatewayURL) - 1 - strlen (gatewayURL));
																if(saveAdminParameter("GATEWAY_URL",gatewayURL)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Gateway URL Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Gateway URL Update\n Failed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;

															}
															else
																continue;
														}
														else if(!strcmp(menu.menuGatewayWeb[subChoice],"Gateway CGI")){

															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "GATEWAY PARAMS", "Gateway CGI:",
																						"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", gatewayCGI, sizeof(gatewayCGI), 3*GL_TIME_MINUTE);
															if(keyPressed == GL_KEY_VALID){
																memset (&gatewayCGI[strlen (gatewayCGI)], ' ', sizeof (gatewayCGI) - 1 - strlen (gatewayCGI));
																if(saveAdminParameter("GATEWAY_CGI",gatewayCGI)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Gateway CGI Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Gateway CGI Update\n Failed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;
															}
															else
																continue;
														}
													}
												}while(subChoice!=GL_KEY_CANCEL);

											}
											else
												GL_Dialog_Message(APEMV_UI_GoalHandle(), "GATEWAY PARAMS", "Not Able to Update \n Re-Try",
																	NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
											break;
										}
										continue;
									}
									else
										continue;
								}

								else if(!strcmp(menu.menuMore[moreChoice],"System")){
									do{
										subChoice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "SYSTEM",(const) menu.menuSystem,
														subChoice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
										if(subChoice > 7) {subChoice = GL_KEY_CANCEL;}
										if(subChoice!=GL_KEY_CANCEL){
											if(!strcmp(menu.menuSystem[subChoice],"Date/Time")){
												DATE date;
												DATE sys_date;
												char localDate[50]={0};
												memset(localDate, '\0',sizeof(localDate));
												memset(&sys_date,'\0', sizeof(sys_date));
												Telium_Read_date(&sys_date);
												sprintf(localDate,"%2.2s%2.2s%2.2s%2.2s%2.2s%2.2s",sys_date.month,sys_date.day,sys_date.year,sys_date.hour, sys_date.minute, sys_date.second);

												keyPressed=GL_Dialog_Text (APEMV_UI_GoalHandle(), "Date/Time:","Set Date/Time: MM/DD/YY HH:MM:SS", "/d/d///d/d///d/d /d/d:/d/d:/d/d",localDate, sizeof(localDate), 3*GL_TIME_MINUTE);
												if(keyPressed == GL_KEY_VALID){
													memset(&date,'\0', sizeof(date));
													 strncpy(date.month,localDate, sizeof(date.month));
													 strncpy(date.day,localDate+2,sizeof(date.day));
													 strncpy(date.year,localDate+4,sizeof(date.year));
													 strncpy(date.hour,localDate+6,sizeof(date.hour));
													 strncpy(date.minute,localDate+8,sizeof(date.minute));
													 strncpy(date.second,localDate+10,sizeof(date.second));
													 if(Telium_Write_date(&date)==0){
														 GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Date/Time Updated",
																GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
													 }
													 else {
														 GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Date/Time Update\n Failed",
																GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
													 }
												}
											}
											else if(!strcmp(menu.menuSystem[subChoice],"App Version")){
												char terminalModel[10];
												char appVersion[10]="00100";
												char temp[50]={0};
												GetProductName(terminalModel);
												sprintf(temp,"Terminal Model: %s \n Terminal Version:%s", terminalModel,appVersion);
												GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM",temp, NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
											}
											else if(!strcmp(menu.menuSystem[subChoice],"PIN Pad")){

												pinpadMode=GL_Dialog_Choice (APEMV_UI_GoalHandle(),"SYSTEM",
																	 (const)menu.menuPinPad, pinpadMode, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
												if(pinpadMode != GL_KEY_CANCEL){
													switch(pinpadMode){
													case 0:
														if (saveAdminParameter ("EXTERNAL_PINPAD", "1")) {
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Configured to \n External PINPAD",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														}
														else
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Not Able to Update \n Re-Try",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													case 1:
														if (saveAdminParameter ("EXTERNAL_PINPAD", "0")) {
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Configured to \n Internal PINPAD",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														}
														else
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Not Able to Update \n Re-Try",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													}
													continue;
												}
												else
													continue;
											}
											else if(!strcmp(menu.menuSystem[subChoice],"Point-of-Sale Mode")){
												posMode=GL_Dialog_Choice (APEMV_UI_GoalHandle(),"SYSTEM",
																	 (const)menu.menuPOSMode, posMode, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
												if(posMode != GL_KEY_CANCEL){
													switch(posMode){
													case 0:
														if (saveAdminParameter ("POS_MODE", "0")) {
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Configured to \n Stand-Alone",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														}
														else
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Not Able to Update \n Re-Try",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													case 1:
														if (saveAdminParameter ("POS_MODE", "1")) {
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Configured to \n Semi-Integrated",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														}
														else
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Not Able to Update \n Re-Try",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													}
													continue;
												}
												else
													continue;
											}
											else if(!strcmp(menu.menuSystem[subChoice],"Receipt")){


												receiptMode=GL_Dialog_Choice (APEMV_UI_GoalHandle(),"SYSTEM",
																	 (const)menu.menuAccept, receiptMode, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
												if(receiptMode != GL_KEY_CANCEL){
													switch(receiptMode){
													case 0:
														if (saveAdminParameter ("PAPER_RECEIPT", "1")) {
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Updated to Yes",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														}
														else
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Not Able to Update \n Re-Try",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													case 1:
														if (saveAdminParameter ("PAPER_RECEIPT", "0")) {
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Updated to No",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														}
														else
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Not Able to Update \n Re-Try",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													}
													continue;
												}
												else
													continue;
											}
											else if(!strcmp(menu.menuSystem[subChoice],"Reference-ID")){
												referenceMode=GL_Dialog_Choice (APEMV_UI_GoalHandle(),"SYSTEM",
																	 (const)menu.menuAccept, referenceMode, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
												if(referenceMode != GL_KEY_CANCEL){
													switch(referenceMode){
													case 0:
														if (saveAdminParameter ("REFERENCE_FLAG", "1")) {
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Updated to Yes",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														}
														else
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Not Able to Update \n Re-Try",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													case 1:
														if (saveAdminParameter ("REFERENCE_FLAG", "0")) {
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Updated to No",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														}
														else
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "SYSTEM", "Not Able to Update \n Re-Try",
																				NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													}
													continue;
												}
												else
													continue;
											}
											else if (!strcmp(menu.menuSystem[subChoice],"Level-2")) {
												level_2_Mode = GL_Dialog_Choice (APEMV_UI_GoalHandle(),"LEVEL",
														 (const)menu.menuAccept, level_2_Mode, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
												if (level_2_Mode != GL_KEY_CANCEL) {
													switch (level_2_Mode) {
													case 0:
														if (saveAdminParameter ("LEVEL_2_DISPLAY_FLAG", "1"))
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "LEVEL", "Level-2 Data Enabled", NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													case 1:
														if (saveAdminParameter ("LEVEL_2_DISPLAY_FLAG", "0"))
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "LEVEL", "Level-2 Data Disabled", NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													default:
														break;
													}
													continue;
												}
												else
													continue;
											}
											else if (!strcmp(menu.menuSystem[subChoice],"Level-3")) {
												level_3_Mode = GL_Dialog_Choice (APEMV_UI_GoalHandle(),"LEVEL",
														(const)menu.menuAccept, level_3_Mode, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
												if (level_3_Mode != GL_KEY_CANCEL) {
													switch (level_3_Mode) {
													case 0:
														if (saveAdminParameter ("LEVEL_3_DISPLAY_FLAG", "1"))
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "LEVEL", "Level-3 Data Enabled", NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
													case 1:
														if (saveAdminParameter ("LEVEL_3_DISPLAY_FLAG", "0"))
															GL_Dialog_Message(APEMV_UI_GoalHandle(), "LEVEL", "Level-3 Data Disabled", NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
														break;
														default:
															break;
													}
													continue;
												}
												else
													continue;
											}
										}
									}while(subChoice!=GL_KEY_CANCEL);
								}
								else if(!strcmp(menu.menuMore[moreChoice],"Merchant Management")){
											menu.menuUserMgmt[0]="Manager Password";
											menu.menuUserMgmt[1]="Department Count";
											char deptMenu[DEPARTMENT_COUNT][20]={0};
											int i=1;
											char depaprtmentCount[2]={0};
											getDepartmentCount(depaprtmentCount);
											for(i=2;i<=(atoi(depaprtmentCount)+1);i++){
												sprintf(&deptMenu[i-2][0],"DEPARTMENT %d",i-1);
												menu.menuUserMgmt[i]=deptMenu[i-2];
											}
											menu.menuUserMgmt[i]=NULL;
											do{
												choice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "Merchant Management",(const) menu.menuUserMgmt,
														choice, GL_BUTTON_CANCEL , GL_KEY_1, 3*GL_TIME_MINUTE);
												if(choice > 3+DEPARTMENT_COUNT) {choice = GL_KEY_CANCEL;}
												if(choice!=GL_KEY_CANCEL){
													if(!strcmp(menu.menuUserMgmt[choice],"Manager Password")){
														char mngrPassword[5]={0};
														char tempPwd[5]={0};
														keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "Merchant Management", "Enter Password:",
																					"/d/d/d/d", tempPwd, sizeof(tempPwd), 3*GL_TIME_MINUTE);
														if(keyPressed == GL_KEY_VALID){
															if(strlen(tempPwd)<4){
																GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Invalid Pass Word",
																	GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;
															}
															keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "Merchant Management", "Re-Enter Password:",
																						"/d/d/d/d", mngrPassword, sizeof(mngrPassword), 3*GL_TIME_MINUTE);
															if(!strcmp(tempPwd,mngrPassword)){
																if(saveAdminParameter("MANAGER_PASSWORD",mngrPassword)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Password Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
																else
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Password Update \nFailed",
																		GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																continue;
															}
															else{
																GL_Dialog_Message(APEMV_UI_GoalHandle(), "Merchant Management","Password Doesn't \n Match", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
															}

														}
														else
															continue;
													}
													else if(!strcmp(menu.menuUserMgmt[choice],"Department Count")){
														keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "Merchant Management", "Enter No of Departments:",
																						"/d", depaprtmentCount, sizeof(depaprtmentCount), 3*GL_TIME_MINUTE);
														if(keyPressed == GL_KEY_VALID){
															if(atoi(depaprtmentCount)<0){
																GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Number should be \n More than Zero",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
															}
															else if(atoi(depaprtmentCount)>5){
																GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Number Can't be \n More than Five",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
															}
															else{
																if(saveAdminParameter("DEPARTMENT_COUNT",depaprtmentCount)){
																	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Department Count Updated",
																						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																}
															}
														}
														moreChoice=GL_KEY_CANCEL;
														break;
													}
													else{
														char deptName[DEPARTMENT_NAME_LEN+1]={0};
														char deptMID[MERCHANT_ID_LEN+1]={0};
														char deptAPIKey[APIKEY_LEN+1]={0};
														char temp[20 +1]={0};
														strcpy(deptName,departmentList[choice-2]);
														strcpy(deptMID,deptMIDList[choice-2]);
														strcpy(deptAPIKey,deptAPIKeyList[choice-2]);
														keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "Merchant Management", "Enter Department Name:",
																						"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", deptName, sizeof(deptName), 3*GL_TIME_MINUTE);
														if(keyPressed == GL_KEY_VALID){
															sprintf(temp,"DEPARTMENT_%d",choice-1);
															memset(&deptName[strlen(deptName)],' ',sizeof(deptName)-strlen(deptName)-1);
															if(saveAdminParameter(temp,deptName)){
																keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "Merchant Management", "Enter Merchant ID:",
																							"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", deptMID, sizeof(deptMID), 3*GL_TIME_MINUTE);
																if(keyPressed == GL_KEY_VALID){
																	memset(temp,0,sizeof(temp));
																	sprintf(temp,"MERCHANT_ID_%d",choice-1);
																	memset(&deptMID[strlen(deptMID)],' ',sizeof(deptMID)-strlen(deptMID)-1);
																	if(saveAdminParameter(temp,deptMID)){
																		keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "Merchant Management", "Enter API Key:",
																									"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", deptAPIKey, sizeof(deptAPIKey), 3*GL_TIME_MINUTE);
																		if(keyPressed == GL_KEY_VALID){
																			memset(temp,0,sizeof(temp));
																			sprintf(temp,"GATEWAY_API_KEY_%d",choice-1);
																			memset(&deptAPIKey[strlen(deptAPIKey)],' ',sizeof(deptAPIKey)-strlen(deptAPIKey)-1);
																			if(saveAdminParameter(temp,deptAPIKey))
																				GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Department Details Updated",
																									GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
																		}
																	}
																}
															}
															else
																GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Department Name Update\nFailed",
																	GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
															continue;
														}
														else
															continue;
													}
												}
											}while(choice!=GL_KEY_CANCEL);
										}
									}
								}while(moreChoice!=GL_KEY_CANCEL);
								mainChoice=GL_KEY_CANCEL;
								break;
		  }
		  else if(!strcmp(menu.menuMain[mainChoice],"Logout")){
			  result=0;
			  result=GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Do you Want Logout ?\n\n[CANCEL]         [YES]",GL_ICON_QUESTION, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
			  if (result==GL_KEY_VALID)
				  saveAdminParameter("LOGOUT","1");
			  mainChoice=GL_KEY_CANCEL;
		  }
    }
  } while (mainChoice!=GL_KEY_CANCEL);

  lblEnd:
  if (strcmp(getErrorCode(),"ERROR:000")) {
  		  displayError(getErrorCode());
  	  }
  releaseUIContext();
  return;
}

int getLevel2Input(){
	ulong ret=0;
	char *mnuPurchaseID[8]={"Not Used","Reserved","Direct Marketing","RFU","Auto Rental","Hotel Folio NO","None",0};
	char *mnuLocalTaxFlg[5]={"Sales Tax not provided","Local or Sales Tax","Tax Exempt","None",0};
	char *mnuNationalTaxFlg[4]={"Tax Not Included","Tax Included","None",0};

	char optAmtId[2]={0};
	char optAmt[12+1]={0};
	char purchaseID[24+1]={0};
	char localTax[12+1]={0};
	char nationalTax[12+1]={0};
	char poNumber[17+1]={0};
	char mechVatRegNo[20+1]={0};
	char custVatRegNo[13+1]={0};
	char sumCommoditycode[4+1]={0};
	char discAmt[12+1]={0};
	char frightAmt[12+1]={0};
	char dutyAmt[12+1]={0};
	char destZip[10+1]={0},shippingZip[10+1]={0};
	char destCountryCode[3+1]={0};
	char lineItemCnt[2]={0};
	char vatInvRef[12+1]={0};
	char orderDate[8+1]={"MM/DD/YY"};
	char vatTaxAmt[12+1]={0};
	char vatTaxRate[4+1]={0};
	char supplierRefNo[9+1]={0};
	char chRefNo[17+1]={0};
	char shipToZip[9+1]={0};
	char salesTax[6+1]={0};
	char chargeDesc[24+1]={0};
	char requesterName[24+1]={0};
	char totalTaxAmt[12+1]={0};
	char taxTypeCode[3+1]={0};
	char altTaxAmtId[2]={0};
	char altTaxAmt[12+1]={0};
	int masterCard=0,visaCard=0,amexCard=0;
	char userCardNo[20]; int cardLength;

	getCardNumber(userCardNo,&cardLength);
	if(userCardNo[0] == '4' ){
		visaCard = TRUE;
	}
	else if(userCardNo[0] == '5'  ||userCardNo[0] == '2'){
		masterCard = TRUE;
	}
	else if(!memcmp (userCardNo, "34", 2) || !memcmp (userCardNo, "37", 2)){
		amexCard = TRUE;
	}

	if(masterCard || visaCard){

		//  <optAmtID>
		ret= GL_Dialog_Text (APEMV_UI_GoalHandle(), "OPT AMOUNT ID", "Enter Opt.Amount ID:",
									"/c", optAmtId, sizeof(optAmtId), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setOptAmtID(optAmtId);
		}
		else
			return TRUE;

		//  <optAmt>
		ret = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "OPT. AMOUNT", "Enter Opt Amount:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", optAmt, sizeof(optAmt),"USD",
								GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			if(atoi(optAmt)>0){
				sprintf(optAmt,"%d.%02d",atoi(optAmt)/100,atoi(optAmt)%100);
				setOptAmt(optAmt);
			}
		}
		else
			return TRUE;

		//PURCHASE ID FORMAT
		ret = GL_Dialog_Choice (APEMV_UI_GoalHandle(),"Purchase ID Format",(const)mnuPurchaseID, ret, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
		if(ret<=sizeof(mnuPurchaseID)/sizeof(mnuPurchaseID[0])){
			switch(ret){
			case 0:
				setPurchaseIDFormat(NOT_USED);
				break;
			case 1:
				setPurchaseIDFormat(RESERVED);
				break;
			case 2:
				setPurchaseIDFormat(DIRECT_MARKETING);
				break;
			case 3:
				setPurchaseIDFormat(RFU);
				break;
			case 4:
				setPurchaseIDFormat(AUTO_RENTAL);
				break;
			case 5:
				setPurchaseIDFormat(HOTEL);
				break;
			default:
				break;
			}

		}
		else
			return TRUE;

		//PURCHASE ID
		ret= GL_Dialog_Text (APEMV_UI_GoalHandle(), "Purchase ID", "Enter Purchase ID:",
									"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", purchaseID, sizeof(purchaseID), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setPurchaseID(purchaseID);
		}
		else
			return TRUE;

		//Local Tax Included Flag
		ret=0;
		ret = GL_Dialog_Choice (APEMV_UI_GoalHandle(),"Local Tax Included Flag",(const)mnuLocalTaxFlg, ret, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
		if(ret<=sizeof(mnuLocalTaxFlg)/sizeof(mnuLocalTaxFlg[0])){
			switch(ret){
			case 0:
				setLocalTaxInclFlag(TAX_NOT_PROVIDED);
				break;
			case 1:
				setLocalTaxInclFlag(TAX_AMOUNT);
				break;
			case 2:
				setLocalTaxInclFlag(TAX_EXEMPT);
				break;
			default:
				break;
			}
		}
		else
			return TRUE;

		//Local Tax
		ret = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "Local Tax", "Enter Local Tax:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", localTax, sizeof(localTax),"USD",
								GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			if(atoi(localTax)>0){
				sprintf(localTax,"%d.%02d",atoi(localTax)/100,atoi(localTax)%100);
				setLocalTax(localTax);
			}
		}
		else
			return TRUE;

		//National Tax Included Flag
		ret=0;
		ret = GL_Dialog_Choice (APEMV_UI_GoalHandle(),"National Tax Flag",(const)mnuNationalTaxFlg, ret, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
		if(ret<=sizeof(mnuNationalTaxFlg)/sizeof(mnuNationalTaxFlg[0])){
			switch(ret){
			case 0:
				setNatTaxInclFlag(TAX_NOT_INCLUDED);
				break;
			case 1:
				setNatTaxInclFlag(TAX_INCLUDED);
				break;
			default:
				break;
			}
		}
		else
			return TRUE;

		//National Tax
		ret = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "National Tax", "Enter National Tax:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", nationalTax, sizeof(nationalTax),"USD",
								GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			if(atoi(nationalTax)>0){
				sprintf(nationalTax,"%d.%02d",atoi(nationalTax)/100,atoi(nationalTax)%100);
				setNatTax(nationalTax);
			}
		}
		else
			return TRUE;

		//PO Number
		ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "PO Number", "Enter PO Number:",
				"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", poNumber, sizeof(poNumber), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setPONumber(poNumber);
		}
		else
			return TRUE;

		//Freight Amount
		ret = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "Freight Amount", "Enter Freight Amt:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", frightAmt, sizeof(frightAmt),"USD",
								GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			if(atoi(frightAmt)>0){
				sprintf(frightAmt,"%d.%02d",atoi(frightAmt)/100,atoi(frightAmt)%100);
				setFreightAmt(frightAmt);
			}
		}
		else
			return TRUE;

		//Duty Amount
		ret = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "Duty Amount", "Enter Duty Amt:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", dutyAmt, sizeof(dutyAmt),"USD",
								GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			if(atoi(dutyAmt)>0){
				sprintf(dutyAmt,"%d.%02d",atoi(dutyAmt)/100,atoi(dutyAmt)%100);
				setDutyAmt(dutyAmt);
			}
		}
		else
			return TRUE;

		//Destination Zip
		ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Destination Zip", "Destination Zip:",
				"/d/d/d/d/d/d/d/d/d/d", destZip, sizeof(destZip), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setDestZip(destZip);
		}
		else
			return TRUE;

		//Shipping Zip
		ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Shipping Zip", "Shipping Zip:",
				"/d/d/d/d/d/d/d/d/d/d", shippingZip, sizeof(shippingZip), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setShippingZip(shippingZip);
		}
		else
			return TRUE;

		//Dest Country Code
		ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Dest Country Code", "Dest Country Code:",
				"/d/d/d", destCountryCode, sizeof(destCountryCode), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setDestCountryCode(destCountryCode);
		}
		else
			return TRUE;

		//Line Item Count
		ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Line Item Count", "Line Item Count:",
				"/d", lineItemCnt, sizeof(lineItemCnt), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setLineItemCnt(lineItemCnt);
		}
		else
			return TRUE;

		//if(visaCard){
			//Merch VAT Reg Number
			ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Merch VAT Reg NO", "Enter Merch VAT Reg NO:",
					"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", mechVatRegNo, sizeof(mechVatRegNo), 3*GL_TIME_MINUTE);
			if(ret == GL_KEY_VALID){
				setMVATRegNum(mechVatRegNo);
			}
			else
				return TRUE;

			//Cust VAT Reg Number
			ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Cust VAT Reg NO", "Enter Cust VAT Reg NO:",
					"/c/c/c/c/c/c/c/c/c/c/c/c/c", custVatRegNo, sizeof(custVatRegNo), 3*GL_TIME_MINUTE);
			if(ret == GL_KEY_VALID){
				setCVATRegNum(custVatRegNo);
			}
			else
				return TRUE;

			//Summary Commodity Code
			ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Summary Commodity Code", "Summary Commodity Code:",
					"/c/c/c/c", sumCommoditycode, sizeof(sumCommoditycode), 3*GL_TIME_MINUTE);
			if(ret == GL_KEY_VALID){
				setSumCommodityCd(sumCommoditycode);
			}
			else
				return TRUE;

			//Discount Amount
			ret = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "Discount Amount", "Enter Discount Amt:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", discAmt, sizeof(discAmt),"USD",
									GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
			if(ret == GL_KEY_VALID){
				if(atoi(discAmt)>0){
					sprintf(discAmt,"%d.%02d",atoi(discAmt)/100,atoi(discAmt)%100);
					setDiscAmt(discAmt);
				}
			}
			else
				return TRUE;

						//VAT Invoice Reference Num
			ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "VAT Invoice Ref NO", "VAT Invoice Ref NO:",
					"/c/c/c/c/c/c/c/c/c/c/c/c", vatInvRef, sizeof(vatInvRef), 3*GL_TIME_MINUTE);
			if(ret == GL_KEY_VALID){
				setVATInvcRefNum(vatInvRef);
			}
			else
				return TRUE;

			//Order Date
			ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Order Date", "Order Date:",
					"/c/c///c/c///c/c", orderDate, sizeof(orderDate), 3*GL_TIME_MINUTE);
			if(ret == GL_KEY_VALID){
				setOrderDate(orderDate);
			}
			else
				return TRUE;

			//VAT/Tax Amount
			ret = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "VAT/Tax Amount", "VAT/Tax Amount:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", vatTaxAmt, sizeof(vatTaxAmt),"USD",
									GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
			if(ret == GL_KEY_VALID){
				if(atoi(vatTaxAmt)>0){
					sprintf(vatTaxAmt,"%d.%02d",atoi(vatTaxAmt)/100,atoi(vatTaxAmt)%100);
					setVATTaxAmt(vatTaxAmt);
				}
			}
			else
				return TRUE;

			//VAT/Tax Rate
			ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "VAT/Tax Rate", "VAT/Tax Rate:",
					"/c/c/c/c", vatTaxRate, sizeof(vatTaxRate), 3*GL_TIME_MINUTE);
			if(ret == GL_KEY_VALID){
				setVATTaxRate(vatTaxRate);
			}
			else
				return TRUE;
		//}
		//<altTaxAmtInd>
		ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Alt Tax Amount ID", "Alt Tax Amount ID:",
				"/c", altTaxAmtId, sizeof(altTaxAmtId), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setAltAmtTaxId(altTaxAmtId);
		}
		else
			return TRUE;
		//<altTaxAmt>
		ret = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "Alt Tax Amount", "Alt Tax Amount:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", altTaxAmt, sizeof(altTaxAmt),"USD",
								GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			if(atoi(altTaxAmt)>0){
				sprintf(altTaxAmt,"%d.%02d",atoi(altTaxAmt)/100,atoi(altTaxAmt)%100);
				setAltAmtTax(altTaxAmt);
			}
		}
		else
			return TRUE;
	}
	//Supplier Reference Number - AMEX
	if(amexCard){
		ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Supplier Ref No", "Supplier Ref No:",
				"/c/c/c/c/c/c/c/c/c", supplierRefNo, sizeof(supplierRefNo), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setSupplierRefNum(supplierRefNo);
		}
		else
			return TRUE;

		//CH Reference Number - AMEX
		ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "CH Ref No", "CH Ref No:",
				"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", chRefNo, sizeof(chRefNo), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setCHRefNum(chRefNo);
		}
		else
			return TRUE;

		//Ship to Zip - AMEX
		ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Ship to Zip", "Ship to Zip:",
				"/c/c/c/c/c/c/c/c/c", shipToZip, sizeof(shipToZip), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setShipToZip(shipToZip);
		}
		else
			return TRUE;

		//Sales Tax Amount - AMEX
		ret = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "Sales Tax Amt", "Sales Tax Amt:", "/d,/d/d/D./D/D", salesTax, sizeof(salesTax),"USD",
								GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			if(atoi(salesTax)>0){
				sprintf(salesTax,"%d.%02d",atoi(salesTax)/100,atoi(salesTax)%100);
				setSalesTaxAmt(salesTax);
			}
		}
		else
			return TRUE;

		//Charges Description - AMEX
		ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Charge Description", "Charge Desc:",
				"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", chargeDesc, sizeof(chargeDesc), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setChargeDesc1(chargeDesc);
		}
		else
			return TRUE;

		//Requester Name - AMEX
		ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "REQUESTER NAME", "Enter Requester Name:",
				"/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", requesterName, sizeof(requesterName), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setRequesterName(requesterName);
		}
		else
			return TRUE;

		//Total Tax Amount - AMEX
		ret = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "Total Tax Amt", "Total Tax Amt:", "/d,/d/d/D./D/D", totalTaxAmt, sizeof(totalTaxAmt),"USD",
								GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			if(atoi(totalTaxAmt)>0){
				sprintf(totalTaxAmt,"%d.%02d",atoi(totalTaxAmt)/100,atoi(totalTaxAmt)%100);
				setTotalTaxAmount(totalTaxAmt);
			}
		}
		else
			return TRUE;

		//Tax Type Code - AMEX
		ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Tax Type Code", "Enter Tax Type Code:",
				"/c/c/c", taxTypeCode, sizeof(taxTypeCode), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setTaxTypeCode(taxTypeCode);
		}
		else
			return TRUE;
	}
	return TRUE;
}

int getLevel3Input(){
	int ret;

	char productCode[12+1]={0};
	char prodCommodity[12+1]={0};
	char prodName[13+1]={0};
	char prodQuatity[12+1]={0};
	char prodMeasure[12+1]={0};
	char disAmount[12+1]={0};

	char costPerUnit[2]={0};
	char lineItemTotCnt[6]={0};
	char altTaxID[2]={0};
	char taxTypeApplied[2]={0};
	char discInd[2]={0};
	char netGrossInd[2]={0};
	char extItemAmt[12+1]={0};
	char drCrInd[2]={0};
	char itemDiscRate[2]={0};
	char itemQtyExpInd[2]={0};
	char itemDisExpInd[2]={0};

	int masterCard=0,visaCard=0,amexCard=0;
	char userCardNo[20]; int cardLength;

	getCardNumber(userCardNo,&cardLength);
	if(userCardNo[0] == '4' ){
		visaCard = TRUE;
	}
	else if(userCardNo[0] == '5'  ||userCardNo[0] == '2'){
		masterCard = TRUE;
	}
	else if(!((memcmp (userCardNo, "34", 2)) || (memcmp (userCardNo, "37", 2)))){
		amexCard = TRUE;
	}

	//Product Code
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Product Code", "Product Code:",
			"/c/c/c/c/c/c/c/c/c/c/c/c", productCode, sizeof(productCode), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setProductCd(productCode);
	}
	else
		return TRUE;

	//if(visaCard){
		//Product Commodity Code
		ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Product Commodity Code", "Product Commodity Code:",
				"/c/c/c/c/c/c/c/c/c/c/c/c", prodCommodity, sizeof(prodCommodity), 3*GL_TIME_MINUTE);
		if(ret == GL_KEY_VALID){
			setProductCommodityCd(prodCommodity);
		}
		else
			return TRUE;
	//}

	//Product Name
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Product Name", "Product Name:",
			"/c/c/c/c/c/c/c/c/c/c/c/c/c", prodName, sizeof(prodName), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setProductDesc(prodName);
	}
	else
		return TRUE;

	//Quantity
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Quantity", "Quantity:",
			"/c/c/c/c/c/c/c/c/c/c/c/c", prodQuatity, sizeof(prodQuatity), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setProductQuantity(prodQuatity);
	}
	else
		return TRUE;

	//Unit of Measure
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Unit of Measure", "Unit of Measure:",
			"/c/c/c/c/c/c/c/c/c/c/c/c", prodMeasure, sizeof(prodMeasure), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setProductMeasurementUnit(prodMeasure);
	}
	else
		return TRUE;

	//Discount Amount
	ret = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "Discount Amount", "Discount Amount:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", disAmount, sizeof(disAmount),"USD",
							GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		if(atoi(disAmount)>0)
			setDiscountAmt(disAmount);
	}
	else
		return TRUE;

	//<costPerUnit>
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Cost per Unit", "Cost per Unit:",
			"/c", costPerUnit, sizeof(costPerUnit), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setCostPerUnit(costPerUnit);
	}
	else
		return TRUE;

	//   <lineItemTotCount>
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Line Item Total Count", "Line Item Total Count:",
			"/c/c/c/c/c/c", lineItemTotCnt, sizeof(lineItemTotCnt), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setLineItemTotCnt(lineItemTotCnt);
	}
	else
		return TRUE;

	//  <altTaxID>
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Alt Tax ID", "Alt Tax ID:",
			"/c", altTaxID, sizeof(altTaxID), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setAltTaxID(altTaxID);
	}
	else
		return TRUE;

	//  <taxTypeApplied>
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Tax Type Applied", "Tax Type Applied:",
			"/c", taxTypeApplied, sizeof(taxTypeApplied), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setTaxTypeApplied(taxTypeApplied);
	}
	else
		return TRUE;

	//  <discInd>
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Disc Indicator", "Disc Ind:",
			"/c", discInd, sizeof(discInd), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setDiscInd(discInd);
	}
	else
		return TRUE;

	// <netGrossInd>
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Net Gross Ind", "Net Gross Ind:",
			"/c", netGrossInd, sizeof(netGrossInd), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setNetGrossInd(netGrossInd);
	}
	else
		return TRUE;

	//  <extItemAmt>
	ret = GL_Dialog_Amount (APEMV_UI_GoalHandle(), "Ext Item Amount", "Ext Item Amount:", "/d/d/d/d,/d/d/d,/d/d/D./D/D", extItemAmt, sizeof(extItemAmt),"USD",
							GL_ALIGN_LEFT, 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		if(atoi(extItemAmt)>0){
			sprintf(extItemAmt,"%d.%02d",atoi(extItemAmt)/100,atoi(extItemAmt)%100);
			setExtItemAmt(extItemAmt);
		}
	}
	else
		return TRUE;

	//<drCrInd>
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Dr Cr Ind", "Dr Cr Ind:",
			"/c", drCrInd, sizeof(drCrInd), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setDrCrInd(drCrInd);
	}
	else
		return TRUE;


	//<itemDiscRate>
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Item Disc Rate", "Item Disc Rate:",
			"/c", itemDiscRate, sizeof(itemDiscRate), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setItemDiscRate(itemDiscRate);
	}
	else
		return TRUE;

	//<itemQtyExpInd>
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Item Qty Exp Ind", "Item Qty Exp Ind:",
			"/c", itemQtyExpInd, sizeof(itemQtyExpInd), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setItemQtyExpInd(itemQtyExpInd);
	}
	else
		return TRUE;

	//<itemDiscExpInd>
	ret = GL_Dialog_Text (APEMV_UI_GoalHandle(), "Item Disc Exp Ind", "Item Disc Exp Ind:",
			"/c", itemDisExpInd, sizeof(itemDisExpInd), 3*GL_TIME_MINUTE);
	if(ret == GL_KEY_VALID){
		setItemDisExpInd(itemDisExpInd);
	}
	else
		return TRUE;

}


/**
 * Initialize the display context to maximize the canvas on user area
 */
void initUIContext(int displayHeaderFooterLeds) {
	if(displayHeaderFooterLeds != _OFF_ && displayHeaderFooterLeds != _ON_) {
		displayHeaderFooterLeds = _OFF_;
	}
	sSavedStatusHeader=DisplayHeader(displayHeaderFooterLeds);
	sSavedStatusLeds=DisplayLeds(displayHeaderFooterLeds);
	sSavedStatusFooter=DisplayFooter(displayHeaderFooterLeds);

    // Open display
    sDisplay = Telium_Fopen("DISPLAY", "w*");
    // Open keyboard
    sKeyboard = Telium_Fopen("KEYBOARD", "r*");

    return;
}
/**
 * Restore display context
 */
void releaseUIContext(void) {
    // close keyboard
	flag_app=1;
	houseKeeping();
    if (sKeyboard) {
        Telium_Fclose(sKeyboard);
        sKeyboard = NULL;
    }
    // close display
    if (sDisplay) {
        Telium_Fclose(sDisplay);
        sDisplay = NULL;
    }
    CloseUSB();
	// Restore display context
	DisplayHeader(sSavedStatusHeader);
	DisplayLeds(sSavedStatusLeds);
	DisplayFooter(sSavedStatusFooter);
	return;
}
void setMerchantChoice(ulong choice){
	/***********Pre Loader********************/
	  char mMerchantAddres[DEPARTMENT_COUNT][MERCHANT_API_LEN +1]={0};
	  char mMerchantCity[DEPARTMENT_COUNT][MERCHANT_API_LEN +1]={0};
	  char mMerchantState[DEPARTMENT_COUNT][MERCHANT_API_LEN+1]={0};
	  char mMerchantZip[DEPARTMENT_COUNT][MERCHANT_ZIP_LEN+1]={0};
	  char mMerchantPhone[DEPARTMENT_COUNT][MERCHANT_PHONE_LEN+1]={0};
	  getMerchantAddressList(mMerchantAddres);
	  getMerchantCityList(mMerchantCity);
	  getMerchantStateList(mMerchantState);
	  getMerchantZIPList(mMerchantZip);
	  getMerchantPhoneList(mMerchantPhone);
  /**************Pre Loader*****************/
	  setMerchantAddress(&mMerchantAddres[choice][0]);
	  setMerchantCity(&mMerchantCity[choice][0]);
	  setMerchantState(&mMerchantState[choice][0]);
	  setMerchantZip(&mMerchantZip[choice][0]);
	  setMerchantPhone(&mMerchantPhone[choice][0]);

}
int TransactionSummary(){
	char transactionsum[]=
				"GET /payment-services/tms/user/search HTTP/1.0\r\n"
				"Accept: application/xml\r\n"
				"terminalId: %s\r\n"
				"apiKey: %s\r\n\n\r";
	ulong transum=NULL;
	char requestbuf[2000]={0};
	char responsebuf[2000]={0};
	char terminalnum[20 +1]={0};
	char clerIDist[200]={0};
	char apikey[48 +1]={0};
	char *listclerk[20]={0};
	int cnt=0;
	struct sUserMenu menusummary={.menuTranSummary={"With-Transactions", "Without-Transactions", "ALL", 0}};
	transum = GL_Dialog_Choice (APEMV_UI_GoalHandle(),"TRANSACTIONS SUMMARY",(const)menusummary.menuTranSummary, transum, GL_BUTTON_ALL, GL_KEY_1, 3*GL_TIME_MINUTE);
	if(transum != GL_KEY_CANCEL){
		if(!strcmp(menusummary.menuTranSummary[transum], "ALL"))
			batchall=1;
		else if(!strcmp(menusummary.menuTranSummary[transum], "Without-Transactions"))
			batchall=2;
		if(strcmp(menusummary.menuTranSummary[transum], "ALL")){
		 memset(terminalnum, 0, sizeof(terminalnum));
		 memset(apikey, 0, sizeof(apikey));
		 getTMSTerminalID(terminalnum);
		 getTMSAPIKey(apikey);
		 memset(requestbuf, 0, sizeof(requestbuf));
		 memset(responsebuf, 0, sizeof(responsebuf));
		 sprintf(requestbuf,transactionsum,terminalnum,apikey);
		 hostcall(requestbuf, responsebuf, 5);
		 for(cnt; cnt <clerkcnt; cnt ++){
			 listclerk[cnt]=mclerklist[cnt];
		 }
		 if(clerkcnt)
		 transum = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "CLERKID LIST", listclerk, transum, GL_BUTTON_ALL, GL_KEY_1, 30*GL_TIME_SECOND);
		 setClerkID(listclerk[transum]);
		}
	}
}
int temsUserMenu(){
	char temsUserAuthen[]=
					"GET /payment-services/tms/user/validate HTTP/1.0\r\n"
					"Accept: application/xml\r\n"
					"terminalId: %s\r\n"
					"userId: %s\r\n"
					"password: %s\r\n"
					"apiKey: %s\r\n\n\r";
	extern int temsLoginFlag;
	ulong tmsmenue=NULL;
	char clerkID[10 +1]={0};
	 char morePassword [5]={0};
	 char clerkpwd     [20 +1]={0};
	 char tmsterminal_id[20 +1]={0};
	 char requestbuf[2000]={0};
	 char responsebuf[2000]={0};
	 char apikey[48 +1]={0};
	 ulong result=NULL;
	struct sUserMenu menutm={.menuTms={"ADMIN", "CLERK", 0}};
	 do {
		 tmsmenue=GL_Dialog_Choice (APEMV_UI_GoalHandle(),"LOGIN",(const)menutm.menuTms, tmsmenue,
				 GL_BUTTON_ALL, GL_KEY_1, 3*GL_TIME_MINUTE);
		 switch (tmsmenue) {
		 case 0:
			 result = GL_Dialog_Password(APEMV_UI_GoalHandle(), "LOGIN", "Enter Password :","/d/d/d/d",
					 morePassword, sizeof(morePassword), 3*GL_TIME_MINUTE);
			 if(result != GL_KEY_CANCEL){
				 if(!memcmp(morePassword,getManagerPassword(),sizeof(morePassword)-1)){
					 saveAdminParameter("LOGOUT","0");
					 tmsmenue=GL_KEY_CANCEL;
					 return 1;
				 }
				 else{
					 GL_Dialog_Message(APEMV_UI_GoalHandle(), "LOGIN","Invalid Password",
					 							 GL_ICON_ERROR, GL_BUTTON_VALID,3*GL_TIME_SECOND);
				 }
			 }
			 break;
		 case 1:
			 result=GL_Dialog_Text (APEMV_UI_GoalHandle(), "LOGIN", "Enter Login ID:","/d/d/d/d/d/d",
					 clerkID, sizeof(clerkID), 3*GL_TIME_MINUTE);
			 if(result != GL_KEY_CANCEL){
				 memset(tmsterminal_id, 0, sizeof(tmsterminal_id));
				 memset(apikey, 0, sizeof(apikey));
				 getTMSTerminalID(tmsterminal_id);
				 getTMSAPIKey(apikey);
				 memset(requestbuf, 0, sizeof(requestbuf));
				 memset(responsebuf, 0, sizeof(responsebuf));
				 sprintf(requestbuf,temsUserAuthen,tmsterminal_id,clerkID,clerkpwd,apikey);
				 if(hostcall(requestbuf,responsebuf,4)){
					 if(temsLoginFlag){
						 temsLoginFlag=0;
						 saveAdminParameter("LOGOUT","0");
						 int length=strlen(clerkID);
						 char tempID[6]={0};
						 memcpy (&tempID[sizeof(tempID) - length],clerkID, length);
						 memset (tempID, '0', sizeof (tempID) - length);
						 saveAdminParameter("CLERK_ID",tempID);
						 tmsmenue=GL_KEY_CANCEL;
						 return 2;
					 }
				 }
			 }
			 break;
		 default:
			 break;
		 }
	 }while(tmsmenue != GL_KEY_CANCEL);
	  return 3;
}

int tmsDownloadProcess(char *choice)
{
	/*********************************************************************
	 *
	 * @param TMS
	 * @param TMS Download
	 * @return
	 **********************************************************************/
	char httpTMSRegHeader[]=
				"POST /payment-services/tms/register HTTP/1.0\r\n"
				"Content-Type: application/xml\r\n"
				"Accept: application/xml\r\n"
				"apiKey: cG9zMTAwMQ==\r\n"
				"Content-Length: %d\r\n\r\n";
	char tmsRegbody[]=
				"<TerminalManagementMBAModel>\r\n"
				"<serialNo>%s</serialNo>\r\n"
				"</TerminalManagementMBAModel>\r\n";
	char httpTMSMerchantHeader[]=
				//"GET /TMSWeb/rest/tms/merchants HTTP/1.0\r\n"
				"GET /payment-services/tms/merchants HTTP/1.0\r\n"
				"Accept: application/xml\r\n"
				"terminalId: %s\r\n"
				"apiKey: %s\r\n\r\n";
	char httpTMSConfigHeader[]=
					"GET /payment-services/tms/config HTTP/1.0\r\n"
					"Accept: application/xml\r\n"
					"terminalId: %s\r\n"
					"apiKey: %s\r\n\r\n";
	char httpTMSFileHeader[]=
				"GET /payment-services/tms/file HTTP/1.0\r\n"
				"Accept: application/xml\r\n"
				"terminalId: %s\r\n"
				"fileType: %d\r\n"
				"apiKey: %s\r\n\n\r";
	char httpTMSUpdateHeader[]=
				"POST /payment-services/tms/update HTTP/1.0\r\n"
				"Content-Type: application/xml\r\n"
				"Accept: application/xml\r\n"
				"apiKey: %s\r\n"
				"Content-Length: %d\r\n\r\n";
	char tmsUpdatebody[]=
				"<PosFileModel>\r\n"
			    "<fileType>%d</fileType>\r\n"
			    "<fileVersion>%s</fileVersion>\r\n"
				"<terminalId>%s</terminalId>\r\n"
				"</PosFileModel>\r\n";

	char UserAddHeader[]=
						"POST /payment-services/tms/user/ HTTP/1.0\r\n"
						"Content-Type: application/xml\r\n"
						"Accept: application/xml\r\n"
						"terminalId: %s\r\n"
						"apiKey: %s\r\n"
						"Content-Length: %d\r\n\r\n";
	char UserAddBody[]=
					"<PosUserModel>\r\n"
				    "<userId>%s</userId>\r\n"
					"<passWord>%s</passWord>\r\n"
					"<roleId>2</roleId>\r\n"
					"</PosUserModel>\r\n";


	ulong keyPressed = 0;
	ulong tmsmenue=0;
	char requestbuf[5000]={0};
	char responsebuf[5000]={0};
	char authHeader[1024]={0};
	//char serial_num[50]={0};
	char revreq[1024]={0};
	char tmsterminal_id[20 +1]={0};
	char tempterminal[20 +1]={0};
	char filetype[2]={0};
	char filever[20 +1]={0};
	char tempfilever[20 +1]={0};
	ulong userchoice=NULL;
	char apikey[48 +1]={0};
	char userid[10+1]={0};
	char passWord[10+1]={0};
	NO_SERIE serial_num={0};
	if(!strcmp(choice, "USER")){
		struct sUserMenu menutm={.menuUser={"Add User",0}};
		do{
		userchoice =GL_Dialog_Choice (APEMV_UI_GoalHandle(),"USER",(const)menutm.menuUser, userchoice, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
		if(userchoice != GL_KEY_CANCEL){
			switch(userchoice){
			case 0:
				userchoice=GL_Dialog_Text (APEMV_UI_GoalHandle(), "USER", "Enter USER ID:","/d/d/d/d/d/d/d/d", userid, sizeof(userid), 3*GL_TIME_MINUTE);
				GL_Dialog_Message(APEMV_UI_GoalHandle(), "USER", "Adding User",NULL, GL_BUTTON_ALL, GL_TIME_SECOND);
				if(userchoice != GL_KEY_CANCEL && strlen(userid)){
				memset(requestbuf, 0, sizeof(requestbuf));
				memset(responsebuf, 0, sizeof(responsebuf));
				memset(revreq, 0, sizeof(revreq));
				getTMSTerminalID(tmsterminal_id);
				getTMSAPIKey(apikey);
				sprintf(revreq,UserAddBody,userid,passWord);
				sprintf(authHeader,UserAddHeader,tmsterminal_id,apikey,strlen(revreq));
				strcpy(requestbuf, authHeader);
				strcat(requestbuf,revreq);
				if(!hostcall(requestbuf,responsebuf,0))
					return 0;
				}
				break;
			}
		}
		}while(userchoice !=userchoice);
	}
	if(!strcmp(choice, "Pre Loader")){
	struct sUserMenu menutm={.menuTms={"Terminal Register","Merchants Update","Configuration File update","Software update",0}};

	do{
			restoreAdminParameters();
			tmsmenue=GL_Dialog_Choice (APEMV_UI_GoalHandle(),"PRELOADER",(const)menutm.menuTms, tmsmenue, GL_BUTTON_VALID_CANCEL, GL_KEY_1, 3*GL_TIME_MINUTE);
			if(tmsmenue != GL_KEY_CANCEL){
			switch(tmsmenue){
			case 0:
				memset(serial_num, 0, sizeof(serial_num));
				PSQ_Give_Serial_Number(serial_num);
				//GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Enter serial number",GL_ICON_INFORMATION, GL_BUTTON_ALL, 2*GL_TIME_SECOND);
				//memset(serial_num, 0, sizeof(serial_num));
				keyPressed= GL_Dialog_Text (APEMV_UI_GoalHandle(), "SERIAL_NUM", "Serial_num:","/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c/c", serial_num, sizeof(serial_num) -1, 3*GL_TIME_MINUTE);
				GL_Dialog_Message(APEMV_UI_GoalHandle(), "Terminal Register", "Registering Terminal",NULL, GL_BUTTON_ALL, GL_TIME_SECOND);
				if(keyPressed != GL_KEY_CANCEL && strlen(serial_num)){
				memset(requestbuf, 0, sizeof(requestbuf));
				memset(responsebuf, 0, sizeof(responsebuf));
				memset(revreq, 0, sizeof(revreq));
				sprintf(revreq,tmsRegbody,serial_num);
				sprintf(authHeader,httpTMSRegHeader,strlen(revreq));
				strcpy(requestbuf, authHeader);
				strcat(requestbuf,revreq);
				if(!hostcall(requestbuf,responsebuf,0))
					return 0;
				}
				break;
			case 1:
				keyPressed=GL_Dialog_Message(APEMV_UI_GoalHandle(), "Merchants Update", "Merchant List Updating",NULL, GL_BUTTON_ALL, 2*GL_TIME_SECOND);
				if(keyPressed != GL_KEY_CANCEL){
				getTMSTerminalID(tmsterminal_id);
				getTMSAPIKey(apikey);
				memset(requestbuf, 0, sizeof(requestbuf));
				memset(responsebuf, 0, sizeof(responsebuf));
				memset(revreq, 0, sizeof(revreq));
				sprintf(revreq,httpTMSMerchantHeader,tmsterminal_id,apikey);
				strcpy(requestbuf, revreq);
				if(!hostcall(requestbuf,responsebuf,1))
					return 0;
				}
				break;
			case 2:
				keyPressed=GL_Dialog_Message(APEMV_UI_GoalHandle(), "Configuration File", "Configuration file updating",NULL, GL_BUTTON_ALL, 2*GL_TIME_SECOND);
				if(keyPressed != GL_KEY_CANCEL){
				memset(requestbuf, 0, sizeof(requestbuf));
				memset(responsebuf, 0, sizeof(responsebuf));
				memset(revreq, 0, sizeof(revreq));
				getTMSTerminalID(tmsterminal_id);
				getTMSAPIKey(apikey);
				sprintf(revreq,httpTMSConfigHeader,tmsterminal_id,apikey);
				strcpy(requestbuf, revreq);
				if(!hostcall(requestbuf,responsebuf,3))
					return 0;
				}
				break;
			case 3:
				keyPressed=GL_Dialog_Message(APEMV_UI_GoalHandle(), "SOFTWARE", "Software Installing",NULL, GL_BUTTON_ALL, 2*GL_TIME_SECOND);
		        if(keyPressed != GL_KEY_CANCEL){
				memset(requestbuf, 0, sizeof(requestbuf));
				memset(responsebuf, 0, sizeof(responsebuf));
				memset(revreq, 0, sizeof(revreq));
		        getTMSTerminalID(tmsterminal_id);
		        getFileType(filetype);
		        getTMSAPIKey(apikey);
		        memset(revreq, 0, sizeof(revreq));
		        memset(responsebuf, 0, sizeof(responsebuf));
				sprintf(revreq,httpTMSFileHeader,tmsterminal_id,atoi(filetype),apikey);
				strcpy(requestbuf, revreq);
				setErrorCode("ERROR:000");
				if(!hostcall(requestbuf,responsebuf,0))
					return 0;
				if(!strcmp(getErrorCode(),"ERROR:000")){
				if(iFtp_download_Connect(FALSE))
				{
					memset(revreq, 0, sizeof(revreq));
					memset(responsebuf, 0, sizeof(responsebuf));
					memset(requestbuf, 0, sizeof(requestbuf));
					getFileVersion(tempfilever);
					trimTrailing(tempfilever,filever);
					getTMSTerminalID(tempterminal);
					trimTrailing(tempterminal,tmsterminal_id);
					sprintf(revreq,tmsUpdatebody,atoi(filetype),filever,tmsterminal_id);
					sprintf(authHeader,httpTMSUpdateHeader,apikey,strlen(revreq));
					strcpy(requestbuf, authHeader);
					strcat(requestbuf,revreq);
					if(!hostcall(requestbuf,responsebuf,2))
						return 0;
					GL_Dialog_Message(APEMV_UI_GoalHandle(), "SOFTWARE", "Restarting Terminal\n Please Wait...",NULL, GL_BUTTON_ALL, 2*GL_TIME_SECOND);
					Telium_Exit(1);
				}
				}else
					GL_Dialog_Message(APEMV_UI_GoalHandle(), "SOFTWARE", "Error in TEMS Response",NULL, GL_BUTTON_ALL, 2*GL_TIME_SECOND);
		        }
                 break;
			default:
				break;
				}
			}
			if(strcmp(getErrorCode(),"ERROR:000") && strcmp(getErrorCode(),"ERROR:PRELOADER")){
					tmsmenue=GL_KEY_CANCEL;
			}

		}while(tmsmenue != GL_KEY_CANCEL);
	}
}
void displayCardTypeMenu(){
	ulong choice=0;
	typedef struct sCardTypeMenu {
		char *menuCardType	[3];
	};
	struct sCardTypeMenu mCardTypeMenu = {.menuCardType = "Credit", "Debit" };
	choice = GL_Dialog_Menu(APEMV_UI_GoalHandle(), "CARD TYPE",(const) mCardTypeMenu.menuCardType, choice, GL_BUTTON_CANCEL , GL_KEY_1, 30*GL_TIME_SECOND);
	if(choice!= GL_KEY_CANCEL) {
		switch(choice) {
		case 0:
			setCardType(CREDIT);
			break;
		case 1:
			setCardType(DEBIT);
			break;
		default:
			setErrorCode("ERROR:012");
			break;
		}
	}
	else{
		saveAdminParameter("DISPLAY_MSG_FLAG","1");
		setErrorCode("ERROR:012");
	}

}
