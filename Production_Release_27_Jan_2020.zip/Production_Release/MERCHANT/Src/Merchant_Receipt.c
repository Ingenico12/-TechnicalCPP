#include <sdk_tplus.h>
#include <GL_GraphicLib.h>
#include "GL_Types.h"
#include "Transaction.h"
#include "MerchantData.h"
#include "_emvdctag_.h"

extern struct mBatch mBatchDetais;
extern struct mSubBatch mSubBatchdetails[50];
void pepareDataForReceipt(struct receiptData * govPayReceiptData){
	char mLocalDate[8+1]={0}, mLocalTime[8+1]={0};

	char total[12]={0};
	char *token=NULL;
	char newline[2] = {0};

	DATE date;
	Telium_Read_date(&date);
	char temp[10] = {0};
	//Date
	sprintf(temp,"%2.2s/%2.2s/%2.2s",date.month,date.day,date.year);
	memcpy(mLocalDate, temp, strlen(temp));
	//Time
	memset(temp, 0, sizeof(temp));
	sprintf(temp,"%2.2s:%2.2s:%2.2s",date.hour,date.minute,date.second);
	memcpy (mLocalTime, temp, strlen(temp));
	memset (govPayReceiptData->locDateTime, ' ', sizeof(govPayReceiptData->locDateTime) - 1);
	memcpy (&govPayReceiptData->locDateTime[0], mLocalDate, strlen(mLocalDate));
	memcpy (&govPayReceiptData->locDateTime[strlen(mLocalDate)+strlen(mLocalTime)], mLocalTime, strlen(mLocalTime));
    //ISO Parent Name
	char isoName [24+1] = {0};
	if(getIndustrytype(isoName)){
	int isoNameLength=0;
	int space=0;
	int n = 0;
	for (n = 0; n < sizeof(isoName); n++, isoNameLength++) {
		if (isoName[n] == ' ') {
			if (space == true) {
				isoNameLength--;
				break;
			}
			space = true;
		}
	}
	isoNameLength =(sizeof(isoName) - isoNameLength) / 2;
	memset (govPayReceiptData->isoName, ' ', sizeof(govPayReceiptData->isoName) - 1);
	memcpy (&govPayReceiptData->isoName[isoNameLength], isoName, strlen(isoName));
	govPayReceiptData->isoName[24] = '\0';
	}

	//Department Name
	char deptName [24+1] = {0};
	if(getDepartmentName(deptName)){
	int deptNameLength=0;
	int space=0;
	int n = 0;
	for (n = 0; n < sizeof(deptName); n++, deptNameLength++) {
		if (deptName[n] == ' ') {
			if (space == true) {
				deptNameLength--;
				break;
			}
			space = true;
		}
	}
	deptNameLength =(sizeof(deptName) - deptNameLength) / 2;
	memset (govPayReceiptData->department, ' ', sizeof(govPayReceiptData->department) - 1);
	memcpy (&govPayReceiptData->department[deptNameLength], deptName, strlen(deptName));
	govPayReceiptData->department[24] = '\0';
	}
	memset (govPayReceiptData->country, ' ', sizeof(govPayReceiptData->country) - 1);
	memcpy (&govPayReceiptData->country[10], "USA", sizeof("USA")-1);
	govPayReceiptData->country[24] = '\0';

	//Merchant Number
	char mrchntID[20+1];
	if(getMerchantID(mrchntID)){
	int ID=atoi(mrchntID);
	memset(mrchntID, 0, sizeof(mrchntID));
	sprintf(mrchntID,"%d",(int)ID);
	memset (govPayReceiptData->merchantNo, ' ', sizeof(govPayReceiptData->merchantNo) - 1);
	memcpy (govPayReceiptData->merchantNo, "Merchant No:", strlen("Merchant No:"));
	memcpy (&govPayReceiptData->merchantNo[sizeof(govPayReceiptData->merchantNo) - strlen(mrchntID) - 1], mrchntID, strlen(mrchntID));
	}
	//Terminal Number
	char terminalNo[20+1];
	if(getTerminalID(terminalNo)){
	int ID=atoi(terminalNo);
	memset(terminalNo, 0, sizeof(terminalNo));
	sprintf(terminalNo,"%d",(int)ID);
	memset (govPayReceiptData->terminalNo, ' ', sizeof(govPayReceiptData->terminalNo) - 1);
	memcpy (govPayReceiptData->terminalNo, "Terminal No:", strlen("Terminal No:"));
	memcpy (&govPayReceiptData->terminalNo[sizeof(govPayReceiptData->terminalNo) - strlen(terminalNo) - 1], terminalNo, strlen(terminalNo));
	}

	int n = 0;
	int space = false;
	// Merchant Name
	char mrchtName[25] = {0};
	if (getMerchantName(mrchtName)) {
		int mrchtNameLength = 0;
		for (n = 0; n < sizeof(mrchtName); n++, mrchtNameLength++) {
			if (mrchtName[n] == ' ') {
				if (space == true) {
					mrchtNameLength--;
					break;
				}
				space = true;
			}
		}
		mrchtNameLength = (sizeof(mrchtName) - mrchtNameLength) / 2;
		memset (govPayReceiptData->merchantName, ' ', sizeof(govPayReceiptData->merchantName) - 1);
		memcpy (&govPayReceiptData->merchantName[mrchtNameLength], mrchtName, strlen(mrchtName));
		govPayReceiptData->merchantName [24] = '\0';
	}
	space = false;
	char mrchtCity[25] = {0};
	if (getMerchantCity(mrchtCity)) {
		int mrchtCityLength = 0;
		for (n = 0; n < sizeof(mrchtCity); n++, mrchtCityLength++) {
			if (mrchtCity[n] == ' ') {
				if (space == true) {
					mrchtCityLength--;
					break;
				}
				space = true;
			}
		}
		mrchtCityLength =(sizeof(mrchtCity) - mrchtCityLength) / 2;
		memset (govPayReceiptData->merchantCity, ' ', sizeof(govPayReceiptData->merchantCity) - 1);
		memcpy (&govPayReceiptData->merchantCity[mrchtCityLength], mrchtCity, strlen(mrchtCity));
		govPayReceiptData->merchantCity [24] = '\0';
	}
	space = false;
	char mrchtAddr [25]= {0};
	if(getMerchantAddress(mrchtAddr)) {
		int mrchtAddrLength = 0;
		for (n = 0; n < sizeof(mrchtAddr); n++) {
			if (mrchtAddr[n] == ' ') {
				//if (space == true) {
					mrchtAddrLength++;
					//break;
				//}
				//space = true;
			}
		}
		mrchtAddrLength =mrchtAddrLength/ 2;
		memset (govPayReceiptData->merchantAddress, ' ', sizeof(govPayReceiptData->merchantAddress) - 1);
		memcpy (&govPayReceiptData->merchantAddress[mrchtAddrLength], mrchtAddr, strlen(mrchtAddr));
		govPayReceiptData->merchantAddress[24] = '\0';
	}
	space = false;
	char mrchtState [25]= {0};
	char mrchtZIP [25] = {0};
	int mrchtZIPLength = 0;
	int mrchtStateLength = 0;
	if(getMerchantState(mrchtState)) {
		char temp1[25] = {0};
		for (n = 0; n < sizeof(mrchtState); n++, mrchtStateLength++) {
			if (mrchtState[n] == ' ') {
				if (space == true) {
					mrchtStateLength--;
					break;
				}
				space = true;
			}
		}
		space = false;
		memcpy (temp1, mrchtState, mrchtStateLength);
		if (getMerchantZIP(mrchtZIP)){
			for (n = 0; n < sizeof(mrchtZIP); n++, mrchtZIPLength++) {
				if (mrchtZIP[n] == ' ') {
					if (space == true) {
						mrchtZIPLength = mrchtZIPLength - 1;
						break;
					}
					space = true;
				}
			}
		}
		temp1 [mrchtStateLength] = ' ';
		memcpy (&temp1[mrchtStateLength + 1], mrchtZIP, mrchtZIPLength);
		int len = strlen(temp1);
		len =(sizeof(mrchtZIP) - len) / 2;
		memset (govPayReceiptData->merchantZIP, ' ', sizeof(govPayReceiptData->merchantZIP) - 1);
		memcpy (&govPayReceiptData->merchantZIP[len], temp1, strlen(temp1));
		govPayReceiptData->merchantZIP[24] = '\0';
	}
	space = false;
	char mrchtPh[20 +1]   ={0};
	if (getMerchantPhone(mrchtPh)) {
		if(strrchr(mrchtPh, ')')){
		int mrchtPhLength = 0;
		for (n = 0; n < sizeof(mrchtPh); n++, mrchtPhLength++) {
			if (mrchtPh[n] == ' ') {
				if (space == true) {
					mrchtPhLength--;
					break;
				}
				space = true;
			}
		}
	   mrchtPhLength =(sizeof(mrchtPh) - mrchtPhLength) / 2;
	   memset (govPayReceiptData->merchantPhone, ' ', sizeof(govPayReceiptData->merchantPhone) - 1);
	   memcpy (&govPayReceiptData->merchantPhone[mrchtPhLength], mrchtPh, strlen(mrchtPh));
	   govPayReceiptData->merchantPhone[20] = '\0';
		}else{
		char ph1[4]={0};
		char ph2[4]={0};
		char ph3[5]={0};
		int mrchtPhLength = 0;
		for (n = 0; n < sizeof(mrchtPh); n++, mrchtPhLength++) {
			if (mrchtPh[n] == ' ') {
				if (space == true) {
					mrchtPhLength--;
					break;
				}
				space = true;
			}
		}
		strncpy(ph1,mrchtPh,3);
		strncpy(ph2, mrchtPh +3,3);
		strncpy(ph3, mrchtPh +6,4 );
		memset(mrchtPh, 0, sizeof(mrchtPh));
		sprintf(mrchtPh, "(%s)%s-%s",ph1,ph2,ph3);
		mrchtPhLength =(sizeof(mrchtPh) - mrchtPhLength) / 2;
		memset (govPayReceiptData->merchantPhone, ' ', sizeof(govPayReceiptData->merchantPhone) - 1);
		memcpy (&govPayReceiptData->merchantPhone[mrchtPhLength], mrchtPh, strlen(mrchtPh));
		govPayReceiptData->merchantPhone[20] = '\0';
		}
	}
	if (getCardType() == 'C'){
		memset (govPayReceiptData->txnTypeDorC, ' ', sizeof(govPayReceiptData->txnTypeDorC) - 1);
		memcpy (&govPayReceiptData->txnTypeDorC[sizeof("Credit")+9], "Credit", sizeof("Credit")-1);
	}
	else{
		memset (govPayReceiptData->txnTypeDorC, ' ', sizeof(govPayReceiptData->txnTypeDorC) - 1);
		memcpy (&govPayReceiptData->txnTypeDorC[sizeof("Debit ")+9], "Debit ", sizeof("Debit ")-1);
	}
	govPayReceiptData->txnTypeDorC[24] = '\0';

	//txn type
	char txnType [25]= {0};
	if(!strcmp(getTransactionType(),PURCHASE)){
		strcpy(txnType,"SALE");
		memset (govPayReceiptData->txnType, ' ', sizeof(govPayReceiptData->txnType) - 1);
		memcpy (&govPayReceiptData->txnType[16], txnType, strlen(txnType));
	}
	else if(!strcmp(getTransactionType(),DUPLICATE_RECEIPT)){
		strcpy(txnType,"DUPLICATE");
		memset (govPayReceiptData->txnType, ' ', sizeof(govPayReceiptData->txnType) - 1);
		memcpy (&govPayReceiptData->txnType[11], txnType, strlen(txnType));
	}
	else if(!strcmp(getTransactionType(),REFUND)){
		strcpy(txnType,getTransactionType());
		memset (govPayReceiptData->txnType, ' ', sizeof(govPayReceiptData->txnType) - 1);
		memcpy (&govPayReceiptData->txnType[14], txnType, strlen(txnType));
	}
	else{
		memcpy(txnType, getTransactionType(), sizeof(txnType)-1);
		int txnTypeLength = strlen(txnType);
		txnTypeLength = (sizeof(txnType) - txnTypeLength) / 2;
		memset (govPayReceiptData->txnType, ' ', sizeof(govPayReceiptData->txnType) - 1);
		memcpy (&govPayReceiptData->txnType[txnTypeLength], txnType, strlen(txnType));
	}
	govPayReceiptData->txnType[24] = '\0';

	  char mClrkID[7] = {0};
	  if (getClerkId(mClrkID)) {
		int ID=0;
		ID = atoi(mClrkID);
		memset(mClrkID,0,sizeof(mClrkID));
		sprintf (mClrkID,"%d",(int)ID);
		memcpy (govPayReceiptData->clrkID, "Clerk ID:", sizeof("Clerk ID:"));
		memcpy (govPayReceiptData->clrkID + sizeof(govPayReceiptData->clrkID) - strlen(mClrkID) - 1, mClrkID, strlen(mClrkID));
		memset (govPayReceiptData->clrkID + sizeof ("Clerk ID:") - 1, ' ', sizeof (govPayReceiptData->clrkID) - strlen(mClrkID) - sizeof ("Clerk ID:"));
	}
	char txnID[20] = {0};
	if(strlen(getRespTxnSequenceNo())){
	memcpy (txnID, getRespTxnSequenceNo(), sizeof(txnID)-1);
	memcpy (govPayReceiptData->txnID, "Txn ID:", sizeof("Txn ID:"));
	memcpy (govPayReceiptData->txnID + sizeof(govPayReceiptData->txnID) - strlen(txnID) - 1, txnID, strlen(txnID));
	memset (govPayReceiptData->txnID + sizeof ("Txn ID:") - 1, ' ', sizeof (govPayReceiptData->txnID) - strlen(txnID) - sizeof ("Txn ID:"));
	}
	char refrID[20+1] = {0};
	if(strlen(getReferenceNo())){
	memcpy (refrID, getReferenceNo(), sizeof(refrID)-1);
	memcpy (govPayReceiptData->ReferenceNo, "Ref ID:  ", sizeof("Ref ID:  "));
	//memcpy (govPayReceiptData->ReferenceNo + sizeof(govPayReceiptData->ReferenceNo) - strlen(refrID) - 1, refrID, strlen(refrID));
	memcpy (govPayReceiptData->ReferenceNo + strlen("Ref ID:  "), refrID, strlen(refrID));
	//memset (govPayReceiptData->ReferenceNo + sizeof ("Ref ID:"), ' ', sizeof (govPayReceiptData->ReferenceNo) - strlen(refrID) - sizeof ("Ref ID:"));
	}


	//TODO Amount part
	struct sFeesApplied feesApplied [MAX_FEE_COUNT]={0}; //Total= %d.%02d Please Confirm?
	int feeCount,i;
	int totalAmount = 0;
	char tempAmount[12+1]={0};
	if (getProprietaryData (feesApplied,&feeCount)) {
		for(i=0;i<feeCount;i++){
			if(!strcmp(feesApplied[i].feeType,"CORE")){
				memcpy(tempAmount, feesApplied[i].feeAmount,sizeof(tempAmount));
				memcpy (govPayReceiptData->subTotalAmt, "Amount:", sizeof("Amount:"));
				memcpy (govPayReceiptData->subTotalAmt + sizeof(govPayReceiptData->subTotalAmt) - strlen(tempAmount) - 1, tempAmount, strlen(tempAmount));
				memset (govPayReceiptData->subTotalAmt + sizeof ("Amount:") - 1, ' ', sizeof (govPayReceiptData->subTotalAmt) - strlen(tempAmount) - sizeof ("Amount:"));
				memset (govPayReceiptData->subTotalAmt + sizeof (govPayReceiptData->subTotalAmt) - strlen(tempAmount) - 2, '$', 1);
			}
			else if (!strcmp(feesApplied[i].feeType,"STATE")) {
				memset(tempAmount, 0, sizeof(tempAmount));
				memcpy(tempAmount, feesApplied[i].feeAmount,sizeof(tempAmount));
				memcpy (govPayReceiptData->stateFee, "STATE:", sizeof("STATE:"));
				memcpy (govPayReceiptData->stateFee + sizeof(govPayReceiptData->stateFee) - strlen(tempAmount) - 1, tempAmount, strlen(tempAmount));
				memset (govPayReceiptData->stateFee + sizeof ("STATE:") - 1, ' ', sizeof (govPayReceiptData->stateFee) - strlen(tempAmount) - sizeof ("STATE:"));
				memset (govPayReceiptData->stateFee + sizeof (govPayReceiptData->stateFee) - strlen(tempAmount) - 2, '$', 1);
			}
			else if (!strcmp(feesApplied[i].feeType,"CONV")) {
				memset(tempAmount, 0, sizeof(tempAmount));
				memcpy(tempAmount, feesApplied[i].feeAmount,sizeof(tempAmount));
				memcpy (govPayReceiptData->convFee, "CONV:", sizeof("CONV:"));
				memcpy (govPayReceiptData->convFee + sizeof(govPayReceiptData->convFee) - strlen(tempAmount) - 1, tempAmount, strlen(tempAmount));
				memset (govPayReceiptData->convFee + sizeof ("CONV:") - 1, ' ', sizeof (govPayReceiptData->convFee) - strlen(tempAmount) - sizeof ("CONV:"));
				memset (govPayReceiptData->convFee + sizeof (govPayReceiptData->convFee) - strlen(tempAmount) - 2, '$', 1);
			}

			if (strcmp(feesApplied[i].feeType,"CHARG")){
				float temp_amount=0.00;
                 temp_amount=atof(feesApplied[i].feeAmount)*100;
                totalAmount = totalAmount + temp_amount;
			}
		}
		sprintf(total,"%d.%02d",totalAmount/100, abs(totalAmount%100));
		memcpy (govPayReceiptData->totalAmt, "TOTAL:", sizeof("TOTAL:"));
		memcpy (govPayReceiptData->totalAmt + sizeof(govPayReceiptData->totalAmt) - strlen(total) - 1, total, strlen(total));
		memset (govPayReceiptData->totalAmt + sizeof ("TOTAL:") - 1, ' ', sizeof (govPayReceiptData->totalAmt) - strlen(total) - sizeof ("TOTAL:"));
		memset (govPayReceiptData->totalAmt + sizeof (govPayReceiptData->totalAmt) - strlen(total) - 2, '$', 1);
	}

	// Card Entry Mode
	char cardInMode [16]= {0};
	memcpy(cardInMode, getCardInputMode(), sizeof(cardInMode) - 1);
	if(strlen(cardInMode)){
	/*if(!strcmp(getTransactionType(),DUPLICATE_RECEIPT) || !strcmp(getTransactionType(), FULL_REVERSAL)){
		    memset(cardInMode, 0, sizeof(cardInMode));
			strcpy(cardInMode,"MANUALENTRY");
	}*/
	memcpy (govPayReceiptData->cardEntryMode, "Entry:", sizeof("Entry:"));
	memcpy (govPayReceiptData->cardEntryMode + sizeof(govPayReceiptData->cardEntryMode) - strlen(cardInMode) - 1, cardInMode, strlen(cardInMode));
	memset (govPayReceiptData->cardEntryMode + sizeof ("Entry:") - 1, ' ', sizeof (govPayReceiptData->cardEntryMode) - strlen(cardInMode) - sizeof ("Entry:"));
	}
	// Brand + Card last 4 digits
	char cardBrand[11] = {0};
	if(!strcmp(getTransactionType(),REFUND)){
		char apptemp[17]={0};
			strcpy (apptemp, getEMVApplicationLabel());
			if(strlen(apptemp)){
			char *tok=strtok(apptemp, " ");
			if(strlen(tok))
			strcpy(cardBrand, tok);
			}
		}else
	memcpy (cardBrand, getCardBrand(), sizeof(cardBrand)-1);

	int cardLength = 0;
	char cardTemp[21] = {0};
	char card[5+1] = {0};
	if (strcmp(getTransactionType(),DUPLICATE_RECEIPT)) {
		getCardNumber (cardTemp, &cardLength);
		if(strlen(cardTemp)){
		memcpy(card,"-",sizeof("-"));
		memcpy (&card[1], cardTemp + cardLength - 4, sizeof(card) - 1);
		}
	}
	else {
		if(strlen(getLastFourDigitCardNo())){
			strcpy(card,"-");
			strncat(card,getLastFourDigitCardNo(),4);
		}
		else{
			strcpy(card, "-");
			strncat(card, getRespCardNumber(), 4);
		}
	}
	memcpy (govPayReceiptData->cardNum, cardBrand, strlen(cardBrand));
	memcpy (govPayReceiptData->cardNum + sizeof(govPayReceiptData->cardNum) - sizeof(card), card, sizeof(card) - 1);
	memset (govPayReceiptData->cardNum +  strlen(cardBrand), ' ', sizeof (govPayReceiptData->cardNum) - strlen(cardBrand) - sizeof(card));

	// Card Expiry Date
	/*char cardExpDate[5]={0};
	char formatChangeExpDate[5]={0};
	memcpy(cardExpDate, getCardExpiryDate(), sizeof(cardExpDate)-1);
	memcpy(formatChangeExpDate, &cardExpDate[2], 2);
	memcpy(&formatChangeExpDate[2], &cardExpDate[0], 2);
	//memcpy (govPayReceiptData->expDate, "Expiry Date:       xx/", sizeof("Expiry Date:       xx/"));
	memcpy (govPayReceiptData->expDate, "Exp Date:           ", sizeof("Exp Date:           "));
	memcpy (govPayReceiptData->expDate + sizeof(govPayReceiptData->expDate) - 5, &formatChangeExpDate[0], 4); */

	// EMV DATA
	if(!strcmp(getCardInputMode(),EMV)||
	   !strcmp(getCardInputMode(),EMVCONTACTLESS)){
		// APP:
		char emvAPP[17]= {0};
		strcpy (emvAPP, getEMVApplicationLabel());
		memcpy (govPayReceiptData->app, "APP:", sizeof("APP:"));
		memcpy (govPayReceiptData->app + sizeof(govPayReceiptData->app) - strlen(emvAPP) - 1, emvAPP, strlen(emvAPP));
		memset (govPayReceiptData->app + sizeof ("APP:") - 1, ' ', sizeof (govPayReceiptData->app) - strlen(emvAPP) - sizeof ("APP:"));
		// AID:
		char emvAID [33]={0};
		strcpy (emvAID, getEMVApplicationIdentifier());
		if(strlen(emvAID)>18){
			memcpy (govPayReceiptData->specialAid, "AID:", sizeof("AID:"));
			memcpy (govPayReceiptData->specialAid + sizeof(govPayReceiptData->specialAid) - strlen(emvAID) - 1, emvAID, strlen(emvAID));
			memset (govPayReceiptData->specialAid + sizeof ("AID:") - 1, ' ', sizeof (govPayReceiptData->specialAid) - strlen(emvAID) - sizeof ("AID:"));
		}
		else{
			memcpy (govPayReceiptData->aid, "AID:", sizeof("AID:"));
			memcpy (govPayReceiptData->aid + sizeof(govPayReceiptData->aid) - strlen(emvAID) - 1, emvAID, strlen(emvAID));
			memset (govPayReceiptData->aid + sizeof ("AID:") - 1, ' ', sizeof (govPayReceiptData->aid) - strlen(emvAID) - sizeof ("AID:"));
		}
		// TVR:
		memcpy (govPayReceiptData->tvr, "TVR:", sizeof("TVR:"));
		memcpy (govPayReceiptData->tvr + sizeof(govPayReceiptData->tvr) - 11, getEMVTerminalVerificationResult(), 10);
		memset (govPayReceiptData->tvr + sizeof ("TVR:") - 1, ' ', sizeof (govPayReceiptData->tvr) - 10 - sizeof ("TVR:"));
		// TSI:
		memcpy (govPayReceiptData->tsi, "TSI:", sizeof("TSI:"));
		memcpy (govPayReceiptData->tsi + sizeof(govPayReceiptData->tsi) - 5, getEMVTransactionStatusInformation(), 4);
		memset (govPayReceiptData->tsi + sizeof ("TSI:") - 1, ' ', sizeof(govPayReceiptData->tsi) - 4 - sizeof ("TSI:"));
	}
	//Response code
	if( !strcmp(getResponseCode(), "85") || !strcmp(getResponseCode(), "T0")
		|| !strcmp(getResponseCode(), "08") || !strcmp(getResponseCode(), "11")){
			setResponseCode("00");
		}
	// Authorization Response Code
	if (strcmp(getResponseCode(),"00")){
	memcpy(govPayReceiptData->arc,"Resp Code:",sizeof("Resp Code:"));
	memcpy(govPayReceiptData->arc+sizeof(govPayReceiptData->arc)-1-strlen(getResponseCode()),getResponseCode(),strlen(getResponseCode()));
	memset (govPayReceiptData->arc+sizeof("Resp Code:")-1,' ',sizeof(govPayReceiptData->arc)-strlen(getResponseCode())-sizeof("Resp Code:"));
	}
	if (!strcmp(getResponseCode(),"00")) {
		// Auth Code
		if (strlen(getAuthCode())){
			memcpy(govPayReceiptData->authCode,"Auth Code:",sizeof("Auth Code:"));
			memcpy(govPayReceiptData->authCode+sizeof(govPayReceiptData->authCode)-1-strlen(getAuthCode()),getAuthCode(),strlen(getAuthCode()));
			memset(govPayReceiptData->authCode+sizeof("Auth Code:")-1,' ',sizeof(govPayReceiptData->authCode)-strlen(getAuthCode())-sizeof("Auth Code:"));
		}
		//strcpy (govPayReceiptData->txnStatus,"Txn Status:     APPROVED");
	}
	//else
		//strcpy (govPayReceiptData->txnStatus,"Txn Status:     DECLINED");

	// Response Text
	char respText [24] = {0};
	memcpy (respText, getResponseText(), sizeof (respText) - 1);
	int respTextLength = 0;
	space = false;
	int y = strlen(respText);
	if (strlen(respText)){
		for (n = 0; n < strlen(respText); n++, respTextLength++) {
			if (respText[n] == ' ') {
				if (space == true) {
					respTextLength = respTextLength - 1;
					break;
				}
				space = true;
			}
			else
				space = false;
		}
	}
	respTextLength = (sizeof(respText) - respTextLength) / 2;
	memset (govPayReceiptData->responseTxt, ' ', sizeof(govPayReceiptData->responseTxt) - 1);
	if (!strcmp(getResponseCode(), "00"))
		memcpy (&govPayReceiptData->responseTxt[sizeof("APPROVED")+2], "APPROVED", sizeof("APPROVED"));
	else
		memcpy (&govPayReceiptData->responseTxt[respTextLength], respText, strlen(respText));
	govPayReceiptData->responseTxt[24] = '\0';

	//print response definition
	if (strcmp(getResponseCode(),"00")){
		char responseDefText[72]={0};
		memcpy(responseDefText,getResponseDefination(),sizeof(responseDefText)-1);
		if(strlen(responseDefText)>0){
			memcpy(govPayReceiptData->responseDef,getResponseDefination(),23);
			govPayReceiptData->responseDef[24] = '\0';
		}
	}
	// CVM
	int cvm = getCHVerificationMethod();
	govPayReceiptData->cvm = ((cvm == OFF_CLEARTEXT_PIN || cvm == SIGN_OFF_CLR_PIN || cvm == OFF_ENCIPHER_PIN || cvm == SIGN_OFF_ENC_PIN || cvm == ONLINE_PIN) ? '2' :
			                  (cvm == PAPER_SIGNATURE ? '1' : '0'));

	char chName [25] = {0};
	if(!strcmp(getCardInputMode(), "MANUALENTRY")){
		strcpy(chName, "MANUAL_ENTRY");
	}else
	memcpy (chName, getCardHolderName(), sizeof(chName) - 1);
	//int chNameLength = 0;
	space = false;
	if (strlen(chName)){
		/*for (n = 0; n <= strlen(chName); n++, chNameLength++) {
			if (chName[n] == ' ') {
				if (space == true) {
					chNameLength = chNameLength - 1;
					break;
				}
				space = true;
			}
		} */
	}
	//chNameLength = (sizeof(chName) - chNameLength) / 2;
	//memset (govPayReceiptData->chName, ' ', sizeof(govPayReceiptData->chName) - 1);
	memcpy(govPayReceiptData->chName, "Name: ", sizeof("Name: "));
	memcpy (&govPayReceiptData->chName[strlen("Name: ")], chName, 18);
	govPayReceiptData->chName[24] = '\0';
	if (strcmp(getTransactionType(),DUPLICATE_RECEIPT)) {
		T_GL_HFILE mFile;
		mFile = GL_File_Open("file://flash/HOST/RECEIPT.TXT",GL_FILE_OPEN_ALWAYS,GL_FILE_ACCESS_WRITE);
		if(mFile==NULL)
			return;
		GL_File_Seek(mFile, 0, GL_FILE_SEEK_BEGIN);
		GL_File_Write (mFile, govPayReceiptData, sizeof(struct receiptData));
		GL_File_Close(mFile);
	}
}

void duplicateReceipt(struct receiptData * receiptDetails){
	T_GL_HFILE mFile;
	mFile = GL_File_Open("file://flash/HOST/RECEIPT.TXT",GL_FILE_OPEN_EXISTING, GL_FILE_ACCESS_READ);
	if (mFile == NULL)
		return;
	int length;
		length = GL_File_GetSize(mFile);
		char *buffer = (char *) calloc(1, length*sizeof(char));
		if(GL_File_Read(mFile, buffer, length) != 0){
			memcpy(receiptDetails, buffer, sizeof(struct receiptData));
		}
		GL_File_Close(mFile);
		free(buffer);
}

void printReceipt(T_GL_HGRAPHIC_LIB hGraphicLib,int receiptFlag,int duplicateFlag){
	char convFee[12+1]={0},stateFee[12+1]={0};
	char buffer[8+1]={0};
	char DupRecdatetime[19+1]={0};
	char duplicbuffer[24 +1]={0};
	struct receiptData copyReceiptData;
	memset(&copyReceiptData, 0, sizeof(copyReceiptData));

	if (duplicateFlag == DUPLICATE_COPY)
		duplicateReceipt(&copyReceiptData);
	else
		pepareDataForReceipt(&copyReceiptData);

	/*================== Printing Receipt ===============*/
	unsigned char* ad_status;
	Telium_File_t *hPrinter;
	hPrinter = Telium_Fopen("PRINTER", "w-*"); // Open printer driver
	if (hPrinter != NULL) {
		GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Printing .........",GL_ICON_NONE, GL_BUTTON_ALL, GL_TIME_SECOND);
		Telium_Pprintf("\x1B""F""%s\n""\x1B""F",copyReceiptData.isoName);
		Telium_Pprintf("\x1B""F""%s\n""\x1B""F",copyReceiptData.department);
		//Telium_Pprintf("\x12""%s\n", copyReceiptData.country);
		//Telium_Pprintf("\x12"" \n");
		if (strcmp(getTransactionType(),DUPLICATE_RECEIPT)){
			//Telium_Pprintf("\x12""%s\n",  copyReceiptData.merchantName);
			Telium_Pprintf("\x12""%s\n", copyReceiptData.merchantAddress);
			Telium_Pprintf("\x12""%s\n", copyReceiptData.merchantCity);
			Telium_Pprintf("\x12""%s\n", copyReceiptData.merchantZIP);
			//Telium_Pprintf("\x12""%s\n", copyReceiptData.country);
			Telium_Pprintf("\x12""  %s\n", copyReceiptData.merchantPhone);
			Telium_Pprintf("\x12"" \n");
			Telium_Pprintf("\x12""%s", copyReceiptData.locDateTime);
		}else{
			memcpy(DupRecdatetime, getTxnDateTime(), 19);
			char mm[2 + 1]={0};
			char dd[2 +1]={0};
			char yy[2 +1]={0};
			char dtime[12 +1]={0};
			memcpy(yy, &DupRecdatetime[2], 2);
			memcpy(mm, &DupRecdatetime[5],2);
			memcpy(dd, &DupRecdatetime[8],2);
			memcpy(dtime, &DupRecdatetime[10], 10);
			memset(DupRecdatetime, 0, sizeof(DupRecdatetime));
			sprintf(DupRecdatetime,"%s/%s/%s    %s", mm,dd,yy,dtime);
			Telium_Pprintf("\x12"" \n\n");
			Telium_Pprintf("\x12""%s", DupRecdatetime);
		}
		Telium_Pprintf("\x12"" \n\n");
		// Clerk ID
		Telium_Pprintf("\x12""%s\n", copyReceiptData.clrkID);
		// Transaction ID
		if(strlen(copyReceiptData.txnID))
		Telium_Pprintf("\x12""%s\n\n", copyReceiptData.txnID);
		// Cust Name
		if(strlen(copyReceiptData.chName))
		Telium_Pprintf("\x12""%s\n", copyReceiptData.chName);
		/// Ref
		if(strlen(copyReceiptData.ReferenceNo))
		Telium_Pprintf("\x12""%s\n", copyReceiptData.ReferenceNo);
		// Terminal ID
		Telium_Pprintf("\x12""%s\n\n", copyReceiptData.terminalNo);
		// Merchant Number
		//Telium_Pprintf("\x12""%s\n", copyReceiptData.merchantNo);
		//Telium_Pprintf("\x12"" \n");
		//Txn Type
		//Telium_Pprintf("\x1B""@""%s\n""\x1B""F",copyReceiptData.txnType);
		Telium_Pprintf("\x1B""E""%s\n""\x1B""F",copyReceiptData.txnTypeDorC);
		strcpy(duplicbuffer, copyReceiptData.responseTxt);
		if(strstr(strupr(duplicbuffer), "DUPLICATE")){
			memset (copyReceiptData.txnType, ' ', sizeof(copyReceiptData.txnType) - 1);
			memcpy (&copyReceiptData.txnType[14], "FAILURE", strlen("FAILURE"));
			Telium_Pprintf("\x1B""E""%s\n""\x1B""F",copyReceiptData.txnType);
		}else
		Telium_Pprintf("\x1B""E""%s\n""\x1B""F",copyReceiptData.txnType);

		Telium_Pprintf("\x12""\n");
		// Card Entry Mode
		Telium_Pprintf("\x12""%s\n", copyReceiptData.cardEntryMode);

		// Brand + Card last 4 digits
		Telium_Pprintf("\x12""%s\n", copyReceiptData.cardNum);

		// Print EMV Data
		if (strcmp(getTransactionType(),DUPLICATE_RECEIPT)){
			if (strlen(copyReceiptData.aid)){
				Telium_Pprintf("\x12""%s\n", copyReceiptData.app);
				Telium_Pprintf("\x12""%s\n", copyReceiptData.aid);
				Telium_Pprintf("\x12""%s\n", copyReceiptData.tvr);
				Telium_Pprintf("\x12""%s\n", copyReceiptData.tsi);
			}
			else if(strlen(copyReceiptData.specialAid)){
				Telium_Pprintf("\x12""%s\n", copyReceiptData.app);
				Telium_Pprintf("\x12""%s\n", copyReceiptData.specialAid);
				Telium_Pprintf("\x12""%s\n", copyReceiptData.tvr);
				Telium_Pprintf("\x12""%s\n", copyReceiptData.tsi);
			}
		}
		if (strcmp(getResponseCode(),"00")){
		Telium_Pprintf("\x12""%s\n", copyReceiptData.arc);
		}
		Telium_Pprintf("\x12"" \n");
		if(!strcmp (getTransactionType(), REFUND)){
			if (!strcmp(getResponseCode(),"00")){
			Telium_Pprintf("\x12"" \n \n");
			Telium_Pprintf("\x1B""E""          %s\n""\x1B""F","REFUNDED");
			}else
				Telium_Pprintf("\x1B""E""%s\n""\x1B""F",copyReceiptData.responseTxt);
		}
		else
			Telium_Pprintf("\x1B""E""%s\n""\x1B""F",copyReceiptData.responseTxt);
		//todo
		if(strcmp(getResponseCode(),"00")){
		  if(strlen(copyReceiptData.responseDef))
			 Telium_Pprintf("\x12""%s\n",copyReceiptData.responseDef);
		}
		// Auth Code
		if (strlen(copyReceiptData.authCode)) {
			Telium_Pprintf("\x12""%s\n", copyReceiptData.authCode);
		}
		//Fees details
		Telium_Pprintf("\x12""%s\n", copyReceiptData.subTotalAmt);
		//Telium_Pprintf("\x12B""E""%s\n""\x1B""F", copyReceiptData.subTotalAmt);
		if (strlen(copyReceiptData.convFee))
			Telium_Pprintf("\x12""%s\n", copyReceiptData.convFee);
		if (strlen (copyReceiptData.stateFee))
			Telium_Pprintf("\x12""%s\n", copyReceiptData.stateFee);
		Telium_Pprintf("\x12""%s\n", copyReceiptData.totalAmt);
		Telium_Pprintf("\x12"" \n");

		if (receiptFlag == MERCHANT_COPY) {
			if (strlen(copyReceiptData.authCode)) {
				if (copyReceiptData.cvm == '2') {
					Telium_Pprintf("\x12"" \n\n");
					Telium_Pprintf("\x12""    VERIFIED BY PIN\n");
				}
				else if (copyReceiptData.cvm == '1' || !strcmp(getCardInputMode(),"CREDIT")) {
					Telium_Pprintf("\x12"" \n");
					Telium_Pprintf("\x12""    Client Signature\n\n\n");
					Telium_Pprintf("_______________________\n");
				}
				Telium_Pprintf("\x12"" \n");
				Telium_Pprintf("\xF""         SIGNATURE OR PIN ENTRY INDICATES\n""\x12");
				Telium_Pprintf("\xF""        COMPLIANCE WITH CARDHOLDER PAYMENT\n""\x12");
				Telium_Pprintf("\xF""       AGREEMENT, GOV-PAY IS THE AUTHORIZED\n""\x12");
				Telium_Pprintf("\xF""               3RD-PARTY FACILITATOR \n""\x12");
				//Telium_Pprintf("\xF""                 YOUR COUNTRY\n""\x12");
			}
			Telium_Pprintf("\x12"" \n");
			Telium_Pprintf("\xF""                 THANK YOU!\n""\x12");
			Telium_Pprintf("\x12"" \n");
			Telium_Pprintf("\xF""                  GOV-PAY\n""\x12");
			Telium_Pprintf("\xF""               WWW.GOV-PAY.COM\n""\x12");
			Telium_Pprintf("\xF""                800-300-8007\n""\x12");
			Telium_Pprintf("\x12"" \n");
			Telium_Pprintf("\x12"" \n");
			Telium_Pprintf("\x12""     MERCHANT COPY\n");
			Telium_Pprintf("\x12"" \n\n\n\n\n");
		}
		else if(receiptFlag == CUSTOMER_COPY){
			if (strlen(copyReceiptData.authCode)) {
				if (copyReceiptData.cvm == '2') {
					Telium_Pprintf("\x12"" \n\n");
					Telium_Pprintf("\x12""    VERIFIED BY PIN\n");
				}
				else if (copyReceiptData.cvm == '1' || !strcmp(getCardInputMode(),"CREDIT")) {
					Telium_Pprintf("\x12"" \n");
					Telium_Pprintf("\x12""    Client Signature\n\n\n");
					Telium_Pprintf("_______________________\n");
				}
				Telium_Pprintf("\x12"" \n");
				Telium_Pprintf("\xF""         SIGNATURE OR PIN ENTRY INDICATES\n""\x12");
				Telium_Pprintf("\xF""        COMPLIANCE WITH CARDHOLDER PAYMENT\n""\x12");
				Telium_Pprintf("\xF""       AGREEMENT, GOV-PAY IS THE AUTHORIZED\n""\x12");
				Telium_Pprintf("\xF""               3RD-PARTY FACILITATOR \n""\x12");
				//Telium_Pprintf("\xF""                 YOUR COUNTRY\n""\x12");
			}
			Telium_Pprintf("\xF""                 THANK YOU!\n""\x12");
			Telium_Pprintf("\x12"" \n");
			Telium_Pprintf("\xF""                 GOV-PAY\n""\x12");
			Telium_Pprintf("\xF""               WWW.GOV-PAY.COM\n""\x12");
			Telium_Pprintf("\xF""               800-300-8007\n""\x12");
			Telium_Pprintf("\x12"" \n");
			Telium_Pprintf("\x12"" \n");
			Telium_Pprintf("\x12""     CUSTOMER COPY\n");
			Telium_Pprintf("\x12"" \n\n\n\n\n");
		}
		// Display Screen For Merchant Copy
		Telium_Ttestall(PRINTER, 0);
	}
	Telium_Fclose(hPrinter); // Close printer driver
}

void printBatchReceipt(int batchflag){
    char mLocalDate[8+1]={0}, mLocalTime[8+1]={0};
    struct receiptData batchRecieptData={0};
    struct receiptData * govPayReceiptData=&batchRecieptData;
    char total[12]={0};
    char *token=NULL;
    char newline[2] = {0};
    char saletotal[40]={0};
    char refundtotal[40]={0};

    DATE date;
    Telium_Read_date(&date);
    char temp[10] = {0};
    //Date
    sprintf(temp,"%2.2s/%2.2s/%2.2s",date.month, date.day, date.year);
    memcpy(mLocalDate, temp, strlen(temp));
    //Time
    memset(temp, 0, sizeof(temp));
    sprintf(temp,"%2.2s:%2.2s:%2.2s",date.hour,date.minute,date.second);
    memcpy (mLocalTime, temp, strlen(temp));
	memset (govPayReceiptData->locDateTime, ' ', sizeof(govPayReceiptData->locDateTime) - 1);
	memcpy (&govPayReceiptData->locDateTime[0], mLocalDate, strlen(mLocalDate));
	memcpy (&govPayReceiptData->locDateTime[strlen(mLocalDate)+strlen(mLocalTime)], mLocalTime, strlen(mLocalTime));

    //ISO Parent Name
   	char isoName [24+1] = {0};
   	if(getIndustrytype(isoName)){
   	int isoNameLength=0;
   	int space=0;
   	int n = 0;
   	for (n = 0; n < sizeof(isoName); n++, isoNameLength++) {
   		if (isoName[n] == ' ') {
   			if (space == true) {
   				isoNameLength--;
   				break;
   			}
   			space = true;
   		}
   	}
   	isoNameLength =(sizeof(isoName) - isoNameLength) / 2;
   	memset (govPayReceiptData->isoName, ' ', sizeof(govPayReceiptData->isoName) - 1);
   	memcpy (&govPayReceiptData->isoName[isoNameLength], isoName, strlen(isoName));
   	govPayReceiptData->isoName[24] = '\0';
   	}

   char deptName [24+1] = {0};
	if(getDepartmentName(deptName)){
	int deptNameLength=0;
	int space=0;
	int n = 0;
	for (n = 0; n < sizeof(deptName); n++, deptNameLength++) {
		if (deptName[n] == ' ') {
			if (space == true) {
				deptNameLength--;
				break;
			}
			space = true;
		}
	}
	deptNameLength = (sizeof(deptName) - deptNameLength) / 2;
	memset (govPayReceiptData->department, ' ', sizeof(govPayReceiptData->department) - 1);
	memcpy (&govPayReceiptData->department[deptNameLength], deptName, strlen(deptName));
	govPayReceiptData->department[24] = '\0';
	}
     /*================== Printing Receipt ===============*/
           Telium_File_t *hhPrinter=NULL;
           int i=0;
           int j=0;
           int mbatchcnt=0;
           char batchreport[80]={0};
           char headbuff[40]={0};
           int subcount=0;
           hhPrinter = Telium_Fopen("PRINTER", "w-*"); // Open printer driver
           if (hhPrinter != NULL) {
        	   GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Printing .........",GL_ICON_NONE, GL_BUTTON_ALL, GL_TIME_SECOND);
        	   	Telium_Pprintf("\x1B""E""      BATCH SUMMARY\n""\x1B""F");
        	   	Telium_Pprintf("\x12"" \n");
                  Telium_Pprintf("\x12"" \n");
                  Telium_Pprintf("\x12""%s", batchRecieptData.locDateTime);
                  Telium_Pprintf("\x12"" \n");
                  Telium_Pprintf("\x1B""F""%s\n""\x1B""F",batchRecieptData.isoName);

                  mbatchcnt=atoi(mSubBatchdetails[i].subTotalCount);
                  for(j; j < atoi(mBatchDetais.mTotalcount); j++){
                  for(i, subcount; i < mbatchcnt; i++, subcount++ ){
                	  if(strlen(mSubBatchdetails[i].mMerchantName)){
                		  char merchantname[40]={0};
						   strcpy(merchantname,mSubBatchdetails[i].mMerchantName);
						   Telium_Pprintf("\x1B""E""\x12""%s \n \n""\x1B""F", merchantname);
						   memset(merchantname, 0, sizeof(merchantname));
						   sprintf(headbuff, "%s   %s  %s   %s","TX", "ID","Type","Amount");
						  Telium_Pprintf("\x12""%s", headbuff);
						  Telium_Pprintf("\x12"" \n");
						  memset(headbuff, 0, sizeof(headbuff));
                	  }
						   if(strlen(mSubBatchdetails[i].mAmount))
						   sprintf(batchreport, "%s %d %s  $%s",mSubBatchdetails[i].mTransactionId, mSubBatchdetails[i].mClerkid,
								   mSubBatchdetails[i].mType, mSubBatchdetails[i].mAmount);
						   if(strlen(mSubBatchdetails[i].mRefundAmount))
							   sprintf(batchreport, "%s %d %s  -$%s",mSubBatchdetails[i].mTransactionId, mSubBatchdetails[i].mClerkid,
							   								   mSubBatchdetails[i].mType, mSubBatchdetails[i].mRefundAmount);
						   Telium_Pprintf("\x12""%s \n", batchreport);
						   memset(batchreport, 0, sizeof(batchreport));
					  if(strlen(mSubBatchdetails[i].mNetAmt)){
						  char batchtemp[50]="Total sales: $";
						  strcat(batchtemp, mSubBatchdetails[i].mNetAmt);
						  strcpy(saletotal,batchtemp);
						  memset(batchtemp, 0, sizeof(batchtemp));
					  }
					  if(strlen(mSubBatchdetails[i].mrefundNetAmt)){
						  char refundtemp[50]="Total Refunds: -$";
						  strcat(refundtemp, mSubBatchdetails[i].mrefundNetAmt);
						  strcpy(refundtotal,refundtemp);
						  memset(refundtemp, 0, sizeof(refundtemp));
					  }

                  }
                  if(i==mbatchcnt){
                	  mbatchcnt=atoi(mSubBatchdetails[i].subTotalCount);
					   Telium_Pprintf("_______________________\n");
					   Telium_Pprintf("\x12""%s \n", saletotal);
					   Telium_Pprintf("\x12""%s \n", refundtotal);
					   Telium_Pprintf("Total Count: %d \n",subcount);
					   memset(saletotal, 0, sizeof(saletotal));
					   memset(refundtotal, 0, sizeof(refundtotal));
					   Telium_Pprintf("\x12"" \n");
					   subcount=0;
				   }

                  }
           	   	  Telium_Pprintf("\x1B""E""Total Summary  \n""\x1B""F");
                  Telium_Pprintf("_______________________\n");
				  char subtemp[40]="Total sales $";
				  strcat(subtemp, mBatchDetais.mGrandTotal);
				  Telium_Pprintf("\x12""%s \n", subtemp);
				  Telium_Pprintf("Total Count: %d \n",i);
                  Telium_Pprintf("\x12"" \n\n");
                  Telium_Pprintf("\xF""                 THANK YOU!\n""\x12");
                  Telium_Pprintf("\x12"" \n");
                  Telium_Pprintf("\xF""                  GOV-PAY\n""\x12");
                  Telium_Pprintf("\xF""               WWW.GOV-PAY.COM\n""\x12");
                  Telium_Pprintf("\xF""               800-300-8007\n""\x12");
                  Telium_Pprintf("\x12"" \n");
                  Telium_Pprintf("\x12"" \n");
                  Telium_Pprintf("\x12""     MERCHANT COPY\n");
                  Telium_Pprintf("\x12"" \n\n\n\n\n");
                  Telium_Ttestall(PRINTER, 0);
           }
       	memset(&mSubBatchdetails,0,sizeof(mSubBatchdetails));
       	memset(&mBatchDetais, 0, sizeof(mBatchDetais));
       	Telium_Fclose(hhPrinter); // Close printer driver
}

void printTranSummaryReceipt(int batchflag){
    char mLocalDate[8+1]={0}, mLocalTime[8+1]={0};
    struct receiptData batchRecieptData={0};
    struct receiptData * govPayReceiptData=&batchRecieptData;
    char total[12]={0};
    char *token=NULL;
    char newline[2] = {0};
    char saletotal[40]={0};
    char refundtotal[40]={0};

    DATE date;
    Telium_Read_date(&date);
    char temp[10] = {0};
    //Date
    sprintf(temp,"%2.2s/%2.2s/%2.2s",date.month, date.day, date.year);
    memcpy(mLocalDate, temp, strlen(temp));
    //Time
    memset(temp, 0, sizeof(temp));
    sprintf(temp,"%2.2s:%2.2s:%2.2s",date.hour,date.minute,date.second);
    memcpy (mLocalTime, temp, strlen(temp));
	memset (govPayReceiptData->locDateTime, ' ', sizeof(govPayReceiptData->locDateTime) - 1);
	memcpy (&govPayReceiptData->locDateTime[0], mLocalDate, strlen(mLocalDate));
	memcpy (&govPayReceiptData->locDateTime[strlen(mLocalDate)+strlen(mLocalTime)], mLocalTime, strlen(mLocalTime));

    //ISO Parent Name
   	char isoName [24+1] = {0};
   	if(getIndustrytype(isoName)){
   	int isoNameLength=0;
   	int space=0;
   	int n = 0;
   	for (n = 0; n < sizeof(isoName); n++, isoNameLength++) {
   		if (isoName[n] == ' ') {
   			if (space == true) {
   				isoNameLength--;
   				break;
   			}
   			space = true;
   		}
   	}
   	isoNameLength =(sizeof(isoName) - isoNameLength) / 2;
   	memset (govPayReceiptData->isoName, ' ', sizeof(govPayReceiptData->isoName) - 1);
   	memcpy (&govPayReceiptData->isoName[isoNameLength], isoName, strlen(isoName));
   	govPayReceiptData->isoName[24] = '\0';
   	}

   char deptName [24+1] = {0};
	if(getDepartmentName(deptName)){
	int deptNameLength=0;
	int space=0;
	int n = 0;
	for (n = 0; n < sizeof(deptName); n++, deptNameLength++) {
		if (deptName[n] == ' ') {
			if (space == true) {
				deptNameLength--;
				break;
			}
			space = true;
		}
	}
	deptNameLength = (sizeof(deptName) - deptNameLength) / 2;
	memset (govPayReceiptData->department, ' ', sizeof(govPayReceiptData->department) - 1);
	memcpy (&govPayReceiptData->department[deptNameLength], deptName, strlen(deptName));
	govPayReceiptData->department[24] = '\0';
	}
     /*================== Printing Receipt ===============*/
           Telium_File_t *hhPrinter=NULL;
           int i=0;
           int j=0;
           int mbatchcnt=0;
           char batchreport[80]={0};
           char headbuff[40]={0};
           int subcount=0;
           int mclerkreid=0;
           hhPrinter = Telium_Fopen("PRINTER", "w-*"); // Open printer driver
           if (hhPrinter != NULL) {
        	   GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Printing .........",GL_ICON_NONE, GL_BUTTON_ALL, GL_TIME_SECOND);
        	   	Telium_Pprintf("\x12"" TRANSACTIONS SUMMARY\n");
        	   	Telium_Pprintf("\x12"" \n");
                  Telium_Pprintf("\x12"" \n");
                  Telium_Pprintf("\x12""%s", batchRecieptData.locDateTime);
                  Telium_Pprintf("\x12"" \n");
                  Telium_Pprintf("\x12""%s\n \n" ,batchRecieptData.isoName);
                if(batchall ==2){
						memset(headbuff, 0, sizeof(headbuff));
						memset(batchreport, 0, sizeof(batchreport));
                	   //Telium_Pprintf("\x1B""E""%s \n \n""\x1B""F", mSubBatchdetails[i].mClerkid);
					   sprintf(headbuff, "%s %s  %s"," ID","TOTALTRAN","Amount");
					   Telium_Pprintf("\x12""%s", headbuff);
					   Telium_Pprintf("\x12"" \n");
					   sprintf(batchreport, "%d   %s       %s", mSubBatchdetails[0].mClerkid, mSubBatchdetails[0].subTotalCount, mSubBatchdetails[0].mNetAmt);
					   Telium_Pprintf("\x12""%s \n", batchreport);
					   batchall=0;
                } else{
                  mbatchcnt=atoi(mSubBatchdetails[i].subTotalCount);
                  for(j; j < atoi(mBatchDetais.mTotalcount); j++){
                  for(i, subcount; i < mbatchcnt; i++, subcount++ ){
                	  if(mclerkreid != mSubBatchdetails[i].mClerkid){
                		  mclerkreid = mSubBatchdetails[i].mClerkid;
                	  if(mSubBatchdetails[i].mClerkid){
						   Telium_Pprintf("\x1B""E""Clerk ID: %d \n \n""\x1B""F", mSubBatchdetails[i].mClerkid);
						   sprintf(headbuff, " %s   %s   %s","TX","Type","Amount");
						  Telium_Pprintf("\x12""%s", headbuff);
						  Telium_Pprintf("\x12"" \n");
						  memset(headbuff, 0, sizeof(headbuff));
                	  	  }
                	  }
						   if(strlen(mSubBatchdetails[i].mAmount))
						   sprintf(batchreport, "%s  %s  $%s",mSubBatchdetails[i].mTransactionId, mSubBatchdetails[i].mType, mSubBatchdetails[i].mAmount);
						   if(strlen(mSubBatchdetails[i].mRefundAmount))
							   sprintf(batchreport, "%s  %s  -$%s",mSubBatchdetails[i].mTransactionId,mSubBatchdetails[i].mType, mSubBatchdetails[i].mRefundAmount);
						   Telium_Pprintf("\x12""%s \n", batchreport);
						   memset(batchreport, 0, sizeof(batchreport));
					  if(strlen(mSubBatchdetails[i].mNetAmt)){
						  char batchtemp[50]="Total sale: $";
						  strcat(batchtemp, mSubBatchdetails[i].mNetAmt);
						  strcpy(saletotal,batchtemp);
						  memset(batchtemp, 0, sizeof(batchtemp));
					  }
					  if(strlen(mSubBatchdetails[i].mrefundNetAmt)){
						  char refundtemp[50]="Total Refunds: -$";
						  strcat(refundtemp, mSubBatchdetails[i].mrefundNetAmt);
						  strcpy(refundtotal,refundtemp);
						  memset(refundtemp, 0, sizeof(refundtemp));
					  }

                  }
                  if(i==mbatchcnt){
                	  mbatchcnt=atoi(mSubBatchdetails[i].subTotalCount);
					   Telium_Pprintf("_______________________\n");
					   Telium_Pprintf("\x12""%s \n", saletotal);
					   Telium_Pprintf("\x12""%s \n", refundtotal);
					   Telium_Pprintf("Total Count: %d \n",subcount);
					   memset(saletotal, 0, sizeof(saletotal));
					   memset(refundtotal, 0, sizeof(refundtotal));
					   Telium_Pprintf("\x12"" \n");
					   subcount=0;
				   }

                  }
           	   	  Telium_Pprintf("\x1B""E""Total Summary   \n""\x1B""F");
                  Telium_Pprintf("_______________________\n");
				  char subtemp[40]="Total sales $";
				  strcat(subtemp, mBatchDetais.mGrandTotal);
				  Telium_Pprintf("\x12""%s \n", subtemp);
				  Telium_Pprintf("Total Count: %d \n",i);
				  batchall=0;
                }
                  Telium_Pprintf("\x12"" \n\n");
                  Telium_Pprintf("\xF""                 THANK YOU!\n""\x12");
                  Telium_Pprintf("\x12"" \n");
                  Telium_Pprintf("\xF""                  GOV-PAY\n""\x12");
                  Telium_Pprintf("\xF""               WWW.GOV-PAY.COM\n""\x12");
                  Telium_Pprintf("\xF""               800-300-8007\n""\x12");
                  Telium_Pprintf("\x12"" \n");
                  Telium_Pprintf("\x12"" \n");
                  Telium_Pprintf("\x12""     MERCHANT COPY\n");
                  Telium_Pprintf("\x12"" \n\n\n\n\n");
                  Telium_Ttestall(PRINTER, 0);
           }
       	memset(mSubBatchdetails,0,sizeof(mSubBatchdetails));
       	memset(&mBatchDetais, 0, sizeof(mBatchDetais));
       	Telium_Fclose(hhPrinter); // Close printer driver
}
