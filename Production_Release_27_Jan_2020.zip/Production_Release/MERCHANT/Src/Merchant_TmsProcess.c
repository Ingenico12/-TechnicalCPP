#include <sdk_tplus.h>
#include "GL_Types.h"
#include "FTP_.h"
#include "MerchantData.h"
#define __DATA_SIZE 512  // Download a file.
T_GL_HGRAPHIC_LIB gGoalGraphicLibInstance = NULL;
int __SoftwareActivate( const char *szName );
typedef struct
{
	char m_szName[40];		// Disk name.
	unsigned long m_nSize;	// Disk size.
	int m_bUnload;			// Unload application.

	int m_nFreeSize;

} T__RAMDISK;
void trimTrailing(char * str, char * dest)
{
    int index, i;
    index = -1;

    /* Find last index of non-white space character */
    i = 0;
    while(str[i] != '\0')
    {
        if(str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
        {
            index= i;
        }

        i++;
    }
    /* Mark next character to last non-white space character as NULL */
    str[index + 1] = '\0';
    strcpy(dest, str);
}
int iFtp_download_file ( FTP_HANDLE hFTP, RAMDISK_HANDLE hDisk, char *szFilename ) {
    unsigned char pucBuffer[__DATA_SIZE];
    int nRet = -1;
    int nReadBytes = 0;
    int fileSize=0;
    // Get the file to transfer.
	if( FTP_Get( hFTP, szFilename ) == 0 )    {
       // Open and create a file in the RAM disk. In append mode
		RAMDISK_FILE hFile = RAMDISK_OpenFile( hDisk, "PAYMENTAPP.AGN", "a");
       if( hFile != 0 )       {
          nRet = 0;
          do{
              // Read bytes of the file from the data channel.
        	  nReadBytes = FTP_GetData( hFTP, pucBuffer, __DATA_SIZE );
        	  fileSize+=nReadBytes;
              if( nReadBytes >= 0 ){
                  // Write the read files in the RAM file.
            	  //GL_File_Seek(mFile,0,GL_FILE_SEEK_END);
            	  //GL_File_Write (mFile,pucBuffer,nReadBytes);
            	  if( RAMDISK_WriteInFile( hDisk, hFile, pucBuffer, nReadBytes ) != 0 ){
                      // Write Error.
            		  nRet = -1;

                  }
                  else                  {
                  // Write success.
                	  }
              }
          }while(( nReadBytes > 0 ) && ( nRet == 0 ));

           // Close the RAM file

        		   RAMDISK_CloseFile( hDisk, hFile );
        		  // fileSize = GL_File_GetSize(mFile);

       }
       // Close FTP data channel.
          FTP_CloseData( hFTP );

    }
    else    {
        // File error. Can not access remote file.        //To complete...
    	}
    return nRet;

 }
  int  iFtp_download_Connect( int bFTPS ) {
	  restoreAdminParameters();
     RAMDISK_HANDLE hDisk = NULL;
     char hostAddr[15+1]={0};
     char temphost[49 +1]={0};
     char hostm[49 +1]={0};
     char user_name[20 +1]={0};
     char tempname[20 +1]={0};
     char hport[20 +1]={0};
     char tempport[20 +1]={0};
     char hfilepath[50 +1]={0};
     char temppath[50 +1]={0};
     char hpassword[30 +1]={0};
      FTP_HANDLE hFTP = 0;
      getTMSUserName(tempname);
      trimTrailing(tempname, user_name);
      getTMSPort(tempport);
      trimTrailing(tempport, hport);
      getTMSURL(temphost);
      trimTrailing(temphost, hostm);
      getFilePath(temppath);
      trimTrailing(temppath, hfilepath);
	  trimTrailing(TmsftpPwd, hpassword);
     DNS_GetIpAddress(hostm,hostAddr,sizeof(hostAddr));
   // FTP connection Handle.      // FTP connection (passive mode).
      if( bFTPS == FALSE )     {
    	  GL_Dialog_Message(APEMV_UI_GoalHandle(), "App Update",
    	      	           "Connecting FTP Server...", GL_ICON_INFORMATION, GL_BUTTON_VALID,
						   3*GL_TIME_SECOND);
        hFTP = FTP_Connect( user_name, hpassword, hostAddr , atoi(hport), 1 );
     }
     else     {
        // We use a secured connection in that case.
    	 hFTP = FTPS_Connect( "user", "1234", "213.222.84.6", 990, 1, "SSLPROFILE" );

     }
     if( hFTP != NULL )     {
        // Go into the remote directory "logs".
    	 char *dir=strtok(hfilepath, "/");
    	 if( FTP_ChangeDir( hFTP, dir ) == 0 )        {
           // RAM disk creation of size 4 KBytes, maximum 2 files.

    		 CleanRamDisk();
    		 hDisk = RAMDISK_Create( "TEMP", 4096*1024, 0 );
    		 GL_Dialog_Message(APEMV_UI_GoalHandle(), "App Update",
    		     	      	           "File Downloading...", GL_ICON_INFORMATION, GL_BUTTON_VALID,
    		     	      	            GL_TIME_SECOND);

            if( hDisk != 0 )           {
            	char *hfile=strstr(hfilepath, "/");
            	if(iFtp_download_file ( hFTP, hDisk, hfilepath +2) == 0 ){
                 // DownloadSuccess.
            	  }
              else              {
                 // Download Error.
            	  // Ignore RAMDISK. Return NULL.
            	  hDisk = NULL;

              }
           }
              else           {
              // RAM disk creation error.               //To complete...
            	  }
        }
        else        {
           // Bad directory.           //To complete...
        	}
        FTP_Disconnect( hFTP );

     }
     else     {
        // Connection error.
    	 GL_Dialog_Message(APEMV_UI_GoalHandle(), "App Update",
    	           "FTP Error...", GL_ICON_INFORMATION, GL_BUTTON_VALID,
    	            3*GL_TIME_SECOND);
    	 return 0;
    	 }
     // Activate the downloaded software
     GL_Dialog_Message(APEMV_UI_GoalHandle(), "App Update",
         	           "Installing the Application", GL_ICON_INFORMATION, GL_BUTTON_VALID,
         	            3*GL_TIME_SECOND);
     if(( hDisk != NULL ) && ( RAMDISK_Activate( hDisk ) == 0 ))
     {
    	 GL_Dialog_Message(APEMV_UI_GoalHandle(), "App Update",
    	          	           "Installed Successfully...", GL_ICON_INFORMATION, GL_BUTTON_VALID,
    	          	            3*GL_TIME_SECOND);
    	 // Success. OK.
    	return 1;
    	 }
     else     {
    	 // Activation error.
    	 //To complete...
    	 GL_Dialog_Message(APEMV_UI_GoalHandle(), "App Update",
    	     	          	           "Software Activation Error\n Restart Terminal", GL_ICON_INFORMATION, GL_BUTTON_VALID,
    	     	          	            2* GL_TIME_MINUTE);
    	 return 0;
    	 }
     memset(TmsftpPwd, 0, sizeof(TmsftpPwd));
 }

  // Functions.
  //-------------------------------------------------------------------

  int RAMDISK_WriteInFile( RAMDISK_HANDLE hDisk, void *hFile,
  						 const unsigned char *pucBuffer, unsigned int nSize )
  {
  	T__RAMDISK* pDisk = (T__RAMDISK*)hDisk;

  	char Temp[30];

  	if( ( pDisk != NULL ) && ( nSize <= pDisk->m_nSize ) )
  	{
  		unsigned int nBytes = FS_write(	(unsigned char *) pucBuffer,
  										1, nSize,
  										(S_FS_FILE*) hFile );

  		pDisk->m_nSize -= nBytes;

  		memset(Temp,0,sizeof(Temp));
  		sprintf(Temp,"nBytes %d",nBytes);
  		//prtS(Temp);


  		if( nBytes == nSize )
  		{
  			return 0;
  		}
  	}

  	return -1;
  }

  RAMDISK_HANDLE RAMDISK_Create( const char *szName, unsigned long nSize,
  							   unsigned int nMaxFile )
  {
      unsigned long nDiskSize = 0;
      S_FS_PARAM_CREATE  DiskParam;
  	T__RAMDISK* pDisk = NULL;

      // Create the disk.
      strcpy( DiskParam.Label, szName );

      DiskParam.Mode         = FS_WRITEMANY;
      DiskParam.IdentZone    = FS_WO_ZONE_APPLICATION;
      DiskParam.AccessMode   = FS_WRTMOD;
      DiskParam.NbFichierMax = nMaxFile;

      nDiskSize = FreeSpace() - (512 * 1024);

      if( nDiskSize > (4096 * 1024))
      {
          nDiskSize = 4096 * 1024;
      }

  	if( nDiskSize > nSize )
  	{
  		nDiskSize = nSize;
  	}
  	int dskRet = FS_dskcreate( &DiskParam, &nDiskSize );

      if( dskRet == FS_OK )
  	{

  		pDisk = (T__RAMDISK*)umalloc( sizeof(T__RAMDISK) );
  		if( pDisk != NULL )
  		{

  			strcpy( pDisk->m_szName, szName );

  			pDisk->m_nSize     = nDiskSize;
  			pDisk->m_bUnload   = 0;
  			pDisk->m_nFreeSize = nDiskSize - 512;	// !! VG : 512 bytes allocated
  													// for the resumption file.
  		}
  	}

  	return (RAMDISK_HANDLE)pDisk;
  }


  int RAMDISK_Delete( RAMDISK_HANDLE hDisk )
  {
  	T__RAMDISK* pDisk = (T__RAMDISK*)hDisk;

  	char szDisk[16];
  	int  nError = 0;

  	if( ( pDisk != NULL ) && ( pDisk->m_nSize != 0 ) )
  	{
  		// Add the starting '/'
  		sprintf( szDisk, "/%s", pDisk->m_szName );

  		// Unmount the disk
  		nError = FS_unmount( szDisk );
  		if( nError == FS_OK )
  		{
  			// Destroy the disk
  			nError = FS_dskkill( szDisk );
  			if( nError == FS_OK )
  			{
  				ufree( pDisk );
  				return 0; // Successful !!!
  			}
  		}
  	}

  	return (-1);
  }



  RAMDISK_FILE RAMDISK_OpenFile( RAMDISK_HANDLE hDisk, const char *szName, const char *szMode )
  {
      T__RAMDISK* pDisk = (T__RAMDISK*)hDisk;
  	S_FS_FILE*  hFile = NULL;

  	char szFullPath[64];

  	if( memcmp( szName, "./", strlen("./") ) == 0 )
  	{
  		// In case of file names beginning with "./", skip it !
  		szName += strlen( "./" );
  	}

  	if( pDisk != NULL )
  	{
  		if( strchr( pDisk->m_szName, '/') == NULL )
  		{
  			sprintf( szFullPath, "/%s/%s", pDisk->m_szName, szName );
  		}
  		else
  		{
  			sprintf( szFullPath, "%s/%s", pDisk->m_szName, szName );
  		}

  		hFile = FS_open((char*) szFullPath, (char*) szMode );
  		//prtS("szFullPath");
  		//prtS(szFullPath);
      }


      return hFile;
  }

  void RAMDISK_CloseFile( RAMDISK_HANDLE hDisk, RAMDISK_FILE hFile )
  {
      FS_close((S_FS_FILE*) hFile );
  }

  int RAMDISK_Activate( RAMDISK_HANDLE hDisk )
  {

  	T__RAMDISK* pDisk = (T__RAMDISK*)hDisk;
  	//prtS("RAMDISK_Activate");
  	int ret = NTP_SoftwareCheck(pDisk->m_szName);
  	if( pDisk != NULL )
  	{
  		ret = SoftwareActivate( pDisk->m_szName ) ;
  		if(ret == 0 )
  		{
  			//prtS("SOFTWARE ACTIVATED");
  			return 0;
  		}
  	}

  	return -1;
  }

  int FileDel()
  {
  	int ret;
  	char FPath[40];
  	memset(FPath,0,sizeof(FPath));
  	strcpy(FPath,"/TEMP/PAYMENTAPP.AGN");
  	//GenPath(FPath,FileName);
  	ret = FS_unlink(FPath);
  	return ret;
  }

  void CleanRamDisk(){
	FileDel();
  	RAMDISK_HANDLE hDisk = NULL;
  	hDisk = RAMDISK_Create( "TEMP", 4096*1024,1);
  	RAMDISK_Delete(hDisk);
  }
