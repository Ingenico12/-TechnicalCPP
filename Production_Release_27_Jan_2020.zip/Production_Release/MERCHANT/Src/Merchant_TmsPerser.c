#include <sdk_tplus.h>
#include <XMLs.h>
#include "MerchantData.h"
char TmsftpPwd[30]={0};
char tempfilepath[40]={0};
char tagName[50]={0};
int Count=0;
int merchant_cnt=1;
int clerkcnt=0;
int temsLoginFlag=0;
char mclerklist[10][12]={0};
static void __XmlStartElement( XMLs_PARSER hXml, const char* szName, XMLs_ATTRIBUTE_HANDLE hAttribute ){
	strcpy(tagName,szName);
}
static void __XmlEndElement( XMLs_PARSER hXml, const char* szName ){
	if(!strcmp(szName,"PosRegistrationModel"))
		++Count;
}
void ConfigFilehandleData( XMLs_PARSER hXml, const char* pcDataBuffer, unsigned int nDataLength )   {
	char* szData = XMLs_ProcessData( pcDataBuffer, nDataLength, XML_DATA_ALL );
	char buffer[100 +1]={0};
	char mGatewayURL[49 +1]={0};
	char gatewayPort [3 +1]={0};
	char buffer2size[1 +1]={0};
	char mTxnCurrencyCode[3 +1]={0};
	char mClerkID[6 +1]={0};
	char mIdleMessage[24 +1]={0};
	char managerpwd[4 +1]={0};
	char industryType[24 +1]={0};
	char mMaxTxnAmt[12 +1]={0};
	int length=0;
	if( szData != NULL ){
		strcpy(buffer,szData);
		length=strlen(buffer);
		if(!strcmp(tagName,"GATEWAY_URL")){
			memcpy (mGatewayURL,buffer, sizeof(mGatewayURL) -1);
			memset(&mGatewayURL[strlen(mGatewayURL)],' ', sizeof(mGatewayURL) -1 -strlen(mGatewayURL));
			saveAdminParameter("GATEWAY_URL",mGatewayURL);
		}
		else if(!strcmp(tagName,"CREDIT")){
			memset(buffer2size, 0, sizeof(buffer2size));
			memcpy (buffer2size, buffer, sizeof(buffer2size) -1);
			saveAdminParameter("CREDIT",buffer2size);
		}
		else if(!strcmp(tagName,"TXN_CURRENCY_CODE")){
			memcpy(mTxnCurrencyCode, buffer, sizeof(mTxnCurrencyCode) -1);
			memset(&mTxnCurrencyCode[strlen(mTxnCurrencyCode)], ' ', sizeof(mTxnCurrencyCode) -1 -strlen(mTxnCurrencyCode));
			saveAdminParameter("TXN_CURRENCY_CODE",mTxnCurrencyCode);
		}
		else if(!strcmp(tagName,"MANAGER_PASSWORD")){
			memcpy(managerpwd, buffer, sizeof(managerpwd) -1);
			memset(&managerpwd[strlen(managerpwd)], ' ', sizeof(managerpwd) -1 -strlen(managerpwd));
			saveAdminParameter("MANAGER_PASSWORD",managerpwd);
		}
		else if(!strcmp(tagName,"PARENT_NAME")){
			memcpy(industryType, buffer, sizeof(industryType) -1);
			memset(&industryType[strlen(industryType)], ' ', sizeof(industryType) -1 -strlen(industryType));
			saveAdminParameter("INDUSTRY_TYPE",industryType);
		}
		else if(!strcmp(tagName,"MAX_TXN_AMOUNT")){
			memcpy(mMaxTxnAmt, buffer, sizeof(mMaxTxnAmt) -1);
			memset(&mMaxTxnAmt[strlen(mMaxTxnAmt)], ' ', sizeof(mMaxTxnAmt) -1 -strlen(mMaxTxnAmt));
			saveAdminParameter("MAX_TXN_AMOUNT",mMaxTxnAmt);
		}
		else if(!strcmp(tagName,"CLERK_ID")){
			memcpy(mClerkID, buffer, sizeof(mClerkID) -1);
			memset(&mClerkID[strlen(mClerkID)], ' ', sizeof(mClerkID) -1 -strlen(mClerkID));
			saveAdminParameter("CLERK_ID",mClerkID);
		}
		else if(!strcmp(tagName,"IDLE_MESSAGE")){
			memcpy(mIdleMessage,buffer,sizeof(mIdleMessage) -1);
			memset(&mIdleMessage[strlen(mIdleMessage)], ' ', sizeof(mIdleMessage) -1 -strlen(mIdleMessage));
			saveAdminParameter("IDLE_MESSAGE",mIdleMessage);
		}
		else if(!strcmp(tagName,"DEBIT")){
			memset(buffer2size, 0, sizeof(buffer2size));
			memcpy (buffer2size, buffer, sizeof(buffer2size) -1);
			saveAdminParameter("DEBIT",buffer2size);
		}
		else if(!strcmp(tagName,"AUTH")){
			memset(buffer2size, 0, sizeof(buffer2size));
			memcpy (buffer2size, buffer, sizeof(buffer2size) -1);
			saveAdminParameter("AUTH",buffer2size);
		}
		else if(!strcmp(tagName,"PAPER_RECEIPT")){
			memset(buffer2size, 0, sizeof(buffer2size));
			memcpy (buffer2size, buffer, sizeof(buffer2size) -1);
			saveAdminParameter("PAPER_RECEIPT",buffer2size);
		}
		else if(!strcmp(tagName,"REFERENCE_FLAG")){
			memset(buffer2size, 0, sizeof(buffer2size));
			memcpy (buffer2size, buffer, sizeof(buffer2size) -1);
			saveAdminParameter("REFERENCE_FLAG",buffer2size);
		}
		else if(!strcmp(tagName,"GATEWAY_PORT")){
			memcpy (gatewayPort, buffer, sizeof(gatewayPort) -1);
			memcpy(&gatewayPort[strlen(gatewayPort)], " ", sizeof(gatewayPort) -1 - strlen(gatewayPort));
			saveAdminParameter("GATEWAY_PORT",gatewayPort);
		}
		else if(!strcmp(tagName,"GATEWAY_IP_ADDRESS")){
			char mGatewayIP[15 +1]={0};
			memcpy(mGatewayIP,buffer,sizeof(mGatewayIP) -1);
			memset(&mGatewayIP[strlen(mGatewayIP)], ' ', sizeof(mGatewayIP) -1 -strlen(mGatewayIP));
			saveAdminParameter("GATEWAY_IP_ADDRESS",mGatewayIP);
		}
		else if(!strcmp(tagName,"TXN_SEQUENCE_NUMBER")){
			char TxnSequenseNo[4+1]={0};
			memcpy(TxnSequenseNo,buffer,sizeof(TxnSequenseNo) -1);
			memset(&TxnSequenseNo[strlen(TxnSequenseNo)], ' ', sizeof(TxnSequenseNo) -strlen(TxnSequenseNo) -1);
			saveAdminParameter("TXN_SEQUENCE_NUMBER",TxnSequenseNo);
		}
		else if(!strcmp(tagName,"MAX_TXN_AMOUNT")){
			char mMaxTxnAmt[12 +1]={0};
			memcpy(mMaxTxnAmt,buffer,sizeof(mMaxTxnAmt) -1);
			memset(&mMaxTxnAmt[strlen(mMaxTxnAmt)], ' ', sizeof(mMaxTxnAmt) -1 -strlen(mMaxTxnAmt));
			saveAdminParameter("MAX_TXN_AMOUNT",mMaxTxnAmt);
		}
		else if(!strcmp(tagName,"errorMessage")){
			GL_Dialog_Message(APEMV_UI_GoalHandle(), "ERROR", buffer,NULL, GL_BUTTON_ALL, 3*GL_TIME_SECOND);
			setErrorCode("ERROR:PRELOADER");
		}
		else if(!strcmp(tagName,"message")){
			GL_Dialog_Message(APEMV_UI_GoalHandle(), "STATUS", buffer,NULL, GL_BUTTON_ALL, 3*GL_TIME_SECOND);
		}
	}
}
void clerkTransummaryData(XMLs_PARSER hXml, const char* pcDataBuffer, unsigned int nDataLength ){
	char* szData = XMLs_ProcessData( pcDataBuffer, nDataLength, XML_DATA_ALL );
	char buffer[50 +1]={0};
	int incr=0;
	if( szData != NULL){
     strcpy(buffer, szData);
     if(!strcmp(tagName, "userId")){
    	 memcpy(&mclerklist[clerkcnt][0], buffer, strlen(buffer) );
         clerkcnt++;
     }
     else if(!strcmp(tagName,"errorMessage")){
		GL_Dialog_Message(APEMV_UI_GoalHandle(), "ERROR", buffer,NULL, GL_BUTTON_ALL, 3*GL_TIME_SECOND);
		setErrorCode("ERROR:PRELOADER");
	}
	else if(!strcmp(tagName,"message")){
		GL_Dialog_Message(APEMV_UI_GoalHandle(), "STATUS", buffer,NULL, GL_BUTTON_ALL, 3*GL_TIME_SECOND);
		}
	}
}
void handleFtphandleData( XMLs_PARSER hXml, const char* pcDataBuffer, unsigned int nDataLength )   {
	char* szData = XMLs_ProcessData( pcDataBuffer, nDataLength, XML_DATA_ALL );
	char buffer[50 +1]={0};
	char mTMS_APIKey		[48 +1]={0};
	char mTMSIp				[15 +1]={0};
	char mTMSPort			[4 +1]={0};
	char mTMSURL			[49 +1]={0};
	char mTMSFTPPWD			[24 +1]={0};
	char mTMSUserName		[20 +1]={0};
	char mTMSFileVer        [20 +1]={0};
	char mTMSFilePath       [40 +1]={0};
	char mTMSFileType       [2]={0};
	char mTMSTerminalID     [20 +1]={0};
	int length=0;
	if( szData != NULL ){
		strcpy(buffer,szData);
		length=strlen(buffer);
		if(!strcmp(tagName,"ftpUrl")){
			memcpy (mTMSURL,buffer, length);
			memset(&mTMSURL[strlen(mTMSURL)],' ', sizeof(mTMSURL)- 1-strlen(mTMSURL));
			saveAdminParameter("TMS_URL",mTMSURL);
		}
		else if(!strcmp(tagName,"ftpPort")){
			memcpy (mTMSPort, buffer, length);
			memset (&mTMSPort[strlen(mTMSPort)], ' ', sizeof (mTMSPort) -1 -strlen(mTMSPort));
			saveAdminParameter("TMS_PORT",mTMSPort);
		}
		else if(!strcmp(tagName,"ftpUserName")){
			memcpy(mTMSUserName, buffer, length);
			memset(&mTMSUserName[strlen(mTMSUserName)], ' ', sizeof(mTMSUserName) -1 -strlen(mTMSUserName));
			saveAdminParameter("TMSFTPUSER_NAME",mTMSUserName);
		}
		else if(!strcmp(tagName,"ftpPassword")){
			memcpy(TmsftpPwd,buffer, strlen(buffer) );
		}
		else if(!strcmp(tagName,"fileType")){
		    mTMSFileType[0]=buffer[0];
			//memset(&mTMSFileType[strlen(mTMSFileType)], ' ', sizeof(mTMSFileType) -strlen(mTMSFileType));
			saveAdminParameter("TMSFILE_TYPE",mTMSFileType);
		}
		else if(!strcmp(tagName,"fileVersion")){
			memcpy(mTMSFileVer,buffer,length);
			memset(&mTMSFileVer[strlen(mTMSFileVer)], ' ', sizeof(mTMSFileVer) -1 -strlen(mTMSFileVer));
			saveAdminParameter("TMSFILE_VERSION",mTMSFileVer);
			saveAdminParameter("SOFTWARE_VERSION",mTMSFileVer);
		}
		else if(!strcmp(tagName,"apiKey")){
			memcpy(mTMS_APIKey,buffer,length);
			memset(&mTMS_APIKey[strlen(mTMS_APIKey)], ' ', sizeof(mTMS_APIKey) -1 -strlen(mTMS_APIKey));
			saveAdminParameter("TMS_API_KEY",mTMS_APIKey);
		}
		else if(!strcmp(tagName,"filePath")){
			memcpy(mTMSFilePath, buffer, length);
			memcpy(tempfilepath, buffer, length);
			memset(&mTMSFilePath[strlen(mTMSFilePath)], ' ', sizeof(mTMSFilePath) -1 -strlen(mTMSFileVer));
			saveAdminParameter("TMSFILE_PATH",mTMSFilePath);
		}

		else if(!strcmp(tagName,"errorMessage")){
			GL_Dialog_Message(APEMV_UI_GoalHandle(), "ERROR", buffer, NULL, GL_BUTTON_ALL, 3*GL_TIME_SECOND);
			setErrorCode("ERROR:PRELOADER");
		}
		else if(!strcmp(tagName,"message")){
			GL_Dialog_Message(APEMV_UI_GoalHandle(), "STATUS", buffer,NULL, GL_BUTTON_ALL, 3*GL_TIME_SECOND);
		}
		else if(!strcmp(tagName, "status")){
			if(atoi(buffer))
				temsLoginFlag=1;
			else
				temsLoginFlag=0;
		}
		else if(!strcmp(tagName, "terminalId")){
			memcpy(mTMSTerminalID, buffer, length);
			memset(&mTMSTerminalID[strlen(mTMSTerminalID)], ' ',sizeof(mTMSTerminalID) -1 -strlen(mTMSTerminalID) );
			saveAdminParameter("TMSTERMINAL_ID",mTMSTerminalID);
			saveAdminParameter("TERMINAL_ID",mTMSTerminalID);
		}
	}
}

void MerchanthandleData( XMLs_PARSER hXml, const char* pcDataBuffer, unsigned int nDataLength )   {
	char* szData = XMLs_ProcessData( pcDataBuffer, nDataLength, XML_DATA_ALL );
	char buffer[80 +1]={0};
	char merchant_name[80]={0};
	char department_name[80]={0};
	char api_name[80]={0};
	char merchant_id[MERCHANT_ID_LEN +1]={0};
	char hdepartment_name[DEPARTMENT_NAME_LEN +1]={0};
	char mMerchantAddres	[24 +1]={0};
	char mMerchantCity		[24 +1]={0};
	char mMerchantState		[24 +1]={0};
	char mMerchantZip		[10 +1]={0};
	char mMerchantPhone		[20 +1]={0};
	char mMerchantStore		[4]={0};
	char mMerchantBankID	[6]={0};
	char mMerchantChainNo	[6]={0};
	char mMerchantAgentNo	[6]={0};
	char mMerchantABANo		[10]={0};
	char mMerchantReimburse [2]={0};
	char mMerchantSettleAgent[4]={0};
	char mMerchantDebitSharing[2]={0};
	char api_key[APIKEY_LEN +1]={0};
	char tempbuff[50 +1]={0};
	int length=0;
	char dep_cnt[2]={0};
	if( szData != NULL ){
		strcpy(buffer,szData);
		length=strlen(buffer);
		if(!strcmp(tagName,"department")){
			sprintf(department_name, "DEPARTMENT_%d", merchant_cnt);
			if(length !=0){
			memcpy (hdepartment_name,buffer, sizeof(hdepartment_name) -1);
			memset(&hdepartment_name[strlen(hdepartment_name)],' ', sizeof(hdepartment_name) -1 -strlen(hdepartment_name));
			saveAdminParameter(department_name,hdepartment_name);
			}
		}
		else if(!strcmp(tagName,"merchantId")){
			sprintf(merchant_name, "MERCHANT_ID_%d", merchant_cnt);
			if(length!=0){
			memcpy (merchant_id,buffer, sizeof(merchant_id)-1);
			memset(&merchant_id[strlen(merchant_id)],' ', sizeof(merchant_id)-1 - strlen(merchant_id));
			saveAdminParameter(merchant_name,merchant_id);
			}
		}
		else if(!strcmp(tagName, "merchantAddress")){
			sprintf(tempbuff, "MERCHANT_ADDRESS_%d", merchant_cnt);
			if(length !=0){
				memcpy(mMerchantAddres, buffer, sizeof(mMerchantAddres) -1);
				memset(&mMerchantAddres[strlen(mMerchantAddres)], ' ', sizeof(mMerchantAddres) -1 -strlen(mMerchantAddres));
				saveAdminParameter(tempbuff,mMerchantAddres);
			}
		}
		else if(!strcmp(tagName, "merchantCity")){
			sprintf(tempbuff, "MERCHANT_CITY_%d",merchant_cnt);
			if(length !=0){
				memcpy(mMerchantCity, buffer, sizeof(mMerchantCity) -1);
				memset(&mMerchantCity[strlen(mMerchantCity)], ' ', sizeof(mMerchantCity) -1 - strlen(mMerchantCity));
				saveAdminParameter(tempbuff, mMerchantCity);
			}
		}
		else if(!strcmp(tagName, "merchantState")){
			sprintf(tempbuff, "MERCHANT_STATE_%d",merchant_cnt);
			if(length !=0){
				memcpy(mMerchantState, buffer, sizeof(mMerchantState) -1);
				memset(&mMerchantState[strlen(mMerchantState)], ' ', sizeof(mMerchantState) -1 - strlen(mMerchantState));
				saveAdminParameter(tempbuff, mMerchantState);
			}
		}
		else if(!strcmp(tagName,"merchantZip")){
			sprintf(tempbuff, "MERCHANT_ZIP_%d", merchant_cnt);
			if(length !=0){
				memcpy(mMerchantZip, buffer, sizeof(mMerchantZip) -1);
				memset(&mMerchantZip[strlen(mMerchantZip)], ' ', sizeof(mMerchantZip) -1 - strlen(mMerchantZip));
				saveAdminParameter(tempbuff, mMerchantZip);
			}
		}
		else if(!strcmp(tagName,"merchantPhone")){
			sprintf(tempbuff, "MERCHANT_PHONE_%d", merchant_cnt);
			if(length !=0){
				memcpy(mMerchantPhone, buffer, sizeof(mMerchantPhone) -1);
				memset(&mMerchantPhone[strlen(mMerchantPhone)], ' ', sizeof(mMerchantPhone) -1 - strlen(mMerchantPhone));
				saveAdminParameter(tempbuff, mMerchantPhone);
			}
			++merchant_cnt;
		}
		else if(!strcmp(tagName,"gatewayApiKey")){
			sprintf(api_name, "GATEWAY_API_KEY_%d", merchant_cnt);
			if(length!=0){
			memcpy (api_key,buffer, length);
			memset(&api_key[strlen(api_key)],' ', sizeof(api_key) -1 - strlen(api_key));
			saveAdminParameter(api_name,api_key);
			}
		}
		else if(!strcmp(tagName,"count")){
			 strcpy(dep_cnt,buffer);
			saveAdminParameter("DEPARTMENT_COUNT",dep_cnt);
		}
		else if(!strcmp(tagName,"errorMessage")){
			GL_Dialog_Message(APEMV_UI_GoalHandle(), "ERROR", buffer, NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
			setErrorCode("ERROR:PRELOADER");
		}
		else if(!strcmp(tagName,"message")){
		GL_Dialog_Message(APEMV_UI_GoalHandle(), "STATUS", buffer,NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
		}
	}
	}

void ClerkResponseParser (const char* xmlData){
	XMLs_PARSER hXml;
	int nStartTags = 0;
	int nReturn;
	clerkcnt=0;
	hXml = XMLs_Create();
	if( hXml != NULL ) {
		XMLs_SetOption( hXml, XMLs_START_ELEMENT_HANDLER, __XmlStartElement );
		XMLs_SetOption( hXml, XMLs_END_ELEMENT_HANDLER, __XmlEndElement );
		XMLs_SetOption( hXml, XMLs_DATA_HANDLER, clerkTransummaryData);
		XMLs_SetUserData( hXml, &nStartTags );
		nReturn = XMLs_ParseBuffer( hXml, xmlData, strlen(xmlData) );
		if( nReturn != XMLS_OK )
		   {
			   setErrorCode("ERROR:032");
			   return FALSE;
		   }
	   XMLs_Destroy( hXml );
	}
	return;
}

void ftpResponseParser (const char* xmlData){
	XMLs_PARSER hXml;
	int nStartTags = 0;
	int nReturn;
	hXml = XMLs_Create();
	if( hXml != NULL ) {
		XMLs_SetOption( hXml, XMLs_START_ELEMENT_HANDLER, __XmlStartElement );
		XMLs_SetOption( hXml, XMLs_END_ELEMENT_HANDLER, __XmlEndElement );
		XMLs_SetOption( hXml, XMLs_DATA_HANDLER, handleFtphandleData);
		XMLs_SetUserData( hXml, &nStartTags );
		nReturn = XMLs_ParseBuffer( hXml, xmlData, strlen(xmlData) );
		if( nReturn != XMLS_OK )
		   {
			   setErrorCode("ERROR:032");
			   return FALSE;
		   }
	   XMLs_Destroy( hXml );
	}
	return;
}

void MerchantResponseParser (const char* xmlData){
	XMLs_PARSER hXml;
	int nStartTags = 0;
	merchant_cnt=1;
	int nReturn;
	hXml = XMLs_Create();
	if( hXml != NULL ) {
		XMLs_SetOption( hXml, XMLs_START_ELEMENT_HANDLER, __XmlStartElement );
		XMLs_SetOption( hXml, XMLs_END_ELEMENT_HANDLER, __XmlEndElement );
		XMLs_SetOption( hXml, XMLs_DATA_HANDLER, MerchanthandleData);
		XMLs_SetUserData( hXml, &nStartTags );
		nReturn = XMLs_ParseBuffer( hXml, xmlData, strlen(xmlData) );
		if( nReturn != XMLS_OK )
		   {
			   setErrorCode("ERROR:032");
			   return FALSE;
		   }
	   XMLs_Destroy( hXml );
	}
	return;
}

void ConfigFileParser(const char* xmlData){
	XMLs_PARSER hXml;
	int nStartTags = 0;
	int nReturn;
	hXml = XMLs_Create();
	if( hXml != NULL ) {
		XMLs_SetOption( hXml, XMLs_START_ELEMENT_HANDLER, __XmlStartElement );
		XMLs_SetOption( hXml, XMLs_END_ELEMENT_HANDLER, __XmlEndElement );
		XMLs_SetOption( hXml, XMLs_DATA_HANDLER, ConfigFilehandleData);
		XMLs_SetUserData( hXml, &nStartTags );
		nReturn = XMLs_ParseBuffer( hXml, xmlData, strlen(xmlData) );
		if( nReturn != XMLS_OK )
		   {
			   setErrorCode("ERROR:032");
			   return FALSE;
		   }
	   XMLs_Destroy( hXml );
	}
	merchant_cnt=1;
	return;
}
int hostcall(char *requestbuf, char *responsebuf, int flag){
	if(flag==2)
		GL_Dialog_Message(APEMV_UI_GoalHandle(), "PROCESS", "Sending Response to TMS...",NULL, GL_BUTTON_ALL, 2*GL_TIME_SECOND);
	else if(flag ==4)
		GL_Dialog_Message(APEMV_UI_GoalHandle(), "USER", "Validating...",NULL, GL_BUTTON_ALL, 2*GL_TIME_SECOND);
	else
		GL_Dialog_Message(APEMV_UI_GoalHandle(), "PROCESS", "Please Wait...",NULL, GL_BUTTON_ALL, 2*GL_TIME_SECOND);
	int ret= hostServiceCall(requestbuf,responsebuf,1);
	if(ret==COMERROR) {
		setErrorCode("ERROR:026");
		return FALSE;
	}
	if(ret==SERVERDOWN) {
		setErrorCode("ERROR:026");
		return FALSE;
	}
	if(ret==HOSTERROR){
		setErrorCode("ERROR:027");
		return FALSE;
	}
		if(ret==RESPTIMEOUT){
			setErrorCode("ERROR:028");
			return FALSE;
		}
		char buffer[4000]= {0};
		char *xmlbody=strstr(responsebuf,"<");
		strcpy(buffer, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
		strcat(buffer,xmlbody);
		if(flag==1)
			MerchantResponseParser(buffer);
		else if(flag == 3)
			ConfigFileParser(buffer);
		else if(flag == 5)
			ClerkResponseParser(buffer);
		else
			ftpResponseParser(buffer);
		return TRUE;
}
