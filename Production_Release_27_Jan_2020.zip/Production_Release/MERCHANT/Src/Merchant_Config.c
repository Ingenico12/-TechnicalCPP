#include <sdk_tplus.h>
#include "GL_Types.h"
#include "MerchantData.h"
#include "Transaction.h"


static struct sConfigParam appConfig;
struct sConfigParam * pAppConfig = &appConfig;

int saveAdminParameter(char * paramName, char * paramData){
	T_GL_HFILE mFile;
	mFile = GL_File_Open("file://flash/HOST/app.conf",GL_FILE_OPEN_EXISTING,GL_FILE_ACCESS_READ_WRITE);

	if(mFile==NULL)
		return FALSE;

	int fileLength = GL_File_GetSize(mFile);
	char * data = (char *) calloc(1, fileLength*sizeof(char));
	struct sConfigTable appConfTab[] = {APPCONFTABLE};
	int paramDataLength = 0;
	int paramNameLength = 0;

	if (GL_File_Read (mFile,data,fileLength) != 0) {
		int x, y = 0, z = 0;

		int length = sizeof(appConfTab)/sizeof (appConfTab[0]);
		for (x = 0; x < length; x++) {
			if (!strcmp(appConfTab[x].mParamName, paramName)){
				paramDataLength = appConfTab[x].mParamLength;
				paramNameLength = strlen(appConfTab[x].mParamName);
				x = length;
			}
			else {
				y = y + strlen(appConfTab[x].mParamName) + sizeof(int);
			}
		}
		y = 0;
		for (x = 0; x < length; x++){
			if (!memcmp(data + y, paramName, paramNameLength)){
				y = y + paramNameLength + strlen("=");
				memcpy (data + y, paramData, paramDataLength);
                if (memcmp (data + y + paramDataLength, "\n",1)){
                	memcpy (data + y + paramDataLength, "\n",1);
                }
                x = length;
			}
			else {
				char * token = (char *) calloc(1, 80*sizeof(char));
				char * temp = data + y;
				memcpy (token, temp, 80);
				token = strtok (token, "\n");
				y = y + strlen(token) + strlen ("\n");
				free (token);
			}
		}
	}
	else {
		free (data);
		GL_File_Close(mFile);
		return FALSE;
	}
	if (GL_File_Seek(mFile,0,GL_FILE_SEEK_BEGIN) == GL_SUCCESS) {
		if (GL_File_Write (mFile,data,fileLength) == 0){
			GL_File_Close(mFile);
			return FALSE;
		}
	}
	else {
		free (data);
		GL_File_Close(mFile);
		return FALSE;
	}
	free (data);
	GL_File_Close(mFile);
	return TRUE;
}
int restoreAdminParameters(){
	T_GL_HFILE mFile;
	mFile = GL_File_Open("file://flash/HOST/app.conf",GL_FILE_OPEN_EXISTING, GL_FILE_ACCESS_READ_WRITE);

	if(mFile==NULL)
		return FALSE;

	int length = GL_File_GetSize(mFile);
	char * data = (char *) calloc(1, length*sizeof(char));
	struct sConfigTable appConfTab[] = {APPCONFTABLE};

	if (GL_File_Read (mFile,data,length) != 0){
		int x, y = 0, z = 0;
		length = sizeof(appConfTab)/sizeof (appConfTab[0]);
		for (x=0; x < length; x++) {
			if (!memcmp(data + y, appConfTab[x].mParamName, strlen(appConfTab[x].mParamName))){
				y = y + strlen(appConfTab[x].mParamName) + strlen("=");
				char * token = data + y;
				token = strtok (token, "\n");
				int tLen = appConfTab[x].mParamLength <= strlen(token) ? appConfTab[x].mParamLength : strlen(token);
				memcpy ((void *) &appConfig + z, token, tLen);
				z = z + appConfTab[x].mParamLength;
				y = y + strlen(token) + strlen ("\n");
			}
		}
	}
	else {
		free (data);
		GL_File_Close(mFile);
		return FALSE;
	}
	free (data);
	GL_File_Close(mFile);
	return TRUE;
}

int fetch_appconfig_data(char * paramName, char * paramData){
       T_GL_HFILE mFile;
       char *token;
       int len;
              mFile = GL_File_Open("file://flash/HOST/app.conf",GL_FILE_OPEN_EXISTING, GL_FILE_ACCESS_READ_WRITE);
              if(mFile==NULL)
                     return FALSE;
              len = GL_File_GetSize(mFile);
              char *buffer = (char *) calloc(1, len*sizeof(char));
              if(GL_File_Read (mFile,buffer,len) != 0){
                     token=strtok(buffer,"\n");
                     while(token !=NULL)
                     {
                     if(strstr(token,paramName))
                     {
                           len=strlen(paramName) +1;
						   strcpy(paramData, token + len);
                           break;
                     }
                     token=strtok(NULL, "\n");
                     }
              }
              GL_File_Close(mFile);
              free(buffer);
              return TRUE;
   }


void setUserDataParameters(){
	char *token=NULL;
	char terminalID[13]={0};
	char merchantID[13]={0};
	char apiKey[50]={0};
	char sequenceNo[5]={0};
	char currencyCode[4]={0};
	char receiptFlag[2]={0};

	getTerminalID(terminalID);
	token = strtok(terminalID," ");
	if(token!=NULL)
		setUserTerminalID(token);

	getMerchantID(merchantID);
	token = strtok(merchantID," ");
	if(token!=NULL)
		setUserMerchantID(token);

	getGatewayAPIKey(apiKey);
	token = strtok(apiKey," ");
	if(token!=NULL)
		setUserAPIKey(token);

	getTxnSequenceNo(sequenceNo);
	token = strtok(sequenceNo," ");
	if(token!=NULL)
		setUserTxnSequnceNo(token);

	getTxnCurrencyCode(currencyCode);
	token = strtok(currencyCode," ");
	if(token!=NULL)
		setUserCurrencyCode(token);

	getReceiptFlag(receiptFlag);
	setUserReceiptFlag(atoi(receiptFlag));
	return;
}

int getTerminalID(char *terminalID){
	memcpy(terminalID,pAppConfig->mTermID,sizeof(pAppConfig->mTermID));
	return TRUE;
}
int getTerminalMngmtId(char *mngmntID){
	memcpy(mngmntID,pAppConfig->mTermMngmtID,sizeof(pAppConfig->mTermMngmtID));
	return TRUE;
}
int getMCC(char *mcCode){
	memcpy(mcCode,pAppConfig->mMerchCategoryCode,sizeof(pAppConfig->mMerchCategoryCode));
	return TRUE;
}

int getMerchantID(char *merchantID){
	memcpy(merchantID,pAppConfig->mMercID,sizeof(pAppConfig->mMercID));
	return TRUE;
}
int getIndustrytype(char *IndustryName){
	memcpy(IndustryName,pAppConfig->mIndustryType,sizeof(pAppConfig->mIndustryType));
	return TRUE;
}
int getMerchantName(char *merchantName){
	memcpy(merchantName,pAppConfig->mMerchantName,sizeof(pAppConfig->mMerchantName));
	return TRUE;
}
int getMerchantAddressList(char mMerchantAddres[DEPARTMENT_COUNT][MERCHANT_API_LEN +1]){
	//memcpy(merchantAddress,pAppConfig->mMerchantAddres,sizeof(pAppConfig->mMerchantAddres));
	int i=0;
	for(i=DEPARTMENT_COUNT-1;i>=0;i--){
		memcpy(&mMerchantAddres[i][0],&(pAppConfig->mMerchantAddres[i][0]),MERCHANT_API_LEN);
	}
	return TRUE;

}
int getMerchantCityList(char mMerchantCity[DEPARTMENT_COUNT][MERCHANT_API_LEN +1]){
	//memcpy(merchantCity,pAppConfig->mMerchantCity,sizeof(pAppConfig->mMerchantCity));
	int i=0;
	for(i=DEPARTMENT_COUNT-1;i>=0;i--){
		memcpy(&mMerchantCity[i][0],&(pAppConfig->mMerchantCity[i][0]),MERCHANT_API_LEN);
	}
	return TRUE;
}
int getMerchantStateList(char mMerchantState[DEPARTMENT_COUNT][MERCHANT_API_LEN +1]){
	//memcpy(merchantState,pAppConfig->mMerchantState,sizeof(pAppConfig->mMerchantState));
	int i=0;
	for(i=DEPARTMENT_COUNT-1;i>=0;i--){
		memcpy(&mMerchantState[i][0],&(pAppConfig->mMerchantState[i][0]),MERCHANT_API_LEN);
	}
	return TRUE;
}
int getMerchantZIPList(char mMerchantZip[DEPARTMENT_COUNT][MERCHANT_ZIP_LEN +1]){
	//memcpy(merchantZip,pAppConfig->mMerchantZip,sizeof(pAppConfig->mMerchantZip));
	int i=0;
	for(i=DEPARTMENT_COUNT-1;i>=0;i--){
		memcpy(&mMerchantZip[i][0],&(pAppConfig->mMerchantZip[i][0]),MERCHANT_ZIP_LEN);
	}
	return TRUE;
}
int getMerchantPhoneList(char mMerchantPhone[DEPARTMENT_COUNT][MERCHANT_PHONE_LEN +1]){
	//memcpy(merchantPhone,pAppConfig->mMerchantPhone,sizeof(pAppConfig->mMerchantPhone));
	int i=0;
	for(i=DEPARTMENT_COUNT-1;i>=0;i--){
		memcpy(&mMerchantPhone[i][0],&(pAppConfig->mMerchantPhone[i][0]),MERCHANT_PHONE_LEN);
	}
	return TRUE;
}
int getMerchantStoreNo(char *merchantStoreNo){
	memcpy(merchantStoreNo,pAppConfig->mMerchantStore,sizeof(pAppConfig->mMerchantStore));
	return TRUE;
}
int getMerchantBankID(char *merchantBankId){
	memcpy(merchantBankId,pAppConfig->mMerchantBankID,sizeof(pAppConfig->mMerchantBankID));
	return TRUE;
}
int getMerchantAgentNo(char *merchantAgentNo){
	memcpy(merchantAgentNo,pAppConfig->mMerchantAgentNo,sizeof(pAppConfig->mMerchantAgentNo));
	return TRUE;

}
int getMerchantChainNo(char *merchantChainNo){
	memcpy(merchantChainNo,pAppConfig->mMerchantChainNo,sizeof(pAppConfig->mMerchantChainNo));
	return TRUE;

}
int getMerchantABANo(char *MerchantABANo){
	memcpy(MerchantABANo,pAppConfig->mMerchantABANo,sizeof(pAppConfig->mMerchantABANo));
	return TRUE;

}
int getMerchantReimburseAttr(char *MerchantReimburseAttr){
	memcpy(MerchantReimburseAttr,pAppConfig->mMerchantReimburse,sizeof(pAppConfig->mMerchantReimburse));
	return TRUE;

}
int getMerchantSettleAgent(char *MerchantSettleAgent){
	memcpy(MerchantSettleAgent,pAppConfig->mMerchantSettleAgent,sizeof(pAppConfig->mMerchantSettleAgent));
	return TRUE;

}
int getMerchantDebitSharingGroup(char *debitSharingGroup){
	memcpy(debitSharingGroup,pAppConfig->mMerchantDebitSharing,sizeof(pAppConfig->mMerchantDebitSharing));
	return TRUE;

}
int setGatewayTDesKey(char *gatewayTDESKey){
	memcpy(pAppConfig->mGatewayTDesKey,gatewayTDESKey,sizeof(pAppConfig->mGatewayTDesKey));
	return TRUE;

}
int setGatewayTDesKCV(char *gatewayTDESKcv){
	memcpy(pAppConfig->mGatewayTDesKCV,gatewayTDESKcv,sizeof(pAppConfig->mGatewayTDesKCV));
	return TRUE;

}
int getGatewayTDesKey(char *gatewayTDESKey){
	memcpy(gatewayTDESKey,pAppConfig->mGatewayTDesKey,sizeof(pAppConfig->mGatewayTDesKey));
	return TRUE;

}
int getGatewayTDesKCV(char *gatewayTDESKcv){
	memcpy(gatewayTDESKcv,pAppConfig->mGatewayTDesKCV,sizeof(pAppConfig->mGatewayTDesKCV));
	return TRUE;

}
int getGatewayAPIKey(char *gatewayAPIKey){
	memcpy(gatewayAPIKey,pAppConfig->mGatewayAPIKey,sizeof(pAppConfig->mGatewayAPIKey));
	return TRUE;

}
int getGatewayIP(char *gatewayIP){
	memcpy(gatewayIP,pAppConfig->mGatewayIP,sizeof(pAppConfig->mGatewayIP));
	return TRUE;

}
int getGatewayPort(char *gatewayPort){
	memcpy(gatewayPort,pAppConfig->mGatewayPort,sizeof(pAppConfig->mGatewayPort));
	return TRUE;

}
int getGatewayURL(char *gatewayURL){
	char tempbuffer[49+1]={0};
	char url[49+1]={0};
	memcpy(tempbuffer,pAppConfig->mGatewayURL,sizeof(pAppConfig->mGatewayURL));
	trimTrailing(tempbuffer,url);
	memcpy(gatewayURL,url,strlen(url));
	return TRUE;
}
int getGatewayCGI(char *gatewayCGI){
	memcpy(gatewayCGI,pAppConfig->mGatewayCGI,sizeof(pAppConfig->mGatewayCGI));
	return TRUE;

}
int getTMSAPIKey(char *tmsApiKey){
	memcpy(tmsApiKey,pAppConfig->mTMS_APIKey,sizeof(pAppConfig->mTMS_APIKey));
	return TRUE;
}
int getTMSUserName(char *userID){
	memcpy(userID,pAppConfig->mTMSUserName,sizeof(pAppConfig->mTMSUserName));
	return TRUE;
}
int getTMSIP(char *TMSIp){
	memcpy(TMSIp,pAppConfig->mTMSIp,sizeof(pAppConfig->mTMSIp));
	return TRUE;

}
int getTMSPort(char *TMSPort){
	memcpy(TMSPort,pAppConfig->mTMSPort,sizeof(pAppConfig->mTMSPort));
	return TRUE;

}
int getTMSURL(char *TMS_URL){
	char tempbuffer[49+1]={0};
	char url[49+1]={0};
	memcpy(tempbuffer,pAppConfig->mTMSURL,sizeof(pAppConfig->mTMSURL));
	trimTrailing(tempbuffer,url);
	memcpy(TMS_URL,url,strlen(url));
	return TRUE;

}
int getTMSFtpPwd(char *TMS_CGI){
	memcpy(TMS_CGI,pAppConfig->mTMSFTPPWD,sizeof(pAppConfig->mTMSFTPPWD));
	return TRUE;

}
int getTMSTerminalID(char *terminalid){
    memcpy(terminalid, pAppConfig->mTMSTerminalID, sizeof(pAppConfig->mTMSTerminalID));
    return TRUE;
}
int getFileType(char *filetype){
	*filetype=pAppConfig->mTMSFileType;
	return TRUE;
}
int getFilePath(char *filepath){
	memcpy(filepath, pAppConfig->mTMSFilePath, sizeof(pAppConfig->mTMSFilePath) );
	return TRUE;
}
int getFileVersion(char *fileversion){
	memcpy(fileversion, pAppConfig->mTMSFileVer, sizeof(pAppConfig->mTMSFileVer));
	return TRUE;
}
char* getManagerPassword(void){
	return pAppConfig->mManagerPassWord;
}
void isDisplyMsgFlagEnable(char *displayMsgFlg){
	*displayMsgFlg=pAppConfig->mDisplayMsgFlag;
}
void isLogout(char *logOutFlg){
	*logOutFlg=pAppConfig->mlogoutFlag;
}
void isCreditSupported(char *creditFlg){
	*creditFlg=pAppConfig->mCreditFlag;
}
void isDebitSupported(char *debitFlg){
	*debitFlg=pAppConfig->mDebitFlag;
}
void isEBTSupported(char *ebtFlg){
	*ebtFlg=pAppConfig->mEBTFlag;
}
void isAuthOnlySupported(char *authOnlyFlag){
	*authOnlyFlag=pAppConfig->mAuthOnlyFlg;
}
void isRefundSupported(char *refundFlag){
	*refundFlag=pAppConfig->mRefundFlg;
}
void isVoidSupported(char *voidFlag){
	*voidFlag=pAppConfig->mVoidFlg;
}
void isBillPmtSupported(char *billPmtFlag){
	*billPmtFlag=pAppConfig->mBillPaymentFlg;
}
void isBalanceEnqSupported(char *balEnqFlag){
	*balEnqFlag=pAppConfig->mBalanceEnqFlg;
}
void isCardAuthSupported(char *cardAuthFlag){
	*cardAuthFlag=pAppConfig->mCardAuthFlg;
}
void isManBatchSupported(char *manBatchFlag){
	*manBatchFlag=pAppConfig->mManualBatchFlg;
}
void isAutoBatchSupported(char *autoBatchFlag){
	*autoBatchFlag=pAppConfig->mAutoBatchSupport;
}
void isFeeSupported(char *feeFlag){
	*feeFlag=pAppConfig->mSplitPmtFlg;
	//memcpy(feeFlag,pAppConfig->mFeeSupport,sizeof(pAppConfig->mFeeSupport));
	return;
}
void getComType(char *comType){
	*comType=pAppConfig->mGatewayComType;
	//memcpy(feeFlag,pAppConfig->mFeeSupport,sizeof(pAppConfig->mFeeSupport));
	return;
}
int getEmailSupportFlag(char *emailFlag){
	*emailFlag=pAppConfig->mEmailFlag;
	return;
}
int getEmailTxnReceiptFlag(char *emailReceiptFlag){
	*emailReceiptFlag=pAppConfig->mEmailTxnReceipt;
	return;
}
int getEmailMerchReportFlag(char *emailReportFlag){
	*emailReportFlag=pAppConfig->mEmailMerchReport;
	return;
}
int getSmtpUrl(char *smtpUrl){
	memcpy(smtpUrl,pAppConfig->mEmailSmtpURL,sizeof(pAppConfig->mEmailSmtpURL));
	return TRUE;
}
int getSmtpIP(char *smtpIP){
	memcpy(smtpIP,pAppConfig->mEmailSmtpIP,sizeof(pAppConfig->mEmailSmtpIP));
	return TRUE;
}
int getSmtpPort(char *smtpPort){
	memcpy(smtpPort,pAppConfig->mEmailSmtpPort,sizeof(pAppConfig->mEmailSmtpPort));
	return TRUE;
}
int getSmtpClient(char *smtpClient){
	memcpy(smtpClient,pAppConfig->mEmailClientID,sizeof(pAppConfig->mEmailClientID));
	return TRUE;
}
int getEmailSenderID(char *senderID){
	memcpy(senderID,pAppConfig->mEmailSenderID,sizeof(pAppConfig->mEmailSenderID));
	return TRUE;
}
int getEmailSenderPwd(char *senderPwd){
	memcpy(senderPwd,pAppConfig->mEmailSenderPWD,sizeof(pAppConfig->mEmailSenderPWD));
	return TRUE;
}
int getEmailReportReciptID(char *receiptID){
	memcpy(receiptID,pAppConfig->mEmailRecieveID,sizeof(pAppConfig->mEmailRecieveID));
	return TRUE;
}
void isManualKeySupported(char *manKeyFlag){
	*manKeyFlag=pAppConfig->mManualKeyFlg;
}
void isSwipeSupported(char *swipeFlag){
	*swipeFlag=pAppConfig->mSwipeFlag;
}
void isChipSupported(char *chipFlag){
	*chipFlag=pAppConfig->mChipFlag;
}
void isClessSupported(char *cLessFlag){
	*cLessFlag=pAppConfig->mCLessFlag;
}
void getEmvStandard(char *emvFlag){
	*emvFlag=pAppConfig->mEMVStandard;
}
int getReceiptFlag(char *receiptFlag){
	*receiptFlag=pAppConfig->mReceiptFlag;
	return TRUE;
}
int getReferenceFlag(char *refFlag){
	*refFlag=pAppConfig->mReferenceFlag;
}
int getLevel_2_DataFlag(char *level_2_DataFlag){
	*level_2_DataFlag = pAppConfig->mLevel_2_Flag;
	return TRUE;
}
int getLevel_3_DataFlag(char *level_3_DataFlag){
	*level_3_DataFlag = pAppConfig->mLevel_3_Flag;
	return TRUE;
}
int getReceiptHeader(char *receiptHeader){
	memcpy(receiptHeader,pAppConfig->mReceiptHeader,sizeof(pAppConfig->mReceiptHeader));
	return TRUE;
}
int getReceiptFooter(char *receiptFooter){
	memcpy(receiptFooter,pAppConfig->mReceiptFooter,sizeof(pAppConfig->mReceiptFooter));
	return TRUE;
}
int getIdleMsg(char *idleMsg){
	memcpy(idleMsg,pAppConfig->mIdleMessage,sizeof(pAppConfig->mIdleMessage));
	return TRUE;
}
int getMaxTxnAmount(char *maxTxnAmt){
	memcpy(maxTxnAmt,pAppConfig->mMaxTxnAmt,sizeof(pAppConfig->mMaxTxnAmt));
	return TRUE;
}
int getSoftwareVersion(char *version){
	memcpy(version, pAppConfig->mSoftwareVer, sizeof(pAppConfig->mSoftwareVer));
}

int getAutoBatchTime(char *autoBatchTime){/*
	memcpy(autoBatchTime,pAppConfig->mAutoBatchTime,sizeof(pAppConfig->mAutoBatchTime));
	return TRUE;
*/}
int getPinPadMode(char *pinpadMode){
	*pinpadMode=pAppConfig->mPinPadFlag;
	return TRUE;
}
int getPOSMode(char *posMode){
	*posMode=pAppConfig->mPosMode;
	//memcpy(posMode,pAppConfig->mPosMode,sizeof(pAppConfig->mPosMode));
	return TRUE;
}
void isPartialApprovalSupported(char *partialApprovalFlag){
	*partialApprovalFlag=pAppConfig->mPartialApprovalFlag;
	//memcpy(partialApprovalFlag,pAppConfig->mPartialApprovalFlag,sizeof(pAppConfig->mPartialApprovalFlag));
	return;
}
int  getDepartmentCount(char *count){
	*count=pAppConfig->mDepartmentCount;
	return;
}
int getClerkId(char *clerkId){
	memcpy(clerkId,pAppConfig->mClerkID,sizeof(pAppConfig->mClerkID));
	return TRUE;
}
int getTxnSequenceNo(char *sequenceNo){
	memcpy(sequenceNo, pAppConfig->mTxnSequenseNo,sizeof(pAppConfig->mTxnSequenseNo));
	return TRUE;
}
void setTxnSequenceNo () {
	char seqNo[5]={0},temp[5]={0};
	int iSeqNo=0;
	getTxnSequenceNo(seqNo);
	iSeqNo = atoi(seqNo);
	iSeqNo = (iSeqNo > 9999 ? 1 : iSeqNo + 1);
	memset(seqNo,0,sizeof(seqNo));
	sprintf(seqNo,"%d",iSeqNo);
	memcpy (&temp[sizeof (temp) - strlen(seqNo)-1],seqNo,strlen(seqNo));
	memset (temp, '0', sizeof (temp) - strlen(seqNo)-1);
	saveAdminParameter("TXN_SEQUENCE_NUMBER",temp);
}
int getTxnCurrencyCode(char *currencyCode){
	memcpy(currencyCode,pAppConfig->mTxnCurrencyCode,sizeof(pAppConfig->mTxnCurrencyCode));
	return TRUE;
}

int getDepartmentList(char deptList[DEPARTMENT_COUNT][DEPARTMENT_NAME_LEN+1]){
	int i=0;
	for(i=DEPARTMENT_COUNT-1;i>=0;i--){
		memcpy(&deptList[i][0],&(pAppConfig->mDepartmentName[i][0]),DEPARTMENT_NAME_LEN);
	}
	return TRUE;
}
int getMIDList(char deptMIDList[DEPARTMENT_COUNT][MERCHANT_ID_LEN+1]){
	int i=0;
	for(i=DEPARTMENT_COUNT-1;i>=0;i--){
		memcpy(&deptMIDList[i][0],&(pAppConfig->mMerchantIDList[i][0]),MERCHANT_ID_LEN);
	}
	return TRUE;
}
int getAPIKeyList(char deptAPIKeyList[DEPARTMENT_COUNT][APIKEY_LEN+1]){
	int i=0;
	for(i=DEPARTMENT_COUNT-1;i>=0;i--){
		memcpy(&deptAPIKeyList[i][0],&(pAppConfig->mApiKeyList[i][0]),APIKEY_LEN);
	}
	return TRUE;
}
