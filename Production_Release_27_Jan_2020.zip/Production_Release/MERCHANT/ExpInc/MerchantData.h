/* --------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                  *
 * --------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                *
 * ---   ---------     ----         -----------                                *
 * V01   RS Software   12/31/2017   Initial Creation                           *
 * --------------------------------------------------------------------------- */
#ifndef __MERCHANTDATA_H
#define __MERCHANTDATA_H

#include <GL_GraphicLib.h>
#include "Transaction.h"

/*+************* #DEFINES **************************************************+*/


/*+************* CONSTANTS *************************************************+*/
#define USERIN_TIMEOUT   	60 * GL_TIME_SECOND;
#define MSGDIS_TIMEOUT      10 * GL_TIME_SECOND;
#define DEPARTMENT_COUNT    5
#define DEPARTMENT_NAME_LEN 24
#define MERCHANT_API_LEN 24
#define MERCHANT_PHONE_LEN 20
#define MERCHANT_ZIP_LEN 10
#define MERCHANT_ID_LEN 20
#define APIKEY_LEN 48
/*+************* STRUCTURES ************************************************+*/
typedef struct receiptData{
	char department	[24 + 1];
	char country	[24 + 1];
	char isoName    [24 +1];
	char merchantName[24+ 1];
	char merchantCity[24+ 1];
	char merchantAddress[24+1];
	char merchantZIP[24+1];
	char merchantPhone[24 + 1];
	char locDateTime[24 + 1];
	char txnTypeDorC[24 + 1];
	char txnType	[24 + 1];
	char clrkID		[24 + 1];
	char txnID		[24 + 1];
	char ReferenceNo[29 + 1];
	char terminalNo	[24 + 1];
	char merchantNo	[24 + 1];
	char subTotalAmt[24 + 1];
	char convFee	[24 + 1];
	char stateFee	[24 + 1];
	char totalAmt	[24 + 1];
	char cardEntryMode[24+1];
	char cardNum    [24 + 1];
	char expDate	[24 + 1];
	char app		[24 + 1];
	char aid		[24 + 1];
	char specialAid	[40 + 1];
	char tvr		[24 + 1];
	char tsi		[24 + 1];
	char arc		[24 + 1];
	char authCode	[24 + 1];
	char txnStatus	[24 + 1];
	char responseTxt[24 + 1];
	char responseDef[71 + 1];
	char cvm;		// '1' = Signature, '2' = PIN
	char chName		[24 + 1];
	char batchNetDeposit	[24+1];
	char batchNumber		[24+1];
	char batchRecordCount	[24+1];
	char batchCoreResponseCode  [24+1];
	char batchConvResponseCode  [24+1];
	char batchCoreResponseText	[24+1];
	char batchConvResponseText	[24+1];
};

typedef struct sUserMenu{
	char *menuMain			[9];
	char *menuCardType		[3];
	char *menuMore			[8];
	char *menuTxnParam		[3];
	char *menuUser          [2];
	char *menuSettleParam	[3];
	//char *menuMerchantParam	[8]; For TEMS Change
	char *menuMerchantParam	[3];
	char *menuReceipt		[3];
	char *menuTerminalParam	[6];
	char *menuDownloadParam	[5];
	char *menuSystem		[9];
	char *menuPinPad		[3];
	char *menuPOSMode		[3];
	char *menuUserMgmt      [3+DEPARTMENT_COUNT];
	char *menuGateway		[3];
	char *menuGatewayTcp	[4];
	char *menuGatewayWeb	[4];
	char *menuAccept		[3];
	char *menuTransactions  [6];
	char *menuTms           [5];
	char *menuRefundDetails [3];
	char *menuBatchDetails  [3];
	char *menuTranSummary   [4];
	char *menuDuplicateReceptChoice [3];
}userMenu;
typedef struct sConfigParam {
	char mTermID 		    [20];
	char mTermMngmtID		[24];
	char mMercID 		    [20];
	char mMerchCategoryCode [4];
	char mIndustryType		[24];
	char mMerchantName		[24];
	char mMerchantAddres	[DEPARTMENT_COUNT][MERCHANT_API_LEN];
	char mMerchantCity		[DEPARTMENT_COUNT][MERCHANT_API_LEN];
	char mMerchantState		[DEPARTMENT_COUNT][MERCHANT_API_LEN];
	char mMerchantZip		[DEPARTMENT_COUNT][MERCHANT_ZIP_LEN];
	char mMerchantPhone		[DEPARTMENT_COUNT][MERCHANT_PHONE_LEN];
	char mMerchantStore		[4];
	char mMerchantBankID	[6];
	char mMerchantChainNo	[6];
	char mMerchantAgentNo	[6];
	char mMerchantABANo		[10];
	char mMerchantReimburse;
	char mMerchantSettleAgent[4];
	char mMerchantDebitSharing;
	char mGatewayComType;
	char mGatewayTDesKey	[48];
	char mGatewayTDesKCV	[8];
	char mGatewayAPIKey		[48];
	char mGatewayIP			[15];
	char mGatewayPort		[3];
	char mGatewayURL		[49];
	char mGatewayCGI		[24];
	char mTMS_APIKey		[48];
	char mTMSIp				[15];
	char mTMSPort			[4];
	char mTMSURL			[49];
	char mTMSFTPPWD			[24];
	char mTMSUserName		[20];
	char mTMSFileVer        [20];
	char mSoftwareVer       [20];
	char mTMSFilePath       [40];
	char mTMSFileType;
	char mTMSTerminalID     [20];
	char mManagerPassWord	[4];
	char mDisplayMsgFlag;
	char mlogoutFlag;
	char mCreditFlag;
	char mDebitFlag;
	char mEBTFlag;
	char mSaleFlag;
	char mAuthOnlyFlg;
	char mRefundFlg;
	char mVoidFlg;
	char mBillPaymentFlg;
	char mBalanceEnqFlg;
	char mCardAuthFlg;
	char mManualBatchFlg;
	char mAutoBatchSupport;
	//char mAutoBatchTime		[4];
	char mSplitPmtFlg;
	char mMaxTxnAmt			[12];
	char mPinPadFlag;
	char mPosMode;
	char mReceiptFlag;
	char mReferenceFlag;
	char mLevel_2_Flag;
	char mLevel_3_Flag;
	char mEmailFlag;
	char mEmailTxnReceipt;
	char mEmailMerchReport;
	char mEmailSmtpURL		[24];
	char mEmailSmtpIP		[15];
	char mEmailSmtpPort		[4];
	char mEmailClientID		[24];
	char mEmailSenderID		[24];
	char mEmailSenderPWD 	[24];
	char mEmailRecieveID	[24];
	char mManualKeyFlg;
	char mSwipeFlag;
	char mChipFlag;
	char mCLessFlag;
	char mEMVStandard;
	char mReceiptHeader		[24];
	char mReceiptFooter		[24];
	char mIdleMessage		[24];
	char mDepartmentCount;
	char mDepartmentName    [DEPARTMENT_COUNT][DEPARTMENT_NAME_LEN];
	char mMerchantIDList    [DEPARTMENT_COUNT][MERCHANT_ID_LEN];
	char mApiKeyList    	[DEPARTMENT_COUNT][APIKEY_LEN];
	char mPartialApprovalFlag;
	char mClerkID			[6];
	char mTxnSequenseNo		[4];
	char mTxnCurrencyCode	[3];

};
struct sConfigParam mApplConf;

typedef struct sConfigTable {
	char * mParamName;
	int    mParamLength;
};



#define APPCONFTABLE    \
		{"TERMINAL_ID",              			sizeof(mApplConf.mTermID)}, 			    \
		{"TERMINAL_MANAGEMENT_ID",              sizeof(mApplConf.mTermMngmtID)}, 			\
		{"MERCHANT_ID",              			sizeof(mApplConf.mMercID)}, 			    \
		{"MERCHANT_CATEGORY_CODE",              sizeof(mApplConf.mMerchCategoryCode)}, 		\
		{"INDUSTRY_TYPE",              			sizeof(mApplConf.mIndustryType)}, 			\
		{"MERCHANT_NAME",              			sizeof(mApplConf.mMerchantName)}, 			\
		{"MERCHANT_ADDRESS_1",					MERCHANT_API_LEN},  		\
		{"MERCHANT_ADDRESS_2",					MERCHANT_API_LEN},  		\
		{"MERCHANT_ADDRESS_3",					MERCHANT_API_LEN},  		\
		{"MERCHANT_ADDRESS_4",					MERCHANT_API_LEN},  		\
		{"MERCHANT_ADDRESS_5",					MERCHANT_API_LEN},  		\
		{"MERCHANT_CITY_1",						MERCHANT_API_LEN},  			\
		{"MERCHANT_CITY_2",						MERCHANT_API_LEN},  			\
		{"MERCHANT_CITY_3",						MERCHANT_API_LEN},  			\
		{"MERCHANT_CITY_4",						MERCHANT_API_LEN},  			\
		{"MERCHANT_CITY_5",						MERCHANT_API_LEN},  			\
		{"MERCHANT_STATE_1",						MERCHANT_API_LEN},  		\
		{"MERCHANT_STATE_2",						MERCHANT_API_LEN},  		\
		{"MERCHANT_STATE_3",						MERCHANT_API_LEN},  		\
		{"MERCHANT_STATE_4",						MERCHANT_API_LEN},  		\
		{"MERCHANT_STATE_5",						MERCHANT_API_LEN},  		\
		{"MERCHANT_ZIP_1",						MERCHANT_ZIP_LEN},  			\
		{"MERCHANT_ZIP_2",						MERCHANT_ZIP_LEN},  			\
		{"MERCHANT_ZIP_3",						MERCHANT_ZIP_LEN},  			\
		{"MERCHANT_ZIP_4",						MERCHANT_ZIP_LEN},  			\
		{"MERCHANT_ZIP_5",						MERCHANT_ZIP_LEN},  			\
		{"MERCHANT_PHONE_1",					MERCHANT_PHONE_LEN},  		\
		{"MERCHANT_PHONE_2",					MERCHANT_PHONE_LEN},  		\
		{"MERCHANT_PHONE_3",					MERCHANT_PHONE_LEN},  		\
		{"MERCHANT_PHONE_4",					MERCHANT_PHONE_LEN},  		\
		{"MERCHANT_PHONE_5",					MERCHANT_PHONE_LEN},  		\
		{"MERCHANT_STORENUMBER",				sizeof(mApplConf.mMerchantStore)},  		\
		{"MERCHANT_BANKID",						sizeof(mApplConf.mMerchantBankID)},  		\
		{"MERCHANT_AGENT_NUMBER",				sizeof(mApplConf.mMerchantChainNo)},  		\
		{"MERCHANT_CHAIN_NUMBER",				sizeof(mApplConf.mMerchantAgentNo)},  		\
		{"MERCHANT_MERCH_ABA_NUM",				sizeof(mApplConf.mMerchantABANo)},  		\
		{"MERCHANT_REIMBURSE_ATTR",				sizeof(mApplConf.mMerchantReimburse)},  	\
		{"MERCHANT_SETTLE_AGENT",				sizeof(mApplConf.mMerchantSettleAgent)},	\
		{"MERCHANT_DEBIT_SHARING_GROUP",		sizeof(mApplConf.mMerchantDebitSharing)},  	\
		{"GATEWAY_COM_TYPE",					sizeof(mApplConf.mGatewayComType)},  		\
		{"GATEWAY_TDES_KEY",					sizeof(mApplConf.mGatewayTDesKey)},  		\
		{"GATEWAY_TDES_KCV",					sizeof(mApplConf.mGatewayTDesKCV)},  		\
		{"GATEWAY_API_KEY",						sizeof(mApplConf.mGatewayAPIKey)},  		\
		{"GATEWAY_IP_ADDRESS",					sizeof(mApplConf.mGatewayIP)},  			\
		{"GATEWAY_PORT",						sizeof(mApplConf.mGatewayPort)},  			\
		{"GATEWAY_URL",               		    sizeof(mApplConf.mGatewayURL)}, 			\
		{"GATEWAY_CGI",          				sizeof(mApplConf.mGatewayCGI)}, 			\
		{"TMS_API_KEY",						    sizeof(mApplConf.mTMS_APIKey)},  		    \
		{"TMS_IP_ADDRESS",              		sizeof(mApplConf.mTMSIp)}, 					\
		{"TMS_PORT",              				sizeof(mApplConf.mTMSPort)}, 				\
		{"TMS_URL",              				sizeof(mApplConf.mTMSURL)}, 				\
		{"TMSFTP_PWD",              			sizeof(mApplConf.mTMSFTPPWD)}, 				\
		{"TMSFTPUSER_NAME",                     sizeof(mApplConf.mTMSUserName)}, 			\
		{"TMSFILE_VERSION",                     sizeof(mApplConf.mTMSFileVer)}, 			\
		{"SOFTWARE_VERSION",                    sizeof(mApplConf.mSoftwareVer)}, 			\
		{"TMSFILE_PATH",                        sizeof(mApplConf.mTMSFilePath)}, 			\
		{"TMSFILE_TYPE",                        sizeof(mApplConf.mTMSFileType)}, 			\
		{"TMSTERMINAL_ID",                      sizeof(mApplConf.mTMSTerminalID)}, 			\
		{"MANAGER_PASSWORD",              		sizeof(mApplConf.mManagerPassWord)}, 		\
		{"DISPLAY_MSG_FLAG",              		sizeof(mApplConf.mDisplayMsgFlag)}, 		\
		{"LOGOUT",              		        sizeof(mApplConf.mlogoutFlag)}, 		    \
		{"CREDIT",              		        sizeof(mApplConf.mCreditFlag)}, 		    \
		{"DEBIT",              					sizeof(mApplConf.mDebitFlag)}, 				\
		{"EBT",              					sizeof(mApplConf.mEBTFlag)}, 				\
		{"SALE",              					sizeof(mApplConf.mSaleFlag)}, 				\
		{"AUTH",              					sizeof(mApplConf.mAuthOnlyFlg)},			\
		{"REFUND",              			    sizeof(mApplConf.mRefundFlg)},				\
		{"VOID",              			        sizeof(mApplConf.mVoidFlg)   },				\
		{"BILL_PAYMENT",              			sizeof(mApplConf.mBillPaymentFlg)},			\
		{"BALANCE_INQUIRY",              		sizeof(mApplConf.mBalanceEnqFlg)},			\
		{"CARD_AUTHENTICATION",              	sizeof(mApplConf.mCardAuthFlg)},			\
		{"MANUAL_BATCH",              			sizeof(mApplConf.mManualBatchFlg)},			\
		{"AUTOBATCH",              				sizeof(mApplConf.mAutoBatchSupport)},		\
		{"SPLIT_PAYMENT",              			sizeof(mApplConf.mSplitPmtFlg)},			\
		{"MAX_TXN_AMOUNT",              		sizeof(mApplConf.mMaxTxnAmt)}, 				\
		{"EXTERNAL_PINPAD",              		sizeof(mApplConf.mPinPadFlag)},				\
		{"POS_MODE",              				sizeof(mApplConf.mPosMode)}, 				\
		{"PAPER_RECEIPT",              		    sizeof(mApplConf.mReceiptFlag)}, 			\
		{"REFERENCE_FLAG",              		sizeof(mApplConf.mReferenceFlag)}, 			\
		{"LEVEL_2_DISPLAY_FLAG",              	sizeof(mApplConf.mLevel_2_Flag)}, 			\
		{"LEVEL_3_DISPLAY_FLAG",              	sizeof(mApplConf.mLevel_3_Flag)}, 			\
		{"EMAIL_SUPPORTED",              		sizeof(mApplConf.mEmailFlag)}, 			    \
		{"EMAIL_TXN_RECEIPT",              		sizeof(mApplConf.mEmailTxnReceipt)}, 		\
		{"EMAIL_MECRH_REPORT",              	sizeof(mApplConf.mEmailMerchReport)}, 		\
		{"EMAIL_SMTP_URL",              		sizeof(mApplConf.mEmailSmtpURL)}, 			\
		{"EMAIL_SMTP_IP",              			sizeof(mApplConf.mEmailSmtpIP)}, 			\
		{"EMAIL_SMTP_PORT",              		sizeof(mApplConf.mEmailSmtpPort)}, 			\
		{"EMAIL_SMTP_CLIENT",              		sizeof(mApplConf.mEmailClientID)}, 			\
		{"EMAIL_SENDER_ID",              		sizeof(mApplConf.mEmailSenderID)}, 			\
		{"EMAIL_SENDER_PWD",              		sizeof(mApplConf.mEmailSenderPWD)}, 		\
		{"EMAIL_REPORT_RECIPIENT_ID",           sizeof(mApplConf.mEmailRecieveID)}, 		\
		{"MANUAL_KEYED",              		    sizeof(mApplConf.mManualKeyFlg)}, 			\
		{"SWIPE",              		            sizeof(mApplConf.mSwipeFlag)}, 				\
		{"CHIP",              					sizeof(mApplConf.mChipFlag)}, 				\
		{"CONTACTLESS",              			sizeof(mApplConf.mCLessFlag)}, 				\
		{"EMV_STANDARD",              			sizeof(mApplConf.mEMVStandard)}, 			\
		{"RECEIPT_HEADER",              		sizeof(mApplConf.mReceiptHeader)}, 			\
		{"RECEIPT_FOOTER",              		sizeof(mApplConf.mReceiptFooter)}, 			\
		{"IDLE_MESSAGE",              			sizeof(mApplConf.mIdleMessage)}, 			\
		{"DEPARTMENT_COUNT",              		sizeof(mApplConf.mDepartmentCount)}, 			\
		{"DEPARTMENT_1",              			DEPARTMENT_NAME_LEN        },				\
		{"DEPARTMENT_2",              			DEPARTMENT_NAME_LEN        },				\
		{"DEPARTMENT_3",              			DEPARTMENT_NAME_LEN        },				\
		{"DEPARTMENT_4",              			DEPARTMENT_NAME_LEN        },				\
		{"DEPARTMENT_5",              			DEPARTMENT_NAME_LEN        },				\
		{"MERCHANT_ID_1",              			MERCHANT_ID_LEN        		},				\
		{"MERCHANT_ID_2",              			MERCHANT_ID_LEN        		},				\
		{"MERCHANT_ID_3",              			MERCHANT_ID_LEN        		},				\
		{"MERCHANT_ID_4",              			MERCHANT_ID_LEN        		},				\
		{"MERCHANT_ID_5",              			MERCHANT_ID_LEN        		},				\
		{"GATEWAY_API_KEY_1",              		APIKEY_LEN        			},				\
		{"GATEWAY_API_KEY_2",              		APIKEY_LEN        			},				\
		{"GATEWAY_API_KEY_3",              		APIKEY_LEN        			},				\
		{"GATEWAY_API_KEY_4",              		APIKEY_LEN        			},				\
		{"GATEWAY_API_KEY_5",              		APIKEY_LEN        			},				\
		{"PARTIAL_APPROVAL_SUPPORTED",          sizeof(mApplConf.mPartialApprovalFlag)},	\
		{"CLERK_ID",              				sizeof(mApplConf.mClerkID)}, 				\
		{"TXN_SEQUENCE_NUMBER",              	sizeof(mApplConf.mTxnSequenseNo)}, 			\
		{"TXN_CURRENCY_CODE",              		sizeof(mApplConf.mTxnCurrencyCode)},		\

/*+************* VARIABLES *************************************************+*/



/*+************* FUNCTION PROTOTYPES ***************************************+*/
extern void merchantTerminalUI (NO_SEGMENT appliId);
extern void externalPINPadUI (NO_SEGMENT appliId);
extern void externalPINPadUIForCardTypeSelection(NO_SEGMENT appliId);
extern void appDownloadForIPP3XX(NO_SEGMENT appliId);
extern void constructRefundData (char *displayFee);
extern void menuHolderDisagree (NO_SEGMENT appliId);
extern void initUIContext(int);
extern void releaseUIContext(void);
extern int temsUserMenu();
extern TransactionSummary();
struct sUserMenu loadMenu ();
struct sTestMenu loadTestMenu();
extern void constructPayableData (char * displayFee);
extern void constructListOfTxnDetails(char * displayTxnDetails,char * txnReferenceNo,int indexNo);
extern int calculateFee (char *transactionType);
extern int getLevel2Input();
extern int getLevel3Input();

extern int saveAdminParameter(char * paramName, char * paramData);
extern int restoreAdminParameters();
extern int fetch_appconfig_data(char * paramName, char * paramData);
extern void setUserDataParameters();

extern int getTerminalID(char *terminalID);
extern int getMerchantID(char *merchantID);
extern int getTerminalMngmtId(char *mngmntID);
extern int getMCC(char *mcCode);
extern int getMerchantName(char *merchantName);
extern int getIndustrytype(char *IndustryName);
extern void setMerchantChoice(ulong choice);
extern int getMerchantAddressList(char mMerchantAddres[DEPARTMENT_COUNT][MERCHANT_API_LEN +1]);
extern int getMerchantCityList(char mMerchantCity[DEPARTMENT_COUNT][MERCHANT_API_LEN +1]);
extern int getMerchantStateList(char mMerchantState[DEPARTMENT_COUNT][MERCHANT_API_LEN +1]);
extern int getMerchantZIPList(char mMerchantZip[DEPARTMENT_COUNT][MERCHANT_ZIP_LEN +1]);
extern int getMerchantPhoneList(char mMerchantPhone[DEPARTMENT_COUNT][MERCHANT_PHONE_LEN +1]);
extern int getMerchantAddress(char *mMerchantAddres);
extern int getMerchantCity(char *mMerchantCity);
extern int getMerchantState(char *mMerchantState);
extern int getMerchantZIP(char *mMerchantZip);
extern int getMerchantPhone(char *mMerchantPhone);
extern int getMerchantStoreNo(char *merchantStoreNo);
extern int getMerchantBankID(char *merchantBankId);
extern int getMerchantAgentNo(char *merchantAgentNo);
extern int getMerchantChainNo(char *merchantChainNo);
extern int getMerchantABANo(char *MerchantABANo);
extern int getMerchantReimburseAttr(char *MerchantReimburseAttr);
extern int getMerchantSettleAgent(char *MerchantSettleAgent);
extern int getMerchantDebitSharingGroup(char *debitSharingGroup);
extern int setGatewayTDesKey(char *gatewayTDESKey);
extern int setGatewayTDesKCV(char *gatewayTDESKcv);
extern int getGatewayTDesKey(char *gatewayTDESKey);
extern int getGatewayTDesKCV(char *gatewayTDESKcv);
extern int getGatewayAPIKey(char *gatewayAPIKey);
extern int getGatewayIP(char *gatewayIP);
extern int getGatewayPort(char *gatewayPort);
extern int getGatewayURL(char *gatewayURL);
extern int 	getGatewayCGI(char *gatewayCGI);
extern int 	getTMSAPIKey(char *tmsApiKey);
extern int 	getTMSIP(char *TMSIp);
extern int 	getTMSPort(char *TMSPort);
extern int  getTMSFtpPwd(char *TMS_CGI);
extern int  getTMSTerminalID(char *terminalid);
extern int  getFileType(char *filetype);
extern int  getFilePath(char *filepath);
extern int  getFileVersion(char *fileversion);
extern int 	getTMSURL(char *TMS_URL);
extern int 	getTMSUserID(char *userID);
extern char * getManagerPassword(void);
extern void isDisplyMsgFlagEnable(char *displayMsgFlg);
extern void isLogout(char *logOutFlg);
extern void isCreditSupported(char *creditFlg);
extern void isDebitSupported(char *debitFlg);
extern void isEBTSupported(char *ebtFlg);
extern void isAuthOnlySupported(char *authOnlyFlag);
extern void isRefundSupported(char *refundFlag);
extern void isVoidSupported(char *voidFlag);
extern void isBillPmtSupported(char *billPmtFlag);
extern void isBalanceEnqSupported(char *balEnqFlag);
extern void isCardAuthSupported(char *cardAuthFlag);
extern void isManBatchSupported(char *manBatchFlag);
extern void isAutoBatchSupported(char *autoBatchFlag);
extern void isFeeSupported(char *feeFlag);
extern void getComType(char *comType);
extern int 	getMaxTxnAmount(char *maxTxnAmt);
extern int 	getPinPadMode(char *pinpadMode);
extern int  getSoftwareVersion(char *version);
extern int 	getPOSMode(char *posMode);
extern int 	getReceiptFlag(char *receiptFlag);
extern int 	getLevel_2_DataFlag(char *level_2_DataFlag);
extern int  getLevel_3_DataFlag(char *level_3_DataFlag);
extern int 	getEmailSupportFlag(char *emailFlag);
extern int 	getEmailTxnReceiptFlag(char *emailReceiptFlag);
extern int 	getEmailMerchReportFlag(char *emailReportFlag);
extern int 	getSmtpUrl(char *smtpUrl);
extern int 	getSmtpIP(char *smtpIP);
extern int 	getSmtpPort(char *smtpPort);
extern int 	getSmtpClient(char *smtpClient);
extern int 	getEmailSenderID(char *senderID);
extern int 	getEmailSenderPwd(char *senderPwd);
extern int 	getEmailReportReciptID(char *receiptID);
extern void isManualKeySupported(char *manKeyFlag);
extern void isSwipeSupported(char *swipeFlag);
extern void isChipSupported(char *chipFlag);
extern void isClessSupported(char *cLessFlag);
extern void getEmvStandard(char *emvFlag);
extern int 	getReceiptHeader(char *receiptHeader);
extern int 	getReceiptFooter(char *receiptFooter);
extern int 	getIdleMsg(char *idleMsg);
extern int 	getAutoBatchTime(char *autoBatchTime);
extern void isPartialApprovalSupported(char *partialApprovalFlag);
extern int 	getClerkId(char *clerkId);
extern int 	getTxnSequenceNo(char *sequenceNo);
extern void setTxnSequenceNo();
extern int 	getTxnCurrencyCode(char *currencyCode);
extern int  getDepartmentCount(char *count);
extern int  getDepartmentList(char deptList[DEPARTMENT_COUNT][DEPARTMENT_NAME_LEN+1]);
extern int  getMIDList(char deptMIDList[DEPARTMENT_COUNT][MERCHANT_ID_LEN+1]);
extern void GL_SampleDocument(T_GL_HGRAPHIC_LIB hGraphicLib);
//TMS File process
extern int  iFtp_download_Connect( int bFTPS );
extern void trimTrailing(char * str, char * dest);
extern int hostcall(char *requestbuf, char *responsebuf, int flag);
extern int hostServiceCall (char *requestBuf,char *responseBuf, int tmsflag);
#define COMERROR 		-1
#define HOSTERROR 		-2
#define RESPTIMEOUT 	-3
#define SERVERDOWN 	    -4
extern char TmsftpPwd[30];
extern char tempfilepath[40];
//TMS File End
//Transaction Summary
extern int batchall;
extern char mclerklist[10][12];
extern int clerkcnt;
// Macros & preprocessor definitions.
#define MAX_FILE (120)
#define MAX_FILE_LEN (15)
// Types
typedef void * RAMDISK_HANDLE;
typedef void * RAMDISK_FILE;
// Functions.
RAMDISK_HANDLE RAMDISK_Create( const char *szName, unsigned long nSize,unsigned int nMaxFile );
int RAMDISK_Delete( RAMDISK_HANDLE hDisk );
RAMDISK_FILE RAMDISK_OpenFile( RAMDISK_HANDLE hDisk,const char *szName, const char *szMode );
void RAMDISK_CloseFile( RAMDISK_HANDLE hDisk, RAMDISK_FILE hFile );
int RAMDISK_WriteInFile( RAMDISK_HANDLE hDisk,void *hFile, const unsigned char *pucBuffer, unsigned int nSize );
int RAMDISK_Activate( RAMDISK_HANDLE hDisk );
#endif //__MENU_H
