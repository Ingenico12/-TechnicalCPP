/* --------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                  *
 * --------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                *
 * ---   ---------     ----         -----------                                *
 * V01   RS Software   12/31/2017   Initial Creation                           *
 * --------------------------------------------------------------------------- */
#ifndef HOSTDATA_H_INCLUDED
#define HOSTDATA_H_INCLUDED

#include "Transaction.h"

#define REQUEST_LEN 	5000
#define RESPONSE_LEN 	5000
#define LEVEL2_LEN     2000

#define COMERROR 		-1
#define HOSTERROR 		-2
#define RESPTIMEOUT 	-3
#define SERVERDOWN 	    -4

typedef struct requestFields{
	int  referenceID;
	char timeStamp [20];
	char terminalNo [13];
	char merchantID[13];
	char cardInputType [15];
	char feeCardInputType[15];
	char cardType [15];
	char currencyCode [4];
	char txnSequence [5];
	char transactionID[22];
	char txnType [12];
	char txnCode [30];
	char cardHolderIdCode [30];
	char cardHolderIdData [36+1];
	char cardHolderDataSource [40];
	char chipConditionCode[2];
	char cardNo [128+1];
	char cardCVV[128+1];
	char customerData [128+1];
	char posData [13];
	char motoIndicator [2];
	char emvData [512];
	char cardExpiryDate [128+1];
	char feeDetail[700];
	char convFee [13];
	char convMID [13];
	char stateFee [13];
	char stateMID [13];
	char coreAmt [13];
	char coreMID [13];
	char coreNonEMVFlag [5];
	char custName[30];
	char custAddress[25];
	char custCity[25];
	char custState[25];
	char custZip[7];
	char trxnReferenceNo[21];
	char cardLastFourDigit[4+1];
	//Level 2
	char mOptAmountId[2+1];
	char mOptAmount[12+1];
   char mPurchaseIDFormat[2];                         // MasterCard and VISA Only
   char mPurchaseID [24+1];                          // MasterCard and VISA Only
   char mLocalTaxInclFlag[2];                         // MasterCard and VISA Only
   char mLocalTax       [12+1];                      // MasterCard and VISA Only
   char mNatTaxInclFlag[2];                           // MasterCard and VISA Only
   char mNatTax [12+1];                              // MasterCard and VISA Only
   char mPONumber [17+1];                     // MasterCard and VISA Only
   char mMVATRegNum [20+1];                          // VISA Only
   char mCVATRegNum [13+1];                          // VISA Only
   char mSumCommodityCd [4+1];                // VISA Only
   char mDiscAmt [12+1];                             // VISA Only
   char mFreightAmt [12+1];                          // MasterCard and VISA Only
   char mDutyAmt [12+1];                             // MasterCard and VISA Only
   char mDestZip [10+1];                             // MasterCard and VISA Only
   char mShippingZip [10+1];                         // MasterCard and VISA Only
   char mDestCountryCode [3+1];               // MasterCard and VISA Only
   char mVATInvcRefNum [12+1];                // VISA Only
   char mOrderDate [6+1];                            // YYMMDD  .. VISA Only
   char mVATTaxAmt [12+1];                           // VISA Only
   char mVATTaxRate [4+1];                           // VISA Only  0.00
   char mAltTaxAmtID[2+1];
   char mAltTaxAmt[12+1];
   char mCostPerUnit[2];
   char mLineItemTotCnt[6];
   char mAltTaxID[2];
   char mTaxTypeApplied[2];
   char mDiscInd[2];
   char mNetGrossInd[2];
   char mExtItemAmt[12+1];
   char mDrCrInd[2];
   char mItemDiscRate[2];
   char mItemQtyExpInd[2];
   char mItemDisExpInd[2];


   // Level 2 AMEX Only
   char mSupplierRefNum [9+1];
   char mCHRefNum [17+1];
   char mShipToZip [9+1];
   char mSalesTaxAmt [6+1];
   char mchargeDesc1 [24+1];
   char mReqRefName[24+1];
   char mTotalTaxAmt[12+1];
   char mTaxTypeCode[3+1];

   // Transaction Level 3 Data
   int  mLevel3Data;
   char mProductCd [12+1];
   char mProductCommodityCd [12+1];
   char mProductDesc [13+1];
   char mProductQuantity [12+1];
   char mProductMeasurementUnit [12+1];       // Meter
   char mDiscountAmt [12+1];
   //clerk ID
   char rClerkID[6+1];
   char rOrderID[20 +1];
   char rSource[15+1];

}requestStructure;

NO_SERIE serial;
int calculateFee ();
char * constructPayableData ();
int authResponseParser(const char* xmlData);
int emvPrepareRequestDataTSYS (char * emvDataASCII, int * emvDataASCIILength);
int prepareLevel2Data(struct requestFields *reqStruct, char *level3Data);
int prepareLevel3Data(struct requestFields *reqStruct, char *level3Data);
//BatchSummary
int batchall;

#endif
