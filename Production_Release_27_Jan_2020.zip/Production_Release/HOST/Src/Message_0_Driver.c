/* ---------------------------------------------------------------------------------------------- *
 *                            PROGRAM HISTORY                                                     *
 * ---------------------------------------------------------------------------------------------- *
 * Ver.  Author(s)     Date         Description                                                   *
 * ---   ---------     ----         -----------                                                   *
 * V01   RS Software   07/01/2018   This module implements Merchant's business rules              *
 * ---------------------------------------------------------------------------------------------- */
#include <sdk_tplus.h>
#include <OSL_Logger.h>
#include <GL_GraphicLib.h>

#include "_emvdctag_.h"
#include "del_lib.h"
#include "def_tag.h"
#include "servcomm.h"
#include "LinkLayer.h"
#include "serveng.h"
#include "EngineInterfaceLib.h"
#include "EngineInterface.h"
#include "GL_GraphicLib.h"
#include "sec_interface.h"
#include "GTL_Assert.h"
#include "GTL_Convert.h"
#include "GL_Types.h"
#include "HostData.h"

int processOnlineTransaction (char *transactionType) {
	  char externalPinPad[2]={0};
	  getPinPadMode(externalPinPad);

	if (!strcmp (getTransactionType(), "CALCULATE_FEE")){
		// Build Request Message
		int ret=0, connectionScreen = 0;
		char feeURL [REQUEST_LEN]={0};
		char feeResponse[RESPONSE_LEN]={0};
		struct sFeesApplied feeRespStructure[MAX_FEE_COUNT]={0};
		int feeCount;
		ret = buildCalculateFeeRequest (feeURL,transactionType);
		if(ret==FALSE)
			return FALSE;

		connectionScreen = GL_File_Exists("file://flash/HOST/GOV.GIF");
		if(connectionScreen==GL_SUCCESS){
			do{
				connectionScreen = GL_Dialog_Picture(APEMV_UI_GoalHandle(),NULL,"Connecting..","file://flash/HOST/GOV.GIF", 0, 1);                // Display BMP
				// Route to host
				ret = hostServiceCall(feeURL,feeResponse,0);
				if (ret == COMERROR)
					break; // TIMER event has been received from the Telium Manager
				else if(ret == HOSTERROR)
					break; // TIMER event has been received from the Telium Manager
				else if(ret == SERVERDOWN)
					break; // When Server Down
				else if(ret==RESPTIMEOUT || strlen(feeResponse) <= 0)
					break; // TIMER event has been received from the Telium Manager
				else
					break;

			}while(1);
		}
		//if connection screen not present
		else{
			GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Processing...", GL_ICON_INFORMATION, GL_BUTTON_ALL, 0);
			ret = hostServiceCall(feeURL,feeResponse,0);
		}

		if (ret == COMERROR) {
			setErrorCode("ERROR:026");
			return FALSE;
		}
		if(ret == HOSTERROR){
			setErrorCode("ERROR:027");
			return FALSE;
		}
		if (ret == SERVERDOWN) {
			setErrorCode("ERROR:048");
			return FALSE;
		}
		if(ret==RESPTIMEOUT || strlen(feeResponse) <= 0) {
			setErrorCode("ERROR:028");
			return FALSE;
		}
		// Parse the message
		char temp [RESPONSE_LEN]={0};
		strcpy (temp,feeResponse);
		char *msgHeader;
		msgHeader = strtok(temp,"<");
		feeResponseParser (&feeResponse [strlen(msgHeader)]);
		if (strcmp(getErrorCode(),"ERROR:000")) {
			return FALSE;
		}

		//Server Down
		if(!strlen(getFeeResponseCode())){
			setErrorCode("ERROR:048");
			return FALSE;
		}
		getProprietaryData(&feeRespStructure,&feeCount);
		if(!strcmp(getFeeResponseCode(),"ED000")){
			//callTerminalDisplay(feeRespStructure.feeResponseMsg);
			return TRUE;
		}
		else{
			callTerminalDisplay(getFeeRespMsg());
			return FALSE;
		}
	}
	else if (!strcmp (getTransactionType(), PURCHASE)||
		!strcmp (getTransactionType(), REFUND)  ||
		!strcmp (getTransactionType(), PREAUTH)  ||
		!strcmp (getTransactionType(), COMPLETION)  ||
		!strcmp (getTransactionType(), FULL_REVERSAL)){
		// Build Request Message
		char authRequest[8000] = {0};
		struct requestFields structReq = {0};
		char authResponse[RESPONSE_LEN]={0};

		buildAuthorizationRequest (authRequest,&structReq);
		if(strcmp(getErrorCode(),"ERROR:000")){
			if (atoi(externalPinPad)){ //EXTERNAL PINPAD
				if(strcmp (getTransactionType(), COMPLETION)){
					acknowledgePINPad ();
					}
				}
			return FALSE;
		}
		int ret=0, connectionScreen=0;
		connectionScreen = GL_File_Exists("file://flash/HOST/GOV.GIF");
		if(connectionScreen==GL_SUCCESS){
			do{
				connectionScreen = GL_Dialog_Picture(APEMV_UI_GoalHandle(),NULL,"Connecting..","file://flash/HOST/GOV.GIF", 0, 1);                // Display BMP
				// Route to host
				ret = hostServiceCall(authRequest,authResponse,0);
				if (ret == COMERROR)
					break;
				else if(ret == HOSTERROR)
					break;
				else if(ret == SERVERDOWN)
					break;
				else if(ret==RESPTIMEOUT || strlen(authResponse)<= 0)
					break; // TIMER event has been received from the Telium Manager
				else
					break;

			}while(1);
		}
		//if connection screen not present
		else{
			GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Processing...", GL_ICON_INFORMATION, GL_BUTTON_ALL, 0);
			ret = hostServiceCall(authRequest,authResponse,0);
		}
		if (ret == SERVERDOWN) {
			setErrorCode("ERROR:048");
			return FALSE;
		}
		if(ret==COMERROR){
			setErrorCode("ERROR:026");
			if (atoi(externalPinPad)){ //EXTERNAL PINPAD
				if(strcmp (getTransactionType(), COMPLETION)){
					acknowledgePINPad ();
				}
			}
			return FALSE;
		}
		if(ret==HOSTERROR){
			setErrorCode("ERROR:027");
			if (atoi(externalPinPad)){ //EXTERNAL PINPAD
				if(strcmp (getTransactionType(), COMPLETION)){
					acknowledgePINPad ();
				}
			}
			return FALSE;
		}
		if(ret==RESPTIMEOUT||strlen(authResponse)<=0){
			setErrorCode("ERROR:028");
			if (atoi(externalPinPad)){ //EXTERNAL PINPAD
				if(strcmp (getTransactionType(), COMPLETION)){
					acknowledgePINPad ();
				}
			}
			return FALSE;
		}
		// Parse the message
		char temp[RESPONSE_LEN]={0};
		strcpy(temp,authResponse);
		char *msgHeader;
		msgHeader = strtok(temp,"<");
		// Parse the message, list of txn for refund
		if(!strcmp (getTransactionType(), REFUND))
			if(strlen(getTransReferenceNo())== 0){
				txnListResponseParser (&authResponse[strlen(msgHeader)]);
				GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, getResponseText(),
												GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
				return TRUE;
		}
		authResponseParser (&authResponse[strlen(msgHeader)]);
		if (strcmp(getErrorCode(),"ERROR:000")) {
			if (atoi(externalPinPad)) //EXTERNAL PINPAD
				acknowledgePINPad ();

			return FALSE;
		}

		// Message Adaptor
		if(!strcmp(getResponseCode(),"00")){
			if(!strcmp (getTransactionType(), REFUND))
				GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Refund done successfully",
													GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
			else
			GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, getResponseText(),
									              GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
		}
		else{
			if (!strcmp(getResponseCode(),"55")) {
				GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "ENTERED\nWRONG PIN",
						GL_ICON_INFORMATION, GL_BUTTON_ALL, 5*GL_TIME_SECOND);
			}
			else if (!strcmp(getResponseCode(),"75")) {
				GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "PIN TRY LIMIT\nEXCEEDED",
						GL_ICON_INFORMATION, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
			}
			else if (!strcmp(getResponseCode(),"01")) {
				GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Call Issuer Not Supported",
						GL_ICON_INFORMATION, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
			}
			GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, getResponseText(),
											GL_ICON_INFORMATION, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
		}
		if (atoi(externalPinPad)){ //EXTERNAL PINPAD
				if(strcmp (getTransactionType(), COMPLETION)){
					acknowledgePINPad ();
				}
		}

		if(getUserReceiptFlag()){
			printReceipt(APEMV_UI_GoalHandle(),MERCHANT_COPY,0);
			if(!strcmp(getResponseCode(),"00")){
				int result = GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Do You Want To Print \n Customer Copy?",
															GL_ICON_INFORMATION, GL_BUTTON_ALL, 20*GL_TIME_SECOND);
				if (result == GL_KEY_VALID)
					printReceipt(APEMV_UI_GoalHandle(),CUSTOMER_COPY,0);
			}
		}
		return TRUE;
	}
	else if (!strcmp(getTransactionType(),DUPLICATE_RECEIPT)){
		// Build Request Message for duplicate receipt
		char receiptRequest[8000] = {0};
		struct requestFields structReq = {0};
		char receptResponse[RESPONSE_LEN]={0};

		buildAuthorizationRequest (receiptRequest,&structReq);
		int ret=0, connectionScreen=0;
		// Route to host
		connectionScreen = GL_File_Exists("file://flash/HOST/GOV.GIF");
		if(connectionScreen==GL_SUCCESS){
			do{
				connectionScreen = GL_Dialog_Picture(APEMV_UI_GoalHandle(),NULL,"Connecting..","file://flash/HOST/GOV.GIF", 0, 1);                // Display BMP
				// Route to host
				ret = hostServiceCall(receiptRequest,receptResponse,0);
				if (ret == COMERROR)
					break;
				else if(ret == HOSTERROR)
					break;
				else if (ret == SERVERDOWN)
					break;
				else if(ret==RESPTIMEOUT || strlen(receptResponse)<= 0)
					break; // TIMER event has been received from the Telium Manager
				else
					break;

			}while(1);
		}
		//if connection screen not present
		else{
			GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Processing...", GL_ICON_INFORMATION, GL_BUTTON_ALL, 0);
			ret = hostServiceCall(receiptRequest,receptResponse,0);
		}
		if (ret == SERVERDOWN) {
			setErrorCode("ERROR:048");
			return FALSE;
		}
		if(ret==COMERROR) {
			if (atoi(externalPinPad)) //EXTERNAL PINPAD
				setErrorCode("ERROR:026");
			return FALSE;
		}
		if(ret==HOSTERROR){
			setErrorCode("ERROR:027");
			return FALSE;
		}
		if(ret==RESPTIMEOUT||strlen(receptResponse)<=0){
			setErrorCode("ERROR:028");
			return FALSE;
		}
		// Parse the message
		char temp[RESPONSE_LEN]={0};
		strcpy(temp,receptResponse);
		char *msgHeader;
		msgHeader = strtok(temp,"<");
		duplicateReceiptResponseParser (&receptResponse[strlen(msgHeader)]);
		//if (!strcmp(getResponseCode(),"00")) {
			if(getUserReceiptFlag()){
				printReceipt(APEMV_UI_GoalHandle(),MERCHANT_COPY,0);
				if(!strcmp(getResponseCode(),"00")){
					int result = GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Do You Want To Print \n Customer Copy?",
							GL_ICON_INFORMATION, GL_BUTTON_ALL, 20*GL_TIME_SECOND);
					if (result == GL_KEY_VALID)
						printReceipt(APEMV_UI_GoalHandle(),CUSTOMER_COPY,0);
				}
			}
		//}
		//else if (strcmp(getResponseCode(),"00"))
			//GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, getResponseText(), GL_ICON_INFORMATION, GL_BUTTON_ALL, 10*GL_TIME_SECOND);

		return TRUE;
	}
	else if(!strcmp (getTransactionType(), BATCH_SETTLE)){
		// Build Request Message
		char batchRequest[800] = {0};
		struct requestFields structReq = {0};
		char batchResponse[RESPONSE_LEN]={0};

		buildAuthorizationRequest (batchRequest,&structReq);
		if(strcmp(getErrorCode(),"ERROR:000"))
			return FALSE;

		int ret=0, connectionScreen=0;
		// Route to host
		connectionScreen = GL_File_Exists("file://flash/HOST/GOV.GIF");
		if(connectionScreen==GL_SUCCESS){
			do{
				connectionScreen = GL_Dialog_Picture(APEMV_UI_GoalHandle(),NULL,"Connecting..","file://flash/HOST/GOV.GIF", 0, 1);                // Display BMP
				// Route to host
				ret = hostServiceCall(batchRequest,batchResponse,0);
				if (ret == COMERROR)
					break;
				else if(ret == HOSTERROR)
					break;
				else if(ret==RESPTIMEOUT || strlen(batchResponse)<= 0)
					break; // TIMER event has been received from the Telium Manager
				else
					break;

			}while(1);
		}
		//if connection screen not present
		else{
			GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Processing...", GL_ICON_INFORMATION, GL_BUTTON_ALL, 0);
			ret = hostServiceCall(batchRequest,batchResponse,0);
		}

		if(ret==COMERROR) {
		if (atoi(externalPinPad)) //EXTERNAL PINPAD
			setErrorCode("ERROR:026");
			return FALSE;
		}
		if(ret==HOSTERROR){
			setErrorCode("ERROR:027");
			return FALSE;
		}
		if(ret==RESPTIMEOUT||strlen(batchResponse)<=0){
			setErrorCode("ERROR:028");
			return FALSE;
		}
		// Parse the message
		char temp[RESPONSE_LEN]={0};
		strcpy(temp,batchResponse);
		char *msgHeader=NULL;
		msgHeader = strtok(temp,"<");
		batchResponseParser (&batchResponse[strlen(msgHeader)]);
		// Message Adaptor
		 if (!strcmp(getErrorCode(),"ERROR:000")){
			printBatchReceipt(1);
		 }
	}
	else if(!strcmp (getTransactionType(), TRAN_SUM)){
		// Build Request Message
		char batchRequest[900] = {0};
		struct requestFields structReq = {0};
		char batchResponse[RESPONSE_LEN]={0};
		buildAuthorizationRequest (batchRequest,&structReq);
		if(strcmp(getErrorCode(),"ERROR:000"))
			return FALSE;

		int ret=0, connectionScreen=0;
		// Route to host
		connectionScreen = GL_File_Exists("file://flash/HOST/GOV.GIF");
		if(connectionScreen==GL_SUCCESS){
			do{
				connectionScreen = GL_Dialog_Picture(APEMV_UI_GoalHandle(),NULL,"Connecting..","file://flash/HOST/GOV.GIF", 0, 1);                // Display BMP
				// Route to host
				ret = hostServiceCall(batchRequest,batchResponse,0);
				if (ret == COMERROR)
					break;
				else if(ret == HOSTERROR)
					break;
				else if(ret==RESPTIMEOUT || strlen(batchResponse)<= 0)
					break; // TIMER event has been received from the Telium Manager
				else
					break;

			}while(1);
		}
		//if connection screen not present
		else{
			GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL, "Processing...", GL_ICON_INFORMATION, GL_BUTTON_ALL, 0);
			ret = hostServiceCall(batchRequest,batchResponse,0);
		}

		if(ret==COMERROR) {
		if (atoi(externalPinPad)) //EXTERNAL PINPAD
			setErrorCode("ERROR:026");
			return FALSE;
		}
		if(ret==HOSTERROR){
			setErrorCode("ERROR:027");
			return FALSE;
		}
		if(ret==RESPTIMEOUT||strlen(batchResponse)<=0){
			setErrorCode("ERROR:028");
			return FALSE;
		}
		// Parse the message
		char temp[RESPONSE_LEN]={0};
		strcpy(temp,batchResponse);
		char *msgHeader=NULL;
		msgHeader = strtok(temp,"<");
		batchResponseParser (&batchResponse[strlen(msgHeader)]);
		// Message Adaptor
		 if (!strcmp(getErrorCode(),"ERROR:000")){
			 printTranSummaryReceipt(1);
		 }
	}
}
