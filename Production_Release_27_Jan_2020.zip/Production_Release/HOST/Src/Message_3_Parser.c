
#include <sdk_tplus.h>
#include <XMLs.h>
#include "HostData.h"

char tagName[50];
struct sFeesApplied feeValues[MAX_FEE_COUNT] = {0};
int detailCount=0;
int feeCount=0;
int coreAuthflag=0;
int dupEntryType=0;
int duptrantype=0;
int dupcardInputType=0;
struct responseFeeDetails authRespDetails[MAX_FEE_COUNT] = {0};
int txnCount=0;
struct refundTxnListBuffer txnList[15] = {0};
//Batch start
struct mBatch mBatchDetais={0};
struct mSubBatch mSubBatchdetails[50]={0};
int batchcnt=0;
int totalbatchcnt=0;
int totalloopbatch=0;
//Batch End
static void __XmlStartElement( XMLs_PARSER hXml, const char* szName, XMLs_ATTRIBUTE_HANDLE hAttribute ){
	memset(tagName, 0, sizeof(tagName));
	strcpy(tagName,szName);
}
static void __XmlEndElement( XMLs_PARSER hXml, const char* szName ){
	if(!strcmp(szName,"detail"))
		++detailCount;
}
static void handleFeeData( XMLs_PARSER hXml, const char* pcDataBuffer, unsigned int nDataLength )   {
	char* szData = XMLs_ProcessData( pcDataBuffer, nDataLength, XML_DATA_ALL );
	if( szData != NULL ){
		if(!strcmp(tagName,"result"))
			setFeeResult(szData);
		else if(!strcmp(tagName,"resCode"))
			setFeeResponseCode(szData);
		else if(!strcmp(tagName,"resMsg"))
			setFeeRespMsg(szData);
		else if(!strcmp(tagName,"amount"))
			memcpy(feeValues[feeCount].feeAmount,szData,strlen(szData));
		else if(!strcmp(tagName,"mid"))
			memcpy(feeValues[feeCount].feeMID,szData,strlen(szData));
		else if(!strcmp(tagName,"charges")){
			memcpy(feeValues[feeCount].feeType,"CHARG",5);
			memcpy(feeValues[feeCount].feeAmount,szData,strlen(szData));
			memcpy(feeValues[feeCount].feeCharges,szData,strlen(szData));
			feeCount=feeCount+1;
		}
		else if(!strcmp(tagName,"type")){
			memcpy(feeValues[feeCount].feeType,szData,strlen(szData));
			++feeCount;
		}
	}
}
static void handleRefundTxnData( XMLs_PARSER hXml, const char* pcDataBuffer, unsigned int nDataLength )   {
	char* respTagValue = XMLs_ProcessData( pcDataBuffer, nDataLength, XML_DATA_ALL );
	if( respTagValue != NULL ){
		if(!strcmp(tagName,"resTime"))
			memcpy(txnList[txnCount].txnDate,respTagValue,strlen(respTagValue));
		else if(!strcmp(tagName,"amount"))
			memcpy(txnList[txnCount].txnAmount,respTagValue,strlen(respTagValue));
		else if(!strcmp(tagName,"trxnId")){
			memcpy(txnList[txnCount].txn_ReferenceNo,respTagValue,strlen(respTagValue));
			++txnCount;
		}
		else if(!strcmp(tagName,"cardHolderName"))
			memcpy(txnList[txnCount].txn_CardHolderName,respTagValue,strlen(respTagValue));
		else if(!strcmp(tagName,"resMsg"))
			setResponseText(respTagValue);
	}
}
static void handleAuthData( XMLs_PARSER hXml, const char* pcDataBuffer, unsigned int nDataLength )   {
	char* respTagValue = XMLs_ProcessData( pcDataBuffer, nDataLength, XML_DATA_ALL );
	   if( respTagValue != NULL ){
			if(!strcmp(tagName,"result"))
				setResponseResult(respTagValue);
			else if(!strcmp(tagName,"resCode"))
				setResponseCode(respTagValue);
			else if(!strcmp(tagName,"resMsg"))
				setResponseText(respTagValue);
			else if(!strcmp(tagName,"resDfn"))
				setResponseDefination(respTagValue);
			else if(!strcmp(tagName,"mid"))
				setResponseMID(respTagValue);
			else if(!strcmp(tagName,"tid"))
				setResponseTermID(respTagValue);
			else if(!strcmp(tagName,"resTime"))
				setTxnDateTime(respTagValue);
			else if(!strcmp(tagName,"currencyCode"))
				setTxnCurrency(respTagValue);
			else if(!strcmp(tagName,"accNo"))
				setRespCardNumber(respTagValue);
			else if(!strcmp(tagName,"cardExpDt"))
				setRespCardExpDate(respTagValue);
			else if(!strcmp(tagName,"tokenID"))
				setRespTokenID(respTagValue);
			else if(!strcmp(tagName,"trxnID"))
				setRespTxnSequenceNo(respTagValue);
			else if(!strcmp(tagName,"cardBrand"))
				setCardBrand(respTagValue);
			else if(!strcmp(tagName,"authCode")){
				if(coreAuthflag){
				setAuthCode(respTagValue);
				coreAuthflag=0;
				}
			}
			else if(!strcmp(tagName,"captureStatus")){
				if(!strcmp(respTagValue,"True"))
					setResponseCode("00");
			}
			else if(!strcmp(tagName,"message")){
				setResponseText(respTagValue);
			}
			else if(!strcmp(tagName,"cardNumber")){
				char cardnum[24]={0};
				strcpy(cardnum, respTagValue + (strlen(respTagValue) -4));
				setCardNumber (cardnum, strlen(cardnum));
			}
			else if(!strcmp(tagName, "terminalFileVersionName")){
				char mTMSFileVer[20 +1]={0};
				memcpy(mTMSFileVer,respTagValue,sizeof(mTMSFileVer) -1);
				memset(&mTMSFileVer[strlen(mTMSFileVer)], ' ', sizeof(mTMSFileVer) -1 -strlen(mTMSFileVer));
				saveAdminParameter("SOFTWARE_VERSION",mTMSFileVer);
			}
			else if(!strcmp(tagName,"type")){
				memcpy(feeValues[feeCount].feeType,respTagValue,strlen(respTagValue));
				feeCount++;
			}
			else if(!strcmp(tagName,"amount")){
				memcpy(feeValues[feeCount].feeAmount,respTagValue,strlen(respTagValue));
			}
	   }
}
static void handleBatchData( XMLs_PARSER hXml, const char* pcDataBuffer, unsigned int nDataLength )   {
	char* respTagValue = XMLs_ProcessData( pcDataBuffer, nDataLength, XML_DATA_ALL );
	   if( respTagValue != NULL ){
		   if(!strcmp(tagName,"totalCount")){
			   strcpy(mSubBatchdetails[batchcnt].subTotalCount, respTagValue);
			   totalbatchcnt= totalbatchcnt + atoi(mSubBatchdetails[batchcnt].subTotalCount);
			   totalloopbatch = totalloopbatch +1;
			   sprintf(mSubBatchdetails[batchcnt].subTotalCount, "%d", totalbatchcnt);
			   sprintf(mBatchDetais.mTotalcount, "%d", totalloopbatch);
		   }
		   else if(!strcmp(tagName,"clerkId"))
			   mSubBatchdetails[batchcnt].mClerkid=atoi(respTagValue);
		   else if(!strcmp(tagName,"merchantName"))
		  		  strcpy(mSubBatchdetails[batchcnt].mMerchantName, respTagValue);
		   else if(!strcmp(tagName,"trxnType")){
			   if(strcmp(respTagValue, "REFUND"))
				   strcpy(mSubBatchdetails[batchcnt].mType, respTagValue);
			   else
				   strcpy(mSubBatchdetails[batchcnt].mType, "REFU");
			   batchcnt++;
		   }
		   else if(!strcmp(tagName,"saleAmount")){
			   if(strcmp(respTagValue, "0"))
			   strcpy(mSubBatchdetails[batchcnt].mAmount,respTagValue );
		   }
		   else if(!strcmp(tagName,"totalSaleAmt"))
			   strcpy(mSubBatchdetails[batchcnt].mNetAmt,respTagValue );
		   else if(!strcmp(tagName,"refundAmount")){
			   if(strcmp(respTagValue, "0"))
			   strcpy(mSubBatchdetails[batchcnt].mRefundAmount,respTagValue );
		   }
		   else if(!strcmp(tagName,"totalRefundAmt"))
			   strcpy(mSubBatchdetails[batchcnt].mrefundNetAmt,respTagValue );

		   else if(!strcmp(tagName,"trxnId")){
			   strcpy(mSubBatchdetails[batchcnt].mTransactionId, (respTagValue + (strlen(respTagValue) -4)));
			   //batchcnt++;
		   }
		   else if(!strcmp(tagName,"refundTotal"))
			   strcpy(mBatchDetais.mRefundTotal, respTagValue);
		   else if(!strcmp(tagName,"subTotal"))
			   strcpy(mBatchDetais.mGrandTotal, respTagValue);
		   else if(!strcmp(tagName,"isIfinswitchErr"))
                setErrorCode("ERROR:BATCH");
		   else if(!strcmp(tagName,"resMsg"))
			   GL_Dialog_Message(APEMV_UI_GoalHandle(), "STATUS", respTagValue, NULL, GL_BUTTON_ALL, 5*GL_TIME_SECOND);

	   }
}
static void handleDuplicateReceiptData( XMLs_PARSER hXml, const char* pcDataBuffer, unsigned int nDataLength )   {
	char* respTagValue = XMLs_ProcessData( pcDataBuffer, nDataLength, XML_DATA_ALL );
	   if( respTagValue != NULL ){
			if(!strcmp(tagName,"result"))
				setResponseResult(respTagValue);
			else if(!strcmp(tagName,"resCode"))
				setResponseCode(respTagValue);
			else if(!strcmp(tagName,"resMsg"))
				setResponseText(respTagValue);
			else if(!strcmp(tagName,"mid"))
				setDepartmentName(respTagValue);
			else if(!strcmp(tagName,"tid"))
				setResponseTermID(respTagValue);
			else if(!strcmp(tagName, "custName"))
				setCardHolderName(respTagValue, 18);
			else if(!strcmp(tagName,"resTime"))
				setTxnDateTime(respTagValue);
			else if(!strcmp(tagName,"currencyCode"))
				setTxnCurrency(respTagValue);
			else if(!strcmp(tagName,"udf1"))
				setReferenceNo(respTagValue);
			else if(!strcmp(tagName,"trxnType"))
			{
				if(duptrantype){
				setResponseTxnType(respTagValue);
				duptrantype=0;
				}
			}
			else if(!strcmp(tagName,"cardType")){
				if(dupEntryType){
				if (!strcmp(respTagValue,"CREDIT_CARD"))
					setCardType(CREDIT);
				else
					setCardType(DEBIT);
				dupEntryType=0;
				}
			}
			else if(!strcmp(tagName,"cardNumber"))
				setRespCardNumber(respTagValue);
			else if(!strcmp(tagName,"cardExpDt"))
				setRespCardExpDate(respTagValue);
			else if(!strcmp(tagName,"tokenID"))
				setRespTokenID(respTagValue);
			else if(!strcmp(tagName,"trxnID"))
				setRespTxnSequenceNo(respTagValue);
			else if(!strcmp(tagName,"cardBrand"))
				setCardBrand(respTagValue);
			else if(!strcmp(tagName,"authCode")){
				if(coreAuthflag){
				setAuthCode(respTagValue);
				coreAuthflag=0;
				}
			}
			else if(!strcmp(tagName,"cardInputType")){
				if (strcmp(respTagValue,"MANUALENTRY"))
					setCardInputMode(respTagValue);
			}
			else if(!strcmp(tagName,"captureStatus")){
				if(!strcmp(respTagValue,"True"))
					setResponseCode("00");
			}
			else if(!strcmp(tagName,"message")){
				setResponseText(respTagValue);
			}
			else if(!strcmp(tagName,"type")){
				memcpy(feeValues[feeCount].feeType,respTagValue,strlen(respTagValue));
				feeCount++;
			}
			else if(!strcmp(tagName,"amount")){
				memcpy(feeValues[feeCount].feeAmount,respTagValue,strlen(respTagValue));
			}
	   }
}
void feeResponseParser (const char* xmlData){
	XMLs_PARSER hXml;
	int nStartTags = 0;
	int nReturn;
	memset(feeValues,0,MAX_FEE_COUNT*sizeof(struct sFeesApplied));
	feeCount=0;
	hXml = XMLs_Create();
	if( hXml != NULL ) {
		XMLs_SetOption( hXml, XMLs_START_ELEMENT_HANDLER, __XmlStartElement );
		XMLs_SetOption( hXml, XMLs_END_ELEMENT_HANDLER, __XmlEndElement );
		XMLs_SetOption( hXml, XMLs_DATA_HANDLER, handleFeeData );
		XMLs_SetUserData( hXml, &nStartTags );
		nReturn = XMLs_ParseBuffer( hXml, xmlData, strlen(xmlData) );
		if( nReturn != XMLS_OK )
		{
			setErrorCode("ERROR:032");
			return FALSE;
		}
	    setProprietaryData (feeValues,feeCount);
	   XMLs_Destroy( hXml );
	}
	return;
}
int authResponseParser(const char* xmlData){
	XMLs_PARSER hXml;
	int nStartTags = 0;
	int nReturn;
	detailCount=0;
	coreAuthflag=1;
	memset(feeValues,0,MAX_FEE_COUNT*sizeof(struct sFeesApplied));
	feeCount=0;
	hXml = XMLs_Create();
	if( hXml != NULL ) {
		XMLs_SetOption( hXml, XMLs_START_ELEMENT_HANDLER, __XmlStartElement );
		XMLs_SetOption( hXml, XMLs_END_ELEMENT_HANDLER, __XmlEndElement );
		XMLs_SetOption( hXml, XMLs_DATA_HANDLER, handleAuthData);
		XMLs_SetUserData( hXml, &nStartTags );
		nReturn = XMLs_ParseBuffer( hXml, xmlData, strlen(xmlData) );
	   if( nReturn != XMLS_OK )
	   {
		   setErrorCode("ERROR:032");
		   return FALSE;
	   }
	   setProprietaryData (feeValues,feeCount);
	   XMLs_Destroy( hXml );
	}
	return TRUE;
}
int batchResponseParser(const char* xmlData){
	XMLs_PARSER hXml;
	int nStartTags = 0;
	int nReturn;
	detailCount=0;
	batchcnt=0;
	totalbatchcnt=0;
	totalloopbatch=0;
	memset(&mSubBatchdetails,0,sizeof(mSubBatchdetails));
	memset(&mBatchDetais, 0, sizeof(mBatchDetais));
	hXml = XMLs_Create();
	if( hXml != NULL ) {
		XMLs_SetOption( hXml, XMLs_START_ELEMENT_HANDLER, __XmlStartElement );
		XMLs_SetOption( hXml, XMLs_END_ELEMENT_HANDLER, __XmlEndElement );
		XMLs_SetOption( hXml, XMLs_DATA_HANDLER, handleBatchData);
		XMLs_SetUserData( hXml, &nStartTags );
		nReturn = XMLs_ParseBuffer( hXml, xmlData, strlen(xmlData) );
	   if( nReturn != XMLS_OK )
	   {
		   setErrorCode("ERROR:032");
		   return FALSE;
	   }
	   XMLs_Destroy( hXml );
	}
	return TRUE;
}

void txnListResponseParser (const char* xmlData){
	XMLs_PARSER hXml;
	int nStartTags = 0;
	int nReturn;
	memset(txnList,0,MAXIMIUM_TXN_IN_A_LIST*sizeof(struct refundTxnListBuffer));
	txnCount=0;
	hXml = XMLs_Create();
	if( hXml != NULL ) {
		XMLs_SetOption( hXml, XMLs_START_ELEMENT_HANDLER, __XmlStartElement );
		XMLs_SetOption( hXml, XMLs_END_ELEMENT_HANDLER, __XmlEndElement );
		XMLs_SetOption( hXml, XMLs_DATA_HANDLER, handleRefundTxnData );
		XMLs_SetUserData( hXml, &nStartTags );
		nReturn = XMLs_ParseBuffer( hXml, xmlData, strlen(xmlData) );
		if( nReturn != XMLS_OK )
	   	{
		   setErrorCode("ERROR:032");
		   return FALSE;
	   	}else{
		   setTxnListForRefund (txnList,txnCount);
	   }
	   XMLs_Destroy( hXml );
	}
	return;
}

int duplicateReceiptResponseParser(const char* xmlData){
	XMLs_PARSER hXml;
	int nStartTags = 0;
	int nReturn;
	detailCount=0;
	feeCount=0;
	dupEntryType=1;
	duptrantype=1;
	coreAuthflag=1;
	dupcardInputType=1;
	memset(feeValues,0,sizeof(feeValues));
	hXml = XMLs_Create();
	if( hXml != NULL ) {
		XMLs_SetOption( hXml, XMLs_START_ELEMENT_HANDLER, __XmlStartElement );
		XMLs_SetOption( hXml, XMLs_END_ELEMENT_HANDLER, __XmlEndElement );
		XMLs_SetOption( hXml, XMLs_DATA_HANDLER, handleDuplicateReceiptData);
		XMLs_SetUserData( hXml, &nStartTags );
		nReturn = XMLs_ParseBuffer( hXml, xmlData, strlen(xmlData) );
	   if( nReturn != XMLS_OK )
	   {
		   setErrorCode("ERROR:032");
		   return FALSE;
	   }
	   else {
		   setProprietaryData (feeValues,feeCount);
	   }
	   XMLs_Destroy( hXml );
	}
	return TRUE;
}
