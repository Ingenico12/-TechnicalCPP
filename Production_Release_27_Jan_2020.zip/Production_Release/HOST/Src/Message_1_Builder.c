#include <sdk_tplus.h>
#include "schVar_def.h"
#include "IP_.h"
#include "HostData.h"
#include "_emvdctag_.h"
#include "EmvLib_Tags.h"
#include "PayPass_Tags.h"

#define ENABLE_RSA

char httpAuthHeader[] =
				"POST /payment-services/v1/card/payment HTTP/1.0\r\n"
				"Content-Type: application/xml\r\n"
				"apiKey: %s\r\n"
				"externalReferenceID: %d\r\n"
				"transactionDate: %s\r\n"
				"clerkID: %s\r\n"
				"source: %s\r\n"
				"ipAddress: %s\r\n"
				"Content-Length: %d\r\n\r\n";

char httpRefundListHeader[] =
				"POST /payment-services/fetchCardTransactionByLast4Digit HTTP/1.0\r\n"
				"Content-Type: application/xml\r\n"
				"apiKey: %s\r\n"
				"Content-Length: %d\r\n\r\n";

char refundTxnListRequestSchema[] = "<cardTransactionsRequest>\r\n"
									"     <mid>%s</mid>\r\n"
									"     <cardLast4Digit>%s</cardLast4Digit>\r\n"
									"</cardTransactionsRequest>\r\n";

char httpDuplicateReceiptHeader[] =
				"POST /payment-services/v1.1/getTransactionReceipt HTTP/1.0\r\n"
				"Content-Type: application/xml\r\n"
				"Content-Length: %d\r\n\r\n";

char duplicateReceiptRequestSchema[] =
									"<cardTransactionsRequest>\r\n"
									"<terminalId>%s</terminalId>\r\n"
									"<cardLast4Digit>%s</cardLast4Digit>\r\n"
									"<trxnId>%s</trxnId>\r\n"
									"</cardTransactionsRequest>\r\n";


/*char httpFeeHeader[]="GET /payment-services/v1.1/calculateFee/%s/%s.%s/%s/%s HTTP/1.0\r\n" //Fees
					"Accept: application/xml\r\n\r\n";
					//"Content-Type: application/xml\r\n\r\n";*/
char httpFeeHeader[]="POST /payment-services/v1.2/calculateFee HTTP/1.0\r\n" //Fees
						"Content-Type: application/xml\r\n"
						"Content-Length: %d\r\n\r\n";
char httpFeeBody[]=
		"<calculateFeeRequest>\r\n"
		"<trxnType>%s</trxnType>\r\n"
		"<mid>%s</mid>\r\n"
		"<trxnAmount>%s.%s</trxnAmount>\r\n"
		"<paymentType>%s</paymentType>\r\n"
		"<trxnId>%s</trxnId>\r\n"
		"</calculateFeeRequest>\r\n";

char httpAutoReverseHeader[]=
						"POST /ifinswitch-1712605549.us-east-1.elb.amazonaws.com/payment-services/card/payment HTTP/1.0\r\n"
						"Content-Type: application/xml\r\n"
						"apiKey: %s\r\n"
						"externalReferenceID: %d\r\n"
						"transactionDate: %s\r\n"
						"ipAddress: %s\r\n"
						"Content-Length: %d\r\n\r\n";
char reversalReqSchema[]=
		"<cardPaymentRequest>\r\n"
		"	<mid>%s</mid>\r\n"
		"	<terminalNumber>%s</terminalNumber>\r\n"
		"   <txnSequenceNumber>%s</txnSequenceNumber>\r\n"
		"	<refTxnID>%s</refTxnID>\r\n"
		"		<transactions>\r\n"
		"			%s"
		"		</transactions>\r\n"
		"<trxnType>VOID</trxnType>\r\n"
		"   <udfs>\r\n"
		"   <udf1>%s</udf1>\r\n"
		"   </udfs>\r\n"
		"</cardPaymentRequest>\r\n";
char autoReversalReqSchema[]=
		"<cardPaymentRequest>\r\n"
		"	<terminalNumber>%s</terminalNumber>\r\n"
		"	<refTxnID>%s</refTxnID>\r\n"
		"   <txnSequenceNumber>%s</txnSequenceNumber>\r\n"
		"	</transactions>\r\n"
		"	</detail>\r\n"
		"			<amount>%s</amount>\r\n"
		"		<mid>%s</mid>\r\n"
		"		<type>CORE</type>\r\n"
		"		<cardInputType>%s</cardInputType>\r\n"
		"		</detail>\r\n"
		"	</transactions>\r\n"
		"	<trxnType>VOID</trxnType>\r\n"
		"   <udfs>\r\n"
		"   <udf1>%s</udf1>\r\n"
		"   </udfs>\r\n"
		"</cardPaymentRequest>\r\n";
char level2_Amex[]=
		  "<supplierRefNum>%s</supplierRefNum>\r\n"
		  "<cardHldrRefNum>%s</cardHldrRefNum>\r\n"
		  "<shipToZip>%s</shipToZip>\r\n"
		  "<salesTaxAmt>%s</salesTaxAmt>\r\n"
		  "<chargeDesc1>%s</chargeDesc1>\r\n"
		  "<requesterName>%s</requesterName>\r\n"
		  "<totalTaxAmount>%s</totalTaxAmount>\r\n"
		  "<taxTypeCode>%s</taxTypeCode>\r\n"
		  /*"<costPerUnit></costPerUnit>\r\n"
		  "<lineItemTotCount></lineItemTotCount>\r\n"
		  "<altTaxID></altTaxID>\r\n"
		  "<taxTypeApplied></taxTypeApplied>\r\n"
		  "<discInd></discInd>\r\n"
		  "<netGrossInd></netGrossInd>\r\n"
		  "<extItemAmt></extItemAmt>\r\n"
		  "<drCrInd></drCrInd>\r\n"
		  "<itemDiscRate></itemDiscRate>\r\n"
		  "<itemQtyExpInd></itemQtyExpInd>\r\n"
		  "<itemDiscExpInd></itemDiscExpInd>\r\n"*/;

char leve2_MasterVisa[]=
		  "<optAmtID>%s</optAmtID>\r\n"
		  "<optAmt>%s</optAmt>\r\n"
		  "<poNumber>%s</poNumber>\r\n"
		  "<purchaseIDFormat>%s</purchaseIDFormat>\r\n"
		  "<purchaseID>%s</purchaseID>\r\n"
		  "<localTaxInclFlag>%s</localTaxInclFlag>\r\n"
		  "<localTax>%s</localTax>\r\n"
		  "<natTaxInclFlag>%s</natTaxInclFlag>\r\n"
		  "<natTax>%s</natTax>\r\n"
		  "<freightAmt>%s</freightAmt>\r\n"
		  "<dutyAmt>%s</dutyAmt>\r\n"
		  "<destZip>%s</destZip>\r\n"
		  "<shippingZip>%s</shippingZip>\r\n"
		  "<destCountryCode>%s</destCountryCode>\r\n"
		  "<lineItemCount>%s</lineItemCount>\r\n"
		  "<mcVATRegNumber>%s</mcVATRegNumber>\r\n"
		  "<custVATRegNumber>%s</custVATRegNumber>\r\n"
		  "<summaryCommodityCd>%s</summaryCommodityCd>\r\n"
		  "<vatInvcRefNumber>%s</vatInvcRefNumber>\r\n"
		  "<orderDate>%s</orderDate>\r\n"
		  "<discAmt>%s</discAmt>\r\n"
		  "<vatTaxAmt>%s</vatTaxAmt>\r\n"
		  "<vatTaxRate>%s</vatTaxRate>\r\n"
		  "<altTaxAmtInd>%s</altTaxAmtInd>\r\n"
		  "<altTaxAmt>%s</altTaxAmt>\r\n";


char level3_MasterVisa[]=
		"<productDesc>%s</productDesc>\r\n"
		  "<productCd>%s</productCd>\r\n"
		  "<productQuantity>%s</productQuantity>\r\n"
		  "<productMeasurementUnit>%s</productMeasurementUnit>\r\n"
		  "<productCommodityCd>%s</productCommodityCd>\r\n"

		  "<costPerUnit>%s</costPerUnit>\r\n"
		   "<lineItemTotCount>%s</lineItemTotCount>\r\n"
		  "<altTaxID>%s</altTaxID>\r\n"
		  "<taxTypeApplied>%s</taxTypeApplied>\r\n"
		  "<discInd>%s</discInd>\r\n"
		  "<netGrossInd>%s</netGrossInd>\r\n"
		  "<extItemAmt>%s</extItemAmt>\r\n"
		  "<drCrInd>%s</drCrInd>\r\n"
		  "<itemDiscRate>%s</itemDiscRate>\r\n"
		  "<itemQtyExpInd>%s</itemQtyExpInd>\r\n"
		  "<itemDiscExpInd>%s</itemDiscExpInd>\r\n";

char purchaseRequestSchema[]=
		"<cardPaymentRequest>\r\n"
		"  <terminalNumber>%s</terminalNumber>\r\n"
		"  <cardType>%s</cardType>\r\n"
		"  <currencyCode>%s</currencyCode>\r\n"
		"  <txnSequenceNumber>%s</txnSequenceNumber>\r\n"
		"  <trxnCode>%s</trxnCode>\r\n"
		"  <refTxnID>%s</refTxnID>\r\n"
		"  <cardHolderIDVerificationCode>%s</cardHolderIDVerificationCode>\r\n"
		"  <cardHolderData>%s</cardHolderData>\r\n"
		"  <custAddress>%s</custAddress>\r\n"
		"  <custCity>%s</custCity>\r\n"
		"  <custState>%s</custState>\r\n"
		"  <custZip>%s</custZip>\r\n"
		"  <accountDataSource>%s</accountDataSource>\r\n"
		"  <customerTrack2Data>%s</customerTrack2Data>\r\n"
		"  <chipConditionCode>%s</chipConditionCode>\r\n"
		"  <transactions>\r\n"
		"		%s"
		"  </transactions>\r\n\r\n"
		"  <cardNumber>%s</cardNumber>\r\n"
		"  <cardExpirationDate>%s</cardExpirationDate>\r\n"
		"  <cardCvv2>%s</cardCvv2>\r\n"
		"  <trxnType>%s</trxnType>\r\n"
		"  <posDataCode>%s</posDataCode>\r\n"
		"  <motoIndicator></motoIndicator>\r\n"
		"  <custName>%s</custName>\r\n"
		"  <tlvData>%s</tlvData>\r\n"
		"<level2Dtls>\r\n"
		"	%s"
		"</level2Dtls>\r\n"
		  "<level3Dtls>\r\n"
		  "%s"
		"</level3Dtls>\r\n"
		"   <udfs>\r\n"
		"   <udf1>%s</udf1>\r\n"
		"   </udfs>\r\n"
		"</cardPaymentRequest>\r\n";
char subSequestTxnSchema[] = "GET /payment-services/captureTransaction/%s HTTP/1.0\r\n"
							 "Accept: application/xml\r\n\r\n";
char BatchReqHeader[]= "POST /payment-services/batch/summary HTTP/1.0\r\n"
							"Content-Type: application/xml\r\n"
							"Content-Length: %d\r\n\r\n";
char BatchReqBody[]=
				"<batchSummaryRequest>\r\n"
				"<mid>%s</mid>\r\n"
				"<terminalId>%s</terminalId>\r\n"
				"<clerkId>%s</clerkId>\r\n"
				"</batchSummaryRequest>\r\n";

char BatchAllReqBody[]=
				"<batchSummaryRequest>\r\n"
				"<terminalId>%s</terminalId>\r\n"
				"</batchSummaryRequest>\r\n";

char txnDetails[] =
		"  		<detail>\r\n"
		"       	<amount>%s</amount>\r\n"
		"           <mid>%s</mid>\r\n"
		"           <type>%s</type>\r\n"
		"  			<cardInputType>%s</cardInputType>\r\n"
		"    	</detail>\r\n";



int buildCalculateFeeRequest (char *feeURL,char *txnType) {
	char txnAmount[13]={0};
	memcpy(txnAmount,getInputAmount(),sizeof(txnAmount)-1);
	unsigned long long userAmt= strtoull(txnAmount,NULL,10);
	char merchantID[20]={0};
	char baseAmount[10+1]={0};
	char decimalAmount[2+1]={0};
	char feeheader[500]={0};
	char feereq[3000]={0};
	ulltostr(userAmt/100,baseAmount,10);
	memcpy(decimalAmount,&txnAmount[strlen(txnAmount)-2],2);
	// <cardType>
	char cardType[10]={0};
	strcpy(cardType, (getCardType () == CREDIT? "credit" :
					 (getCardType () == DEBIT ? "debit" 	:
										       "")));
	 strcpy(merchantID,getDeptMID());
	if(!strcmp(txnType,PURCHASE))
		sprintf(feereq, httpFeeBody, "AUTH",merchantID,baseAmount,decimalAmount,cardType,getTransReferenceNo());
	else if(!strcmp(txnType,REFUND))
		sprintf(feereq, httpFeeBody,"REFUND",merchantID,baseAmount,decimalAmount,cardType,getTransReferenceNo());
	else if(!strcmp(txnType,FULL_REVERSAL))
		sprintf(feereq, httpFeeBody, "VOID",merchantID,baseAmount,decimalAmount,cardType,getTransReferenceNo());
	sprintf(feeheader, httpFeeHeader, strlen(feereq));
	strcpy(feeURL,feeheader);
	strcat(feeURL, feereq);
	return TRUE;
}
void buildAuthorizationRequest (char *finalReq, struct requestFields *reqStruct){
	char authAPIKey[50]={0};
	DATE date={0};
	char localIP[15+1]={0};
	unsigned int local_addr = 0;
	unsigned char *p;
	int amexCard=0;
	memset(serial, 0, sizeof(serial));
	PSQ_Give_Serial_Number(serial);
#ifdef ENABLE_RSA
			unsigned char encryptData[64]={0};
			char encCardNo[128+1]={0};
			int encCardLen;
			getCardNumber (encCardNo,&encCardLen);
			if(!memcmp (encCardNo, "34", 2) || !memcmp (encCardNo, "37", 2)){
				amexCard = 1;
			}
			// <cardNumber>
			if(strlen(encCardNo)){
				memset(encryptData,0,sizeof(encryptData));
				memcpy(&encryptData[sizeof(encryptData)-strlen(encCardNo)],encCardNo,strlen(encCardNo));
				if(encryptDataRSA(encryptData,encryptData)){
					memcpy(reqStruct->cardNo,hexToASCII(encryptData,sizeof(encryptData)),2*sizeof(encryptData));
				}
				else {
					setErrorCode("ERROR:038");
				}
			}
			if (strcmp(getCardInputMode(),MANUALENTRY)) {
				char externalPinPad[2]={0};
				getPinPadMode(externalPinPad);
				int trk2Length;
				getTrack2Data (reqStruct->customerData,&trk2Length);
				if(trk2Length){
					unsigned char trk2Data[64]={0};
					memcpy(&trk2Data[sizeof(trk2Data)-trk2Length],reqStruct->customerData,trk2Length);
					if(encryptDataRSA(trk2Data,trk2Data)){
						memcpy(reqStruct->customerData,hexToASCII(trk2Data,sizeof(trk2Data)),2*sizeof(trk2Data));
					}
					else {
						setErrorCode("ERROR:038");
						if (atoi(externalPinPad)) //EXTERNAL PINPAD
							acknowledgePINPad();
					}

				} else {
					if (!strcmp(getTransactionType(),PURCHASE)||!strcmp(getTransactionType(),PREAUTH)) {
						setErrorCode("ERROR:039");
						if (atoi(externalPinPad)) //EXTERNAL PINPAD
							acknowledgePINPad();
					}
					else if (!strcmp(getTransactionType(),REFUND)) {
						char txnRefNo[20+1]={0};
						strcpy(txnRefNo, getTransReferenceNo());
						if (strlen(txnRefNo)!=0) {
							setErrorCode("ERROR:039");
							if (atoi(externalPinPad)) //EXTERNAL PINPAD
								acknowledgePINPad();
						}
					}
				}
			}

#endif
	if(!strcmp(getTransactionType(),PURCHASE)||!strcmp(getTransactionType(),PREAUTH)){
		struct sFeesApplied reqFee[3]={0};
		char authReq[8000]={0};
		int motoIndicator = 7;    //TODO: temp coding for gateway. motoindicator must be 0 for CP txn. will update
		Telium_Read_date(&date);
		sprintf(reqStruct->timeStamp,"20%2.2s-%2.2s-%2.2s %2.2s:%2.2s:%2.2s",date.year,date.month,date.day, date.hour, date.minute, date.second);
		EthernetGetOption(ETH_IFO_ADDR, &local_addr );
		p = (char *) &local_addr;
		sprintf(localIP, "%d.%d.%d.%d", p[0], p[1], p[2], p[3] );
		strcpy(authAPIKey,getDeptAPIKey());
		reqStruct->referenceID = atoi (getUserTxnSequnceNo());
		//expire card validation
		char bufferCardExp[4+1]={0};
		memcpy(bufferCardExp,getCardExpiryDate(),sizeof(bufferCardExp)-1);
		if(strlen(bufferCardExp)){
			char currentYear[2+1]={0};
			char cardYear[2+1]={0};
			memcpy(currentYear,date.year,2);
			memcpy(cardYear,bufferCardExp,2);
			if(atoi(cardYear)==atoi(currentYear)){  //year checking
				char currentMonth[2+1]={0};
				char cardMonth[2+1]={0};
				memcpy(currentMonth,date.month,2);
				memcpy(cardMonth,&bufferCardExp[2],2);
				if(atoi(cardMonth)<atoi(currentMonth))	//month checking
					setErrorCode("ERROR:002");
			}
			else if (atoi(cardYear)<atoi(currentYear))
				setErrorCode("ERROR:002");
		  }

		// <terminalNumber>
		strcpy(reqStruct->terminalNo,getUserTerminalID());
		//Reference field
		strcpy(reqStruct->rOrderID, getReferenceNo());
		//<clerk ID>
		char clerkID[6+1]={0};
		char source[15+1]={0};
		getClerkId(clerkID);
		strcpy(reqStruct->rClerkID,clerkID);
		strcpy(reqStruct->rSource,"POS-Terminal");
		// <cardType>
		char cardType = 0;
		cardType = getCardType ();

		strcpy(reqStruct->cardType, (cardType == CREDIT ? "CREDIT_CARD" :
									(cardType == DEBIT 	? "DEBIT_CARD" 	:
														  "")));
		//custName
		if(strlen(getCardHolderName())>0)
			strcpy(reqStruct->custName,getCardHolderName());
		// <currencyCode>
		strcpy(reqStruct->currencyCode,getUserCurrencyCode());

		// <txnSequenceNumber>
		strcpy(reqStruct->txnSequence,getUserTxnSequnceNo());
		setTxnSequenceNo();

		strcpy(reqStruct->txnType,getTransactionType());

		// <trxnCode>
		if(cardType == CREDIT){
			strcpy (reqStruct->txnCode, (!strcmp(reqStruct->txnType, PURCHASE) 			? "PURCHASE" :
										(!strcmp(reqStruct->txnType, PREAUTH) 			? "PURCHASE" :
										(!strcmp(reqStruct->txnType, REFUND) 			? "PURCHASE_RETURN_AUTH" :
										(!strcmp(reqStruct->txnType, PARTIAL_REVERSAL) 	? "ONLINE_AUTHORIZATION_REVERSAL" :
										(!strcmp(reqStruct->txnType, FULL_REVERSAL) 	? "ONLINE_AUTHORIZATION_REVERSAL" :
										(!strcmp(reqStruct->txnType, AUTO_REVERSAL) 	? "ONLINE_AUTHORIZATION_REVERSAL" :
																						  "UNKNOWN")))))));
		}
		else if(cardType == DEBIT){ //TODO:Nedd to verify
			strcpy  (reqStruct->txnCode, (!strcmp(reqStruct->txnType, PURCHASE) 		? "DIRECT_DEBIT_PURCHASE" :
										 (!strcmp(reqStruct->txnType, REFUND) 			? "DIRECT_DEBIT_PURCHASE_RETURN" :
										 (!strcmp(reqStruct->txnType, PARTIAL_REVERSAL) ? "DIRECT_DEBIT_PURCHASE_REVERSAL" :
										 (!strcmp(reqStruct->txnType, FULL_REVERSAL) 	? "DIRECT_DEBIT_PURCHASE_REVERSAL" :
										 (!strcmp(reqStruct->txnType, AUTO_REVERSAL) 	? "DIRECT_DEBIT_PURCHASE_REVERSAL" :
																						  "UNKNOWN"))))));

		}

		// <cardHolderIDVerificationCode>
		int cvm = getCHVerificationMethod();
		strcpy (reqStruct->cardHolderIdCode, ((cvm == OFF_CLEARTEXT_PIN || cvm == SIGN_OFF_CLR_PIN) ? "CLEAR_TEXT_PIN" :
											 ((cvm == OFF_ENCIPHER_PIN  || cvm == SIGN_OFF_ENC_PIN) ? "ENCIPHER_OFFLINE_PIN" :
											  (cvm == ONLINE_PIN 									? "PIN_DUK" :
											  (cvm == PAPER_SIGNATURE 								? "CARDHOLDER_SIGN_PINPAD" :
																									  "NO_CVM")))));
		memcpy(reqStruct->cardInputType,getCardInputMode(),sizeof(reqStruct->cardInputType));
		if(!strcmp (reqStruct->cardInputType, MANUALENTRY)){
			memset(reqStruct->cardHolderIdCode,0,sizeof(reqStruct->cardHolderIdCode));
			strcpy(reqStruct->cardHolderIdCode,"CARDHOLDER_SIGN_NO_PINPAD");
		}
		// <cardHolderData> : PIN Data
		if (getCHVerificationMethod() == ONLINE_PIN){
			memcpy(reqStruct->cardHolderIdData,getDUKPTPINBlock(),2*PIN_BLOC_SIZE);
			memcpy(&reqStruct->cardHolderIdData[2*PIN_BLOC_SIZE],getDUKPTKSN()+4,2*DUKPT_SMID_SIZE-4);
		}
		//TODO:Need to be removed
		//strcpy(reqStruct->cardHolderIdData,"623F36B53CC18393000000008F000021");
		/* <accountDataSource> </accountDataSource> */
		strcpy (reqStruct->cardHolderDataSource,(!strcmp (reqStruct->cardInputType, SWIPE) 			? "FULL_MAGNETIC_STRIPE_READ"://"MAGSTRIPE_TRACK_2" :
												(!strcmp (reqStruct->cardInputType, FALLBACK) && getChipErrorFlag() ? "CHIP_CARD_READ_FAILURE_MAGSTRIPE" :
												(!strcmp (reqStruct->cardInputType, FALLBACK) && getEmptyCandidateListFlag() ? "CHIP_CARD_MAGSTRIPE" :
												(!strcmp (reqStruct->cardInputType, MSRCONTACTLESS) ? "MAGSTRIPE_PROXIMITY_PAYMENT_DEVICE" :
												(!strcmp (reqStruct->cardInputType, EMVCONTACTLESS) ? "PROXIMITY_PAYMENT_DEVICE" :
												(!strcmp (reqStruct->cardInputType, EMV) 			? "CHIP_CARD":
												(!strcmp (reqStruct->cardInputType, MANUALENTRY) 	? "MANUAL_ENTRY_NO_TERMINAL"://"MANUALLY_KEYED_CHIP_CARD_TERMINAL":
																									  "UNKNOWN"))))))));

		// <posDataCode>
		reqStruct->posData[0] = 'H';	// Pos.1: Highest-level of card data input capability ==> ICC Reader and Contactless Capability; Magnetic stripe & manual entry implied.
		reqStruct->posData[1] = '1';	// Pos.2: Highest-level capability to verify the Cardholder's identity at this terminal(1 = PIN entry capability)
		reqStruct->posData[2] = '0';	// Pos.3: Terminal card-capture capability ==> No capture capability
		reqStruct->posData[3] = '1';	// Pos.4: Terminal operating environment ==> On card acceptor premises; attended terminal
		reqStruct->posData[4] = '0';	// Pos.5: Cardholder present
		if(!strcmp (reqStruct->cardInputType, MSRCONTACTLESS)){ // Pos.6: Card present for msr Contactless
			if(amexCard)
				reqStruct->posData[5] ='X';
			else {
				reqStruct->posData[5] ='1';
			}
		}
		else if (!strcmp(reqStruct->cardInputType, EMVCONTACTLESS)) {// Pos.6: Card present for emv Contactless
			reqStruct->posData[5] ='X';
		}
		else {
			reqStruct->posData[5] ='1';
		}
		if(!strcmp (reqStruct->cardInputType, MANUALENTRY)){ // Pos.6: Card present
			if(amexCard)
				reqStruct->posData[6] = 'V';
			else
				reqStruct->posData[6] = '6';
		}
		else{
			reqStruct->posData[6] =	(!strcmp (reqStruct->cardInputType, SWIPE) 		 				    		 ? 	'B' :			// Magnetic stripe reader input
									(!strcmp (reqStruct->cardInputType, EMV) 		 				    		 ? 	'C' :			// Online Chip
									(!strcmp (reqStruct->cardInputType, EMVCONTACTLESS) 			    		 ? 	'M' :			// PAN auto-entry via contactless Chip Card (EMV Mode)
									(!strcmp (reqStruct->cardInputType, MSRCONTACTLESS) 			    		 ? 	'A' :			// PAN auto-entry via contactless magnetic stripe
									(!strcmp (reqStruct->cardInputType, FALLBACK) && getChipErrorFlag()			 ? 	'N' :			// Chip Error fallback
									(!strcmp (reqStruct->cardInputType, FALLBACK) && getEmptyCandidateListFlag() ? 	'P' :			// Empty candidate list fallback
																										'0'))))));		// Default.
		}
		//How verified Card holder identity?
		reqStruct->posData[7] = (cvm == OFF_CLEARTEXT_PIN ?						        		'1' :			// PIN
										(cvm == ONLINE_PIN ?									'1' :			// PIN
										(cvm == OFF_ENCIPHER_PIN ? 								'1' :			// ICC � Offline PIN
										(cvm == PAPER_SIGNATURE ? 								'5' :			// Manual Signature
																								'0'))));		// Not authenticated
				// Who verified Card holder identity?
		reqStruct->posData[8] = (cvm == OFF_CLEARTEXT_PIN ?					        			'1' :			// ICC � Offline PIN
										(cvm == SIGN_OFF_ENC_PIN ? 								'1' :
										(cvm == OFF_ENCIPHER_PIN ? 								'1' :
										(cvm == PAPER_SIGNATURE ? 								'4' :			// Merchant/card acceptor - signature
										(cvm == ONLINE_PIN ? 									'3' :			// Authorizing agent � Online PIN
																								'0')))));		// Not authenticated
		reqStruct->posData[9] =  '3';	// Pos.10: Card data output capability ==> ICC
		reqStruct->posData[10] = '4';	// Pos.11: Terminal data output capability ==> Printing and display capability
		reqStruct->posData[11] = '6';	// Pos.12: PIN capture capability six characters maximum (TODO: TEMP)
		// </posDataCode>

		//<chipConditionCode></chipConditionCode>
		strcpy (reqStruct->chipConditionCode, (!strcmp (reqStruct->cardInputType, FALLBACK) ? "2" : ""));

		// 	<transactions> <detail> </amount></mid></type></nonEmvFlag>
		// 	<transactions> <detail> </amount></mid></type></nonEmvFlag>
		struct sFeesApplied fees [MAX_FEE_COUNT] = {0};
		int feeCount;
		getProprietaryData (fees,&feeCount);
		int i=0;
		char temp[200]={0};
		char cardEntryType[15+1]={0};
		while(feeCount){
			if( !strcmp (reqStruct->cardInputType, EMV)||
				!strcmp (reqStruct->cardInputType, EMVCONTACTLESS)||
				!strcmp (reqStruct->cardInputType, MSRCONTACTLESS)||
				cardType == DEBIT || cardType == CREDIT){
				if(!strcmp(fees[i].feeType,"CORE")){
					strcpy(cardEntryType,reqStruct->cardInputType);
				}
				else{
					strcpy(cardEntryType,MANUALENTRY);
				}
			}
			else
				strcpy(cardEntryType,reqStruct->cardInputType);

			if(!strcmp(reqStruct->cardInputType, FALLBACK)){
				memset(cardEntryType,0,sizeof(cardEntryType));
				strcpy(cardEntryType, SWIPE);
			}
			sprintf(temp,txnDetails,fees[i].feeAmount,fees[i].feeMID,fees[i].feeType,cardEntryType);
			strcat(reqStruct->feeDetail,temp);
			memset(temp,0,sizeof(temp));
			i++;
			--feeCount;
		}

		// </detail> </transactions>
		if (!strcmp(reqStruct->cardInputType, MANUALENTRY)){
			char cardCVV[7]={0};
			char cardExpDate[4+1]={0};
			char tempExpDate[4+1]={0};
			memset(reqStruct->cardCVV,' ',sizeof(cardCVV)-1);
			//AVS details
			strcpy(reqStruct->custAddress,getCardHolderAddress());
			strcpy(reqStruct->custCity,getCardHolderCity ());
			strcpy(reqStruct->custState,getCardHolderState ());
			strcpy(reqStruct->custZip,getCardHolderZip ());
			// <cardExpirationDate>
			memcpy(tempExpDate,getCardExpiryDate(),sizeof(tempExpDate)-1);
			if(strlen(tempExpDate)){
				memcpy(cardExpDate, &tempExpDate[2], 2);
				memcpy(&cardExpDate[2], tempExpDate, 2);
				memset(encryptData,0,sizeof(encryptData));
				memcpy(&encryptData[sizeof(encryptData)-strlen(cardExpDate)],cardExpDate,strlen(cardExpDate));
				if(encryptDataRSA(encryptData,encryptData))
					memcpy(reqStruct->cardExpiryDate,hexToASCII(encryptData,sizeof(encryptData)),2*sizeof(encryptData));
				else
					setErrorCode("ERROR:038");
			}
			// <cardCvv2>
			strcpy(cardCVV,getCVV());
			if(getCVVByPassReason()=='1'){
				memset(reqStruct->cardCVV,0,sizeof(reqStruct->cardCVV));
				memset(encryptData,0,sizeof(encryptData));
				memcpy(&encryptData[sizeof(encryptData)-strlen(cardCVV)],cardCVV,strlen(cardCVV));
				if(encryptDataRSA(encryptData,encryptData))
					memcpy(reqStruct->cardCVV,hexToASCII(encryptData,sizeof(encryptData)),2*sizeof(encryptData));
				else
					setErrorCode("ERROR:038");
			}
			else{
				reqStruct->cardCVV[0]=getCVVByPassReason();
				reqStruct->cardCVV[1]='1';
			}
		}
		else {
			memset (reqStruct->cardNo,'\0', sizeof(reqStruct->cardNo));
			memset (reqStruct->cardExpiryDate,'\0', sizeof(reqStruct->cardExpiryDate));
			memset (reqStruct->cardCVV,'\0', sizeof(reqStruct->cardCVV));
		}

		// <tlvData> : EMV Data blob
		if (!strcmp(reqStruct->cardInputType, EMV) ||
			!strcmp(reqStruct->cardInputType, EMVCONTACTLESS) || !strcmp (reqStruct->cardInputType, MSRCONTACTLESS) ) {
			char emvData [512] = {0};
			int emvDataLength = 0;
			if(emvPrepareRequestDataTSYS(emvData,&emvDataLength))
				memcpy(reqStruct->emvData, emvData, emvDataLength);
			else {
				memset (reqStruct->emvData,'\0', sizeof(reqStruct->emvData));
			}
		}
		memset(reqStruct->txnType,0,sizeof(reqStruct->txnType));
		strcpy(reqStruct->txnType, (!strcmp(getTransactionType(),PURCHASE)  ? "SALE" :
								   (!strcmp(getTransactionType(),PREAUTH) 	? "AUTH" :
								   (!strcmp(getTransactionType(),REFUND) 	? "REFUND" :
														  	  	  	    "UNKNOWN" ))));

		strcpy(reqStruct->trxnReferenceNo, (!strcmp(getTransactionType(),REFUND)  ? getTransReferenceNo():""));

		char level2Fields[LEVEL2_LEN]={0};
		char level3Fields[LEVEL2_LEN]={0};
		if(getLevel2Flg())
			prepareLevel2Data(reqStruct,level2Fields);
		else {
			strcpy(level2Fields,"");
		}
		if(getLevel3Flg())
			prepareLevel3Data(reqStruct,level3Fields);
		else {
			strcpy(level3Fields,"");
		}

		char authHeader[700]={0};
		sprintf (authReq, purchaseRequestSchema, reqStruct->terminalNo,reqStruct->cardType, reqStruct->currencyCode,
										 reqStruct->txnSequence, reqStruct->txnCode, reqStruct->trxnReferenceNo,reqStruct->cardHolderIdCode, reqStruct->cardHolderIdData,reqStruct->custAddress,
										 reqStruct->custCity,reqStruct->custState,reqStruct->custZip,reqStruct->cardHolderDataSource, reqStruct->customerData, reqStruct->chipConditionCode,
										 reqStruct->feeDetail,reqStruct->cardNo, reqStruct->cardExpiryDate, reqStruct->cardCVV,reqStruct->txnType, reqStruct->posData, reqStruct->custName,
										 reqStruct->emvData,level2Fields,level3Fields,reqStruct->rOrderID);
		sprintf (authHeader, httpAuthHeader,authAPIKey, reqStruct->referenceID, reqStruct->timeStamp, reqStruct->rClerkID,reqStruct->rSource, localIP, strlen(authReq));
		strcpy (finalReq, authHeader);
		strcat (finalReq, authReq);
	}
	else if (!strcmp(getTransactionType(),REFUND)){
		char refundReq[8000]={0};
		char refundHeader[700]={0};
		char txnRefNumber[20+1]={0};
		strcpy(authAPIKey,getDeptAPIKey());
		strcpy(reqStruct->merchantID,getDeptMID());
		strcpy(reqStruct->cardLastFourDigit,getLastFourDigitCardNo());
		strcpy(txnRefNumber,getTransReferenceNo());
		//Reference field
		strcpy(reqStruct->rOrderID, getReferenceNo());
		if (strlen(txnRefNumber)!=0) {	// actual refund txn request packet
			//expire card validation
			char bufferCardExp[4+1]={0};
			memcpy(bufferCardExp,getCardExpiryDate(),sizeof(bufferCardExp)-1);
			if(strlen(bufferCardExp)){
				char currentYear[2+1]={0};
				char cardYear[2+1]={0};
				memcpy(currentYear,date.year,2);
				memcpy(cardYear,bufferCardExp,2);
				if(atoi(cardYear)==atoi(currentYear)){  //year checking
					char currentMonth[2+1]={0};
					char cardMonth[2+1]={0};
					memcpy(currentMonth,date.month,2);
					memcpy(cardMonth,&bufferCardExp[2],2);
					if(atoi(cardMonth)<atoi(currentMonth))	//month checking
						setErrorCode("ERROR:002");
				}
				else if (atoi(cardYear)<atoi(currentYear))
					setErrorCode("ERROR:002");
			}
			//normal refund txn flow
			struct sFeesApplied reqFee[3]={0};
			int motoIndicator = 7;
			Telium_Read_date(&date);
			sprintf(reqStruct->timeStamp,"20%2.2s-%2.2s-%2.2s %2.2s:%2.2s:%2.2s",date.year,date.month,date.day, date.hour, date.minute, date.second);
			EthernetGetOption(ETH_IFO_ADDR, &local_addr );
			p = (char *) &local_addr;
			sprintf(localIP, "%d.%d.%d.%d", p[0], p[1], p[2], p[3] );
			reqStruct->referenceID = atoi (getUserTxnSequnceNo());
			// <terminalNumber>
			strcpy(reqStruct->terminalNo,getUserTerminalID());
			//<clerk ID>
			char clerkID[6+1]={0};
			char source[15+1]={0};
			getClerkId(clerkID);
			strcpy(reqStruct->rClerkID,clerkID);
			strcpy(reqStruct->rSource,"POS-Terminal");
			// <cardType>
			char cardType = 0;
			cardType = getCardType ();
			strcpy(reqStruct->cardType, (cardType == CREDIT ? "CREDIT_CARD" :
										(cardType == DEBIT 	? "DEBIT_CARD" 	:
															  "")));
			//custName
			if(strlen(getCardHolderName())>0)
				strcpy(reqStruct->custName,getCardHolderName());
			// <currencyCode>
			strcpy(reqStruct->currencyCode,getUserCurrencyCode());
			// <txnSequenceNumber>
			strcpy(reqStruct->txnSequence,getUserTxnSequnceNo());
			setTxnSequenceNo();
			strcpy(reqStruct->txnType,getTransactionType());
			// <trxnCode>
			if(cardType == CREDIT){
				strcpy (reqStruct->txnCode, (!strcmp(reqStruct->txnType, PURCHASE) 			? "PURCHASE" :
											(!strcmp(reqStruct->txnType, PREAUTH) 			? "PURCHASE" :
											(!strcmp(reqStruct->txnType, REFUND) 			? "PURCHASE_RETURN_AUTH" :
											(!strcmp(reqStruct->txnType, PARTIAL_REVERSAL) 	? "ONLINE_AUTHORIZATION_REVERSAL" :
											(!strcmp(reqStruct->txnType, FULL_REVERSAL) 	? "ONLINE_AUTHORIZATION_REVERSAL" :
											(!strcmp(reqStruct->txnType, AUTO_REVERSAL) 	? "ONLINE_AUTHORIZATION_REVERSAL" :
																							  "UNKNOWN")))))));
			}
			else if(cardType == DEBIT){ //TODO:Nedd to verify
				strcpy  (reqStruct->txnCode, (!strcmp(reqStruct->txnType, PURCHASE) 		? "DIRECT_DEBIT_PURCHASE" :
											 (!strcmp(reqStruct->txnType, REFUND) 			? "DIRECT_DEBIT_PURCHASE_RETURN" :
											 (!strcmp(reqStruct->txnType, PARTIAL_REVERSAL) ? "DIRECT_DEBIT_PURCHASE_REVERSAL" :
											 (!strcmp(reqStruct->txnType, FULL_REVERSAL) 	? "DIRECT_DEBIT_PURCHASE_REVERSAL" :
											 (!strcmp(reqStruct->txnType, AUTO_REVERSAL) 	? "DIRECT_DEBIT_PURCHASE_REVERSAL" :
																							  "UNKNOWN"))))));

			}
			// <cardHolderIDVerificationCode>
			int cvm = getCHVerificationMethod();
			strcpy (reqStruct->cardHolderIdCode, ((cvm == OFF_CLEARTEXT_PIN || cvm == SIGN_OFF_CLR_PIN) ? "CLEAR_TEXT_PIN" :
												 ((cvm == OFF_ENCIPHER_PIN  || cvm == SIGN_OFF_ENC_PIN) ? "ENCIPHER_OFFLINE_PIN" :
												  (cvm == ONLINE_PIN 									? "PIN_DUK" :
												  (cvm == PAPER_SIGNATURE 								? "CARDHOLDER_SIGN_PINPAD" :
																										  "NO_CVM")))));
			memcpy(reqStruct->cardInputType,getCardInputMode(),sizeof(reqStruct->cardInputType));
			if(!strcmp (reqStruct->cardInputType, MANUALENTRY)){
				memset(reqStruct->cardHolderIdCode,0,sizeof(reqStruct->cardHolderIdCode));
				strcpy(reqStruct->cardHolderIdCode,"CARDHOLDER_SIGN_NO_PINPAD");
			}
			// <cardHolderData> : PIN Data
			if (getCHVerificationMethod() == ONLINE_PIN){
				memcpy(reqStruct->cardHolderIdData,getDUKPTPINBlock(),2*PIN_BLOC_SIZE);
				memcpy(&reqStruct->cardHolderIdData[2*PIN_BLOC_SIZE],getDUKPTKSN()+4,2*DUKPT_SMID_SIZE-4);
			}
			strcpy (reqStruct->cardHolderDataSource,(!strcmp (reqStruct->cardInputType, SWIPE) 			? "FULL_MAGNETIC_STRIPE_READ"://"MAGSTRIPE_TRACK_2" :
													(!strcmp (reqStruct->cardInputType, FALLBACK) && getChipErrorFlag() ? "CHIP_CARD_READ_FAILURE_MAGSTRIPE" :
													(!strcmp (reqStruct->cardInputType, FALLBACK) && getEmptyCandidateListFlag() ? "CHIP_CARD_MAGSTRIPE" :
													(!strcmp (reqStruct->cardInputType, MSRCONTACTLESS) ? "MAGSTRIPE_PROXIMITY_PAYMENT_DEVICE" :
													(!strcmp (reqStruct->cardInputType, EMVCONTACTLESS) ? "PROXIMITY_PAYMENT_DEVICE" :
													(!strcmp (reqStruct->cardInputType, EMV) 			? "CHIP_CARD":
													(!strcmp (reqStruct->cardInputType, MANUALENTRY) 	? "MANUAL_ENTRY_NO_TERMINAL"://"MANUALLY_KEYED_CHIP_CARD_TERMINAL":
																										  "UNKNOWN"))))))));

			// <posDataCode>
			reqStruct->posData[0] = 'H';	// Pos.1: Highest-level of card data input capability ==> ICC Reader and Contactless Capability; Magnetic stripe & manual entry implied.
			reqStruct->posData[1] = '1';	// Pos.2: Highest-level capability to verify the Cardholder's identity at this terminal(1 = PIN entry capability)
			reqStruct->posData[2] = '0';	// Pos.3: Terminal card-capture capability ==> No capture capability
			reqStruct->posData[3] = '1';	// Pos.4: Terminal operating environment ==> On card acceptor premises; attended terminal
			reqStruct->posData[4] = '0';	// Pos.5: Cardholder present
			if(!strcmp (reqStruct->cardInputType, MSRCONTACTLESS)){ // Pos.6: Card present for msr Contactless
				if(amexCard)
					reqStruct->posData[5] ='X';
				else {
					reqStruct->posData[5] ='1';
				}
			}
			else if (!strcmp(reqStruct->cardInputType, EMVCONTACTLESS)) {// Pos.6: Card present for emv Contactless
				reqStruct->posData[5] ='X';
			}
			else {
				reqStruct->posData[5] ='1';
			}
			if(!strcmp (reqStruct->cardInputType, MANUALENTRY)){ // Pos.6: Card present
				if(amexCard)
					reqStruct->posData[6] = 'V';
				else
					reqStruct->posData[6] = '6';
			}
			else{
				reqStruct->posData[6] =	(!strcmp (reqStruct->cardInputType, SWIPE) 		 				    		 ? 	'B' :			// Magnetic stripe reader input
										(!strcmp (reqStruct->cardInputType, EMV) 		 				    		 ? 	'C' :			// Online Chip
										(!strcmp (reqStruct->cardInputType, EMVCONTACTLESS) 			    		 ? 	'M' :			// PAN auto-entry via contactless Chip Card (EMV Mode)
										(!strcmp (reqStruct->cardInputType, MSRCONTACTLESS) 			    		 ? 	'A' :			// PAN auto-entry via contactless magnetic stripe
										(!strcmp (reqStruct->cardInputType, FALLBACK) && getChipErrorFlag()			 ? 	'N' :			// Chip Error fallback
										(!strcmp (reqStruct->cardInputType, FALLBACK) && getEmptyCandidateListFlag() ? 	'P' :			// Empty candidate list fallback
																											'0'))))));		// Default.
			}
			//How verified Card holder identity?
			reqStruct->posData[7] = (cvm == OFF_CLEARTEXT_PIN ?						        		'1' :			// PIN
											(cvm == ONLINE_PIN ?									'1' :			// PIN
											(cvm == OFF_ENCIPHER_PIN ? 								'1' :			// ICC � Offline PIN
											(cvm == PAPER_SIGNATURE ? 								'5' :			// Manual Signature
																									'0'))));		// Not authenticated
					// Who verified Card holder identity?
			reqStruct->posData[8] = (cvm == OFF_CLEARTEXT_PIN ?					        			'1' :			// ICC � Offline PIN
											(cvm == SIGN_OFF_ENC_PIN ? 								'1' :
											(cvm == OFF_ENCIPHER_PIN ? 								'1' :
											(cvm == PAPER_SIGNATURE ? 								'4' :			// Merchant/card acceptor - signature
											(cvm == ONLINE_PIN ? 									'3' :			// Authorizing agent � Online PIN
																									'0')))));		// Not authenticated
			reqStruct->posData[9] =  '3';	// Pos.10: Card data output capability ==> ICC
			reqStruct->posData[10] = '4';	// Pos.11: Terminal data output capability ==> Printing and display capability
			reqStruct->posData[11] = '6';	// Pos.12: PIN capture capability six characters maximum (TODO: TEMP)
			// </posDataCode>

			//<chipConditionCode></chipConditionCode>
			strcpy (reqStruct->chipConditionCode, (!strcmp (reqStruct->cardInputType, FALLBACK) ? "2" : ""));
			struct sFeesApplied fees [MAX_FEE_COUNT] = {0};
			int feeCount;
			getProprietaryData (fees,&feeCount);
			int i=0;
			char temp[200]={0};
			char cardEntryType[15+1]={0};
			while(feeCount){
				if( !strcmp (reqStruct->cardInputType, EMV)||
					!strcmp (reqStruct->cardInputType, EMVCONTACTLESS)||
					!strcmp (reqStruct->cardInputType, MSRCONTACTLESS)||
					cardType == DEBIT || cardType == CREDIT){
					if(!strcmp(fees[i].feeType,"CORE")){
						strcpy(cardEntryType,reqStruct->cardInputType);
					}
					else{
						strcpy(cardEntryType,MANUALENTRY);
					}
				}
				else
					strcpy(cardEntryType,reqStruct->cardInputType);

				if(!strcmp(reqStruct->cardInputType, FALLBACK)){
					memset(cardEntryType,0,sizeof(cardEntryType));
					strcpy(cardEntryType, SWIPE);
				}
				if (strcmp(fees[i].feeType,"CHARG")){
				sprintf(temp,txnDetails,fees[i].feeAmount,fees[i].feeMID,fees[i].feeType,cardEntryType);
				strcat(reqStruct->feeDetail,temp);
				memset(temp,0,sizeof(temp));
				}
				i++;
				--feeCount;
			}
			// </detail> </transactions>
			if (!strcmp(reqStruct->cardInputType, MANUALENTRY)){
				char cardCVV[7]={0};
				char cardExpDate[4+1]={0};
				char tempExpDate[4+1]={0};
				memset(reqStruct->cardCVV,' ',sizeof(cardCVV)-1);
				//AVS details
				strcpy(reqStruct->custAddress,getCardHolderAddress());
				strcpy(reqStruct->custCity,getCardHolderCity ());
				strcpy(reqStruct->custState,getCardHolderState ());
				strcpy(reqStruct->custZip,getCardHolderZip ());
				// <cardExpirationDate>
				memcpy(tempExpDate,getCardExpiryDate(),sizeof(tempExpDate)-1);
				if(strlen(tempExpDate)){
					memcpy(cardExpDate, &tempExpDate[2], 2);
					memcpy(&cardExpDate, tempExpDate, 2);
					memset(encryptData,0,sizeof(encryptData));
					memcpy(&encryptData[sizeof(encryptData)-strlen(cardExpDate)],cardExpDate,strlen(cardExpDate));
					if(encryptDataRSA(encryptData,encryptData))
						memcpy(reqStruct->cardExpiryDate,hexToASCII(encryptData,sizeof(encryptData)),2*sizeof(encryptData));
					else
						setErrorCode("ERROR:038");
				}
				// <cardCvv2>
				strcpy(cardCVV,getCVV());
				if(getCVVByPassReason()=='1'){
					memset(reqStruct->cardCVV,0,sizeof(reqStruct->cardCVV));
					memset(encryptData,0,sizeof(encryptData));
					memcpy(&encryptData[sizeof(encryptData)-strlen(cardCVV)],cardCVV,strlen(cardCVV));
					if(encryptDataRSA(encryptData,encryptData))
						memcpy(reqStruct->cardCVV,hexToASCII(encryptData,sizeof(encryptData)),2*sizeof(encryptData));
					else
						setErrorCode("ERROR:038");
				}
				else{
					reqStruct->cardCVV[0]=getCVVByPassReason();
					reqStruct->cardCVV[1]='1';
				}
			}
			else {
				memset (reqStruct->cardNo,'\0', sizeof(reqStruct->cardNo));
				memset (reqStruct->cardExpiryDate,'\0', sizeof(reqStruct->cardExpiryDate));
				memset (reqStruct->cardCVV,'\0', sizeof(reqStruct->cardCVV));
			}
			// <tlvData> : EMV Data blob
			if (!strcmp(reqStruct->cardInputType, EMV) ||
				!strcmp(reqStruct->cardInputType, EMVCONTACTLESS) || !strcmp (reqStruct->cardInputType, MSRCONTACTLESS) ) {
				char emvData [512] = {0};
				int emvDataLength = 0;
				if(emvPrepareRequestDataTSYS(emvData,&emvDataLength))
					memcpy(reqStruct->emvData, emvData, emvDataLength);
				else {
					memset (reqStruct->emvData,'\0', sizeof(reqStruct->emvData));
				}
			}
			memset(reqStruct->txnType,0,sizeof(reqStruct->txnType));
			strcpy(reqStruct->txnType, (!strcmp(getTransactionType(),PURCHASE)  ? "SALE" :
									   (!strcmp(getTransactionType(),PREAUTH) 	? "AUTH" :
									   (!strcmp(getTransactionType(),REFUND) 	? "REFUND" :
															  	  	  	    "UNKNOWN" ))));
			strcpy(reqStruct->trxnReferenceNo, (!strcmp(getTransactionType(),REFUND)  ? getTransReferenceNo():""));
			char level2Fields[LEVEL2_LEN]={0};
			char level3Fields[LEVEL2_LEN]={0};
			if(getLevel2Flg())
				prepareLevel2Data(reqStruct,level2Fields);
			else {
				strcpy(level2Fields,"");
			}
			if(getLevel3Flg())
				prepareLevel3Data(reqStruct,level3Fields);
			else {
				strcpy(level3Fields,"");
			}
			sprintf (refundReq, purchaseRequestSchema, reqStruct->terminalNo,reqStruct->cardType, reqStruct->currencyCode,
											 reqStruct->txnSequence,reqStruct->txnCode, reqStruct->trxnReferenceNo,reqStruct->cardHolderIdCode, reqStruct->cardHolderIdData,reqStruct->custAddress,
											 reqStruct->custCity,reqStruct->custState,reqStruct->custZip,reqStruct->cardHolderDataSource, reqStruct->customerData, reqStruct->chipConditionCode,
											 reqStruct->feeDetail,reqStruct->cardNo, reqStruct->cardExpiryDate, reqStruct->cardCVV,reqStruct->txnType, reqStruct->posData, reqStruct->custName,
											 reqStruct->emvData,level2Fields,level3Fields,reqStruct->rOrderID);
			sprintf (refundHeader, httpAuthHeader,authAPIKey, reqStruct->referenceID, reqStruct->timeStamp, reqStruct->rClerkID,reqStruct->rSource, localIP, strlen(refundReq));
			strcpy (finalReq, refundHeader);
			strcat (finalReq, refundReq);
		}
		else {
			memset(refundReq,0,sizeof(refundReq));
			sprintf(refundReq,refundTxnListRequestSchema,reqStruct->merchantID,reqStruct->cardLastFourDigit);
			sprintf(refundHeader,httpRefundListHeader,authAPIKey,strlen(refundReq));
			strcpy(finalReq,refundHeader);
			strcat(finalReq,refundReq);
		}
	}
	else if(!strcmp(getTransactionType(),FULL_REVERSAL)){
			char revReq[REQUEST_LEN]={0};
			int motoIndicator = 7;    //TODO: temp coding for gateway. motoindicator must be 0 for CP txn. will update
			Telium_Read_date(&date);
			sprintf(reqStruct->timeStamp,"20%2.2s-%2.2s-%2.2s %2.2s:%2.2s:%2.2s",date.year,date.month,date.day, date.hour, date.minute, date.second);
			EthernetGetOption(ETH_IFO_ADDR, &local_addr );
			p = (char *) &local_addr;
			sprintf(localIP, "%d.%d.%d.%d", p[0], p[1], p[2], p[3] );
			strcpy(authAPIKey,getDeptAPIKey());
			reqStruct->referenceID = atoi (getUserTxnSequnceNo());
			setTxnSequenceNo();
            strcpy(reqStruct->rOrderID, getReferenceNo());
			strcpy(reqStruct->terminalNo,getUserTerminalID());
			strcpy(reqStruct->merchantID,getDeptMID());
			strcpy(reqStruct->transactionID,getTransReferenceNo());
			// <txnSequenceNumber>
			strcpy(reqStruct->txnSequence,getUserTxnSequnceNo());
			setTxnSequenceNo();

			// 	<transactions> <detail> </amount></mid></type></nonEmvFlag>
			struct sFeesApplied fees [MAX_FEE_COUNT] = {0};
			int feeCount;
			getProprietaryData (fees,&feeCount);
			int i=0;
			char feeDetail[700]={0};
			char temp[200]={0};
			char cardEntryType[15+1]={0};
			while(feeCount){
				strcpy(cardEntryType,MANUALENTRY);
				sprintf(temp,txnDetails,fees[i].feeAmount,fees[i].feeMID,fees[i].feeType,cardEntryType);
				strcat(feeDetail,temp);
				memset(temp,0,sizeof(temp));
				i++;
				--feeCount;
			}
			char revHeader[700]={0};
			sprintf (revReq, reversalReqSchema,reqStruct->merchantID,reqStruct->terminalNo,reqStruct->txnSequence,reqStruct->transactionID,feeDetail,reqStruct->rOrderID);
			sprintf (revHeader, httpAuthHeader,authAPIKey, reqStruct->referenceID, reqStruct->timeStamp, reqStruct->rClerkID,reqStruct->rSource, localIP, strlen(revReq));
			strcpy (finalReq, revHeader);
			strcat (finalReq, revReq);
		}
	else if(!strcmp(getTransactionType(),AUTO_REVERSAL)){
		char revReq[REQUEST_LEN]={0};
		int motoIndicator = 7;    //TODO: temp coding for gateway. motoindicator must be 0 for CP txn. will update
		Telium_Read_date(&date);
		sprintf(reqStruct->timeStamp,"20%2.2s-%2.2s-%2.2s %2.2s:%2.2s:%2.2s",date.year,date.month,date.day, date.hour, date.minute, date.second);
		EthernetGetOption(ETH_IFO_ADDR, &local_addr );
		p = (char *) &local_addr;
		sprintf(localIP, "%d.%d.%d.%d", p[0], p[1], p[2], p[3] );
		strcpy(authAPIKey,getDeptAPIKey());
		reqStruct->referenceID = atoi (getUserTxnSequnceNo());
		setTxnSequenceNo();
		strcpy(reqStruct->rOrderID, getReferenceNo());
		strcpy(reqStruct->terminalNo,getUserTerminalID());
		strcpy(reqStruct->merchantID,getDeptMID());
		strcpy(reqStruct->transactionID,getTransReferenceNo());
		// <txnSequenceNumber>
		strcpy(reqStruct->txnSequence,getUserTxnSequnceNo());
		setTxnSequenceNo();
		char revHeader[700]={0};
		sprintf (revReq, autoReversalReqSchema,reqStruct->terminalNo,reqStruct->transactionID,reqStruct->txnSequence,reqStruct->coreAmt,reqStruct->merchantID,
				reqStruct->cardInputType,reqStruct->rOrderID);
		sprintf (revHeader, httpAutoReverseHeader,authAPIKey, reqStruct->referenceID, reqStruct->timeStamp, localIP, strlen(revReq));
		strcpy (finalReq, revHeader);
		strcat (finalReq, revReq);
	}
	else if(!strcmp(getTransactionType(),COMPLETION)){
		char subSeqTxnHeader[500]={0};
		char subSeqTxnReq[REQUEST_LEN];

		DATE date;
		Telium_Read_date(&date);
		sprintf(reqStruct->timeStamp,"20%2.2s-%2.2s-%2.2sT%2.2s:%2.2s:%2.2s",date.year,date.month,date.day, date.hour, date.minute, date.second);

		EthernetGetOption(ETH_IFO_ADDR, &local_addr );
		p = (char *) &local_addr;
		sprintf(localIP, "%d.%d.%d.%d", p[0], p[1], p[2], p[3] );

		strcpy(authAPIKey,getUserAPIKey());
		reqStruct->referenceID = atoi (getUserTxnSequnceNo());

		// <terminalNumber>
		strcpy(reqStruct->terminalNo,getUserTerminalID());
		strcpy(reqStruct->merchantID,getDeptMID());
		strcpy(reqStruct->transactionID,getTransReferenceNo());


		sprintf(subSeqTxnReq,subSequestTxnSchema,reqStruct->transactionID);

		strcat (finalReq, subSeqTxnReq);
	}
	else if(!strcmp(getTransactionType(),DUPLICATE_RECEIPT)){
		char duplicateReceiptReq[REQUEST_LEN]={0};
		char header[700]={0};
		strcpy(reqStruct->cardLastFourDigit,getLastFourDigitCardNo());
		strcpy(reqStruct->transactionID,getTransReferenceNo());
		if(strlen(reqStruct->cardLastFourDigit))
			sprintf(duplicateReceiptReq,duplicateReceiptRequestSchema, getUserTerminalID(), reqStruct->cardLastFourDigit, "");
		else
			sprintf(duplicateReceiptReq,duplicateReceiptRequestSchema,getUserTerminalID(), "",reqStruct->transactionID);

		sprintf(header,httpDuplicateReceiptHeader,strlen(duplicateReceiptReq));
		strcpy(finalReq,header);
		strcat(finalReq,duplicateReceiptReq);
	}
	else if(!strcmp(getTransactionType(),BATCH_SETTLE)){
		char batchreq[REQUEST_LEN]={0};
		char batchHeader[700]={0};
        extern int batchall;
        if(batchall){
			strcpy(reqStruct->terminalNo,getUserTerminalID());
			sprintf(batchreq,BatchAllReqBody,reqStruct->terminalNo);
			sprintf(batchHeader,BatchReqHeader,strlen(batchreq));
			strcpy(finalReq,batchHeader);
			strcat(finalReq,batchreq);

        }else{
        	strcpy(reqStruct->merchantID,getDeptMID());
        	strcpy(reqStruct->terminalNo,getUserTerminalID());
			sprintf(batchreq,BatchReqBody,reqStruct->merchantID,reqStruct->terminalNo);
			sprintf(batchHeader,BatchReqHeader,strlen(batchreq));
			strcpy(finalReq,batchHeader);
			strcat(finalReq,batchreq);
        }
	}
	else if(!strcmp(getTransactionType(),TRAN_SUM)){
		char batchreq[REQUEST_LEN]={0};
		char batchHeader[700]={0};
		char clerkid[6 +1]={0};
		getClerkId(clerkid);
		if(batchall == 1){
			strcpy(reqStruct->terminalNo,getUserTerminalID());
			sprintf(batchreq,BatchAllReqBody,reqStruct->terminalNo);
			sprintf(batchHeader,BatchReqHeader,strlen(batchreq));
			strcpy(finalReq,batchHeader);
			strcat(finalReq,batchreq);

		}else{
			strcpy(reqStruct->merchantID,getDeptMID());
			strcpy(reqStruct->terminalNo,getUserTerminalID());
			sprintf(batchreq,BatchReqBody,reqStruct->merchantID,reqStruct->terminalNo,clerkid);
			sprintf(batchHeader,BatchReqHeader,strlen(batchreq));
			strcpy(finalReq,batchHeader);
			strcat(finalReq,batchreq);
        }
	}
	return;
}

/* ----------------------------------------------------------------------------------------------*
* Purpose: Prepare EMV Data block (Group 3 Version 55) for TSYS. The following EMV tag may be    *
*          sent in EMV request block to TSYS.                                                    *
*                                                                                                *
*          +-----+---+------------------------------------------------+--------------+           *
*          | TAG |   |                      NOTE                      |    SOURCE    |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |DF79 | M | Kernal Version Number. (EMVDC Version 05.26)   |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |DF78 | M | Device Serial Number.                          |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |82   | M | Application Interchange Profile (AIP)          |     ICC      |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |84   | M | Dedicated File (DF) Name                       |     ICC      |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |95   | M | Terminal Verification Results (TVR)            |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9A   | M | Transaction Date                               |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9C   | M | Transaction Type                               |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |5F2A | M | Transaction Currency Code                      |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F02 | M | Amount, Authorized                             |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F03 | M | Amount, Other                                  |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F10 | M | Issuer Application Data                        |     ICC      |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F1A | M | Terminal country Code                          |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F26 | M | Application Cryptogram                         |     ICC      |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F27 | M | Cryptogram Information Data                    |     ICC      |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F36 | M | Application Transaction Counter                |     ICC      |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F37 | M | Unpredictable Number                           |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F33 | O | Terminal Capabilities                          |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F34 | O | Cardholder Verification Method (CVM) Results   |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F35 | O | Terminal Type                                  |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F40 | O | Additional Terminal Capabilities               |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |4F   | O | Application Identifier (AID) - ICC             |     ICC      |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F06 | O | Application Identifier (AID) - Terminal        |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F39 | O | POS Entry Mode                                 |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9B   | O | Transaction Status Information                 |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F21 | O | Transaction local Time                         |   Terminal   |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |5F34 | O | Primary Account Number (PAN) Sequence Number   |     ICC      |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |5F2D |N/A| Language Preference                            |     ICC      |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |91   |N/A| Issuer Authentication Data                     |    Issuer    |           *
*          +-----+---+------------------------------------------------+--------------+           *
*          |9F5B |N/A| Issuer Script Results                          |    Terminal  |           *
*          +-----+---+------------------------------------------------+--------------+           *
*                                                                                                *
* [in] :   inputTlvTree Input TlvTree.                                                           *
* [out]:   outputTlvTree Output TlvTree.                                                         *
* ---------------------------------------------------------------------------------------------- */
int emvPrepareRequestDataTSYS (char * emvDataASCII, int * emvDataASCIILength){
#define TAG_DF79  "05.26"		// EMVCo LOA 2 - EMVDC Version 05.26

	char emvTVR [11] = {0};
	char emvTSI [5]	= {0};
	TAGNAME tTagName[] = EMVTAGTBL;
	int emvTagCount = sizeof(tTagName) / sizeof(TAGNAME);
	unsigned char dataEMV [512] = {0};
	unsigned char tempEMVHex [256] = {0};
	int tempEMVHexLength = 0;
	int tsysEMVDataLength = 0;
	int dataEMVLength = 0;
	if (getRequestEMVData (dataEMV, &dataEMVLength)) {
		int fieldLen, n;
		while (dataEMVLength != 0) {
			fieldLen = 0;
			for (n = 0; n < emvTagCount; n++){
				if (!memcmp (dataEMV + tempEMVHexLength, &tTagName[n].tagName, tTagName[n].tagNameLen)){
					int dataLen = 0;
					memcpy (&dataLen, dataEMV + tempEMVHexLength + tTagName[n].tagNameLen, 1);
					fieldLen = dataLen + tTagName[n].tagNameLen + 1;
					unsigned char tag [4];
					memset (tag, 0, sizeof(tag));
					if (tTagName[n].tagNameLen == 1)
						memcpy (tag, dataEMV + tempEMVHexLength, 1);
					else if (tTagName[n].tagNameLen == 2) {
						memcpy (&tag[0], dataEMV + tempEMVHexLength + 1, 1);
						memcpy (&tag[1], dataEMV + tempEMVHexLength, 1);
					}
					int emvTag = 0;
					memcpy (&emvTag, tag, sizeof (int));

					switch (emvTag){
					case TAG_AIP:
					case TAG_DF_NAME:
					case TAG_TRANSACTION_DATE:
					case TAG_TRANSACTION_TYPE:
					case TAG_TRANSACTION_CURRENCY_CODE:
					case TAG_AMOUNT_AUTH_NUM:
					case TAG_AMOUNT_OTHER_NUM:
					case TAG_ISSUER_APPLICATION_DATA:
					case TAG_TERMINAL_COUNTRY_CODE:
					case TAG_APPLI_CRYPTOGRAMME_AC:
					case TAG_CRYPTOGRAM_INFORMATION_DATA:
					case TAG_ATC:
					case TAG_UNPREDICTABLE_NUMBER:
					case TAG_POS_ENTRY_MODE_CODE:
					case TAG_TERMINAL_CAPABILITIES:
					case TAG_CVR_RESULT:
					case TAG_TERMINAL_TYPE:
					case TAG_ADD_TERMINAL_CAPABILITIES:
					case TAG_AID_ICC:
					case TAG_AID_TERMINAL:
					case TAG_TRANSACTION_TIME:
					case TAG_APPLI_PRIM_ACCOUNT_NB_SEQ_NB:
					case TAG_EMV_ICC_DYNAMIC_NUMBER:
					case TAG_PAYPASS_TRACK2_DATA:
					case TAG_PAYPASS_THIRD_PARTY_DATA:
					case TAG_PAYPASS_MERCHANT_CUSTOM_DATA:
						memcpy (tempEMVHex + tsysEMVDataLength, dataEMV + tempEMVHexLength, fieldLen);
						tsysEMVDataLength = tsysEMVDataLength + fieldLen;
						break;
					case TAG_TVR:
						memcpy (emvTVR, hexToASCII(dataEMV + tempEMVHexLength + 2, 5), 10);
						setEMVTerminalVerificationResult (emvTVR);
						memcpy (tempEMVHex + tsysEMVDataLength, dataEMV + tempEMVHexLength, fieldLen);
						tsysEMVDataLength = tsysEMVDataLength + fieldLen;
						break;
					case TAG_TSI:
						memcpy (emvTSI, hexToASCII(dataEMV + tempEMVHexLength + 2, 2), 4);
						setEMVTransactionStatusInformation (emvTSI);
						memcpy (tempEMVHex + tsysEMVDataLength, dataEMV + tempEMVHexLength, fieldLen);
						tsysEMVDataLength = tsysEMVDataLength + fieldLen;
						break;
					case TAG_IFD_SERIAL_NUMBER:
					case TAG_TRANSACTION_CURRENCY_EXP:
					case TAG_VERSION_NUMBER_TERMINAL:
					case TAG_APPLI_PRIM_ACCOUNT_NB:
					case TAG_TRANSACTION_SEQ_COUNTER:
					case TAG_APPLI_EXPIRATION_DATE:
					case TAG_TRACK2_EQU_DATA:
					case TAG_SERVICE_CODE:
					case TAG_PAYMENT_ACCOUNT_REFERENCE:
					case TAG_CARDHOLDER_NAME:
						break;
					}
					n = emvTagCount;
				}
			}
			dataEMVLength = dataEMVLength - fieldLen;
			tempEMVHexLength = tempEMVHexLength + fieldLen;
		}
	}
	else
		return FALSE;
	unsigned char emvDataTSYS [256] = {0};
	int emvDataTSYSLength = 0;
	// Tag DF79
	int lengthDF79 = strlen(TAG_DF79);
	unsigned char temp [60] = {0};
	memcpy (temp, "\xDF\x79", 2);
	memcpy (temp + 2, &lengthDF79, 1);
	memcpy (temp + 3, TAG_DF79, strlen(TAG_DF79));
	// Tag DF78
	//NO_SERIE serial={0};
	//PSQ_Give_Serial_Number(serial);
	memcpy (temp + 3 + strlen(TAG_DF79), "\xDF\x78", 2);
	memcpy (temp + 3 + strlen(TAG_DF79) + 2, "\x08", 1);
	memcpy (temp + 3 + strlen(TAG_DF79) + 3, serial, 8);

	//Build EMV Request Data for TSYS.
	memcpy (emvDataTSYS, temp, strlen(TAG_DF79) + 8 + 6);
	memcpy (emvDataTSYS + strlen(TAG_DF79) + 8 + 6, tempEMVHex, tsysEMVDataLength);
	emvDataTSYSLength = strlen(TAG_DF79) + 8 + 6 + tsysEMVDataLength;

	memcpy (emvDataASCII, hexToASCII (emvDataTSYS, emvDataTSYSLength), emvDataTSYSLength*2);
	*emvDataASCIILength = emvDataTSYSLength*2;
	return TRUE;
}

int prepareLevel2Data(struct requestFields *reqStruct, char *level2Data){

	char lvl2Data[LEVEL2_LEN]={0};
	char userCardNo[20]; int cardLength;
	getCardNumber(userCardNo,&cardLength);
	if(getLevel2Flg()){
		if(!memcmp (userCardNo, "34", 2) || !memcmp (userCardNo, "37", 2)){
			memcpy(reqStruct->mSupplierRefNum,getSupplierRefNum(),sizeof(reqStruct->mSupplierRefNum)-1);
			memcpy(reqStruct->mCHRefNum,getCHRefNum(),sizeof(reqStruct->mCHRefNum)-1);
			memcpy(reqStruct->mShipToZip,getShipToZip(),sizeof(reqStruct->mShipToZip)-1);
			memcpy(reqStruct->mSalesTaxAmt,getSalesTaxAmt(),sizeof(reqStruct->mSalesTaxAmt)-1);
			memcpy(reqStruct->mchargeDesc1,getChargeDesc1(),sizeof(reqStruct->mchargeDesc1)-1);
			memcpy(reqStruct->mReqRefName,getRequesterName(),sizeof(reqStruct->mReqRefName)-1);
			memcpy(reqStruct->mTotalTaxAmt,getTotalTaxAmount(),sizeof(reqStruct->mTotalTaxAmt)-1);
			memcpy(reqStruct->mTaxTypeCode,getTaxTypeCode(),sizeof(reqStruct->mTaxTypeCode)-1);

			sprintf(lvl2Data,level2_Amex,reqStruct->mSupplierRefNum,reqStruct->mCHRefNum,reqStruct->mShipToZip,reqStruct->mSalesTaxAmt,reqStruct->mchargeDesc1,
					reqStruct->mReqRefName,reqStruct->mTotalTaxAmt,reqStruct->mTaxTypeCode);
		}
		else{
			memcpy(reqStruct->mOptAmountId,getOptAmtID(),sizeof(reqStruct->mOptAmountId)-1);
			memcpy(reqStruct->mOptAmount,getOptAmt(),sizeof(reqStruct->mOptAmount)-1);
			memcpy(reqStruct->mPONumber,getPONumber(),sizeof(reqStruct->mPONumber)-1);
			reqStruct->mPurchaseIDFormat[0] = getPurchaseIDFormat();
			memcpy(reqStruct->mPurchaseID,getPurchaseID(),sizeof(reqStruct->mPurchaseID)-1);
			reqStruct->mLocalTaxInclFlag[0] = getLocalTaxInclFlag();
			memcpy(reqStruct->mLocalTax,getLocalTax(),sizeof(reqStruct->mLocalTax)-1);
			reqStruct->mNatTaxInclFlag[0] = getNatTaxInclFlag();
			memcpy(reqStruct->mLocalTax,getLocalTax(),sizeof(reqStruct->mLocalTax)-1);
			memcpy(reqStruct->mFreightAmt,getFreightAmt(),sizeof(reqStruct->mFreightAmt)-1);
			memcpy(reqStruct->mDutyAmt,getDutyAmt(),sizeof(reqStruct->mDutyAmt)-1);
			memcpy(reqStruct->mDestZip,getDestZip(),sizeof(reqStruct->mDestZip)-1);
			memcpy(reqStruct->mShippingZip,getShippingZip(),sizeof(reqStruct->mShippingZip)-1);
			memcpy(reqStruct->mDestCountryCode,getDestCountryCode(),sizeof(reqStruct->mDestCountryCode)-1);
			memcpy(reqStruct->mMVATRegNum,getMVATRegNum(),sizeof(reqStruct->mMVATRegNum)-1);
			memcpy(reqStruct->mCVATRegNum,getCVATRegNum(),sizeof(reqStruct->mCVATRegNum)-1);
			memcpy(reqStruct->mSumCommodityCd,getSumCommodityCd(),sizeof(reqStruct->mSumCommodityCd)-1);
			memcpy(reqStruct->mVATInvcRefNum,getVATInvcRefNum(),sizeof(reqStruct->mVATInvcRefNum)-1);
			memcpy(reqStruct->mOrderDate,getOrderDate(),sizeof(reqStruct->mOrderDate)-1);
			memcpy(reqStruct->mDiscAmt,getDiscAmt(),sizeof(reqStruct->mDiscAmt)-1);
			memcpy(reqStruct->mVATTaxAmt,getVATTaxAmt(),sizeof(reqStruct->mVATTaxAmt)-1);
			memcpy(reqStruct->mVATTaxRate,getVATTaxRate(),sizeof(reqStruct->mVATTaxRate)-1);
			memcpy(reqStruct->mAltTaxAmtID,getAltAmtTaxId(),sizeof(reqStruct->mVATTaxRate)-1);
			memcpy(reqStruct->mAltTaxAmt,getAltAmtTax(),sizeof(reqStruct->mVATTaxRate)-1);

			sprintf(lvl2Data,leve2_MasterVisa,reqStruct->mOptAmountId,reqStruct->mOptAmount,reqStruct->mPONumber,reqStruct->mPurchaseIDFormat,reqStruct->mPurchaseID,reqStruct->mLocalTaxInclFlag,reqStruct->mLocalTax,reqStruct->mNatTaxInclFlag,
					reqStruct->mLocalTax,reqStruct->mFreightAmt,reqStruct->mDutyAmt,reqStruct->mDestZip,reqStruct->mShippingZip,reqStruct->mDestCountryCode,getLineItemCnt(),reqStruct->mMVATRegNum,
					reqStruct->mCVATRegNum,reqStruct->mSumCommodityCd,reqStruct->mVATInvcRefNum,reqStruct->mOrderDate,reqStruct->mDiscAmt,reqStruct->mVATTaxAmt,reqStruct->mVATTaxRate,reqStruct->mAltTaxAmtID,reqStruct->mAltTaxAmt
					);

		}
	}
	else {
		strcpy(level2Data,"");
	}
	strcpy(level2Data,lvl2Data);
	return TRUE;
}

int prepareLevel3Data(struct requestFields *reqStruct, char *level3Data){
	if(getLevel3Flg()){
		memcpy(reqStruct->mProductDesc,getProductDesc(),sizeof(reqStruct->mProductDesc)-1);
		memcpy(reqStruct->mProductCd,getProductCd(),sizeof(reqStruct->mProductCd)-1);
		memcpy(reqStruct->mProductQuantity,getProductQuantity(),sizeof(reqStruct->mProductQuantity)-1);
		memcpy(reqStruct->mProductMeasurementUnit,getProductMeasurementUnit(),sizeof(reqStruct->mProductMeasurementUnit)-1);
		memcpy(reqStruct->mProductCommodityCd,getProductCommodityCd(),sizeof(reqStruct->mProductCommodityCd)-1);

		memcpy(reqStruct->mCostPerUnit,getCostPerUnit(),sizeof(reqStruct->mCostPerUnit));
		memcpy(reqStruct->mLineItemTotCnt,getLineItemTotCnt(),sizeof(reqStruct->mLineItemTotCnt));
		memcpy(reqStruct->mAltTaxID,getAltTaxID(),sizeof(reqStruct->mAltTaxID));
		memcpy(reqStruct->mTaxTypeApplied,getTaxTypeApplied(),sizeof(reqStruct->mTaxTypeApplied));
		memcpy(reqStruct->mDiscInd,getDiscInd(),sizeof(reqStruct->mDiscInd));
		memcpy(reqStruct->mNetGrossInd,getNetGrossInd(),sizeof(reqStruct->mNetGrossInd));
		memcpy(reqStruct->mExtItemAmt,getExtItemAmt(),sizeof(reqStruct->mExtItemAmt));
		memcpy(reqStruct->mDrCrInd,getDrCrInd(),sizeof(reqStruct->mDrCrInd));
		memcpy(reqStruct->mItemDiscRate,getItemDiscRate(),sizeof(reqStruct->mItemDiscRate));
		memcpy(reqStruct->mItemQtyExpInd,getItemQtyExpInd(),sizeof(reqStruct->mItemQtyExpInd));
		memcpy(reqStruct->mItemDisExpInd,getItemDisExpInd(),sizeof(reqStruct->mItemDisExpInd));
		sprintf(level3Data,level3_MasterVisa,reqStruct->mProductDesc,reqStruct->mProductCd,reqStruct->mProductQuantity,reqStruct->mProductMeasurementUnit,reqStruct->mProductCommodityCd,
				reqStruct->mCostPerUnit,reqStruct->mLineItemTotCnt,reqStruct->mAltTaxID,reqStruct->mTaxTypeApplied,reqStruct->mDiscInd,reqStruct->mNetGrossInd,reqStruct->mExtItemAmt,reqStruct->mDrCrInd,reqStruct->mItemDiscRate,reqStruct->mItemQtyExpInd,reqStruct->mItemDisExpInd);
	}
	else
		strcpy(level3Data,"");
	return TRUE;
}
