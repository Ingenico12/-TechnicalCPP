#include <sdk_tplus.h>
#include "TlvTree.h"
#include "LinkLayer.h"
#include "HostData.h"
#include "DNS_TPlus.h"
#include "Utils.h"
#include <SSL_.h>
#include <DNS_.h>
#include "ssl_profile.h"
 #define __30_SECONDS__ 3000
 #define __20_SECONDS__ 2000
int createSSLProfile();
int hostServiceCall (char *requestBuf,char *responseBuf, int tmsflag){
	    int nError;
	    char comUrl[50]={0};
	    char hostAddr[15+1]={0};
	    char port[4 +1]={0};
	    char tempBuff[44+1]={0};
	    char x_50[2+1]={0};
	    char* chkServerDown;
	    doubleword uiRemotePort;
	    SSL_HANDLE hSSL; // Connection handle.
	    SSL_PROFILE_HANDLE hProfile=NULL; // Profile handle.
	    int result=createSSLProfile(); //SSL Profile Generate
	    if(result==-1){
	    	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"SSL component missed", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
	    	return -1;
	    } else if(result == -2){
	    	GL_Dialog_Message(APEMV_UI_GoalHandle(), NULL,"SSL Profile Creation failed", NULL, GL_BUTTON_ALL, 10*GL_TIME_SECOND);
	    	return -1;
	    }
	    // Load the profile used for the connection.
	    hProfile = SSL_LoadProfile("GOVPAY");
	    if( hProfile != NULL )
	    {
	        // Init the connection handle from the loaded profile.
	        if( SSL_New( &hSSL, hProfile ) == 0 )
	        {
	        	if(tmsflag){
	        		getGatewayURL(comUrl);
	        		getGatewayPort(port);
					uiRemotePort=atoi(port);
					DNS_GetIpAddress(comUrl,hostAddr,sizeof(hostAddr));
				}else{
	        	getGatewayURL(comUrl);
	        	getGatewayPort(port);
	        	uiRemotePort=atoi(port);
	        	DNS_GetIpAddress(comUrl,hostAddr,sizeof(hostAddr));
				}

	            if( SSL_Connect( hSSL, hostAddr, uiRemotePort,
	            		__30_SECONDS__ ) == 0 )
	            {
	                // Send data
	            	logTestData(requestBuf,strlen(requestBuf));
	                result=SSL_Write( hSSL, requestBuf, strlen(requestBuf), __30_SECONDS__ );
	                if(result < 0){
	                	SSL_Disconnect( hSSL );
	                	return HOSTERROR;
	                }
	                // Receive data
	                result=SSL_Read( hSSL, responseBuf, 5000, __30_SECONDS__ );
	                logTestData(responseBuf,strlen(responseBuf));
	                if(result < 0){
	                	SSL_Disconnect( hSSL );
	                	return RESPTIMEOUT;
	                }
                // Disconnect.
	                SSL_Disconnect( hSSL );
	            }
	            else
	            {
	                // Display the connection error.
	                SSL_ProfileGetLastError( hProfile, &nError );
	        	    return HOSTERROR;
	            }
	            // Release the connection handle.
	            SSL_Disconnect(hSSL);
	            SSL_Free( hSSL );
	            SSL_UnloadProfile(hProfile);
	            ssllib_close();
	            return 0;
	        }
	    }
	    return -1;
}

int createSSLProfile()
{
	int err=0;
	int ret = ssllib_open();
	  if (ret != 0) {
	    return -1;
	  }
	  // Create NEWPROFILE
	  SSL_PROFILE_HANDLE profile_handle =NULL;
      profile_handle = SSL_NewProfile("GOVPAY", &err);
	  if (err < 0) {
	    //ssllib_close();
	    return TRUE;
	  }

	  // Set profile settings
	  SSL_ProfileSetProtocol(profile_handle, TLSv1_2);
	  SSL_ProfileSetCipher(profile_handle, SSL_RSA | SSL_DSS | SSL_DES | SSL_3DES | SSL_AES | SSL_SHA1 | SSL_SHA256
	          | SSL_SHA384
	          | SSL_kECDHE | SSL_aECDSA, SSL_HIGH | SSL_NOT_EXP);

	  //SSL_ProfileSetKeyFile( profile_handle,"/HOST/TEMS.PEM",FALSE );
	  // This is the CA server certificate we loaded in the HOST
	  SSL_ProfileAddCertificateCA(profile_handle, "/HOST/PROD.CRT");
	  SSL_ProfileSetCertificateFile(profile_handle, "/HOST/PROD.CRT");
	  SSL_HANDLE ssl_handle;
	  err = SSL_New(&ssl_handle, profile_handle);
	  if (err != 0) {
	    SSL_UnloadProfile(profile_handle);
	    SSL_DeleteProfile("GOVPAY");
	    ssllib_close();
	    return -2;
	  }
	  SSL_Free(ssl_handle);
	  //ssllib_close();
	  return true;
	}
